(function() {
  "use strict";
  function el(tag, className, text) {
    const node = document.createElement(tag);
    node.className = className;
    if (text) node.textContent = text;
    return node;
  }
  const SVG_NS = "http://www.w3.org/2000/svg";
  function icon(name) {
    const svg = document.createElementNS(SVG_NS, "svg");
    svg.setAttribute("aria-hidden", "true");
    const paths = {
      close: ["14", `<path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>`],
      refresh: ["12", `<path d="M10 6a4 4 0 1 1-1.2-2.85M10 1.5v2.5H7.5" stroke="currentColor" stroke-width="1.3" fill="none" stroke-linecap="round"/>`],
      sound: [
        "14",
        `<path d="M2 5.5v3h2.2L7.5 11V3L4.2 5.5H2z" fill="currentColor"/><path d="M9.5 4.8a2.6 2.6 0 0 1 0 4.4M11.2 3a5 5 0 0 1 0 8" stroke="currentColor" stroke-width="1.3" fill="none" stroke-linecap="round"/>`
      ],
      muted: [
        "14",
        `<path d="M2 5.5v3h2.2L7.5 11V3L4.2 5.5H2z" fill="currentColor"/><path d="M9.3 5.2l3.4 3.6M12.7 5.2l-3.4 3.6" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>`
      ],
      warn: [
        "16",
        `<path d="M8 1.8l6.6 11.6H1.4z" fill="none" stroke="#F2C069" stroke-width="1.4" stroke-linejoin="round"/><path d="M8 6.5v3.2M8 11.4v.2" stroke="#F2C069" stroke-width="1.5" stroke-linecap="round"/>`
      ]
    };
    const [size, body] = paths[name];
    svg.setAttribute("width", size);
    svg.setAttribute("height", size);
    svg.setAttribute("viewBox", `0 0 ${size} ${size}`);
    svg.innerHTML = body;
    return svg;
  }
  const SOUND_NAMES = ["found", "open", "marketLive", "betPlaced", "softError"];
  const SYNTH_STYLES = ["musicbox", "celesta", "chimes"];
  const DEFAULT_STYLE = "celesta";
  const MASTER_VOLUME = 0.25;
  const FLOOR = 1e-4;
  const PENDING_MAX_AGE_MS = 1500;
  const REVERB_SECONDS = 1.6;
  let context = null;
  let master = null;
  let reverbSend = null;
  let muted = false;
  let style$1 = DEFAULT_STYLE;
  let last = "–";
  let pending = null;
  const armedRoots = /* @__PURE__ */ new WeakSet();
  const listeners = /* @__PURE__ */ new Set();
  let onPlay = null;
  function notify() {
    const state = getAudioState();
    for (const listener of listeners) listener(state);
  }
  function getAudioState() {
    return { context: context ? context.state : "not created", muted, style: style$1, last };
  }
  function onAudioState(listener) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  }
  function setDuckHook(hook) {
    onPlay = hook;
  }
  function getContext() {
    return context;
  }
  function impulse(ctx) {
    const length = Math.floor(ctx.sampleRate * REVERB_SECONDS);
    const buffer2 = ctx.createBuffer(2, length, ctx.sampleRate);
    for (let channel = 0; channel < 2; channel++) {
      const data = buffer2.getChannelData(channel);
      let smooth = 0;
      for (let i = 0; i < length; i++) {
        const decay = Math.pow(1 - i / length, 2.6);
        smooth += (Math.random() * 2 - 1 - smooth) * 0.35;
        data[i] = smooth * decay;
      }
    }
    return buffer2;
  }
  function ensureContext() {
    if (context) return context;
    try {
      context = new AudioContext();
      master = context.createGain();
      master.gain.value = MASTER_VOLUME;
      master.connect(context.destination);
      const reverb = context.createConvolver();
      reverb.buffer = impulse(context);
      reverbSend = context.createGain();
      reverbSend.gain.value = 0.3;
      reverbSend.connect(reverb).connect(master);
    } catch {
      context = null;
    }
    notify();
    return context;
  }
  function wake() {
    const ctx = ensureContext();
    if (!ctx || ctx.state === "running") return;
    ctx.resume().then(
      () => {
        notify();
        if (pending && Date.now() - pending.at <= PENDING_MAX_AGE_MS) playSound(pending.name);
        pending = null;
      },
      () => {
      }
    );
  }
  function armSounds(root = window) {
    if (armedRoots.has(root)) return;
    armedRoots.add(root);
    for (const type of ["pointerdown", "keydown", "touchstart"]) {
      root.addEventListener(type, wake, { capture: true, passive: true });
    }
  }
  function setMuted(value) {
    muted = value;
    notify();
  }
  function isMuted() {
    return muted;
  }
  function setStyle(value) {
    style$1 = value;
    notify();
  }
  function getStyle() {
    return style$1;
  }
  const PENTATONIC = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21];
  const C6 = 1046.5;
  function pitch(degree) {
    return C6 * Math.pow(2, PENTATONIC[Math.max(0, Math.min(PENTATONIC.length - 1, degree))] / 12);
  }
  const humanSeconds = () => (Math.random() * 2 - 1) * 0.012;
  const cents = () => (Math.random() * 2 - 1) * 8;
  const TIMBRES = {
    // Plucked, delicate, short, a touch of tine brightness.
    musicbox: { ratios: [1, 2.76, 5.4, 8.93], gains: [1, 0.42, 0.18, 0.06], partialDecay: [1, 0.55, 0.3, 0.18], attack: 4e-3, decay: 0.42, reverb: 0.25, dust: false },
    // Brighter, clear bells.
    celesta: { ratios: [1, 2.76, 5.4, 8.93], gains: [1, 0.55, 0.3, 0.12], partialDecay: [1, 0.6, 0.35, 0.2], attack: 8e-3, decay: 0.7, reverb: 0.32, dust: true },
    // Airy, dreamy, lots of shimmer.
    chimes: { ratios: [1, 2.76, 5.4, 8.93], gains: [1, 0.5, 0.35, 0.16], partialDecay: [1, 0.7, 0.5, 0.35], attack: 0.012, decay: 1.4, reverb: 0.45, dust: true }
  };
  function bell(ctx, out, timbre, freq, at, gain2, length, bright) {
    const detune = cents();
    const start = Math.max(ctx.currentTime, at + humanSeconds());
    for (const [index, ratio] of timbre.ratios.entries()) {
      const partialGain = gain2 * timbre.gains[index] * (index === 0 ? 1 : bright);
      if (partialGain < 4e-3) continue;
      const decay = timbre.decay * length * timbre.partialDecay[index];
      const env = ctx.createGain();
      env.gain.setValueAtTime(FLOOR, start);
      env.gain.linearRampToValueAtTime(partialGain, start + timbre.attack);
      env.gain.exponentialRampToValueAtTime(FLOOR, start + timbre.attack + decay);
      env.connect(out);
      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.value = freq * ratio;
      osc.detune.value = detune;
      osc.connect(env);
      osc.start(start);
      osc.stop(start + timbre.attack + decay + 0.05);
    }
  }
  function dust(ctx, out, timbre, at) {
    const count = 3 + Math.floor(Math.random() * 4);
    for (let i = 0; i < count; i++) {
      const degree = 6 + Math.floor(Math.random() * 4);
      bell(ctx, out, timbre, pitch(degree), at + Math.random() * 0.25, 0.05, 0.35, 0.5);
    }
  }
  const PHRASES = {
    // Three notes rising, like a star appearing: G6 C7 E7.
    found: [{ degree: 3, at: 0 }, { degree: 5, at: 0.09 }, { degree: 7, at: 0.18, gain: 0.8 }],
    // One tiny bell: A6.
    open: [{ degree: 4, at: 0, gain: 0.7, length: 0.7 }],
    // C6 D6 E6 G6 A6 C7, then a bright E7 with sparkle.
    marketLive: [
      { degree: 0, at: 0 },
      { degree: 1, at: 0.11 },
      { degree: 2, at: 0.22 },
      { degree: 3, at: 0.33 },
      { degree: 4, at: 0.44 },
      { degree: 5, at: 0.55, gain: 0.9 },
      { degree: 7, at: 0.7, gain: 0.8, length: 1.3 }
    ],
    // Root, major third, fifth: C6 E6 G6, warm.
    betPlaced: [{ degree: 0, at: 0, bright: 0.5, length: 1.2 }, { degree: 2, at: 0.18, bright: 0.5, length: 1.2 }, { degree: 3, at: 0.36, bright: 0.55, length: 1.5 }],
    // Two soft bells stepping down, an octave below the main register.
    softError: [{ degree: 1, at: 0, gain: 0.55, bright: 0.35, length: 1.1 }, { degree: 0, at: 0.28, gain: 0.5, bright: 0.3, length: 1.4 }]
  };
  const OCTAVE = { softError: 0.5 };
  function synth(ctx, name, timbre, into, send) {
    const dry = ctx.createGain();
    dry.gain.value = 1;
    dry.connect(into);
    const wet = ctx.createGain();
    wet.gain.value = timbre.reverb;
    wet.connect(send);
    const out = ctx.createGain();
    out.connect(dry);
    out.connect(wet);
    const now = ctx.currentTime + 0.02;
    const octave = OCTAVE[name] ?? 1;
    let end = 0;
    for (const note of PHRASES[name]) {
      bell(ctx, out, timbre, pitch(note.degree) * octave, now + note.at, (note.gain ?? 0.6) * 0.5, note.length ?? 1, note.bright ?? 1);
      end = Math.max(end, note.at);
    }
    if (timbre.dust && (name === "found" || name === "marketLive")) dust(ctx, out, timbre, now + end);
  }
  const fileBuffers = /* @__PURE__ */ new Map();
  let filesAvailable = null;
  function fileUrl(name, ext) {
    return typeof chrome !== "undefined" && chrome.runtime?.getURL ? chrome.runtime.getURL(`sfx/${name}.${ext}`) : `sfx/${name}.${ext}`;
  }
  async function filesStyleAvailable() {
    if (filesAvailable !== null) return filesAvailable;
    filesAvailable = false;
    const runtime = typeof chrome !== "undefined" ? chrome.runtime : void 0;
    if (!runtime?.getPackageDirectoryEntry) return false;
    const root = await new Promise((resolve) => {
      try {
        runtime.getPackageDirectoryEntry((entry) => resolve(entry));
      } catch {
        resolve(null);
      }
    });
    if (!root) return false;
    for (const ext of ["mp3", "wav"]) {
      const found = await new Promise((resolve) => root.getFile(`sfx/open.${ext}`, {}, () => resolve(true), () => resolve(false)));
      if (found) {
        filesAvailable = true;
        break;
      }
    }
    return filesAvailable;
  }
  async function playFile(ctx, name) {
    if (!master) return false;
    if (!fileBuffers.has(name)) {
      fileBuffers.set(name, null);
      for (const ext of ["mp3", "wav"]) {
        try {
          const response = await fetch(fileUrl(name, ext));
          if (!response.ok) continue;
          fileBuffers.set(name, await ctx.decodeAudioData(await response.arrayBuffer()));
          break;
        } catch {
        }
      }
    }
    const buffer2 = fileBuffers.get(name);
    if (!buffer2) return false;
    const source2 = ctx.createBufferSource();
    source2.buffer = buffer2;
    source2.connect(master);
    source2.start();
    return true;
  }
  function playSound(name, override) {
    const chosen = override ?? style$1;
    try {
      if (muted) {
        last = `${name} skipped: muted`;
        notify();
        return;
      }
      const ctx = ensureContext();
      if (!ctx || !master || !reverbSend) {
        last = `${name} skipped: no audio`;
        notify();
        return;
      }
      if (ctx.state !== "running") {
        pending = { name, at: Date.now() };
        last = `${name} queued: ${ctx.state}`;
        notify();
        return;
      }
      onPlay?.();
      if (chosen === "files") {
        const into = master;
        const send = reverbSend;
        void playFile(ctx, name).then((played) => {
          if (!played) synth(ctx, name, TIMBRES[DEFAULT_STYLE], into, send);
        });
      } else {
        synth(ctx, name, TIMBRES[chosen], master, reverbSend);
      }
      last = `${name} (${chosen})`;
      notify();
    } catch {
      last = `${name} failed`;
      notify();
    }
  }
  const VOLUME = 0.14;
  const FADE_IN_S = 2;
  const FADE_OUT_S = 1.2;
  const DUCK_S = 0.6;
  const DUCK_LEVEL = 0.7;
  let gain = null;
  let source = null;
  let buffer = null;
  let playing = false;
  let stopping = false;
  function ramp(target, seconds) {
    const ctx = getContext();
    if (!ctx || !gain) return;
    const now = ctx.currentTime;
    gain.gain.cancelScheduledValues(now);
    gain.gain.setValueAtTime(Math.max(1e-4, gain.gain.value), now);
    gain.gain.linearRampToValueAtTime(Math.max(1e-4, target), now + seconds);
  }
  function isMusicPlaying() {
    return playing && !stopping;
  }
  async function startMusic(url) {
    const ctx = getContext();
    if (!ctx || ctx.state !== "running" || playing) return playing;
    try {
      if (!buffer) buffer = await ctx.decodeAudioData(await (await fetch(url)).arrayBuffer());
      if (!gain) {
        gain = ctx.createGain();
        gain.gain.value = 1e-4;
        gain.connect(ctx.destination);
      }
      source = ctx.createBufferSource();
      source.buffer = buffer;
      source.loop = true;
      source.connect(gain);
      source.start();
      playing = true;
      stopping = false;
      ramp(isMuted() ? 1e-4 : VOLUME, FADE_IN_S);
      return true;
    } catch {
      return false;
    }
  }
  function stopMusic(fadeSeconds = FADE_OUT_S) {
    if (!playing || stopping) return;
    stopping = true;
    ramp(1e-4, fadeSeconds);
    const ending = source;
    setTimeout(() => {
      try {
        ending?.stop();
      } catch {
      }
      if (source === ending) {
        source = null;
        playing = false;
        stopping = false;
      }
    }, fadeSeconds * 1e3 + 50);
  }
  function duck() {
    if (!playing || stopping || isMuted()) return;
    const ctx = getContext();
    if (!ctx || !gain) return;
    const now = ctx.currentTime;
    gain.gain.cancelScheduledValues(now);
    gain.gain.setValueAtTime(gain.gain.value, now);
    gain.gain.linearRampToValueAtTime(VOLUME * DUCK_LEVEL, now + 0.05);
    gain.gain.linearRampToValueAtTime(VOLUME, now + DUCK_S);
  }
  function installMusicHooks() {
    setDuckHook(duck);
    onAudioState((state) => {
      if (playing && !stopping) ramp(state.muted ? 1e-4 : VOLUME, 0.3);
    });
  }
  const FONT_SERIF = "Soothia Lora";
  const FONT_SANS = "Soothia Inter";
  const FONT_MONO = "Soothia JetBrains Mono";
  const WELCOME_STYLES = `
@font-face { font-family: "${FONT_SERIF}"; src: url("fonts/soothia-lora.woff2") format("woff2"); font-weight: 100 900; }
@font-face { font-family: "${FONT_SANS}"; src: url("fonts/soothia-inter.woff2") format("woff2"); font-weight: 100 900; }
@font-face { font-family: "${FONT_MONO}"; src: url("fonts/soothia-jetbrains-mono.woff2") format("woff2"); font-weight: 100 900; }
:root {
  --sth-orb-fill: radial-gradient(circle at 38% 34%, #FFFFFF 0%, #F4F1FF 24%, #D6D1F6 52%, #AFA9EC 76%, #7F77DD 100%);
  --sth-orb-fill-bright: radial-gradient(circle at 38% 34%, #FFFFFF 0%, #F8F6FF 30%, #DFDAF9 56%, #B8B2F0 78%, #8A82E4 100%);
  --sth-raised: #0B0B0F; --sth-raised-hover: #121218;
  --sth-hairline: rgba(175,169,236,.22); --sth-hairline-soft: rgba(175,169,236,.14);
  --sth-text: #F5F0E6; --sth-text-2: #A9A5BD; --sth-text-3: #8C88A0; --sth-link: #CFCAF6; --sth-on-orb: #16131F;
  --sth-yes: #5DCAA5; --sth-no: #F0997B; --sth-orb-mid: #AFA9EC;
  --serif: "${FONT_SERIF}", Georgia, serif; --sans: "${FONT_SANS}", system-ui, sans-serif; --mono: "${FONT_MONO}", ui-monospace, Menlo, monospace;
  --ease: cubic-bezier(.2,.7,.2,1);
}
* { box-sizing: border-box; }
body { margin: 0; min-height: 100vh; background: #000; color: var(--sth-text); font: 400 17px/1.6 var(--sans); display: flex; align-items: center; justify-content: center; overflow-x: hidden; }
a { color: var(--sth-link); }
:focus-visible { outline: 2px solid #F4F1FF; outline-offset: 2px; }
@keyframes breathe { 0%,100% { box-shadow: 0 0 40px 6px rgba(127,119,221,.45), 0 0 120px 20px rgba(83,74,183,.3); } 50% { box-shadow: 0 0 60px 12px rgba(127,119,221,.6), 0 0 160px 32px rgba(83,74,183,.4); } }
@keyframes shimmer { 0% { transform: translate(-14%,-10%) rotate(0); } 50% { transform: translate(10%,8%) rotate(180deg); } 100% { transform: translate(-14%,-10%) rotate(360deg); } }
@keyframes twinkle { 0% { transform: scale(0) rotate(-45deg); opacity: 0; } 60% { transform: scale(1.25) rotate(8deg); opacity: 1; } 100% { transform: scale(1) rotate(0); opacity: 1; } }
@keyframes skyTwinkle { 0%,100% { transform: scale(1); } 50% { transform: scale(1.35) rotate(6deg); } }
@keyframes rise { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: none; } }
.sky { position: fixed; inset: 0; z-index: 0; pointer-events: none; }
.sky-star { position: absolute; animation: skyTwinkle 8s ease-in-out infinite; }
.star { display: block; width: 100%; height: 100%; overflow: visible; }
.welcome { position: relative; z-index: 1; width: min(560px, 100% - 32px); padding: 40px 0 56px; text-align: center; }
.orb-wrap { display: flex; justify-content: center; margin-bottom: 36px; }
.orb { position: relative; width: 112px; height: 112px; }
.orb-body { position: absolute; inset: 0; border-radius: 50%; overflow: hidden; background: var(--sth-orb-fill); animation: breathe 4.8s ease-in-out infinite; }
.orb-shimmer { position: absolute; inset: -20%; background: radial-gradient(circle at 30% 30%, rgba(255,255,255,.75) 0%, rgba(255,255,255,0) 32%), radial-gradient(circle at 72% 70%, rgba(127,119,221,.35) 0%, rgba(127,119,221,0) 36%); animation: shimmer 9s ease-in-out infinite; }
.orb-glint { position: absolute; right: -13px; top: -17px; width: 44px; height: 44px; }
.orb-stars .star { position: absolute; opacity: 0; }
.welcome.found .orb-stars .star { animation: twinkle .6s var(--ease) both; }
.welcome.found .orb-body { background: var(--sth-orb-fill-bright); }
.orb-stars .star:nth-child(1) { left: -44px; top: -18px; width: 32px; height: 32px; }
.orb-stars .star:nth-child(2) { left: -68px; top: 34px; width: 22px; height: 22px; animation-delay: .12s; }
.orb-stars .star:nth-child(3) { left: 8px; top: -60px; width: 26px; height: 26px; animation-delay: .24s; }
.step { min-height: 220px; }
.step.in { animation: rise .5s var(--ease) both; }
h1 { margin: 0 0 14px; font: 400 clamp(32px, 6vw, 44px)/1.15 var(--serif); letter-spacing: -.01em; }
h2 { margin: 0 0 12px; font: 400 22px/1.2 var(--serif); }
.step p { margin: 0 auto; max-width: 460px; color: var(--sth-text-2); text-wrap: pretty; }
.button { display: inline-flex; align-items: center; justify-content: center; height: 44px; margin-top: 22px; padding: 0 20px; border: 1px solid rgba(175,169,236,.3); border-radius: 999px; background: var(--sth-raised); color: var(--sth-text); font: 600 14px/1 var(--sans); text-decoration: none; cursor: pointer; }
.button:hover { background: var(--sth-raised-hover); }
.button.primary { border: 0; background: linear-gradient(180deg, #F4F1FF, #C9C3F2); color: var(--sth-on-orb); box-shadow: 0 0 0 1px rgba(255,255,255,.4) inset, 0 6px 20px -6px rgba(127,119,221,.7); }
.button.primary:hover { background: linear-gradient(180deg, #FFFFFF, #D6D1F6); }
.pin { margin-top: 16px !important; font-size: 14px; }
.pin a { color: var(--sth-link); }
.pin-how { display: block; margin-top: 6px; color: var(--sth-text-3); font-size: 13px; }
.visuals { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin: 18px 0 20px; }
.visual { display: flex; flex-direction: column; align-items: center; gap: 10px; padding: 18px 10px 14px; border: 1px solid var(--sth-hairline-soft); border-radius: 14px; background: var(--sth-raised); color: var(--sth-text-2); font: 500 12px/1 var(--sans); }
.mini-orb { position: relative; width: 36px; height: 36px; margin: 10px 0 8px; }
.mini-body { position: absolute; inset: 0; border-radius: 50%; background: var(--sth-orb-fill-bright); box-shadow: 0 0 14px 3px rgba(175,169,236,.6); }
.mini-orb .star { position: absolute; }
.mini-orb .s1 { left: -16px; top: -8px; width: 12px; height: 12px; }
.mini-orb .s2 { left: -24px; top: 12px; width: 9px; height: 9px; }
.mini-orb .s3 { left: 4px; top: -20px; width: 10px; height: 10px; }
.mini-tile { display: flex; flex-direction: column; align-items: flex-start; gap: 6px; width: 100%; padding: 8px; border: 1px solid var(--sth-hairline-soft); border-radius: 10px; background: #000; text-align: left; }
.mini-chip { padding: 3px 6px; border-radius: 999px; background: var(--sth-raised-hover); color: var(--sth-link); font: 500 8px/1 var(--sans); letter-spacing: .06em; text-transform: uppercase; }
.mini-q { color: var(--sth-text); font: 400 10px/1.3 var(--serif); }
.mini-btn { align-self: flex-end; padding: 4px 7px; border-radius: 999px; background: linear-gradient(180deg, #F4F1FF, #C9C3F2); color: var(--sth-on-orb); font: 600 8px/1 var(--sans); }
.mini-pill { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; width: 100%; margin: 12px 0 8px; font: 500 11px/1 var(--mono); }
.mini-pill span { padding: 10px 4px; border-radius: 10px; border: 1px solid var(--sth-hairline-soft); }
.mini-pill .yes { color: var(--sth-yes); border-color: var(--sth-yes); background: rgba(93,202,165,.12); }
.mini-pill .no { color: var(--sth-text-2); }
.stepper { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-top: 28px; }
.nav-btn { height: 40px; padding: 0 18px; border: 1px solid rgba(175,169,236,.3); border-radius: 999px; background: var(--sth-raised); color: var(--sth-text); font: 600 13px/1 var(--sans); cursor: pointer; }
.nav-btn:hover { background: var(--sth-raised-hover); }
.nav-btn:disabled { opacity: .35; cursor: default; }
.nav-btn.primary { border: 0; background: linear-gradient(180deg, #F4F1FF, #C9C3F2); color: var(--sth-on-orb); }
.dots { display: flex; gap: 8px; }
.dot { width: 8px; height: 8px; padding: 0; border: 0; border-radius: 50%; background: rgba(175,169,236,.25); cursor: pointer; }
.dot.selected { background: var(--sth-orb-mid); box-shadow: 0 0 8px rgba(175,169,236,.7); }
.sound-toggle { position: fixed; top: 16px; right: 16px; z-index: 2; width: 40px; height: 40px; border: 1px solid var(--sth-hairline-soft); border-radius: 12px; background: var(--sth-raised); color: var(--sth-text-2); display: flex; align-items: center; justify-content: center; cursor: pointer; }
.sound-toggle:hover { background: var(--sth-raised-hover); color: var(--sth-text); }
.sound-toggle svg { display: block; }
.sfx-test { margin-top: 48px; padding-top: 24px; border-top: 1px solid var(--sth-hairline-soft); }
.audio-state { margin: 0 0 16px; color: var(--sth-text-3); font-size: 12px; }
.mono { font-family: var(--mono); }
.sfx-grid { display: grid; align-items: center; gap: 8px 10px; text-align: center; }
.sfx-col { color: var(--sth-text-2); font-size: 12px; }
.sfx-row-name { color: var(--sth-text-3); font-size: 12px; text-align: right; }
.sfx-grid .button.small { height: 34px; margin: 0; padding: 0; font-size: 12px; }
.sfx-use { display: inline-flex; align-items: center; justify-content: center; gap: 6px; color: var(--sth-text-2); font-size: 12px; }
.sfx-use input { accent-color: #7F77DD; }
.sfx-row { display: flex; flex-wrap: wrap; align-items: center; justify-content: center; gap: 16px; margin-top: 16px; }
.sfx-row .button { margin-top: 0; }
.mute-row { display: inline-flex; align-items: center; gap: 8px; color: var(--sth-text-2); font-size: 14px; }
.mute-row input { accent-color: #7F77DD; }
@media (max-width: 520px) { .visuals { grid-template-columns: 1fr; } }
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation: none !important; transition: none !important; }
  .orb-stars .star, .sky-star { opacity: 1; transform: none; }
}
`;
  const MUTED_KEY = "soothia:muted";
  const STYLE_KEY = "soothia:sfxStyle";
  const MUSIC_URL = "music/onboarding.mp3";
  const STEPS = 4;
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const style = document.createElement("style");
  style.textContent = WELCOME_STYLES;
  document.head.append(style);
  const sections = [...document.querySelectorAll(".step")];
  const back = document.getElementById("back");
  const next = document.getElementById("next");
  const dots = document.getElementById("dots");
  let step = 1;
  let interacted = false;
  for (let index = 1; index <= STEPS; index++) {
    const dot = el("button", "dot");
    dot.type = "button";
    dot.setAttribute("role", "tab");
    dot.setAttribute("aria-label", `Step ${index}`);
    dot.addEventListener("click", () => go(index));
    dots.append(dot);
  }
  function go(target) {
    const clamped = Math.min(STEPS, Math.max(1, target));
    if (clamped === step && interacted) return;
    const advanced = clamped > step;
    step = clamped;
    for (const section of sections) {
      const own = Number(section.dataset.step) === step;
      section.hidden = !own;
      if (own && !reduced) {
        section.classList.remove("in");
        void section.offsetWidth;
        section.classList.add("in");
      } else if (own) section.classList.add("in");
    }
    for (const [index, dot] of [...dots.children].entries()) {
      dot.classList.toggle("selected", index + 1 === step);
      dot.setAttribute("aria-selected", String(index + 1 === step));
    }
    back.disabled = step === 1;
    next.textContent = step === STEPS ? "Done" : "Next";
    if (interacted && advanced) playSound("open");
    interacted = true;
    document.getElementById("welcome")?.classList.toggle("found", step === 1 || step === 4);
  }
  function leave() {
    stopMusic();
  }
  back.addEventListener("click", () => go(step - 1));
  next.addEventListener("click", () => {
    if (step === STEPS) {
      leave();
      setTimeout(() => window.close(), 1300);
    } else go(step + 1);
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "ArrowRight") go(step + 1);
    if (event.key === "ArrowLeft") go(step - 1);
  });
  document.getElementById("show-me")?.addEventListener("click", leave);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) stopMusic();
  });
  document.getElementById("pin-link")?.addEventListener("click", (event) => {
    event.preventDefault();
    const how = document.getElementById("pin-how");
    if (how) how.hidden = !how.hidden;
  });
  const sky = document.getElementById("sky");
  if (sky) {
    for (let i = 0; i < 18; i++) {
      const star = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      star.setAttribute("class", "sky-star");
      star.innerHTML = '<use href="#star"/>';
      const left = i % 2 ? 84 + Math.random() * 14 : 2 + Math.random() * 14;
      const size = 6 + Math.random() * 8;
      star.style.cssText = `left:${left.toFixed(1)}%;top:${(3 + Math.random() * 94).toFixed(1)}%;width:${size.toFixed(0)}px;height:${size.toFixed(0)}px;opacity:${(0.1 + Math.random() * 0.15).toFixed(2)};animation-delay:${(Math.random() * 8).toFixed(1)}s;animation-duration:${(5 + Math.random() * 6).toFixed(1)}s`;
      sky.append(star);
    }
  }
  armSounds(window);
  installMusicHooks();
  const soundToggle = document.getElementById("sound-toggle");
  function renderToggle() {
    if (!soundToggle) return;
    const label = isMuted() ? "Unmute sound" : "Mute sound";
    soundToggle.setAttribute("aria-label", label);
    soundToggle.title = label;
    soundToggle.replaceChildren(icon(isMuted() ? "muted" : "sound"));
    const box = document.getElementById("mute");
    if (box) box.checked = isMuted();
  }
  function saveMuted(value) {
    setMuted(value);
    renderToggle();
    chrome.storage.local.set({ [MUTED_KEY]: value }).catch(() => {
    });
  }
  soundToggle?.addEventListener("click", () => saveMuted(!isMuted()));
  chrome.storage.local.get([MUTED_KEY, STYLE_KEY]).then((stored) => {
    setMuted(stored[MUTED_KEY] === true);
    const saved = stored[STYLE_KEY];
    if (typeof saved === "string" && [...SYNTH_STYLES, "files"].includes(saved)) setStyle(saved);
    renderToggle();
  }).catch(renderToggle);
  let musicWanted = true;
  function startMusicSoon() {
    if (!musicWanted || isMusicPlaying()) return;
    setTimeout(() => void startMusic(MUSIC_URL), 150);
  }
  for (const type of ["pointerdown", "keydown", "touchstart"]) {
    window.addEventListener(type, startMusicSoon, { capture: true, passive: true });
  }
  const devHooks = { getAudioState, isMusicPlaying, playSound, startMusic: () => startMusic(MUSIC_URL), stopMusic };
  window.soothiaAudio = devHooks;
  if (new URLSearchParams(location.search).get("sfx") === "1") {
    const test = document.getElementById("sfx-test");
    const grid = document.getElementById("sfx-grid");
    const state = document.getElementById("audio-state");
    const musicButton = document.getElementById("music-toggle");
    const box = document.getElementById("mute");
    if (test && grid && state) {
      test.hidden = false;
      const render = () => {
        const audio = getAudioState();
        state.textContent = `audio: ${audio.muted ? "muted" : audio.context} · style ${audio.style} · last ${audio.last}${isMusicPlaying() ? " · music playing" : ""}`;
        if (musicButton) musicButton.textContent = isMusicPlaying() ? "Stop music" : "Play music";
      };
      onAudioState(render);
      setInterval(render, 500);
      render();
      const buildGrid = (styles) => {
        grid.replaceChildren();
        grid.style.gridTemplateColumns = `auto repeat(${styles.length}, 1fr)`;
        grid.append(el("span", ""));
        for (const kind of styles) grid.append(el("span", "sfx-col mono", kind));
        for (const name of SOUND_NAMES) {
          grid.append(el("span", "sfx-row-name mono", name));
          for (const kind of styles) {
            const button = el("button", "button small", "▶");
            button.type = "button";
            button.setAttribute("aria-label", `${name} in ${kind}`);
            button.addEventListener("click", () => playSound(name, kind));
            grid.append(button);
          }
        }
        grid.append(el("span", "sfx-row-name mono", "use"));
        for (const kind of styles) {
          const label = el("label", "sfx-use");
          const radio = el("input", "");
          radio.type = "radio";
          radio.name = "sfx-style";
          radio.value = kind;
          radio.checked = getStyle() === kind;
          radio.addEventListener("change", () => {
            setStyle(kind);
            chrome.storage.local.set({ [STYLE_KEY]: kind }).catch(() => {
            });
          });
          label.append(radio, "Use this style");
          grid.append(label);
        }
      };
      buildGrid(SYNTH_STYLES);
      void filesStyleAvailable().then((available) => {
        if (available) buildGrid([...SYNTH_STYLES, "files"]);
      });
      musicButton?.addEventListener("click", () => {
        if (isMusicPlaying()) {
          musicWanted = false;
          stopMusic();
        } else {
          musicWanted = true;
          void startMusic(MUSIC_URL);
        }
        setTimeout(render, 100);
      });
      box?.addEventListener("change", () => saveMuted(box.checked));
    }
  }
  go(1);
})();
