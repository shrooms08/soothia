(function() {
  "use strict";
  const SUI_NS_NAME_REGEX = /^(?!.*(^(?!@)|[-.@])($|[-.@]))(?:[a-z0-9-]{0,63}(?:\.[a-z0-9-]{0,63})*)?@[a-z0-9-]{0,63}$/i;
  const SUI_NS_DOMAIN_REGEX = /^(?!.*(^|[-.])($|[-.]))(?:[a-z0-9-]{0,63}\.)+sui$/i;
  const MAX_SUI_NS_NAME_LENGTH = 235;
  function isValidSuiNSName(name) {
    if (name.length > MAX_SUI_NS_NAME_LENGTH) return false;
    if (name.includes("@")) return SUI_NS_NAME_REGEX.test(name);
    return SUI_NS_DOMAIN_REGEX.test(name);
  }
  const NAME_PATTERN = /^([a-z0-9]+(?:-[a-z0-9]+)*)$/;
  const VERSION_REGEX = /^\d+$/;
  const MAX_APP_SIZE = 64;
  const NAME_SEPARATOR$1 = "/";
  const isValidNamedPackage = (name) => {
    const parts = name.split(NAME_SEPARATOR$1);
    if (parts.length < 2 || parts.length > 3) return false;
    const [org, app, version] = parts;
    if (version !== void 0 && !VERSION_REGEX.test(version)) return false;
    if (!isValidSuiNSName(org)) return false;
    return NAME_PATTERN.test(app) && app.length < MAX_APP_SIZE;
  };
  var BcsReader = class {
    /**
    * @param {Uint8Array} data Data to use as a buffer.
    */
    constructor(data) {
      this.bytePosition = 0;
      this.dataView = new DataView(data.buffer, data.byteOffset, data.byteLength);
      this.bytes = new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    }
    /**
    * Shift current cursor position by `bytes`.
    *
    * @param {Number} bytes Number of bytes to
    * @returns {this} Self for possible chaining.
    */
    shift(bytes) {
      this.bytePosition += bytes;
      return this;
    }
    /**
    * Read U8 value from the buffer and shift cursor by 1.
    * @returns
    */
    read8() {
      const position = this.bytePosition;
      if (position >= this.bytes.length) throw new RangeError("Offset is outside the bounds of the DataView");
      this.bytePosition = position + 1;
      return this.bytes[position];
    }
    /**
    * Read U16 value from the buffer and shift cursor by 2.
    * @returns
    */
    read16() {
      const value = this.dataView.getUint16(this.bytePosition, true);
      this.shift(2);
      return value;
    }
    /**
    * Read U32 value from the buffer and shift cursor by 4.
    * @returns
    */
    read32() {
      const value = this.dataView.getUint32(this.bytePosition, true);
      this.shift(4);
      return value;
    }
    /**
    * Read U64 value from the buffer and shift cursor by 8.
    * @returns
    */
    read64() {
      const value = this.dataView.getBigUint64(this.bytePosition, true);
      this.shift(8);
      return value.toString(10);
    }
    /**
    * Read U128 value from the buffer and shift cursor by 16.
    */
    read128() {
      const value1 = BigInt(this.read64());
      const result = BigInt(this.read64()).toString(16) + value1.toString(16).padStart(16, "0");
      return BigInt("0x" + result).toString(10);
    }
    /**
    * Read U128 value from the buffer and shift cursor by 32.
    * @returns
    */
    read256() {
      const value1 = BigInt(this.read128());
      const result = BigInt(this.read128()).toString(16) + value1.toString(16).padStart(32, "0");
      return BigInt("0x" + result).toString(10);
    }
    /**
    * Read `num` number of bytes from the buffer and shift cursor by `num`.
    * @param num Number of bytes to read.
    */
    readBytes(num) {
      if (this.bytePosition + num > this.bytes.length) throw new RangeError("Offset is outside the bounds of the DataView");
      const start = this.bytePosition + this.dataView.byteOffset;
      const value = new Uint8Array(this.dataView.buffer, start, num);
      this.shift(num);
      return value;
    }
    /**
    * Read ULEB value - an integer of varying size. Used for enum indexes and
    * vector lengths.
    * @returns {Number} The ULEB value.
    */
    readULEB() {
      const bytes = this.bytes;
      let position = this.bytePosition;
      let value = 0;
      let multiplier = 1;
      while (true) {
        if (position >= bytes.length) throw new Error("ULEB decode error: buffer overflow");
        const byte = bytes[position++];
        value += (byte & 127) * multiplier;
        if ((byte & 128) === 0) {
          if (byte === 0 && position - this.bytePosition > 1) throw new Error("ULEB decode error: non-canonical encoding");
          break;
        }
        multiplier *= 128;
      }
      if (!(value <= Number.MAX_SAFE_INTEGER)) throw new Error("ULEB decode error: value exceeds MAX_SAFE_INTEGER");
      this.bytePosition = position;
      return value;
    }
    /**
    * Read a BCS vector: read a length and then apply function `cb` X times
    * where X is the length of the vector, defined as ULEB in BCS bytes.
    * @param cb Callback to process elements of vector.
    * @returns {Array<Any>} Array of the resulting values, returned by callback.
    */
    readVec(cb) {
      const length = this.readULEB();
      const result = [];
      for (let i = 0; i < length; i++) result.push(cb(this, i, length));
      return result;
    }
  };
  const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  const ALPHABET_CODES = Array.from(ALPHABET, (char) => char.charCodeAt(0));
  const DIGIT_VALUES = new Int8Array(128).fill(-1);
  for (let i = 0; i < 58; i++) DIGIT_VALUES[ALPHABET.charCodeAt(i)] = i;
  const B58_5 = 58 ** 5;
  function isBytes$1(value) {
    return value instanceof Uint8Array || ArrayBuffer.isView(value) && value.constructor.name === "Uint8Array" && value.BYTES_PER_ELEMENT === 1;
  }
  function toBase58(buffer) {
    if (!isBytes$1(buffer)) throw new TypeError("toBase58 expects a Uint8Array");
    const length = buffer.length;
    let zeros = 0;
    while (zeros < length && buffer[zeros] === 0) zeros++;
    const limbs = [];
    let i = zeros;
    if ((length - zeros) % 2 === 1) limbs.push(buffer[i++]);
    for (; i < length; i += 2) {
      let carry = buffer[i] * 256 + buffer[i + 1];
      for (let j = 0; j < limbs.length; j++) {
        const x = limbs[j] * 65536 + carry;
        carry = Math.floor(x / B58_5);
        limbs[j] = x - carry * B58_5;
      }
      while (carry > 0) {
        const next = Math.floor(carry / B58_5);
        limbs.push(carry - next * B58_5);
        carry = next;
      }
    }
    const digits = [];
    for (let k = 0; k < zeros; k++) digits.push(ALPHABET_CODES[0]);
    for (let j = limbs.length - 1; j >= 0; j--) {
      let limb = limbs[j];
      const start = digits.length;
      const width = j === limbs.length - 1 ? 0 : 5;
      for (let k = 0; k < 5 && (limb > 0 || k < width); k++) {
        const next = Math.floor(limb / 58);
        digits.push(ALPHABET_CODES[limb - next * 58]);
        limb = next;
      }
      for (let a = start, b = digits.length - 1; a < b; a++, b--) {
        const tmp = digits[a];
        digits[a] = digits[b];
        digits[b] = tmp;
      }
    }
    let result = "";
    for (let start = 0; start < digits.length; start += 8192) result += String.fromCharCode.apply(null, digits.slice(start, start + 8192));
    return result;
  }
  function fromBase58(str) {
    if (typeof str !== "string") throw new TypeError("fromBase58 expects a string");
    const length = str.length;
    let zeros = 0;
    while (zeros < length && str.charCodeAt(zeros) === 49) zeros++;
    const limbs = [];
    let i = zeros;
    const head = (length - zeros) % 5;
    while (i < length) {
      const chunkLength = i === zeros && head !== 0 ? head : 5;
      let carry = 0;
      let multiplier = 1;
      for (let k = 0; k < chunkLength; k++) {
        const code = str.charCodeAt(i + k);
        const digit = code < 128 ? DIGIT_VALUES[code] : -1;
        if (digit < 0) throw new Error(`Invalid base58 character "${str[i + k]}"`);
        carry = carry * 58 + digit;
        multiplier *= 58;
      }
      i += chunkLength;
      for (let j = 0; j < limbs.length; j++) {
        const x = limbs[j] * multiplier + carry;
        carry = Math.floor(x / 65536);
        limbs[j] = x - carry * 65536;
      }
      while (carry > 0) {
        limbs.push(carry % 65536);
        carry = Math.floor(carry / 65536);
      }
    }
    let byteLength = limbs.length * 2;
    if (byteLength > 0 && limbs[limbs.length - 1] < 256) byteLength--;
    const out = new Uint8Array(zeros + byteLength);
    let pos = out.length - 1;
    for (let j = 0; j < limbs.length; j++) {
      out[pos--] = limbs[j] & 255;
      if (pos >= zeros) out[pos--] = limbs[j] >> 8;
    }
    return out;
  }
  function fromBase64(base64String2) {
    const binary = atob(base64String2);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }
  const CHUNK_SIZE = 8192;
  function toBase64(bytes) {
    if (bytes.length <= CHUNK_SIZE) return btoa(String.fromCharCode.apply(null, bytes));
    let output = "";
    for (let i = 0; i < bytes.length; i += CHUNK_SIZE) {
      const chunk2 = bytes.slice(i, i + CHUNK_SIZE);
      output += String.fromCharCode.apply(null, chunk2);
    }
    return btoa(output);
  }
  function fromHex(hexStr) {
    const normalized = hexStr.startsWith("0x") ? hexStr.slice(2) : hexStr;
    const padded = normalized.length % 2 === 0 ? normalized : `0${normalized}`;
    const bytes = new Uint8Array(padded.length / 2);
    for (let i = 0; i < bytes.length; i++) {
      const high = hexDigit(padded.charCodeAt(i * 2));
      const low = hexDigit(padded.charCodeAt(i * 2 + 1));
      if (high < 0 || low < 0) throw new Error(`Invalid hex string ${hexStr}`);
      bytes[i] = high * 16 + low;
    }
    return bytes;
  }
  function hexDigit(code) {
    if (code >= 48 && code <= 57) return code - 48;
    if (code >= 97 && code <= 102) return code - 87;
    if (code >= 65 && code <= 70) return code - 55;
    return -1;
  }
  const HEX_BYTES = Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
  function toHex(bytes) {
    let hex = "";
    for (let i = 0; i < bytes.length; i++) hex += HEX_BYTES[bytes[i]];
    return hex;
  }
  function chunk(array2, size) {
    return Array.from({ length: Math.ceil(array2.length / size) }, (_, i) => {
      return array2.slice(i * size, (i + 1) * size);
    });
  }
  function encodeStr(data, encoding) {
    switch (encoding) {
      case "base58":
        return toBase58(data);
      case "base64":
        return toBase64(data);
      case "hex":
        return toHex(data);
      default:
        throw new Error("Unsupported encoding, supported values are: base64, hex");
    }
  }
  function splitGenericParameters(str, genericSeparators = ["<", ">"]) {
    const [left, right] = genericSeparators;
    const tok = [];
    let word = "";
    let nestedAngleBrackets = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str[i];
      if (char === left) nestedAngleBrackets++;
      if (char === right) nestedAngleBrackets--;
      if (nestedAngleBrackets === 0 && char === ",") {
        tok.push(word.trim());
        word = "";
        continue;
      }
      word += char;
    }
    tok.push(word.trim());
    return tok;
  }
  function ulebEncode(num) {
    let bigNum = BigInt(num);
    const arr = [];
    let len = 0;
    if (bigNum < 0n) throw new TypeError(`Invalid ULEB128 value: ${num}. Expected a non-negative integer`);
    if (bigNum === 0n) return [0];
    while (bigNum > 0) {
      arr[len] = Number(bigNum & 127n);
      bigNum >>= 7n;
      if (bigNum > 0n) arr[len] |= 128;
      len += 1;
    }
    return arr;
  }
  var BcsWriter = class {
    constructor({ initialSize = 1024, maxSize = Infinity, allocateSize = 1024 } = {}) {
      this.bytePosition = 0;
      this.size = initialSize;
      this.maxSize = maxSize;
      this.allocateSize = allocateSize;
      this.dataView = new DataView(new ArrayBuffer(initialSize));
      this.bytes = new Uint8Array(this.dataView.buffer);
    }
    ensureSizeOrGrow(bytes) {
      const requiredSize = this.bytePosition + bytes;
      if (requiredSize > this.size) {
        const nextSize = Math.min(this.maxSize, Math.max(this.size + requiredSize, this.size + this.allocateSize));
        if (requiredSize > nextSize) throw new Error(`Attempting to serialize to BCS, but buffer does not have enough size. Allocated size: ${this.size}, Max size: ${this.maxSize}, Required size: ${requiredSize}`);
        this.size = nextSize;
        const nextBuffer = new ArrayBuffer(this.size);
        const nextBytes = new Uint8Array(nextBuffer);
        nextBytes.set(this.bytes);
        this.dataView = new DataView(nextBuffer);
        this.bytes = nextBytes;
      }
    }
    /**
    * Shift current cursor position by `bytes`.
    *
    * @param {Number} bytes Number of bytes to
    * @returns {this} Self for possible chaining.
    */
    shift(bytes) {
      this.bytePosition += bytes;
      return this;
    }
    /**
    * Write a U8 value into a buffer and shift cursor position by 1.
    * @param {Number} value Value to write.
    * @returns {this}
    */
    write8(value) {
      this.ensureSizeOrGrow(1);
      this.bytes[this.bytePosition] = Number(value);
      return this.shift(1);
    }
    /**
    * Write a U8 value into a buffer and shift cursor position by 1.
    * @param {Number} value Value to write.
    * @returns {this}
    */
    writeBytes(bytes) {
      this.ensureSizeOrGrow(bytes.length);
      this.bytes.set(bytes, this.bytePosition);
      return this.shift(bytes.length);
    }
    /**
    * Write a U16 value into a buffer and shift cursor position by 2.
    * @param {Number} value Value to write.
    * @returns {this}
    */
    write16(value) {
      this.ensureSizeOrGrow(2);
      this.dataView.setUint16(this.bytePosition, Number(value), true);
      return this.shift(2);
    }
    /**
    * Write a U32 value into a buffer and shift cursor position by 4.
    * @param {Number} value Value to write.
    * @returns {this}
    */
    write32(value) {
      this.ensureSizeOrGrow(4);
      this.dataView.setUint32(this.bytePosition, Number(value), true);
      return this.shift(4);
    }
    /**
    * Write a U64 value into a buffer and shift cursor position by 8.
    * @param {bigint} value Value to write.
    * @returns {this}
    */
    write64(value) {
      return this.writeBigLittleEndian(BigInt(value), 8);
    }
    /**
    * Write a U128 value into a buffer and shift cursor position by 16.
    *
    * @param {bigint} value Value to write.
    * @returns {this}
    */
    write128(value) {
      return this.writeBigLittleEndian(BigInt(value), 16);
    }
    /**
    * Write a U256 value into a buffer and shift cursor position by 16.
    *
    * @param {bigint} value Value to write.
    * @returns {this}
    */
    write256(value) {
      return this.writeBigLittleEndian(BigInt(value), 32);
    }
    writeBigLittleEndian(value, size) {
      this.ensureSizeOrGrow(size);
      let remaining = value > 0n ? value : 0n;
      for (let offset = 0; offset < size; offset += 8) {
        this.dataView.setBigUint64(this.bytePosition + offset, BigInt.asUintN(64, remaining), true);
        remaining >>= 64n;
      }
      return this.shift(size);
    }
    /**
    * Write a ULEB value into a buffer and shift cursor position by number of bytes
    * written.
    * @param {Number} value Value to write.
    * @returns {this}
    */
    writeULEB(value) {
      if (value >= 0 && Number.isSafeInteger(value)) {
        let remaining = value;
        while (remaining >= 128) {
          this.write8(remaining % 128 | 128);
          remaining = Math.floor(remaining / 128);
        }
        return this.write8(remaining);
      }
      ulebEncode(value).forEach((el) => this.write8(el));
      return this;
    }
    /**
    * Write a vector into a buffer by first writing the vector length and then calling
    * a callback on each passed value.
    *
    * @param {Array<Any>} vector Array of elements to write.
    * @param {WriteVecCb} cb Callback to call on each element of the vector.
    * @returns {this}
    */
    writeVec(vector2, cb) {
      this.writeULEB(vector2.length);
      Array.from(vector2).forEach((el, i) => cb(this, el, i, vector2.length));
      return this;
    }
    /**
    * Adds support for iterations over the object.
    * @returns {Uint8Array}
    */
    *[Symbol.iterator]() {
      for (let i = 0; i < this.bytePosition; i++) yield this.dataView.getUint8(i);
      return this.toBytes();
    }
    /**
    * Get underlying buffer taking only value bytes (in case initial buffer size was bigger).
    * @returns {Uint8Array} Resulting bcs.
    */
    toBytes() {
      return new Uint8Array(this.dataView.buffer.slice(0, this.bytePosition));
    }
    /**
    * Represent data as 'hex' or 'base64'
    * @param encoding Encoding to use: 'base64' or 'hex'
    */
    toString(encoding) {
      return encodeStr(this.toBytes(), encoding);
    }
  };
  var BcsType = class BcsType2 {
    #write;
    #serialize;
    #validatedWrite = null;
    #validatedSerialize = null;
    #transformValidate = null;
    constructor(options) {
      this.name = options.name;
      this.read = options.read;
      this.serializedSize = options.serializedSize ?? (() => null);
      this.#write = options.write;
      this.#serialize = options.serialize ?? ((value, options$1) => {
        const writer = new BcsWriter({
          initialSize: this.serializedSize(value) ?? void 0,
          ...options$1
        });
        this.#write(value, writer);
        return writer.toBytes();
      });
      this.validate = options.validate ?? (() => {
      });
    }
    write(value, writer) {
      if (this.#validatedWrite && this.validate === this.#transformValidate) {
        this.#validatedWrite(value, writer);
        return;
      }
      this.validate(value);
      this.#write(value, writer);
    }
    serialize(value, options) {
      if (this.#validatedSerialize && this.validate === this.#transformValidate) return new SerializedBcs(this, this.#validatedSerialize(value, options));
      this.validate(value);
      return new SerializedBcs(this, this.#serialize(value, options));
    }
    parse(bytes) {
      const reader = new BcsReader(bytes);
      return this.read(reader);
    }
    fromHex(hex) {
      return this.parse(fromHex(hex));
    }
    fromBase58(b64) {
      return this.parse(fromBase58(b64));
    }
    fromBase64(b64) {
      return this.parse(fromBase64(b64));
    }
    transform({ name, input, output, validate: validate2 }) {
      const type = new BcsType2({
        name: name ?? this.name,
        read: (reader) => output ? output(this.read(reader)) : this.read(reader),
        write: (value, writer) => this.#write(input ? input(value) : value, writer),
        serializedSize: (value) => this.serializedSize(input ? input(value) : value),
        serialize: (value, options) => this.#serialize(input ? input(value) : value, options),
        validate: (value) => {
          validate2?.(value);
          this.validate(input ? input(value) : value);
        }
      });
      type.#transformValidate = type.validate;
      type.#validatedWrite = (value, writer) => {
        validate2?.(value);
        const converted = input ? input(value) : value;
        this.validate(converted);
        this.#write(converted, writer);
      };
      type.#validatedSerialize = (value, options) => {
        validate2?.(value);
        const converted = input ? input(value) : value;
        this.validate(converted);
        return this.#serialize(converted, options);
      };
      return type;
    }
  };
  const SERIALIZED_BCS_BRAND = /* @__PURE__ */ Symbol.for("@mysten/serialized-bcs");
  function isSerializedBcs(obj) {
    return !!obj && typeof obj === "object" && obj[SERIALIZED_BCS_BRAND] === true;
  }
  var SerializedBcs = class {
    #schema;
    #bytes;
    get [SERIALIZED_BCS_BRAND]() {
      return true;
    }
    constructor(schema, bytes) {
      this.#schema = schema;
      this.#bytes = bytes;
    }
    toBytes() {
      return this.#bytes;
    }
    toHex() {
      return toHex(this.#bytes);
    }
    toBase64() {
      return toBase64(this.#bytes);
    }
    toBase58() {
      return toBase58(this.#bytes);
    }
    parse() {
      return this.#schema.parse(this.#bytes);
    }
  };
  function fixedSizeBcsType({ size, ...options }) {
    return new BcsType({
      ...options,
      serializedSize: () => size
    });
  }
  function uIntBcsType({ readMethod, writeMethod, ...options }) {
    return fixedSizeBcsType({
      ...options,
      read: (reader) => reader[readMethod](),
      write: (value, writer) => writer[writeMethod](value),
      validate: (value) => {
        if (typeof value === "number" && !Number.isInteger(value) || value < 0 || value > options.maxValue) throw new TypeError(`Invalid ${options.name} value: ${value}. Expected value in range 0-${options.maxValue}`);
        options.validate?.(value);
      }
    });
  }
  function bigUIntBcsType({ readMethod, writeMethod, ...options }) {
    return fixedSizeBcsType({
      ...options,
      read: (reader) => reader[readMethod](),
      write: (value, writer) => writer[writeMethod](BigInt(value)),
      validate: (val) => {
        const value = BigInt(val);
        if (value < 0 || value > options.maxValue) throw new TypeError(`Invalid ${options.name} value: ${value}. Expected value in range 0-${options.maxValue}`);
        options.validate?.(value);
      }
    });
  }
  function dynamicSizeBcsType({ serialize, ...options }) {
    const type = new BcsType({
      ...options,
      serialize,
      write: (value, writer) => {
        for (const byte of type.serialize(value).toBytes()) writer.write8(byte);
      }
    });
    return type;
  }
  function stringLikeBcsType({ toBytes, fromBytes, ...options }) {
    return new BcsType({
      ...options,
      read: (reader) => {
        const length = reader.readULEB();
        return fromBytes(reader.readBytes(length));
      },
      write: (hex, writer) => {
        const bytes = toBytes(hex);
        writer.writeULEB(bytes.length);
        writer.writeBytes(bytes);
      },
      serialize: (value) => {
        const bytes = toBytes(value);
        const size = ulebEncode(bytes.length);
        const result = new Uint8Array(size.length + bytes.length);
        result.set(size, 0);
        result.set(bytes, size.length);
        return result;
      },
      validate: (value) => {
        if (typeof value !== "string") throw new TypeError(`Invalid ${options.name} value: ${value}. Expected string`);
        options.validate?.(value);
      }
    });
  }
  function lazyBcsType(cb) {
    let lazyType = null;
    function getType() {
      if (!lazyType) lazyType = cb();
      return lazyType;
    }
    return new BcsType({
      name: "lazy",
      read: (data) => getType().read(data),
      serializedSize: (value) => getType().serializedSize(value),
      write: (value, writer) => getType().write(value, writer),
      serialize: (value, options) => getType().serialize(value, options).toBytes()
    });
  }
  var BcsStruct = class extends BcsType {
    constructor({ name, fields, ...options }) {
      const fieldNames = Object.keys(fields);
      const fieldTypes = fieldNames.map((field) => fields[field]);
      const fieldCount = fieldNames.length;
      super({
        name,
        serializedSize: (values) => {
          let total = 0;
          for (let i = 0; i < fieldCount; i++) {
            const size = fieldTypes[i].serializedSize(values[fieldNames[i]]);
            if (size == null) return null;
            total += size;
          }
          return total;
        },
        read: (reader) => {
          const result = {};
          for (let i = 0; i < fieldCount; i++) result[fieldNames[i]] = fieldTypes[i].read(reader);
          return result;
        },
        write: (value, writer) => {
          for (let i = 0; i < fieldCount; i++) fieldTypes[i].write(value[fieldNames[i]], writer);
        },
        ...options,
        validate: (value) => {
          options?.validate?.(value);
          if (typeof value !== "object" || value == null) throw new TypeError(`Expected object, found ${typeof value}`);
        }
      });
    }
  };
  var BcsEnum = class extends BcsType {
    constructor({ fields, ...options }) {
      const canonicalOrder = Object.entries(fields);
      const variantIndex = new Map(canonicalOrder.map(([name], i) => [name, i]));
      super({
        read: (reader) => {
          const index = reader.readULEB();
          const enumEntry = canonicalOrder[index];
          if (!enumEntry) throw new TypeError(`Unknown value ${index} for enum ${options.name}`);
          const [kind, type] = enumEntry;
          const value = type?.read(reader) ?? true;
          if (kind === "__proto__") return {
            [kind]: value,
            $kind: kind
          };
          const result = {};
          result[kind] = value;
          result.$kind = kind;
          return result;
        },
        write: (value, writer) => {
          for (const name of Object.keys(value)) {
            const index = variantIndex.get(name);
            if (index !== void 0) {
              writer.writeULEB(index);
              canonicalOrder[index][1]?.write(value[name], writer);
              return;
            }
          }
        },
        ...options,
        validate: (value) => {
          options?.validate?.(value);
          if (typeof value !== "object" || value == null) throw new TypeError(`Expected object, found ${typeof value}`);
          let variantCount = 0;
          for (const key of Object.keys(value)) if (value[key] !== void 0 && variantIndex.has(key)) variantCount++;
          if (variantCount !== 1) throw new TypeError(`Expected object with one key, but found ${variantCount} for type ${options.name}}`);
        }
      });
    }
  };
  var BcsTuple = class extends BcsType {
    constructor({ fields, name, ...options }) {
      super({
        name: name ?? `(${fields.map((t) => t.name).join(", ")})`,
        serializedSize: (values) => {
          let total = 0;
          for (let i = 0; i < fields.length; i++) {
            const size = fields[i].serializedSize(values[i]);
            if (size == null) return null;
            total += size;
          }
          return total;
        },
        read: (reader) => {
          const result = [];
          for (const field of fields) result.push(field.read(reader));
          return result;
        },
        write: (value, writer) => {
          for (let i = 0; i < fields.length; i++) fields[i].write(value[i], writer);
        },
        ...options,
        validate: (value) => {
          options?.validate?.(value);
          if (!Array.isArray(value)) throw new TypeError(`Expected array, found ${typeof value}`);
          if (value.length !== fields.length) throw new TypeError(`Expected array of length ${fields.length}, found ${value.length}`);
        }
      });
    }
  };
  function fixedArray(size, type, options) {
    return new BcsType({
      read: (reader) => {
        const result = new Array(size);
        for (let i = 0; i < size; i++) result[i] = type.read(reader);
        return result;
      },
      write: (value, writer) => {
        for (const item of value) type.write(item, writer);
      },
      ...options,
      name: options?.name ?? `${type.name}[${size}]`,
      validate: (value) => {
        options?.validate?.(value);
        if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
        if (value.length !== size) throw new TypeError(`Expected array of length ${size}, found ${value.length}`);
      }
    });
  }
  function option(type) {
    const name = `Option<${type.name}>`;
    return new BcsType({
      name,
      read: (reader) => {
        const index = reader.readULEB();
        if (index === 0) return null;
        if (index === 1) return type.read(reader);
        throw new TypeError(`Unknown value ${index} for enum ${name}`);
      },
      write: (value, writer) => {
        if (value == null) {
          writer.write8(0);
          return;
        }
        writer.write8(1);
        type.write(value, writer);
      }
    });
  }
  function vector(type, options) {
    return new BcsType({
      read: (reader) => {
        const length = reader.readULEB();
        const result = new Array(length);
        for (let i = 0; i < length; i++) result[i] = type.read(reader);
        return result;
      },
      write: (value, writer) => {
        writer.writeULEB(value.length);
        for (const item of value) type.write(item, writer);
      },
      ...options,
      name: options?.name ?? `vector<${type.name}>`,
      validate: (value) => {
        options?.validate?.(value);
        if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
      }
    });
  }
  function compareBcsBytes(a, b) {
    for (let i = 0; i < Math.min(a.length, b.length); i++) if (a[i] !== b[i]) return a[i] - b[i];
    return a.length - b.length;
  }
  function map(keyType, valueType) {
    return new BcsType({
      name: `Map<${keyType.name}, ${valueType.name}>`,
      read: (reader) => {
        const length = reader.readULEB();
        const result = /* @__PURE__ */ new Map();
        for (let i = 0; i < length; i++) result.set(keyType.read(reader), valueType.read(reader));
        return result;
      },
      write: (value, writer) => {
        const entries = [...value.entries()].map(([key, val]) => [keyType.serialize(key).toBytes(), val]);
        entries.sort(([a], [b]) => compareBcsBytes(a, b));
        writer.writeULEB(entries.length);
        for (const [keyBytes, val] of entries) {
          writer.writeBytes(keyBytes);
          valueType.write(val, writer);
        }
      }
    });
  }
  let utf8Encoder;
  let utf8Decoder;
  function decoder() {
    return utf8Decoder ??= new TextDecoder("utf-8", {
      fatal: true,
      ignoreBOM: true
    });
  }
  const ASCII_FAST_PATH_MAX_LENGTH = 64;
  function decodeUtf8(bytes) {
    if (bytes.length <= ASCII_FAST_PATH_MAX_LENGTH) {
      let result = "";
      for (let i = 0; i < bytes.length; i++) {
        const byte = bytes[i];
        if (byte >= 128) return decoder().decode(bytes);
        result += String.fromCharCode(byte);
      }
      return result;
    }
    return decoder().decode(bytes);
  }
  const bcs = {
    u8(options) {
      return uIntBcsType({
        readMethod: "read8",
        writeMethod: "write8",
        size: 1,
        maxValue: 2 ** 8 - 1,
        ...options,
        name: options?.name ?? "u8"
      });
    },
    u16(options) {
      return uIntBcsType({
        readMethod: "read16",
        writeMethod: "write16",
        size: 2,
        maxValue: 2 ** 16 - 1,
        ...options,
        name: options?.name ?? "u16"
      });
    },
    u32(options) {
      return uIntBcsType({
        readMethod: "read32",
        writeMethod: "write32",
        size: 4,
        maxValue: 2 ** 32 - 1,
        ...options,
        name: options?.name ?? "u32"
      });
    },
    u64(options) {
      return bigUIntBcsType({
        readMethod: "read64",
        writeMethod: "write64",
        size: 8,
        maxValue: 2n ** 64n - 1n,
        ...options,
        name: options?.name ?? "u64"
      });
    },
    u128(options) {
      return bigUIntBcsType({
        readMethod: "read128",
        writeMethod: "write128",
        size: 16,
        maxValue: 2n ** 128n - 1n,
        ...options,
        name: options?.name ?? "u128"
      });
    },
    u256(options) {
      return bigUIntBcsType({
        readMethod: "read256",
        writeMethod: "write256",
        size: 32,
        maxValue: 2n ** 256n - 1n,
        ...options,
        name: options?.name ?? "u256"
      });
    },
    bool(options) {
      return fixedSizeBcsType({
        size: 1,
        read: (reader) => {
          const value = reader.read8();
          if (value > 1) throw new TypeError(`Invalid bool value: expected 0 or 1, found ${value}`);
          return value === 1;
        },
        write: (value, writer) => writer.write8(value ? 1 : 0),
        ...options,
        name: options?.name ?? "bool",
        validate: (value) => {
          options?.validate?.(value);
          if (typeof value !== "boolean") throw new TypeError(`Expected boolean, found ${typeof value}`);
        }
      });
    },
    uleb128(options) {
      return dynamicSizeBcsType({
        read: (reader) => reader.readULEB(),
        serialize: (value) => {
          return Uint8Array.from(ulebEncode(value));
        },
        ...options,
        name: options?.name ?? "uleb128"
      });
    },
    bytes(size, options) {
      return fixedSizeBcsType({
        size,
        read: (reader) => reader.readBytes(size),
        write: (value, writer) => {
          writer.writeBytes(value instanceof Uint8Array ? value : new Uint8Array(value));
        },
        ...options,
        name: options?.name ?? `bytes[${size}]`,
        validate: (value) => {
          options?.validate?.(value);
          if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
          if (value.length !== size) throw new TypeError(`Expected array of length ${size}, found ${value.length}`);
        }
      });
    },
    byteVector(options) {
      return new BcsType({
        read: (reader) => {
          const length = reader.readULEB();
          return reader.readBytes(length);
        },
        write: (value, writer) => {
          const array2 = value instanceof Uint8Array ? value : new Uint8Array(value);
          writer.writeULEB(array2.length);
          writer.writeBytes(array2);
        },
        ...options,
        name: options?.name ?? "vector<u8>",
        serializedSize: (value) => {
          const length = "length" in value ? value.length : null;
          return length == null ? null : ulebEncode(length).length + length;
        },
        validate: (value) => {
          options?.validate?.(value);
          if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
        }
      });
    },
    string(options) {
      return stringLikeBcsType({
        toBytes: (value) => (utf8Encoder ??= new TextEncoder()).encode(value),
        fromBytes: decodeUtf8,
        ...options,
        name: options?.name ?? "string"
      });
    },
    fixedArray,
    option,
    vector,
    tuple(fields, options) {
      return new BcsTuple({
        fields,
        ...options
      });
    },
    struct(name, fields, options) {
      return new BcsStruct({
        name,
        fields,
        ...options
      });
    },
    enum(name, fields, options) {
      return new BcsEnum({
        name,
        fields,
        ...options
      });
    },
    map,
    lazy(cb) {
      return lazyBcsType(cb);
    }
  };
  const SUI_ADDRESS_LENGTH = 32;
  function isValidSuiAddress(value) {
    return isHex(value) && getHexByteLength(value) === SUI_ADDRESS_LENGTH;
  }
  const MOVE_IDENTIFIER_REGEX = /^[a-zA-Z][a-zA-Z0-9_]*$/;
  function isValidMoveIdentifier(name) {
    return MOVE_IDENTIFIER_REGEX.test(name);
  }
  const PRIMITIVE_TYPE_TAGS = [
    "bool",
    "u8",
    "u16",
    "u32",
    "u64",
    "u128",
    "u256",
    "address",
    "signer"
  ];
  const VECTOR_TYPE_REGEX = /^vector<(.+)>$/;
  function isValidTypeTag(type) {
    if (PRIMITIVE_TYPE_TAGS.includes(type)) return true;
    const vectorMatch = type.match(VECTOR_TYPE_REGEX);
    if (vectorMatch) return isValidTypeTag(vectorMatch[1]);
    if (type.includes("::")) return isValidStructTag(type);
    return false;
  }
  function isValidParsedStructTag(tag) {
    if (!isValidSuiAddress(tag.address) && !isValidNamedPackage(tag.address)) return false;
    if (!isValidMoveIdentifier(tag.module) || !isValidMoveIdentifier(tag.name)) return false;
    return tag.typeParams.every((param) => {
      if (typeof param === "string") return isValidTypeTag(param);
      return isValidParsedStructTag(param);
    });
  }
  function isValidStructTag(type) {
    try {
      return isValidParsedStructTag(parseStructTag(type));
    } catch {
      return false;
    }
  }
  function parseTypeTag(type) {
    if (type.startsWith("vector<")) {
      if (!type.endsWith(">")) throw new Error(`Invalid type tag: ${type}`);
      const inner = type.slice(7, -1);
      if (!inner) throw new Error(`Invalid type tag: ${type}`);
      const parsed = parseTypeTag(inner);
      if (typeof parsed === "string") return `vector<${parsed}>`;
      return `vector<${normalizeStructTag(parsed)}>`;
    }
    if (!type.includes("::")) return type;
    return parseStructTag(type);
  }
  function parseStructTag(type) {
    const parts = type.split("::");
    if (parts.length < 3) throw new Error(`Invalid struct tag: ${type}`);
    const [address, module] = parts;
    if (!address || !module) throw new Error(`Invalid struct tag: ${type}`);
    const isMvrPackage = isValidNamedPackage(address);
    const rest = type.slice(address.length + module.length + 4);
    const name = rest.includes("<") ? rest.slice(0, rest.indexOf("<")) : rest;
    if (!name || rest.includes("<") && !rest.endsWith(">")) throw new Error(`Invalid struct tag: ${type}`);
    const typeParams = rest.includes("<") ? splitGenericParameters(rest.slice(rest.indexOf("<") + 1, rest.lastIndexOf(">"))).map((typeParam) => parseTypeTag(typeParam.trim())) : [];
    return {
      address: isMvrPackage ? address : normalizeSuiAddress(address),
      module,
      name,
      typeParams
    };
  }
  function normalizeStructTag(type) {
    if (typeof type === "string" && type.startsWith("vector<")) throw new Error("normalizeStructTag does not support vector types. Use normalizeTypeTag instead.");
    const { address, module, name, typeParams } = typeof type === "string" ? parseStructTag(type) : type;
    return `${address}::${module}::${name}${typeParams?.length > 0 ? `<${typeParams.map((typeParam) => typeof typeParam === "string" ? typeParam : normalizeStructTag(typeParam)).join(",")}>` : ""}`;
  }
  function normalizeSuiAddress(value, forceAdd0x = false) {
    let address = value.toLowerCase();
    if (!forceAdd0x && address.startsWith("0x")) address = address.slice(2);
    return `0x${address.padStart(SUI_ADDRESS_LENGTH * 2, "0")}`;
  }
  function normalizeSuiObjectId(value, forceAdd0x = false) {
    return normalizeSuiAddress(value, forceAdd0x);
  }
  function isHex(value) {
    return /^(0x|0X)?[a-fA-F0-9]+$/.test(value) && value.length % 2 === 0;
  }
  function getHexByteLength(value) {
    return /^(0x|0X)/.test(value) ? (value.length - 2) / 2 : value.length / 2;
  }
  const VECTOR_REGEX = /^vector<(.+)>$/;
  const STRUCT_REGEX = /^([^:]+)::([^:]+)::([^<]+)(<(.+)>)?/;
  var TypeTagSerializer = class TypeTagSerializer2 {
    static parseFromStr(str, normalizeAddress = false) {
      if (str === "address") return { address: null };
      else if (str === "bool") return { bool: null };
      else if (str === "u8") return { u8: null };
      else if (str === "u16") return { u16: null };
      else if (str === "u32") return { u32: null };
      else if (str === "u64") return { u64: null };
      else if (str === "u128") return { u128: null };
      else if (str === "u256") return { u256: null };
      else if (str === "signer") return { signer: null };
      const vectorMatch = str.match(VECTOR_REGEX);
      if (vectorMatch) return { vector: TypeTagSerializer2.parseFromStr(vectorMatch[1], normalizeAddress) };
      const structMatch = str.match(STRUCT_REGEX);
      if (structMatch) return { struct: {
        address: normalizeAddress ? normalizeSuiAddress(structMatch[1]) : structMatch[1],
        module: structMatch[2],
        name: structMatch[3],
        typeParams: structMatch[5] === void 0 ? [] : TypeTagSerializer2.parseStructTypeArgs(structMatch[5], normalizeAddress)
      } };
      throw new Error(`Encountered unexpected token when parsing type args for ${str}`);
    }
    static parseStructTypeArgs(str, normalizeAddress = false) {
      return splitGenericParameters(str).map((tok) => TypeTagSerializer2.parseFromStr(tok, normalizeAddress));
    }
    static tagToString(tag) {
      if ("bool" in tag) return "bool";
      if ("u8" in tag) return "u8";
      if ("u16" in tag) return "u16";
      if ("u32" in tag) return "u32";
      if ("u64" in tag) return "u64";
      if ("u128" in tag) return "u128";
      if ("u256" in tag) return "u256";
      if ("address" in tag) return "address";
      if ("signer" in tag) return "signer";
      if ("vector" in tag) return `vector<${TypeTagSerializer2.tagToString(tag.vector)}>`;
      if ("struct" in tag) {
        const struct = tag.struct;
        const typeParams = struct.typeParams.map(TypeTagSerializer2.tagToString).join(", ");
        return `${struct.address}::${struct.module}::${struct.name}${typeParams ? `<${typeParams}>` : ""}`;
      }
      throw new Error("Invalid TypeTag");
    }
  };
  function unsafe_u64(options) {
    return bcs.u64({
      name: "unsafe_u64",
      ...options
    }).transform({
      input: (val) => val,
      output: (val) => Number(val)
    });
  }
  function optionEnum(type) {
    return bcs.enum("Option", {
      None: null,
      Some: type
    });
  }
  const HEX_NIBBLES = new Int8Array(128).fill(-1);
  for (let i = 0; i < 16; i++) {
    HEX_NIBBLES["0123456789abcdef".charCodeAt(i)] = i;
    HEX_NIBBLES["0123456789ABCDEF".charCodeAt(i)] = i;
  }
  function hexNibble(code) {
    return code < 128 ? HEX_NIBBLES[code] : -1;
  }
  function decodeAddress(value) {
    if (!value) return null;
    const start = value.length >= 2 && value[0] === "0" && (value[1] === "x" || value[1] === "X") ? 2 : 0;
    if (value.length - start > SUI_ADDRESS_LENGTH * 2) return null;
    const bytes = new Uint8Array(SUI_ADDRESS_LENGTH);
    let byteIndex = SUI_ADDRESS_LENGTH - 1;
    let i = value.length - 1;
    for (; i >= start + 1; i -= 2) {
      const low = hexNibble(value.charCodeAt(i));
      const high = hexNibble(value.charCodeAt(i - 1));
      if (low < 0 || high < 0) return null;
      bytes[byteIndex--] = high << 4 | low;
    }
    if (i === start) {
      const low = hexNibble(value.charCodeAt(i));
      if (low < 0) return null;
      bytes[byteIndex] = low;
    }
    return bytes;
  }
  const Address = bcs.bytes(SUI_ADDRESS_LENGTH).transform({
    input: (val) => {
      if (typeof val === "string") {
        const bytes = decodeAddress(val);
        if (!bytes) throw new Error(`Invalid Sui address ${val}`);
        return bytes;
      }
      const address = toHex(val);
      if (!address || !isValidSuiAddress(normalizeSuiAddress(address))) throw new Error(`Invalid Sui address ${address}`);
      return val;
    },
    output: (val) => `0x${toHex(val)}`
  });
  const ObjectDigest = bcs.byteVector().transform({
    name: "ObjectDigest",
    input: (value) => {
      const bytes = fromBase58(value);
      if (bytes.length !== 32) throw new Error("ObjectDigest must be 32 bytes");
      return bytes;
    },
    output: (value) => toBase58(value)
  });
  const SuiObjectRef = bcs.struct("SuiObjectRef", {
    objectId: Address,
    version: bcs.u64(),
    digest: ObjectDigest
  });
  const SharedObjectRef = bcs.struct("SharedObjectRef", {
    objectId: Address,
    initialSharedVersion: bcs.u64(),
    mutable: bcs.bool()
  });
  const ObjectArg$1 = bcs.enum("ObjectArg", {
    ImmOrOwnedObject: SuiObjectRef,
    SharedObject: SharedObjectRef,
    Receiving: SuiObjectRef
  });
  const Owner = bcs.enum("Owner", {
    AddressOwner: Address,
    ObjectOwner: Address,
    Shared: bcs.struct("Shared", { initialSharedVersion: bcs.u64() }),
    Immutable: null,
    ConsensusAddressOwner: bcs.struct("ConsensusAddressOwner", {
      startVersion: bcs.u64(),
      owner: Address
    })
  });
  const Reservation = bcs.enum("Reservation", { MaxAmountU64: bcs.u64() });
  const WithdrawalType = bcs.enum("WithdrawalType", { Balance: bcs.lazy(() => TypeTag) });
  const WithdrawFrom = bcs.enum("WithdrawFrom", {
    Sender: null,
    Sponsor: null,
    SenderAllowance: bcs.struct("SenderAllowance", {
      funder: Address,
      allowance: Address
    })
  });
  const FundsWithdrawal = bcs.struct("FundsWithdrawal", {
    reservation: Reservation,
    typeArg: WithdrawalType,
    withdrawFrom: WithdrawFrom
  });
  const CallArg$1 = bcs.enum("CallArg", {
    Pure: bcs.struct("Pure", { bytes: bcs.byteVector().transform({
      input: (val) => typeof val === "string" ? fromBase64(val) : val,
      output: (val) => toBase64(val)
    }) }),
    Object: ObjectArg$1,
    FundsWithdrawal
  });
  const InnerTypeTag = bcs.enum("TypeTag", {
    bool: null,
    u8: null,
    u64: null,
    u128: null,
    address: null,
    signer: null,
    vector: bcs.lazy(() => InnerTypeTag),
    struct: bcs.lazy(() => StructTag),
    u16: null,
    u32: null,
    u256: null
  });
  const TypeTag = InnerTypeTag.transform({
    input: (typeTag) => typeof typeTag === "string" ? TypeTagSerializer.parseFromStr(typeTag, true) : typeTag,
    output: (typeTag) => TypeTagSerializer.tagToString(typeTag)
  });
  const Argument$1 = bcs.enum("Argument", {
    GasCoin: null,
    Input: bcs.u16(),
    Result: bcs.u16(),
    NestedResult: bcs.tuple([bcs.u16(), bcs.u16()])
  });
  const ProgrammableMoveCall$1 = bcs.struct("ProgrammableMoveCall", {
    package: Address,
    module: bcs.string(),
    function: bcs.string(),
    typeArguments: bcs.vector(TypeTag),
    arguments: bcs.vector(Argument$1)
  });
  const Command$1 = bcs.enum("Command", {
    MoveCall: ProgrammableMoveCall$1,
    TransferObjects: bcs.struct("TransferObjects", {
      objects: bcs.vector(Argument$1),
      address: Argument$1
    }),
    SplitCoins: bcs.struct("SplitCoins", {
      coin: Argument$1,
      amounts: bcs.vector(Argument$1)
    }),
    MergeCoins: bcs.struct("MergeCoins", {
      destination: Argument$1,
      sources: bcs.vector(Argument$1)
    }),
    Publish: bcs.struct("Publish", {
      modules: bcs.vector(bcs.byteVector().transform({
        input: (val) => typeof val === "string" ? fromBase64(val) : val,
        output: (val) => toBase64(val)
      })),
      dependencies: bcs.vector(Address)
    }),
    MakeMoveVec: bcs.struct("MakeMoveVec", {
      type: optionEnum(TypeTag).transform({
        input: (val) => val === null ? { None: true } : { Some: val },
        output: (val) => val.Some ?? null
      }),
      elements: bcs.vector(Argument$1)
    }),
    Upgrade: bcs.struct("Upgrade", {
      modules: bcs.vector(bcs.byteVector().transform({
        input: (val) => typeof val === "string" ? fromBase64(val) : val,
        output: (val) => toBase64(val)
      })),
      dependencies: bcs.vector(Address),
      package: Address,
      ticket: Argument$1
    })
  });
  const ProgrammableTransaction = bcs.struct("ProgrammableTransaction", {
    inputs: bcs.vector(CallArg$1),
    commands: bcs.vector(Command$1)
  });
  const ValidDuring = bcs.struct("ValidDuring", {
    minEpoch: bcs.option(bcs.u64()),
    maxEpoch: bcs.option(bcs.u64()),
    minTimestamp: bcs.option(bcs.u64()),
    maxTimestamp: bcs.option(bcs.u64()),
    chain: ObjectDigest,
    nonce: bcs.u32()
  });
  function assertAllowedProposersNotEmpty(proposers) {
    if (proposers.length === 0) throw new Error("Allowed proposers must not be empty");
    return proposers;
  }
  function assertAllowedProposersStrictlyIncreasing(proposers) {
    assertAllowedProposersNotEmpty(proposers);
    for (let i = 1; i < proposers.length; i++) if (proposers[i] <= proposers[i - 1]) throw new Error("Allowed proposers must be strictly increasing");
    return proposers;
  }
  const AllowedProposerIndices = bcs.vector(bcs.u32()).transform({
    input: assertAllowedProposersStrictlyIncreasing,
    output: assertAllowedProposersNotEmpty
  });
  const AllowedProposers = bcs.struct("AllowedProposers", {
    epoch: bcs.u64(),
    proposers: AllowedProposerIndices
  });
  const Validity = bcs.struct("Validity", {
    minEpoch: bcs.option(bcs.u64()),
    maxEpoch: bcs.option(bcs.u64()),
    minTimestamp: bcs.option(bcs.u64()),
    maxTimestamp: bcs.option(bcs.u64()),
    chain: ObjectDigest,
    nonce: bcs.u32(),
    allowedProposers: bcs.option(AllowedProposers)
  });
  const TransactionExpiration$2 = bcs.enum("TransactionExpiration", {
    None: null,
    Epoch: unsafe_u64(),
    ValidDuring,
    Validity
  });
  const StructTag = bcs.struct("StructTag", {
    address: Address,
    module: bcs.string(),
    name: bcs.string(),
    typeParams: bcs.vector(InnerTypeTag)
  });
  const GasData$1 = bcs.struct("GasData", {
    payment: bcs.vector(SuiObjectRef),
    owner: Address,
    price: bcs.u64(),
    budget: bcs.u64()
  });
  const IntentScope = bcs.enum("IntentScope", {
    TransactionData: null,
    TransactionEffects: null,
    CheckpointSummary: null,
    PersonalMessage: null
  });
  const IntentVersion = bcs.enum("IntentVersion", { V0: null });
  const AppId = bcs.enum("AppId", { Sui: null });
  const Intent = bcs.struct("Intent", {
    scope: IntentScope,
    version: IntentVersion,
    appId: AppId
  });
  function IntentMessage(T) {
    return bcs.struct(`IntentMessage<${T.name}>`, {
      intent: Intent,
      value: T
    });
  }
  const CompressedSignature = bcs.enum("CompressedSignature", {
    ED25519: bcs.bytes(64),
    Secp256k1: bcs.bytes(64),
    Secp256r1: bcs.bytes(64),
    ZkLogin: bcs.byteVector(),
    Passkey: bcs.byteVector(),
    MLDSA65: bcs.bytes(3309)
  });
  const PublicKey = bcs.enum("PublicKey", {
    ED25519: bcs.bytes(32),
    Secp256k1: bcs.bytes(33),
    Secp256r1: bcs.bytes(33),
    ZkLogin: bcs.byteVector(),
    Passkey: bcs.bytes(33),
    MLDSA65: bcs.bytes(1952)
  });
  const MultiSigPkMap = bcs.struct("MultiSigPkMap", {
    pubKey: PublicKey,
    weight: bcs.u8()
  });
  const MultiSigPublicKey = bcs.struct("MultiSigPublicKey", {
    pk_map: bcs.vector(MultiSigPkMap),
    threshold: bcs.u16()
  });
  const MultiSig = bcs.struct("MultiSig", {
    sigs: bcs.vector(CompressedSignature),
    bitmap: bcs.u16(),
    multisig_pk: MultiSigPublicKey
  });
  const base64String = bcs.byteVector().transform({
    input: (val) => typeof val === "string" ? fromBase64(val) : val,
    output: (val) => toBase64(val)
  });
  const PasskeyAuthenticator = bcs.struct("PasskeyAuthenticator", {
    authenticatorData: bcs.byteVector(),
    clientDataJson: bcs.string(),
    userSignature: bcs.byteVector()
  });
  const MoveObjectType = bcs.enum("MoveObjectType", {
    Other: StructTag,
    GasCoin: null,
    StakedSui: null,
    Coin: TypeTag,
    AccumulatorBalanceWrapper: null
  });
  const TypeOrigin = bcs.struct("TypeOrigin", {
    moduleName: bcs.string(),
    datatypeName: bcs.string(),
    package: Address
  });
  const UpgradeInfo = bcs.struct("UpgradeInfo", {
    upgradedId: Address,
    upgradedVersion: bcs.u64()
  });
  const MovePackage = bcs.struct("MovePackage", {
    id: Address,
    version: bcs.u64(),
    moduleMap: bcs.map(bcs.string(), bcs.byteVector()),
    typeOriginTable: bcs.vector(TypeOrigin),
    linkageTable: bcs.map(Address, UpgradeInfo)
  });
  const MoveObject = bcs.struct("MoveObject", {
    type: MoveObjectType,
    hasPublicTransfer: bcs.bool(),
    version: bcs.u64(),
    contents: bcs.byteVector()
  });
  const Data = bcs.enum("Data", {
    Move: MoveObject,
    Package: MovePackage
  });
  const ObjectInner = bcs.struct("ObjectInner", {
    data: Data,
    owner: Owner,
    previousTransaction: ObjectDigest,
    storageRebate: bcs.u64()
  });
  const ChangeEpoch = bcs.struct("ChangeEpoch", {
    epoch: bcs.u64(),
    protocolVersion: bcs.u64(),
    storageCharge: bcs.u64(),
    computationCharge: bcs.u64(),
    storageRebate: bcs.u64(),
    nonRefundableStorageFee: bcs.u64(),
    epochStartTimestampMs: bcs.u64(),
    systemPackages: bcs.vector(bcs.tuple([
      bcs.u64(),
      bcs.vector(bcs.byteVector()),
      bcs.vector(Address)
    ]))
  });
  const GenesisObject = bcs.enum("GenesisObject", { RawObject: bcs.struct("RawObject", {
    data: Data,
    owner: Owner
  }) });
  const GenesisTransaction = bcs.struct("GenesisTransaction", { objects: bcs.vector(GenesisObject) });
  const ConsensusCommitPrologue = bcs.struct("ConsensusCommitPrologue", {
    epoch: bcs.u64(),
    round: bcs.u64(),
    commitTimestampMs: bcs.u64()
  });
  const ConsensusCommitPrologueV2 = bcs.struct("ConsensusCommitPrologueV2", {
    epoch: bcs.u64(),
    round: bcs.u64(),
    commitTimestampMs: bcs.u64(),
    consensusCommitDigest: ObjectDigest
  });
  const ConsensusDeterminedVersionAssignments = bcs.enum("ConsensusDeterminedVersionAssignments", {
    CancelledTransactions: bcs.vector(bcs.tuple([ObjectDigest, bcs.vector(bcs.tuple([Address, bcs.u64()]))])),
    CancelledTransactionsV2: bcs.vector(bcs.tuple([ObjectDigest, bcs.vector(bcs.tuple([bcs.tuple([Address, bcs.u64()]), bcs.u64()]))]))
  });
  const ConsensusCommitPrologueV3 = bcs.struct("ConsensusCommitPrologueV3", {
    epoch: bcs.u64(),
    round: bcs.u64(),
    subDagIndex: bcs.option(bcs.u64()),
    commitTimestampMs: bcs.u64(),
    consensusCommitDigest: ObjectDigest,
    consensusDeterminedVersionAssignments: ConsensusDeterminedVersionAssignments
  });
  const ConsensusCommitPrologueV4 = bcs.struct("ConsensusCommitPrologueV4", {
    epoch: bcs.u64(),
    round: bcs.u64(),
    subDagIndex: bcs.option(bcs.u64()),
    commitTimestampMs: bcs.u64(),
    consensusCommitDigest: ObjectDigest,
    consensusDeterminedVersionAssignments: ConsensusDeterminedVersionAssignments,
    additionalStateDigest: ObjectDigest
  });
  const ActiveJwk = bcs.struct("ActiveJwk", {
    jwkId: bcs.struct("JwkId", {
      iss: bcs.string(),
      kid: bcs.string()
    }),
    jwk: bcs.struct("JWK", {
      kty: bcs.string(),
      e: bcs.string(),
      n: bcs.string(),
      alg: bcs.string()
    }),
    epoch: bcs.u64()
  });
  const AuthenticatorStateUpdate = bcs.struct("AuthenticatorStateUpdate", {
    epoch: bcs.u64(),
    round: bcs.u64(),
    newActiveJwks: bcs.vector(ActiveJwk),
    authenticatorObjInitialSharedVersion: bcs.u64()
  });
  const RandomnessStateUpdate = bcs.struct("RandomnessStateUpdate", {
    epoch: bcs.u64(),
    randomnessRound: bcs.u64(),
    randomBytes: bcs.byteVector(),
    randomnessObjInitialSharedVersion: bcs.u64()
  });
  const AuthenticatorStateExpire = bcs.struct("AuthenticatorStateExpire", {
    minEpoch: bcs.u64(),
    authenticatorObjInitialSharedVersion: bcs.u64()
  });
  const ExecutionTimeObservationKey = bcs.enum("ExecutionTimeObservationKey", {
    MoveEntryPoint: bcs.struct("MoveEntryPoint", {
      package: Address,
      module: bcs.string(),
      function: bcs.string(),
      typeArguments: bcs.vector(TypeTag)
    }),
    TransferObjects: null,
    SplitCoins: null,
    MergeCoins: null,
    Publish: null,
    MakeMoveVec: null,
    Upgrade: null
  });
  const StoredExecutionTimeObservations = bcs.enum("StoredExecutionTimeObservations", { V1: bcs.vector(bcs.tuple([ExecutionTimeObservationKey, bcs.vector(bcs.tuple([bcs.byteVector(), bcs.struct("Duration", {
    secs: bcs.u64(),
    nanos: bcs.u32()
  })]))])) });
  const WriteAccumulatorStorageCost = bcs.struct("WriteAccumulatorStorageCost", { storageCost: bcs.u64() });
  const EndOfEpochTransactionKind = bcs.enum("EndOfEpochTransactionKind", {
    ChangeEpoch,
    AuthenticatorStateCreate: null,
    AuthenticatorStateExpire,
    RandomnessStateCreate: null,
    DenyListStateCreate: null,
    BridgeStateCreate: ObjectDigest,
    BridgeCommitteeInit: bcs.u64(),
    StoreExecutionTimeObservations: StoredExecutionTimeObservations,
    AccumulatorRootCreate: null,
    CoinRegistryCreate: null,
    DisplayRegistryCreate: null,
    AddressAliasStateCreate: null,
    WriteAccumulatorStorageCost,
    ForwardingAddressRegistryCreate: null
  });
  const TransactionKind = bcs.enum("TransactionKind", {
    ProgrammableTransaction,
    ChangeEpoch,
    Genesis: GenesisTransaction,
    ConsensusCommitPrologue,
    AuthenticatorStateUpdate,
    EndOfEpochTransaction: bcs.vector(EndOfEpochTransactionKind),
    RandomnessStateUpdate,
    ConsensusCommitPrologueV2,
    ConsensusCommitPrologueV3,
    ConsensusCommitPrologueV4,
    ProgrammableSystemTransaction: ProgrammableTransaction
  });
  const TransactionDataV1 = bcs.struct("TransactionDataV1", {
    kind: TransactionKind,
    sender: Address,
    gasData: GasData$1,
    expiration: TransactionExpiration$2
  });
  const TransactionData = bcs.enum("TransactionData", { V1: TransactionDataV1 });
  const SenderSignedTransaction = bcs.struct("SenderSignedTransaction", {
    intentMessage: IntentMessage(TransactionData),
    txSignatures: bcs.vector(base64String)
  });
  const SenderSignedData = bcs.vector(SenderSignedTransaction, { name: "SenderSignedData" });
  const PackageUpgradeError = bcs.enum("PackageUpgradeError", {
    UnableToFetchPackage: bcs.struct("UnableToFetchPackage", { packageId: Address }),
    NotAPackage: bcs.struct("NotAPackage", { objectId: Address }),
    IncompatibleUpgrade: null,
    DigestDoesNotMatch: bcs.struct("DigestDoesNotMatch", { digest: bcs.byteVector() }),
    UnknownUpgradePolicy: bcs.struct("UnknownUpgradePolicy", { policy: bcs.u8() }),
    PackageIDDoesNotMatch: bcs.struct("PackageIDDoesNotMatch", {
      packageId: Address,
      ticketId: Address
    })
  });
  const ModuleId = bcs.struct("ModuleId", {
    address: Address,
    name: bcs.string()
  });
  const MoveLocation = bcs.struct("MoveLocation", {
    module: ModuleId,
    function: bcs.u16(),
    instruction: bcs.u16(),
    functionName: bcs.option(bcs.string())
  });
  const CommandArgumentError = bcs.enum("CommandArgumentError", {
    TypeMismatch: null,
    InvalidBCSBytes: null,
    InvalidUsageOfPureArg: null,
    InvalidArgumentToPrivateEntryFunction: null,
    IndexOutOfBounds: bcs.struct("IndexOutOfBounds", { idx: bcs.u16() }),
    SecondaryIndexOutOfBounds: bcs.struct("SecondaryIndexOutOfBounds", {
      resultIdx: bcs.u16(),
      secondaryIdx: bcs.u16()
    }),
    InvalidResultArity: bcs.struct("InvalidResultArity", { resultIdx: bcs.u16() }),
    InvalidGasCoinUsage: null,
    InvalidValueUsage: null,
    InvalidObjectByValue: null,
    InvalidObjectByMutRef: null,
    SharedObjectOperationNotAllowed: null,
    InvalidArgumentArity: null,
    InvalidTransferObject: null,
    InvalidMakeMoveVecNonObjectArgument: null,
    ArgumentWithoutValue: null,
    CannotMoveBorrowedValue: null,
    CannotWriteToExtendedReference: null,
    InvalidReferenceArgument: null,
    InvalidTxContext: null
  });
  const TypeArgumentError = bcs.enum("TypeArgumentError", {
    TypeNotFound: null,
    ConstraintNotSatisfied: null
  });
  const ExecutionFailureStatus = bcs.enum("ExecutionFailureStatus", {
    InsufficientGas: null,
    InvalidGasObject: null,
    InvariantViolation: null,
    FeatureNotYetSupported: null,
    MoveObjectTooBig: bcs.struct("MoveObjectTooBig", {
      objectSize: bcs.u64(),
      maxObjectSize: bcs.u64()
    }),
    MovePackageTooBig: bcs.struct("MovePackageTooBig", {
      objectSize: bcs.u64(),
      maxObjectSize: bcs.u64()
    }),
    CircularObjectOwnership: bcs.struct("CircularObjectOwnership", { object: Address }),
    InsufficientCoinBalance: null,
    CoinBalanceOverflow: null,
    PublishErrorNonZeroAddress: null,
    SuiMoveVerificationError: null,
    MovePrimitiveRuntimeError: bcs.option(MoveLocation),
    MoveAbort: bcs.tuple([MoveLocation, bcs.u64()]),
    VMVerificationOrDeserializationError: null,
    VMInvariantViolation: null,
    FunctionNotFound: null,
    ArityMismatch: null,
    TypeArityMismatch: null,
    NonEntryFunctionInvoked: null,
    CommandArgumentError: bcs.struct("CommandArgumentError", {
      argIdx: bcs.u16(),
      kind: CommandArgumentError
    }),
    TypeArgumentError: bcs.struct("TypeArgumentError", {
      argumentIdx: bcs.u16(),
      kind: TypeArgumentError
    }),
    UnusedValueWithoutDrop: bcs.struct("UnusedValueWithoutDrop", {
      resultIdx: bcs.u16(),
      secondaryIdx: bcs.u16()
    }),
    InvalidPublicFunctionReturnType: bcs.struct("InvalidPublicFunctionReturnType", { idx: bcs.u16() }),
    InvalidTransferObject: null,
    EffectsTooLarge: bcs.struct("EffectsTooLarge", {
      currentSize: bcs.u64(),
      maxSize: bcs.u64()
    }),
    PublishUpgradeMissingDependency: null,
    PublishUpgradeDependencyDowngrade: null,
    PackageUpgradeError: bcs.struct("PackageUpgradeError", { upgradeError: PackageUpgradeError }),
    WrittenObjectsTooLarge: bcs.struct("WrittenObjectsTooLarge", {
      currentSize: bcs.u64(),
      maxSize: bcs.u64()
    }),
    CertificateDenied: null,
    SuiMoveVerificationTimedout: null,
    SharedObjectOperationNotAllowed: null,
    InputObjectDeleted: null,
    ExecutionCancelledDueToSharedObjectCongestion: bcs.struct("ExecutionCancelledDueToSharedObjectCongestion", { congested_objects: bcs.vector(Address) }),
    AddressDeniedForCoin: bcs.struct("AddressDeniedForCoin", {
      address: Address,
      coinType: bcs.string()
    }),
    CoinTypeGlobalPause: bcs.struct("CoinTypeGlobalPause", { coinType: bcs.string() }),
    ExecutionCancelledDueToRandomnessUnavailable: null,
    MoveVectorElemTooBig: bcs.struct("MoveVectorElemTooBig", {
      valueSize: bcs.u64(),
      maxScaledSize: bcs.u64()
    }),
    MoveRawValueTooBig: bcs.struct("MoveRawValueTooBig", {
      valueSize: bcs.u64(),
      maxScaledSize: bcs.u64()
    }),
    InvalidLinkage: null,
    InsufficientBalanceForWithdraw: null,
    NonExclusiveWriteInputObjectModified: bcs.struct("NonExclusiveWriteInputObjectModified", { id: Address }),
    TransactionExpired: null
  });
  const ExecutionStatus = bcs.enum("ExecutionStatus", {
    Success: null,
    Failure: bcs.struct("Failure", {
      error: ExecutionFailureStatus,
      command: bcs.option(bcs.u64())
    })
  });
  const GasCostSummary = bcs.struct("GasCostSummary", {
    computationCost: bcs.u64(),
    storageCost: bcs.u64(),
    storageRebate: bcs.u64(),
    nonRefundableStorageFee: bcs.u64()
  });
  const TransactionEffectsV1 = bcs.struct("TransactionEffectsV1", {
    status: ExecutionStatus,
    executedEpoch: bcs.u64(),
    gasUsed: GasCostSummary,
    modifiedAtVersions: bcs.vector(bcs.tuple([Address, bcs.u64()])),
    sharedObjects: bcs.vector(SuiObjectRef),
    transactionDigest: ObjectDigest,
    created: bcs.vector(bcs.tuple([SuiObjectRef, Owner])),
    mutated: bcs.vector(bcs.tuple([SuiObjectRef, Owner])),
    unwrapped: bcs.vector(bcs.tuple([SuiObjectRef, Owner])),
    deleted: bcs.vector(SuiObjectRef),
    unwrappedThenDeleted: bcs.vector(SuiObjectRef),
    wrapped: bcs.vector(SuiObjectRef),
    gasObject: bcs.tuple([SuiObjectRef, Owner]),
    eventsDigest: bcs.option(ObjectDigest),
    dependencies: bcs.vector(ObjectDigest)
  });
  const VersionDigest = bcs.tuple([bcs.u64(), ObjectDigest]);
  const ObjectIn = bcs.enum("ObjectIn", {
    NotExist: null,
    Exist: bcs.tuple([VersionDigest, Owner])
  });
  const AccumulatorAddress = bcs.struct("AccumulatorAddress", {
    address: Address,
    ty: TypeTag
  });
  const AccumulatorOperation = bcs.enum("AccumulatorOperation", {
    Merge: null,
    Split: null
  });
  const AccumulatorValue = bcs.enum("AccumulatorValue", {
    Integer: bcs.u64(),
    IntegerTuple: bcs.tuple([bcs.u64(), bcs.u64()]),
    EventDigest: bcs.vector(bcs.tuple([bcs.u64(), ObjectDigest]))
  });
  const AccumulatorWriteV1 = bcs.struct("AccumulatorWriteV1", {
    address: AccumulatorAddress,
    operation: AccumulatorOperation,
    value: AccumulatorValue
  });
  const ObjectOut = bcs.enum("ObjectOut", {
    NotExist: null,
    ObjectWrite: bcs.tuple([ObjectDigest, Owner]),
    PackageWrite: VersionDigest,
    AccumulatorWriteV1
  });
  const IDOperation = bcs.enum("IDOperation", {
    None: null,
    Created: null,
    Deleted: null
  });
  const EffectsObjectChange = bcs.struct("EffectsObjectChange", {
    inputState: ObjectIn,
    outputState: ObjectOut,
    idOperation: IDOperation
  });
  const UnchangedConsensusKind = bcs.enum("UnchangedConsensusKind", {
    ReadOnlyRoot: VersionDigest,
    MutateConsensusStreamEnded: bcs.u64(),
    ReadConsensusStreamEnded: bcs.u64(),
    Cancelled: bcs.u64(),
    PerEpochConfig: null
  });
  const TransactionEffectsV2 = bcs.struct("TransactionEffectsV2", {
    status: ExecutionStatus,
    executedEpoch: bcs.u64(),
    gasUsed: GasCostSummary,
    transactionDigest: ObjectDigest,
    gasObjectIndex: bcs.option(bcs.u32()),
    eventsDigest: bcs.option(ObjectDigest),
    dependencies: bcs.vector(ObjectDigest),
    lamportVersion: bcs.u64(),
    changedObjects: bcs.vector(bcs.tuple([Address, EffectsObjectChange])),
    unchangedConsensusObjects: bcs.vector(bcs.tuple([Address, UnchangedConsensusKind])),
    auxDataDigest: bcs.option(ObjectDigest)
  });
  const TransactionEffects = bcs.enum("TransactionEffects", {
    V1: TransactionEffectsV1,
    V2: TransactionEffectsV2
  });
  function pureBcsSchemaFromTypeName(name) {
    switch (name) {
      case "u8":
        return bcs.u8();
      case "u16":
        return bcs.u16();
      case "u32":
        return bcs.u32();
      case "u64":
        return bcs.u64();
      case "u128":
        return bcs.u128();
      case "u256":
        return bcs.u256();
      case "bool":
        return bcs.bool();
      case "string":
        return bcs.string();
      case "id":
      case "address":
        return Address;
    }
    const generic = name.match(/^(vector|option)<(.+)>$/);
    if (generic) {
      const [kind, inner] = generic.slice(1);
      if (kind === "vector") return bcs.vector(pureBcsSchemaFromTypeName(inner));
      else return bcs.option(pureBcsSchemaFromTypeName(inner));
    }
    throw new Error(`Invalid Pure type name: ${name}`);
  }
  const suiBcs = {
    ...bcs,
    U8: bcs.u8(),
    U16: bcs.u16(),
    U32: bcs.u32(),
    U64: bcs.u64(),
    U128: bcs.u128(),
    U256: bcs.u256(),
    ULEB128: bcs.uleb128(),
    Bool: bcs.bool(),
    String: bcs.string(),
    Address,
    AppId,
    Argument: Argument$1,
    CallArg: CallArg$1,
    Command: Command$1,
    CompressedSignature,
    Data,
    GasData: GasData$1,
    Intent,
    IntentMessage,
    IntentScope,
    IntentVersion,
    MoveObject,
    MoveObjectType,
    MovePackage,
    MultiSig,
    MultiSigPkMap,
    MultiSigPublicKey,
    Object: ObjectInner,
    ObjectArg: ObjectArg$1,
    ObjectDigest,
    Owner,
    PasskeyAuthenticator,
    ProgrammableMoveCall: ProgrammableMoveCall$1,
    ProgrammableTransaction,
    PublicKey,
    SenderSignedData,
    SenderSignedTransaction,
    SharedObjectRef,
    StructTag,
    SuiObjectRef,
    TransactionData,
    TransactionDataV1,
    TransactionEffects,
    TransactionExpiration: TransactionExpiration$2,
    TransactionKind,
    TypeOrigin,
    TypeTag,
    UpgradeInfo
  };
  const DEFAULT_CONFIG = {
    lang: void 0,
    message: void 0,
    abortEarly: void 0,
    abortPipeEarly: void 0
  };
  // @__NO_SIDE_EFFECTS__
  function getGlobalConfig(config$1) {
    return DEFAULT_CONFIG;
  }
  let store$3;
  // @__NO_SIDE_EFFECTS__
  function getGlobalMessage(lang) {
    return store$3?.get(lang);
  }
  let store$2;
  // @__NO_SIDE_EFFECTS__
  function getSchemaMessage(lang) {
    return store$2?.get(lang);
  }
  let store$1;
  // @__NO_SIDE_EFFECTS__
  function getSpecificMessage(reference, lang) {
    return store$1?.get(reference)?.get(lang);
  }
  // @__NO_SIDE_EFFECTS__
  function _stringify(input) {
    const type = typeof input;
    if (type === "string") return `"${input}"`;
    if (type === "number" || type === "bigint" || type === "boolean") return `${input}`;
    if (type === "object" || type === "function") return (input && Object.getPrototypeOf(input)?.constructor?.name) ?? "null";
    return type;
  }
  function _addIssue(context, label, dataset, config$1, other) {
    const input = other && "input" in other ? other.input : dataset.value;
    const expected = other?.expected ?? context.expects ?? null;
    const received = other?.received ?? /* @__PURE__ */ _stringify(input);
    const issue = {
      kind: context.kind,
      type: context.type,
      input,
      expected,
      received,
      message: `Invalid ${label}: ${expected ? `Expected ${expected} but r` : "R"}eceived ${received}`,
      requirement: context.requirement,
      path: other?.path,
      issues: other?.issues,
      lang: config$1.lang,
      abortEarly: config$1.abortEarly,
      abortPipeEarly: config$1.abortPipeEarly
    };
    const isSchema = context.kind === "schema";
    const message$1 = other?.message ?? context.message ?? /* @__PURE__ */ getSpecificMessage(context.reference, issue.lang) ?? (isSchema ? /* @__PURE__ */ getSchemaMessage(issue.lang) : null) ?? config$1.message ?? /* @__PURE__ */ getGlobalMessage(issue.lang);
    if (message$1 !== void 0) issue.message = typeof message$1 === "function" ? message$1(issue) : message$1;
    if (isSchema) dataset.typed = false;
    if (dataset.issues) dataset.issues.push(issue);
    else dataset.issues = [issue];
  }
  // @__NO_SIDE_EFFECTS__
  function _isSameValueZero(value1, value2) {
    return value1 === value2 || Number.isNaN(value1) && Number.isNaN(value2);
  }
  // @__NO_SIDE_EFFECTS__
  function _isValidObjectKey(object$1, key) {
    return Object.prototype.hasOwnProperty.call(object$1, key) && key !== "__proto__" && key !== "prototype" && key !== "constructor";
  }
  // @__NO_SIDE_EFFECTS__
  function _joinExpects(values$1, separator) {
    const list = [...new Set(values$1)];
    if (list.length > 1) return `(${list.join(` ${separator} `)})`;
    return list[0] ?? "never";
  }
  function _standardSchema(schema) {
    schema["~standard"] = {
      version: 1,
      vendor: "valibot",
      validate: (value$1) => schema["~run"]({ value: value$1 }, /* @__PURE__ */ getGlobalConfig())
    };
    return schema;
  }
  var ValiError = class extends Error {
    /**
    * Creates a Valibot error with useful information.
    *
    * @param issues The error issues.
    */
    constructor(issues) {
      super(issues[0].message);
      this.name = "ValiError";
      this.issues = issues;
    }
  };
  // @__NO_SIDE_EFFECTS__
  function check(requirement, message$1) {
    return {
      kind: "validation",
      type: "check",
      reference: check,
      async: false,
      expects: null,
      requirement,
      message: message$1,
      "~run"(dataset, config$1) {
        if (dataset.typed && !this.requirement(dataset.value)) _addIssue(this, "input", dataset, config$1);
        return dataset;
      }
    };
  }
  // @__NO_SIDE_EFFECTS__
  function integer(message$1) {
    return {
      kind: "validation",
      type: "integer",
      reference: integer,
      async: false,
      expects: null,
      requirement: Number.isInteger,
      message: message$1,
      "~run"(dataset, config$1) {
        if (dataset.typed && !this.requirement(dataset.value)) _addIssue(this, "integer", dataset, config$1);
        return dataset;
      }
    };
  }
  // @__NO_SIDE_EFFECTS__
  function transform(operation) {
    return {
      kind: "transformation",
      type: "transform",
      reference: transform,
      async: false,
      operation,
      "~run"(dataset) {
        dataset.value = this.operation(dataset.value);
        return dataset;
      }
    };
  }
  const ABORT_EARLY_CONFIG = { abortEarly: true };
  // @__NO_SIDE_EFFECTS__
  function getFallback(schema, dataset, config$1) {
    return typeof schema.fallback === "function" ? schema.fallback(dataset, config$1) : schema.fallback;
  }
  // @__NO_SIDE_EFFECTS__
  function getDefault(schema, dataset, config$1) {
    return typeof schema.default === "function" ? schema.default(dataset, config$1) : schema.default;
  }
  // @__NO_SIDE_EFFECTS__
  function is(schema, input) {
    return !schema["~run"]({ value: input }, ABORT_EARLY_CONFIG).issues;
  }
  // @__NO_SIDE_EFFECTS__
  function array(item, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "array",
      reference: array,
      expects: "Array",
      async: false,
      item,
      message: message$1,
      "~run"(dataset, config$1) {
        const input = dataset.value;
        if (Array.isArray(input)) {
          dataset.typed = true;
          dataset.value = [];
          for (let key = 0; key < input.length; key++) {
            const value$1 = input[key];
            const itemDataset = this.item["~run"]({ value: value$1 }, config$1);
            if (itemDataset.issues) {
              const pathItem = {
                type: "array",
                origin: "value",
                input,
                key,
                value: value$1
              };
              for (const issue of itemDataset.issues) {
                if (issue.path) issue.path.unshift(pathItem);
                else issue.path = [pathItem];
                dataset.issues?.push(issue);
              }
              if (!dataset.issues) dataset.issues = itemDataset.issues;
              if (config$1.abortEarly) {
                dataset.typed = false;
                break;
              }
            }
            if (!itemDataset.typed) dataset.typed = false;
            dataset.value.push(itemDataset.value);
          }
        } else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function bigint(message$1) {
    return _standardSchema({
      kind: "schema",
      type: "bigint",
      reference: bigint,
      expects: "bigint",
      async: false,
      message: message$1,
      "~run"(dataset, config$1) {
        if (typeof dataset.value === "bigint") dataset.typed = true;
        else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function boolean(message$1) {
    return _standardSchema({
      kind: "schema",
      type: "boolean",
      reference: boolean,
      expects: "boolean",
      async: false,
      message: message$1,
      "~run"(dataset, config$1) {
        if (typeof dataset.value === "boolean") dataset.typed = true;
        else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function lazy(getter) {
    return _standardSchema({
      kind: "schema",
      type: "lazy",
      reference: lazy,
      expects: "unknown",
      async: false,
      getter,
      "~run"(dataset, config$1) {
        return this.getter(dataset.value)["~run"](dataset, config$1);
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function literal(literal_, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "literal",
      reference: literal,
      expects: /* @__PURE__ */ _stringify(literal_),
      async: false,
      literal: literal_,
      message: message$1,
      "~run"(dataset, config$1) {
        if (/* @__PURE__ */ _isSameValueZero(dataset.value, this.literal)) dataset.typed = true;
        else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function nullable(wrapped, default_) {
    return _standardSchema({
      kind: "schema",
      type: "nullable",
      reference: nullable,
      expects: `(${wrapped.expects} | null)`,
      async: false,
      wrapped,
      default: default_,
      "~run"(dataset, config$1) {
        if (dataset.value === null) {
          if (this.default !== void 0) dataset.value = /* @__PURE__ */ getDefault(this, dataset, config$1);
          if (dataset.value === null) {
            dataset.typed = true;
            return dataset;
          }
        }
        return this.wrapped["~run"](dataset, config$1);
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function nullish(wrapped, default_) {
    return _standardSchema({
      kind: "schema",
      type: "nullish",
      reference: nullish,
      expects: `(${wrapped.expects} | null | undefined)`,
      async: false,
      wrapped,
      default: default_,
      "~run"(dataset, config$1) {
        if (dataset.value === null || dataset.value === void 0) {
          if (this.default !== void 0) dataset.value = /* @__PURE__ */ getDefault(this, dataset, config$1);
          if (dataset.value === null || dataset.value === void 0) {
            dataset.typed = true;
            return dataset;
          }
        }
        return this.wrapped["~run"](dataset, config$1);
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function number(message$1) {
    return _standardSchema({
      kind: "schema",
      type: "number",
      reference: number,
      expects: "number",
      async: false,
      message: message$1,
      "~run"(dataset, config$1) {
        if (typeof dataset.value === "number" && !isNaN(dataset.value)) dataset.typed = true;
        else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function object(entries$1, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "object",
      reference: object,
      expects: "Object",
      async: false,
      entries: entries$1,
      message: message$1,
      "~run"(dataset, config$1) {
        const input = dataset.value;
        if (input && typeof input === "object") {
          dataset.typed = true;
          dataset.value = {};
          for (const key in this.entries) {
            const valueSchema = this.entries[key];
            if (key in input || (valueSchema.type === "exact_optional" || valueSchema.type === "optional" || valueSchema.type === "nullish") && valueSchema.default !== void 0) {
              const value$1 = key in input ? input[key] : /* @__PURE__ */ getDefault(valueSchema);
              const valueDataset = valueSchema["~run"]({ value: value$1 }, config$1);
              if (valueDataset.issues) {
                const pathItem = {
                  type: "object",
                  origin: "value",
                  input,
                  key,
                  value: value$1
                };
                for (const issue of valueDataset.issues) {
                  if (issue.path) issue.path.unshift(pathItem);
                  else issue.path = [pathItem];
                  dataset.issues?.push(issue);
                }
                if (!dataset.issues) dataset.issues = valueDataset.issues;
                if (config$1.abortEarly) {
                  dataset.typed = false;
                  break;
                }
              }
              if (!valueDataset.typed) dataset.typed = false;
              dataset.value[key] = valueDataset.value;
            } else if (valueSchema.fallback !== void 0) dataset.value[key] = /* @__PURE__ */ getFallback(valueSchema);
            else if (valueSchema.type !== "exact_optional" && valueSchema.type !== "optional" && valueSchema.type !== "nullish") {
              _addIssue(this, "key", dataset, config$1, {
                input: void 0,
                expected: `"${key}"`,
                path: [{
                  type: "object",
                  origin: "key",
                  input,
                  key,
                  value: input[key]
                }]
              });
              if (config$1.abortEarly) break;
            }
          }
        } else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function optional(wrapped, default_) {
    return _standardSchema({
      kind: "schema",
      type: "optional",
      reference: optional,
      expects: `(${wrapped.expects} | undefined)`,
      async: false,
      wrapped,
      default: default_,
      "~run"(dataset, config$1) {
        if (dataset.value === void 0) {
          if (this.default !== void 0) dataset.value = /* @__PURE__ */ getDefault(this, dataset, config$1);
          if (dataset.value === void 0) {
            dataset.typed = true;
            return dataset;
          }
        }
        return this.wrapped["~run"](dataset, config$1);
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function picklist(options, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "picklist",
      reference: picklist,
      expects: /* @__PURE__ */ _joinExpects(options.map(_stringify), "|"),
      async: false,
      options,
      message: message$1,
      "~run"(dataset, config$1) {
        if (this.options.includes(dataset.value)) dataset.typed = true;
        else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function record(key, value$1, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "record",
      reference: record,
      expects: "Object",
      async: false,
      key,
      value: value$1,
      message: message$1,
      "~run"(dataset, config$1) {
        const input = dataset.value;
        if (input && typeof input === "object") {
          dataset.typed = true;
          dataset.value = {};
          for (const entryKey in input) if (/* @__PURE__ */ _isValidObjectKey(input, entryKey)) {
            const entryValue = input[entryKey];
            const keyDataset = this.key["~run"]({ value: entryKey }, config$1);
            if (keyDataset.issues) {
              const pathItem = {
                type: "object",
                origin: "key",
                input,
                key: entryKey,
                value: entryValue
              };
              for (const issue of keyDataset.issues) {
                issue.path = [pathItem];
                dataset.issues?.push(issue);
              }
              if (!dataset.issues) dataset.issues = keyDataset.issues;
              if (config$1.abortEarly) {
                dataset.typed = false;
                break;
              }
            }
            const valueDataset = this.value["~run"]({ value: entryValue }, config$1);
            if (valueDataset.issues) {
              const pathItem = {
                type: "object",
                origin: "value",
                input,
                key: entryKey,
                value: entryValue
              };
              for (const issue of valueDataset.issues) {
                if (issue.path) issue.path.unshift(pathItem);
                else issue.path = [pathItem];
                dataset.issues?.push(issue);
              }
              if (!dataset.issues) dataset.issues = valueDataset.issues;
              if (config$1.abortEarly) {
                dataset.typed = false;
                break;
              }
            }
            if (!keyDataset.typed || !valueDataset.typed) dataset.typed = false;
            if (keyDataset.typed) dataset.value[keyDataset.value] = valueDataset.value;
          }
        } else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function string(message$1) {
    return _standardSchema({
      kind: "schema",
      type: "string",
      reference: string,
      expects: "string",
      async: false,
      message: message$1,
      "~run"(dataset, config$1) {
        if (typeof dataset.value === "string") dataset.typed = true;
        else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function tuple(items, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "tuple",
      reference: tuple,
      expects: "Array",
      async: false,
      items,
      message: message$1,
      "~run"(dataset, config$1) {
        const input = dataset.value;
        if (Array.isArray(input)) {
          dataset.typed = true;
          dataset.value = [];
          for (let key = 0; key < this.items.length; key++) {
            const value$1 = input[key];
            const itemDataset = this.items[key]["~run"]({ value: value$1 }, config$1);
            if (itemDataset.issues) {
              const pathItem = {
                type: "array",
                origin: "value",
                input,
                key,
                value: value$1
              };
              for (const issue of itemDataset.issues) {
                if (issue.path) issue.path.unshift(pathItem);
                else issue.path = [pathItem];
                dataset.issues?.push(issue);
              }
              if (!dataset.issues) dataset.issues = itemDataset.issues;
              if (config$1.abortEarly) {
                dataset.typed = false;
                break;
              }
            }
            if (!itemDataset.typed) dataset.typed = false;
            dataset.value.push(itemDataset.value);
          }
        } else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _subIssues(datasets) {
    let issues;
    if (datasets) for (const dataset of datasets) if (issues) for (const issue of dataset.issues) issues.push(issue);
    else issues = dataset.issues;
    return issues;
  }
  // @__NO_SIDE_EFFECTS__
  function union(options, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "union",
      reference: union,
      expects: /* @__PURE__ */ _joinExpects(options.map((option2) => option2.expects), "|"),
      async: false,
      options,
      message: message$1,
      "~run"(dataset, config$1) {
        let validDataset;
        let typedDatasets;
        let untypedDatasets;
        for (const schema of this.options) {
          const optionDataset = schema["~run"]({ value: dataset.value }, config$1);
          if (optionDataset.typed) if (optionDataset.issues) if (typedDatasets) typedDatasets.push(optionDataset);
          else typedDatasets = [optionDataset];
          else {
            validDataset = optionDataset;
            break;
          }
          else if (untypedDatasets) untypedDatasets.push(optionDataset);
          else untypedDatasets = [optionDataset];
        }
        if (validDataset) return validDataset;
        if (typedDatasets) {
          if (typedDatasets.length === 1) return typedDatasets[0];
          _addIssue(this, "type", dataset, config$1, { issues: /* @__PURE__ */ _subIssues(typedDatasets) });
          dataset.typed = true;
        } else if (untypedDatasets?.length === 1) return untypedDatasets[0];
        else _addIssue(this, "type", dataset, config$1, { issues: /* @__PURE__ */ _subIssues(untypedDatasets) });
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function unknown() {
    return _standardSchema({
      kind: "schema",
      type: "unknown",
      reference: unknown,
      expects: "unknown",
      async: false,
      "~run"(dataset) {
        dataset.typed = true;
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function variant(key, options, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "variant",
      reference: variant,
      expects: "Object",
      async: false,
      key,
      options,
      message: message$1,
      "~run"(dataset, config$1) {
        const input = dataset.value;
        if (input && typeof input === "object") {
          let outputDataset;
          let maxDiscriminatorPriority = 0;
          let invalidDiscriminatorKey = this.key;
          let expectedDiscriminators = [];
          const parseOptions = (variant$1, allKeys) => {
            for (const schema of variant$1.options) {
              if (schema.type === "variant") parseOptions(schema, new Set(allKeys).add(schema.key));
              else {
                let keysAreValid = true;
                let currentPriority = 0;
                for (const currentKey of allKeys) {
                  const discriminatorSchema = schema.entries[currentKey];
                  if (currentKey in input ? discriminatorSchema["~run"]({
                    typed: false,
                    value: input[currentKey]
                  }, ABORT_EARLY_CONFIG).issues : discriminatorSchema.type !== "exact_optional" && discriminatorSchema.type !== "optional" && discriminatorSchema.type !== "nullish") {
                    keysAreValid = false;
                    if (invalidDiscriminatorKey !== currentKey && (maxDiscriminatorPriority < currentPriority || maxDiscriminatorPriority === currentPriority && currentKey in input && !(invalidDiscriminatorKey in input))) {
                      maxDiscriminatorPriority = currentPriority;
                      invalidDiscriminatorKey = currentKey;
                      expectedDiscriminators = [];
                    }
                    if (invalidDiscriminatorKey === currentKey) expectedDiscriminators.push(schema.entries[currentKey].expects);
                    break;
                  }
                  currentPriority++;
                }
                if (keysAreValid) {
                  const optionDataset = schema["~run"]({ value: input }, config$1);
                  if (!outputDataset || !outputDataset.typed && optionDataset.typed) outputDataset = optionDataset;
                }
              }
              if (outputDataset && !outputDataset.issues) break;
            }
          };
          parseOptions(this, /* @__PURE__ */ new Set([this.key]));
          if (outputDataset) return outputDataset;
          _addIssue(this, "type", dataset, config$1, {
            input: input[invalidDiscriminatorKey],
            expected: /* @__PURE__ */ _joinExpects(expectedDiscriminators, "|"),
            path: [{
              type: "object",
              origin: "value",
              input,
              key: invalidDiscriminatorKey,
              value: input[invalidDiscriminatorKey]
            }]
          });
        } else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  function parse(schema, input, config$1) {
    const dataset = schema["~run"]({ value: input }, /* @__PURE__ */ getGlobalConfig());
    if (dataset.issues) throw new ValiError(dataset.issues);
    return dataset.value;
  }
  // @__NO_SIDE_EFFECTS__
  function pipe(...pipe$1) {
    return _standardSchema({
      ...pipe$1[0],
      pipe: pipe$1,
      "~run"(dataset, config$1) {
        for (const item of pipe$1) if (item.kind !== "metadata") {
          if (dataset.issues && (item.kind === "schema" || item.kind === "transformation")) {
            dataset.typed = false;
            break;
          }
          if (!dataset.issues || !config$1.abortEarly && !config$1.abortPipeEarly) dataset = item["~run"](dataset, config$1);
        }
        return dataset;
      }
    });
  }
  function safeEnum(options) {
    const schemas = Object.keys(options).map((key) => /* @__PURE__ */ object({
      [key]: options[key],
      $kind: /* @__PURE__ */ literal(key)
    }));
    return /* @__PURE__ */ pipe(/* @__PURE__ */ unknown(), /* @__PURE__ */ check((input) => unsupportedEnumVariantMessage(input, options) === void 0, ({ input, message }) => unsupportedEnumVariantMessage(input, options) ?? message), /* @__PURE__ */ transform(addMissingEnumKind), /* @__PURE__ */ variant("$kind", schemas));
  }
  function getEnumKind(input) {
    if (typeof input !== "object" || input === null) return null;
    if ("$kind" in input && typeof input.$kind === "string") return input.$kind;
    return Object.keys(input).find((key) => key !== "$kind") ?? null;
  }
  function addMissingEnumKind(input) {
    if (typeof input !== "object" || input === null || "$kind" in input) return input;
    const kind = getEnumKind(input);
    return kind === null ? input : {
      ...input,
      $kind: kind
    };
  }
  function unsupportedEnumVariantMessage(input, options) {
    const kind = getEnumKind(input);
    if (kind === null || Object.hasOwn(options, kind)) return void 0;
    return `Unsupported enum variant "${kind}". Expected one of: ${Object.keys(options).map((key) => `"${key}"`).join(", ")}.`;
  }
  function withKind(key, schema) {
    return /* @__PURE__ */ pipe(/* @__PURE__ */ object({
      ...schema.entries,
      $kind: /* @__PURE__ */ optional(/* @__PURE__ */ literal(key))
    }), /* @__PURE__ */ transform((value) => ({
      ...value,
      $kind: key
    })));
  }
  const SuiAddress = /* @__PURE__ */ pipe(/* @__PURE__ */ string(), /* @__PURE__ */ transform((value) => normalizeSuiAddress(value)), /* @__PURE__ */ check(isValidSuiAddress));
  const ObjectID = SuiAddress;
  const BCSBytes = /* @__PURE__ */ string();
  const JsonU64 = /* @__PURE__ */ pipe(/* @__PURE__ */ union([/* @__PURE__ */ string(), /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer())]), /* @__PURE__ */ check((val) => {
    try {
      BigInt(val);
      return BigInt(val) >= 0 && BigInt(val) <= 18446744073709551615n;
    } catch {
      return false;
    }
  }, "Invalid u64"));
  const U32 = /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer(), /* @__PURE__ */ check((val) => val >= 0 && val < 2 ** 32, "Invalid u32"));
  const ObjectRefSchema = /* @__PURE__ */ object({
    objectId: SuiAddress,
    version: JsonU64,
    digest: /* @__PURE__ */ string()
  });
  const ArgumentSchema = /* @__PURE__ */ union([
    withKind("GasCoin", /* @__PURE__ */ object({ GasCoin: /* @__PURE__ */ literal(true) })),
    withKind("Input", /* @__PURE__ */ object({
      Input: /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()),
      type: /* @__PURE__ */ optional(/* @__PURE__ */ union([
        /* @__PURE__ */ literal("pure"),
        /* @__PURE__ */ literal("object"),
        /* @__PURE__ */ literal("withdrawal")
      ]))
    })),
    withKind("Result", /* @__PURE__ */ object({ Result: /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()) })),
    withKind("NestedResult", /* @__PURE__ */ object({ NestedResult: /* @__PURE__ */ tuple([/* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()), /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer())]) }))
  ]);
  const GasDataSchema = /* @__PURE__ */ object({
    budget: /* @__PURE__ */ nullable(JsonU64),
    price: /* @__PURE__ */ nullable(JsonU64),
    owner: /* @__PURE__ */ nullable(SuiAddress),
    payment: /* @__PURE__ */ nullable(/* @__PURE__ */ array(ObjectRefSchema))
  });
  const OpenSignatureBodySchema = /* @__PURE__ */ union([
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("address") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("bool") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("u8") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("u16") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("u32") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("u64") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("u128") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("u256") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("unknown") }),
    /* @__PURE__ */ object({
      $kind: /* @__PURE__ */ literal("vector"),
      vector: /* @__PURE__ */ lazy(() => OpenSignatureBodySchema)
    }),
    /* @__PURE__ */ object({
      $kind: /* @__PURE__ */ literal("datatype"),
      datatype: /* @__PURE__ */ object({
        typeName: /* @__PURE__ */ string(),
        typeParameters: /* @__PURE__ */ array(/* @__PURE__ */ lazy(() => OpenSignatureBodySchema))
      })
    }),
    /* @__PURE__ */ object({
      $kind: /* @__PURE__ */ literal("typeParameter"),
      index: /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer())
    })
  ]);
  const OpenSignatureSchema = /* @__PURE__ */ object({
    reference: /* @__PURE__ */ nullable(/* @__PURE__ */ union([
      /* @__PURE__ */ literal("mutable"),
      /* @__PURE__ */ literal("immutable"),
      /* @__PURE__ */ literal("unknown")
    ])),
    body: OpenSignatureBodySchema
  });
  const ProgrammableMoveCallSchema = /* @__PURE__ */ object({
    package: ObjectID,
    module: /* @__PURE__ */ string(),
    function: /* @__PURE__ */ string(),
    typeArguments: /* @__PURE__ */ array(/* @__PURE__ */ string()),
    arguments: /* @__PURE__ */ array(ArgumentSchema),
    _argumentTypes: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(/* @__PURE__ */ array(OpenSignatureSchema)))
  });
  const $Intent$1 = /* @__PURE__ */ object({
    name: /* @__PURE__ */ string(),
    inputs: /* @__PURE__ */ record(/* @__PURE__ */ string(), /* @__PURE__ */ union([ArgumentSchema, /* @__PURE__ */ array(ArgumentSchema)])),
    data: /* @__PURE__ */ record(/* @__PURE__ */ string(), /* @__PURE__ */ unknown())
  });
  const CommandSchema = safeEnum({
    MoveCall: ProgrammableMoveCallSchema,
    TransferObjects: /* @__PURE__ */ object({
      objects: /* @__PURE__ */ array(ArgumentSchema),
      address: ArgumentSchema
    }),
    SplitCoins: /* @__PURE__ */ object({
      coin: ArgumentSchema,
      amounts: /* @__PURE__ */ array(ArgumentSchema)
    }),
    MergeCoins: /* @__PURE__ */ object({
      destination: ArgumentSchema,
      sources: /* @__PURE__ */ array(ArgumentSchema)
    }),
    Publish: /* @__PURE__ */ object({
      modules: /* @__PURE__ */ array(BCSBytes),
      dependencies: /* @__PURE__ */ array(ObjectID)
    }),
    MakeMoveVec: /* @__PURE__ */ object({
      type: /* @__PURE__ */ nullable(/* @__PURE__ */ string()),
      elements: /* @__PURE__ */ array(ArgumentSchema)
    }),
    Upgrade: /* @__PURE__ */ object({
      modules: /* @__PURE__ */ array(BCSBytes),
      dependencies: /* @__PURE__ */ array(ObjectID),
      package: ObjectID,
      ticket: ArgumentSchema
    }),
    $Intent: $Intent$1
  });
  const ObjectArgSchema = safeEnum({
    ImmOrOwnedObject: ObjectRefSchema,
    SharedObject: /* @__PURE__ */ object({
      objectId: ObjectID,
      initialSharedVersion: JsonU64,
      mutable: /* @__PURE__ */ boolean()
    }),
    Receiving: ObjectRefSchema
  });
  const ReservationSchema = safeEnum({ MaxAmountU64: JsonU64 });
  const WithdrawalTypeArgSchema = safeEnum({ Balance: /* @__PURE__ */ string() });
  const WithdrawFromSchema = safeEnum({
    Sender: /* @__PURE__ */ literal(true),
    Sponsor: /* @__PURE__ */ literal(true),
    SenderAllowance: /* @__PURE__ */ object({
      funder: SuiAddress,
      allowance: ObjectID
    })
  });
  const FundsWithdrawalArgSchema = /* @__PURE__ */ object({
    reservation: ReservationSchema,
    typeArg: WithdrawalTypeArgSchema,
    withdrawFrom: WithdrawFromSchema
  });
  const CallArgSchema = safeEnum({
    Object: ObjectArgSchema,
    Pure: /* @__PURE__ */ object({ bytes: BCSBytes }),
    UnresolvedPure: /* @__PURE__ */ object({ value: /* @__PURE__ */ unknown() }),
    UnresolvedObject: /* @__PURE__ */ object({
      objectId: ObjectID,
      version: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(JsonU64)),
      digest: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(/* @__PURE__ */ string())),
      initialSharedVersion: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(JsonU64)),
      mutable: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(/* @__PURE__ */ boolean()))
    }),
    FundsWithdrawal: FundsWithdrawalArgSchema
  });
  const NormalizedCallArg$1 = safeEnum({
    Object: ObjectArgSchema,
    Pure: /* @__PURE__ */ object({ bytes: BCSBytes })
  });
  const ValidDuringSchema = /* @__PURE__ */ object({
    minEpoch: /* @__PURE__ */ nullable(JsonU64),
    maxEpoch: /* @__PURE__ */ nullable(JsonU64),
    minTimestamp: /* @__PURE__ */ nullable(JsonU64),
    maxTimestamp: /* @__PURE__ */ nullable(JsonU64),
    chain: /* @__PURE__ */ string(),
    nonce: U32
  });
  const AllowedProposersSchema = /* @__PURE__ */ object({
    epoch: JsonU64,
    proposers: /* @__PURE__ */ pipe(/* @__PURE__ */ array(U32), /* @__PURE__ */ check((proposers) => proposers.length > 0, "Allowed proposers must not be empty"))
  });
  const ValiditySchema = /* @__PURE__ */ object({
    ...ValidDuringSchema.entries,
    allowedProposers: /* @__PURE__ */ nullable(AllowedProposersSchema)
  });
  const TransactionExpiration$1 = safeEnum({
    None: /* @__PURE__ */ literal(true),
    Epoch: JsonU64,
    ValidDuring: ValidDuringSchema,
    Validity: ValiditySchema
  });
  const TransactionDataSchema = /* @__PURE__ */ object({
    version: /* @__PURE__ */ literal(2),
    sender: /* @__PURE__ */ nullish(SuiAddress),
    expiration: /* @__PURE__ */ nullish(TransactionExpiration$1),
    gasData: GasDataSchema,
    inputs: /* @__PURE__ */ array(CallArgSchema),
    commands: /* @__PURE__ */ array(CommandSchema)
  });
  function getIdFromCallArg(arg) {
    if (typeof arg === "string") return normalizeSuiAddress(arg);
    if (arg.Object) {
      if (arg.Object.ImmOrOwnedObject) return normalizeSuiAddress(arg.Object.ImmOrOwnedObject.objectId);
      if (arg.Object.Receiving) return normalizeSuiAddress(arg.Object.Receiving.objectId);
      return normalizeSuiAddress(arg.Object.SharedObject.objectId);
    }
    if (arg.UnresolvedObject) return normalizeSuiAddress(arg.UnresolvedObject.objectId);
  }
  function remapCommandArguments(command, inputMapping, commandMapping) {
    const remapArg = (arg) => {
      switch (arg.$kind) {
        case "Input": {
          const newInputIndex = inputMapping.get(arg.Input);
          if (newInputIndex === void 0) throw new Error(`Input ${arg.Input} not found in input mapping`);
          return {
            ...arg,
            Input: newInputIndex
          };
        }
        case "Result": {
          const newCommandIndex = commandMapping.get(arg.Result);
          if (newCommandIndex !== void 0) return {
            ...arg,
            Result: newCommandIndex
          };
          return arg;
        }
        case "NestedResult": {
          const newCommandIndex = commandMapping.get(arg.NestedResult[0]);
          if (newCommandIndex !== void 0) return {
            ...arg,
            NestedResult: [newCommandIndex, arg.NestedResult[1]]
          };
          return arg;
        }
        default:
          return arg;
      }
    };
    switch (command.$kind) {
      case "MoveCall":
        command.MoveCall.arguments = command.MoveCall.arguments.map(remapArg);
        break;
      case "TransferObjects":
        command.TransferObjects.objects = command.TransferObjects.objects.map(remapArg);
        command.TransferObjects.address = remapArg(command.TransferObjects.address);
        break;
      case "SplitCoins":
        command.SplitCoins.coin = remapArg(command.SplitCoins.coin);
        command.SplitCoins.amounts = command.SplitCoins.amounts.map(remapArg);
        break;
      case "MergeCoins":
        command.MergeCoins.destination = remapArg(command.MergeCoins.destination);
        command.MergeCoins.sources = command.MergeCoins.sources.map(remapArg);
        break;
      case "MakeMoveVec":
        command.MakeMoveVec.elements = command.MakeMoveVec.elements.map(remapArg);
        break;
      case "Upgrade":
        command.Upgrade.ticket = remapArg(command.Upgrade.ticket);
        break;
      case "$Intent": {
        const inputs = command.$Intent.inputs;
        command.$Intent.inputs = {};
        for (const [key, value] of Object.entries(inputs)) command.$Intent.inputs[key] = Array.isArray(value) ? value.map(remapArg) : remapArg(value);
        break;
      }
    }
  }
  const ObjectRef = /* @__PURE__ */ object({
    digest: /* @__PURE__ */ string(),
    objectId: /* @__PURE__ */ string(),
    version: /* @__PURE__ */ union([
      /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()),
      /* @__PURE__ */ string(),
      /* @__PURE__ */ bigint()
    ])
  });
  const ObjectArg = safeEnum({
    ImmOrOwned: ObjectRef,
    Shared: /* @__PURE__ */ object({
      objectId: ObjectID,
      initialSharedVersion: JsonU64,
      mutable: /* @__PURE__ */ boolean()
    }),
    Receiving: ObjectRef
  });
  const NormalizedCallArg = safeEnum({
    Object: ObjectArg,
    Pure: /* @__PURE__ */ array(/* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()))
  });
  function expirationToV1(expiration) {
    if (!expiration) return null;
    switch (expiration.$kind) {
      case "Epoch":
        return { Epoch: Number(expiration.Epoch) };
      case "ValidDuring":
        return { ValidDuring: expiration.ValidDuring };
      case "Validity":
        return { Validity: expiration.Validity };
      case "None":
        return { None: true };
      default:
        throw new Error(`Unknown transaction expiration: ${JSON.stringify(expiration)}`);
    }
  }
  function expirationFromV1(expiration) {
    if (!expiration) return null;
    if ("Epoch" in expiration) return { Epoch: expiration.Epoch };
    if ("ValidDuring" in expiration) return { ValidDuring: expiration.ValidDuring };
    if ("Validity" in expiration) return { Validity: expiration.Validity };
    if ("None" in expiration) return { None: true };
    throw new Error(`Unknown transaction expiration in v1 transaction data: ${Object.keys(expiration).join(", ")}`);
  }
  function serializeV1TransactionData(transactionData) {
    const inputs = transactionData.inputs.map((input, index) => {
      if (input.Object) return {
        kind: "Input",
        index,
        value: { Object: input.Object.ImmOrOwnedObject ? { ImmOrOwned: input.Object.ImmOrOwnedObject } : input.Object.Receiving ? { Receiving: {
          digest: input.Object.Receiving.digest,
          version: input.Object.Receiving.version,
          objectId: input.Object.Receiving.objectId
        } } : { Shared: {
          mutable: input.Object.SharedObject.mutable,
          initialSharedVersion: input.Object.SharedObject.initialSharedVersion,
          objectId: input.Object.SharedObject.objectId
        } } },
        type: "object"
      };
      if (input.Pure) return {
        kind: "Input",
        index,
        value: { Pure: Array.from(fromBase64(input.Pure.bytes)) },
        type: "pure"
      };
      if (input.UnresolvedPure) return {
        kind: "Input",
        type: "pure",
        index,
        value: input.UnresolvedPure.value
      };
      if (input.UnresolvedObject) return {
        kind: "Input",
        type: "object",
        index,
        value: input.UnresolvedObject.objectId
      };
      throw new Error("Invalid input");
    });
    return {
      version: 1,
      sender: transactionData.sender ?? void 0,
      expiration: expirationToV1(transactionData.expiration),
      gasConfig: {
        owner: transactionData.gasData.owner ?? void 0,
        budget: transactionData.gasData.budget ?? void 0,
        price: transactionData.gasData.price ?? void 0,
        payment: transactionData.gasData.payment ?? void 0
      },
      inputs,
      transactions: transactionData.commands.map((command) => {
        if (command.MakeMoveVec) return {
          kind: "MakeMoveVec",
          type: command.MakeMoveVec.type === null ? { None: true } : { Some: TypeTagSerializer.parseFromStr(command.MakeMoveVec.type) },
          objects: command.MakeMoveVec.elements.map((arg) => convertTransactionArgument(arg, inputs))
        };
        if (command.MergeCoins) return {
          kind: "MergeCoins",
          destination: convertTransactionArgument(command.MergeCoins.destination, inputs),
          sources: command.MergeCoins.sources.map((arg) => convertTransactionArgument(arg, inputs))
        };
        if (command.MoveCall) return {
          kind: "MoveCall",
          target: `${command.MoveCall.package}::${command.MoveCall.module}::${command.MoveCall.function}`,
          typeArguments: command.MoveCall.typeArguments,
          arguments: command.MoveCall.arguments.map((arg) => convertTransactionArgument(arg, inputs))
        };
        if (command.Publish) return {
          kind: "Publish",
          modules: command.Publish.modules.map((mod) => Array.from(fromBase64(mod))),
          dependencies: command.Publish.dependencies
        };
        if (command.SplitCoins) return {
          kind: "SplitCoins",
          coin: convertTransactionArgument(command.SplitCoins.coin, inputs),
          amounts: command.SplitCoins.amounts.map((arg) => convertTransactionArgument(arg, inputs))
        };
        if (command.TransferObjects) return {
          kind: "TransferObjects",
          objects: command.TransferObjects.objects.map((arg) => convertTransactionArgument(arg, inputs)),
          address: convertTransactionArgument(command.TransferObjects.address, inputs)
        };
        if (command.Upgrade) return {
          kind: "Upgrade",
          modules: command.Upgrade.modules.map((mod) => Array.from(fromBase64(mod))),
          dependencies: command.Upgrade.dependencies,
          packageId: command.Upgrade.package,
          ticket: convertTransactionArgument(command.Upgrade.ticket, inputs)
        };
        throw new Error(`Unknown transaction ${Object.keys(command)}`);
      })
    };
  }
  function convertTransactionArgument(arg, inputs) {
    if (arg.$kind === "GasCoin") return { kind: "GasCoin" };
    if (arg.$kind === "Result") return {
      kind: "Result",
      index: arg.Result
    };
    if (arg.$kind === "NestedResult") return {
      kind: "NestedResult",
      index: arg.NestedResult[0],
      resultIndex: arg.NestedResult[1]
    };
    if (arg.$kind === "Input") return inputs[arg.Input];
    throw new Error(`Invalid argument ${Object.keys(arg)}`);
  }
  function transactionDataFromV1(data) {
    return parse(TransactionDataSchema, {
      version: 2,
      sender: data.sender ?? null,
      expiration: expirationFromV1(data.expiration),
      gasData: {
        owner: data.gasConfig.owner ?? null,
        budget: data.gasConfig.budget?.toString() ?? null,
        price: data.gasConfig.price?.toString() ?? null,
        payment: data.gasConfig.payment?.map((ref) => ({
          digest: ref.digest,
          objectId: ref.objectId,
          version: ref.version.toString()
        })) ?? null
      },
      inputs: data.inputs.map((input) => {
        if (input.kind === "Input") {
          if (/* @__PURE__ */ is(NormalizedCallArg, input.value)) {
            const value = parse(NormalizedCallArg, input.value);
            if (value.Object) {
              if (value.Object.ImmOrOwned) return { Object: { ImmOrOwnedObject: {
                objectId: value.Object.ImmOrOwned.objectId,
                version: String(value.Object.ImmOrOwned.version),
                digest: value.Object.ImmOrOwned.digest
              } } };
              if (value.Object.Shared) return { Object: { SharedObject: {
                mutable: value.Object.Shared.mutable ?? null,
                initialSharedVersion: value.Object.Shared.initialSharedVersion,
                objectId: value.Object.Shared.objectId
              } } };
              if (value.Object.Receiving) return { Object: { Receiving: {
                digest: value.Object.Receiving.digest,
                version: String(value.Object.Receiving.version),
                objectId: value.Object.Receiving.objectId
              } } };
              throw new Error("Invalid object input");
            }
            return { Pure: { bytes: toBase64(new Uint8Array(value.Pure)) } };
          }
          if (input.type === "object") return { UnresolvedObject: { objectId: input.value } };
          return { UnresolvedPure: { value: input.value } };
        }
        throw new Error("Invalid input");
      }),
      commands: data.transactions.map((transaction) => {
        switch (transaction.kind) {
          case "MakeMoveVec":
            return { MakeMoveVec: {
              type: "Some" in transaction.type ? TypeTagSerializer.tagToString(transaction.type.Some) : null,
              elements: transaction.objects.map((arg) => parseV1TransactionArgument(arg))
            } };
          case "MergeCoins":
            return { MergeCoins: {
              destination: parseV1TransactionArgument(transaction.destination),
              sources: transaction.sources.map((arg) => parseV1TransactionArgument(arg))
            } };
          case "MoveCall": {
            const [pkg, mod, fn] = transaction.target.split("::");
            return { MoveCall: {
              package: pkg,
              module: mod,
              function: fn,
              typeArguments: transaction.typeArguments,
              arguments: transaction.arguments.map((arg) => parseV1TransactionArgument(arg))
            } };
          }
          case "Publish":
            return { Publish: {
              modules: transaction.modules.map((mod) => toBase64(Uint8Array.from(mod))),
              dependencies: transaction.dependencies
            } };
          case "SplitCoins":
            return { SplitCoins: {
              coin: parseV1TransactionArgument(transaction.coin),
              amounts: transaction.amounts.map((arg) => parseV1TransactionArgument(arg))
            } };
          case "TransferObjects":
            return { TransferObjects: {
              objects: transaction.objects.map((arg) => parseV1TransactionArgument(arg)),
              address: parseV1TransactionArgument(transaction.address)
            } };
          case "Upgrade":
            return { Upgrade: {
              modules: transaction.modules.map((mod) => toBase64(Uint8Array.from(mod))),
              dependencies: transaction.dependencies,
              package: transaction.packageId,
              ticket: parseV1TransactionArgument(transaction.ticket)
            } };
        }
        throw new Error(`Unknown transaction ${Object.keys(transaction)}`);
      })
    });
  }
  function parseV1TransactionArgument(arg) {
    switch (arg.kind) {
      case "GasCoin":
        return { GasCoin: true };
      case "Result":
        return { Result: arg.index };
      case "NestedResult":
        return { NestedResult: [arg.index, arg.resultIndex] };
      case "Input":
        return { Input: arg.index };
    }
  }
  function isBytes(a) {
    return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a && a.BYTES_PER_ELEMENT === 1;
  }
  const atitle = (title) => title ? `"${title}" ` : "";
  function anumber(n, title = "") {
    if (typeof n !== "number")
      throw new TypeError(atitle(title) + "expected number, got " + typeof n);
    if (!Number.isSafeInteger(n) || n < 0)
      throw new RangeError(atitle(title) + "expected integer >= 0, got " + n);
    return n;
  }
  function abytes(value, length, title = "") {
    if (isBytes(value) && (length === void 0 || value.length === length))
      return value;
    if (length !== void 0)
      anumber(length, "length");
    const bytes = isBytes(value);
    const ofLen = length !== void 0 ? ` of length ${length}` : "";
    const got = bytes ? `length=${value.length}` : `type=${typeof value}`;
    const message = atitle(title) + "expected Uint8Array" + ofLen + ", got " + got;
    if (!bytes)
      throw new TypeError(message);
    throw new RangeError(message);
  }
  function copyBytes(bytes) {
    return Uint8Array.from(abytes(bytes));
  }
  const aobject = (value, label) => {
    if (value === null || typeof value !== "object" || Array.isArray(value))
      throw new TypeError((label === "object" ? "" : `"${label}" `) + "expected object, got type=" + typeof value);
  };
  const aopts = (value, label) => {
    aobject(value, label);
    const proto = Object.getPrototypeOf(value);
    if (proto !== Object.prototype && proto !== null)
      throw new TypeError(`"${label}" expected plain object`);
    if (Object.hasOwn(value, "__proto__"))
      throw new TypeError(`"${label}.__proto__" is not allowed`);
  };
  function aexists(instance, checkFinished = true) {
    if (instance.destroyed)
      throw new Error("hash was destroyed");
    if (checkFinished && instance.finished)
      throw new Error("digest() was already called");
  }
  function aoutput(out, instance) {
    abytes(out, void 0, "output");
    const min = instance.outputLen;
    if (!(out.length >= min)) {
      throw new RangeError('"output" expected length >= ' + min);
    }
  }
  function u32(arr) {
    return new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
  }
  function clean(...arrays) {
    for (let i = 0; i < arrays.length; i++) {
      arrays[i].fill(0);
    }
  }
  const isLE = /* @__PURE__ */ (() => new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68)();
  function byteSwap(word) {
    return word << 24 & 4278190080 | word << 8 & 16711680 | word >>> 8 & 65280 | word >>> 24 & 255;
  }
  const swap8IfBE = isLE ? (n) => n : (n) => byteSwap(n) >>> 0;
  function byteSwap32(arr) {
    for (let i = 0; i < arr.length; i++) {
      arr[i] = byteSwap(arr[i]);
    }
    return arr;
  }
  const swap32IfBE = isLE ? (u) => u : byteSwap32;
  function checkOpts(defaults, opts, title = "opts") {
    aopts(defaults, "defaults");
    if (opts !== void 0)
      aopts(opts, title);
    const merged = Object.assign(/* @__PURE__ */ Object.create(null), defaults, opts);
    return merged;
  }
  function createHasher(hashCons, info = {}) {
    if (typeof hashCons !== "function")
      throw new TypeError('"hashCons" expected function, got type=' + typeof hashCons);
    info = checkOpts({}, info, "info");
    const hashC = (msg, opts) => hashCons(opts).update(msg).digest();
    const tmp = hashCons(void 0);
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.canXOF = tmp.canXOF;
    hashC.create = (opts) => hashCons(opts);
    Object.assign(hashC, info);
    return Object.freeze(hashC);
  }
  const BSIGMA = /* @__PURE__ */ Uint8Array.from([
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    14,
    10,
    4,
    8,
    9,
    15,
    13,
    6,
    1,
    12,
    0,
    2,
    11,
    7,
    5,
    3,
    11,
    8,
    12,
    0,
    5,
    2,
    15,
    13,
    10,
    14,
    3,
    6,
    7,
    1,
    9,
    4,
    7,
    9,
    3,
    1,
    13,
    12,
    11,
    14,
    2,
    6,
    5,
    10,
    4,
    0,
    15,
    8,
    9,
    0,
    5,
    7,
    2,
    4,
    10,
    15,
    14,
    1,
    11,
    12,
    6,
    8,
    3,
    13,
    2,
    12,
    6,
    10,
    0,
    11,
    8,
    3,
    4,
    13,
    7,
    5,
    15,
    14,
    1,
    9,
    12,
    5,
    1,
    15,
    14,
    13,
    4,
    10,
    0,
    7,
    6,
    3,
    9,
    2,
    8,
    11,
    13,
    11,
    7,
    14,
    12,
    1,
    3,
    9,
    5,
    0,
    15,
    4,
    8,
    6,
    2,
    10,
    6,
    15,
    14,
    9,
    11,
    3,
    0,
    8,
    12,
    2,
    13,
    7,
    1,
    4,
    10,
    5,
    10,
    2,
    8,
    4,
    7,
    6,
    1,
    5,
    15,
    11,
    9,
    14,
    3,
    12,
    13,
    0,
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    14,
    10,
    4,
    8,
    9,
    15,
    13,
    6,
    1,
    12,
    0,
    2,
    11,
    7,
    5,
    3,
    // Blake1, unused in others
    11,
    8,
    12,
    0,
    5,
    2,
    15,
    13,
    10,
    14,
    3,
    6,
    7,
    1,
    9,
    4,
    7,
    9,
    3,
    1,
    13,
    12,
    11,
    14,
    2,
    6,
    5,
    10,
    4,
    0,
    15,
    8,
    9,
    0,
    5,
    7,
    2,
    4,
    10,
    15,
    14,
    1,
    11,
    12,
    6,
    8,
    3,
    13,
    2,
    12,
    6,
    10,
    0,
    11,
    8,
    3,
    4,
    13,
    7,
    5,
    15,
    14,
    1,
    9
  ]);
  const fromNumH = (n) => n / 2 ** 32 | 0;
  const fromNumL = (n) => n >>> 0;
  const rotrSH = (h, l, s) => h >>> s | l << 32 - s;
  const rotrSL = (h, l, s) => h << 32 - s | l >>> s;
  const rotrBH = (h, l, s) => h << 64 - s | l >>> s - 32;
  const rotrBL = (h, l, s) => h >>> s - 32 | l << 64 - s;
  const rotr32H = (_h, l) => l;
  const rotr32L = (h, _l) => h;
  function add(Ah, Al, Bh, Bl) {
    const l = (Al >>> 0) + (Bl >>> 0);
    return { h: Ah + Bh + (l / 2 ** 32 | 0) | 0, l: l | 0 };
  }
  const add3L = (Al, Bl, Cl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0);
  const add3H = (low, Ah, Bh, Ch) => Ah + Bh + Ch + (low / 2 ** 32 | 0) | 0;
  const B2B_IV = /* @__PURE__ */ Uint32Array.from([
    4089235720,
    1779033703,
    2227873595,
    3144134277,
    4271175723,
    1013904242,
    1595750129,
    2773480762,
    2917565137,
    1359893119,
    725511199,
    2600822924,
    4215389547,
    528734635,
    327033209,
    1541459225
  ]);
  const BBUF = /* @__PURE__ */ new Uint32Array(32);
  function G1b(a, b, c, d, msg, x) {
    const Xl = msg[x], Xh = msg[x + 1];
    let Al = BBUF[2 * a], Ah = BBUF[2 * a + 1];
    let Bl = BBUF[2 * b], Bh = BBUF[2 * b + 1];
    let Cl = BBUF[2 * c], Ch = BBUF[2 * c + 1];
    let Dl = BBUF[2 * d], Dh = BBUF[2 * d + 1];
    const ll = add3L(Al, Bl, Xl);
    Ah = add3H(ll, Ah, Bh, Xh);
    Al = ll | 0;
    let xh = Dh ^ Ah, xl = Dl ^ Al;
    Dh = rotr32H(xh, xl);
    Dl = rotr32L(xh);
    ({ h: Ch, l: Cl } = add(Ch, Cl, Dh, Dl));
    xh = Bh ^ Ch;
    xl = Bl ^ Cl;
    Bh = rotrSH(xh, xl, 24);
    Bl = rotrSL(xh, xl, 24);
    BBUF[2 * a] = Al;
    BBUF[2 * a + 1] = Ah;
    BBUF[2 * b] = Bl;
    BBUF[2 * b + 1] = Bh;
    BBUF[2 * c] = Cl;
    BBUF[2 * c + 1] = Ch;
    BBUF[2 * d] = Dl;
    BBUF[2 * d + 1] = Dh;
  }
  function G2b(a, b, c, d, msg, x) {
    const Xl = msg[x], Xh = msg[x + 1];
    let Al = BBUF[2 * a], Ah = BBUF[2 * a + 1];
    let Bl = BBUF[2 * b], Bh = BBUF[2 * b + 1];
    let Cl = BBUF[2 * c], Ch = BBUF[2 * c + 1];
    let Dl = BBUF[2 * d], Dh = BBUF[2 * d + 1];
    const ll = add3L(Al, Bl, Xl);
    Ah = add3H(ll, Ah, Bh, Xh);
    Al = ll | 0;
    let xh = Dh ^ Ah, xl = Dl ^ Al;
    Dh = rotrSH(xh, xl, 16);
    Dl = rotrSL(xh, xl, 16);
    ({ h: Ch, l: Cl } = add(Ch, Cl, Dh, Dl));
    xh = Bh ^ Ch;
    xl = Bl ^ Cl;
    Bh = rotrBH(xh, xl, 63);
    Bl = rotrBL(xh, xl, 63);
    BBUF[2 * a] = Al;
    BBUF[2 * a + 1] = Ah;
    BBUF[2 * b] = Bl;
    BBUF[2 * b + 1] = Bh;
    BBUF[2 * c] = Cl;
    BBUF[2 * c + 1] = Ch;
    BBUF[2 * d] = Dl;
    BBUF[2 * d + 1] = Dh;
  }
  function checkBlake2Opts(outputLen, opts = {}, keyLen, saltLen, persLen) {
    anumber(keyLen);
    if (outputLen <= 0 || outputLen > keyLen)
      throw new Error('"dkLen" must be 1..' + keyLen + ", got " + outputLen);
    const { key, salt, personalization } = opts;
    if (key !== void 0 && (key.length < 1 || key.length > keyLen))
      throw new Error('"key" expected to be undefined or of length=1..' + keyLen);
    if (salt !== void 0)
      abytes(salt, saltLen, "salt");
    if (personalization !== void 0)
      abytes(personalization, persLen, "personalization");
  }
  class _BLAKE2 {
    buffer;
    buffer32;
    finished = false;
    destroyed = false;
    length = 0;
    pos = 0;
    blockLen;
    outputLen;
    canXOF = false;
    constructor(blockLen, outputLen) {
      anumber(blockLen);
      anumber(outputLen);
      this.blockLen = blockLen;
      this.outputLen = outputLen;
      this.buffer = new Uint8Array(blockLen);
      this.buffer32 = u32(this.buffer);
    }
    update(data) {
      aexists(this);
      abytes(data);
      const { blockLen, buffer, buffer32 } = this;
      const len = data.length;
      const offset = data.byteOffset;
      const buf = data.buffer;
      for (let pos = 0; pos < len; ) {
        if (this.pos === blockLen) {
          swap32IfBE(buffer32);
          this.compress(buffer32, 0, false);
          swap32IfBE(buffer32);
          this.pos = 0;
        }
        const take = Math.min(blockLen - this.pos, len - pos);
        const dataOffset = offset + pos;
        if (take === blockLen && !(dataOffset % 4) && pos + take < len) {
          const data32 = new Uint32Array(buf, dataOffset, Math.floor((len - pos) / 4));
          swap32IfBE(data32);
          for (let pos32 = 0; pos + blockLen < len; pos32 += buffer32.length, pos += blockLen) {
            this.length += blockLen;
            this.compress(data32, pos32, false);
          }
          swap32IfBE(data32);
          continue;
        }
        buffer.set(pos === 0 && take === len ? data : data.subarray(pos, pos + take), this.pos);
        this.pos += take;
        this.length += take;
        pos += take;
      }
      return this;
    }
    digestInto(out) {
      aexists(this);
      aoutput(out, this);
      if (out.byteOffset & 3)
        throw new RangeError('"output" expected 4-byte aligned byteOffset, got ' + out.byteOffset);
      const { pos, buffer32 } = this;
      this.finished = true;
      this.buffer.fill(0, pos);
      swap32IfBE(buffer32);
      this.compress(buffer32, 0, true);
      swap32IfBE(buffer32);
      const state = this.get();
      const out32 = out === this.buffer ? buffer32 : u32(out);
      const full = Math.floor(this.outputLen / 4);
      for (let i = 0; i < full; i++)
        out32[i] = swap8IfBE(state[i]);
      const tail = this.outputLen % 4;
      if (!tail)
        return;
      const off = full * 4;
      const word = state[full];
      for (let i = 0; i < tail; i++)
        out[off + i] = word >>> 8 * i;
    }
    digest() {
      const { buffer, outputLen } = this;
      this.digestInto(buffer);
      const res = buffer.slice(0, outputLen);
      this.destroy();
      return res;
    }
    _cloneInto(to) {
      const { buffer, length, finished, destroyed, outputLen, pos } = this;
      to ||= new this.constructor({ dkLen: outputLen });
      to.set(...this.get());
      to.buffer.set(buffer);
      to.destroyed = destroyed;
      to.finished = finished;
      to.length = length;
      to.pos = pos;
      to.outputLen = outputLen;
      return to;
    }
    clone() {
      return this._cloneInto();
    }
  }
  class _BLAKE2b extends _BLAKE2 {
    // Same IV words as SHA-512 / BLAKE2b, encoded as LE u32 low/high halves.
    v0l = B2B_IV[0] | 0;
    v0h = B2B_IV[1] | 0;
    v1l = B2B_IV[2] | 0;
    v1h = B2B_IV[3] | 0;
    v2l = B2B_IV[4] | 0;
    v2h = B2B_IV[5] | 0;
    v3l = B2B_IV[6] | 0;
    v3h = B2B_IV[7] | 0;
    v4l = B2B_IV[8] | 0;
    v4h = B2B_IV[9] | 0;
    v5l = B2B_IV[10] | 0;
    v5h = B2B_IV[11] | 0;
    v6l = B2B_IV[12] | 0;
    v6h = B2B_IV[13] | 0;
    v7l = B2B_IV[14] | 0;
    v7h = B2B_IV[15] | 0;
    constructor(opts = {}) {
      opts = checkOpts({}, opts);
      const olen = opts.dkLen === void 0 ? 64 : opts.dkLen;
      super(128, olen);
      checkBlake2Opts(olen, opts, 64, 16, 16);
      let { key, personalization, salt } = opts;
      let keyLength = 0;
      if (key !== void 0) {
        abytes(key, void 0, "key");
        keyLength = key.length;
      }
      this.v0l ^= this.outputLen | keyLength << 8 | 1 << 16 | 1 << 24;
      if (salt !== void 0) {
        abytes(salt, void 0, "salt");
        const slt = u32(copyBytes(salt));
        this.v4l ^= swap8IfBE(slt[0]);
        this.v4h ^= swap8IfBE(slt[1]);
        this.v5l ^= swap8IfBE(slt[2]);
        this.v5h ^= swap8IfBE(slt[3]);
      }
      if (personalization !== void 0) {
        abytes(personalization, void 0, "personalization");
        const pers = u32(copyBytes(personalization));
        this.v6l ^= swap8IfBE(pers[0]);
        this.v6h ^= swap8IfBE(pers[1]);
        this.v7l ^= swap8IfBE(pers[2]);
        this.v7h ^= swap8IfBE(pers[3]);
      }
      if (key !== void 0) {
        const tmp = new Uint8Array(this.blockLen);
        tmp.set(key);
        this.update(tmp);
        clean(tmp);
      }
    }
    // prettier-ignore
    get() {
      let { v0l, v0h, v1l, v1h, v2l, v2h, v3l, v3h, v4l, v4h, v5l, v5h, v6l, v6h, v7l, v7h } = this;
      return [v0l, v0h, v1l, v1h, v2l, v2h, v3l, v3h, v4l, v4h, v5l, v5h, v6l, v6h, v7l, v7h];
    }
    // prettier-ignore
    set(v0l, v0h, v1l, v1h, v2l, v2h, v3l, v3h, v4l, v4h, v5l, v5h, v6l, v6h, v7l, v7h) {
      this.v0l = v0l | 0;
      this.v0h = v0h | 0;
      this.v1l = v1l | 0;
      this.v1h = v1h | 0;
      this.v2l = v2l | 0;
      this.v2h = v2h | 0;
      this.v3l = v3l | 0;
      this.v3h = v3h | 0;
      this.v4l = v4l | 0;
      this.v4h = v4h | 0;
      this.v5l = v5l | 0;
      this.v5h = v5h | 0;
      this.v6l = v6l | 0;
      this.v6h = v6h | 0;
      this.v7l = v7l | 0;
      this.v7h = v7h | 0;
    }
    compress(msg, offset, isLast) {
      const { v0l, v0h, v1l, v1h, v2l, v2h, v3l, v3h, v4l, v4h, v5l, v5h, v6l, v6h, v7l, v7h } = this;
      {
        BBUF[0] = v0l;
        BBUF[1] = v0h;
        BBUF[2] = v1l;
        BBUF[3] = v1h;
        BBUF[4] = v2l;
        BBUF[5] = v2h;
        BBUF[6] = v3l;
        BBUF[7] = v3h;
        BBUF[8] = v4l;
        BBUF[9] = v4h;
        BBUF[10] = v5l;
        BBUF[11] = v5h;
        BBUF[12] = v6l;
        BBUF[13] = v6h;
        BBUF[14] = v7l;
        BBUF[15] = v7h;
      }
      BBUF.set(B2B_IV, 16);
      const l = fromNumL(this.length);
      const h = fromNumH(this.length);
      BBUF[24] = B2B_IV[8] ^ l;
      BBUF[25] = B2B_IV[9] ^ h;
      if (isLast) {
        BBUF[28] = ~BBUF[28];
        BBUF[29] = ~BBUF[29];
      }
      let j = 0;
      const s = BSIGMA;
      for (let i = 0; i < 12; i++) {
        G1b(0, 4, 8, 12, msg, offset + 2 * s[j++]);
        G2b(0, 4, 8, 12, msg, offset + 2 * s[j++]);
        G1b(1, 5, 9, 13, msg, offset + 2 * s[j++]);
        G2b(1, 5, 9, 13, msg, offset + 2 * s[j++]);
        G1b(2, 6, 10, 14, msg, offset + 2 * s[j++]);
        G2b(2, 6, 10, 14, msg, offset + 2 * s[j++]);
        G1b(3, 7, 11, 15, msg, offset + 2 * s[j++]);
        G2b(3, 7, 11, 15, msg, offset + 2 * s[j++]);
        G1b(0, 5, 10, 15, msg, offset + 2 * s[j++]);
        G2b(0, 5, 10, 15, msg, offset + 2 * s[j++]);
        G1b(1, 6, 11, 12, msg, offset + 2 * s[j++]);
        G2b(1, 6, 11, 12, msg, offset + 2 * s[j++]);
        G1b(2, 7, 8, 13, msg, offset + 2 * s[j++]);
        G2b(2, 7, 8, 13, msg, offset + 2 * s[j++]);
        G1b(3, 4, 9, 14, msg, offset + 2 * s[j++]);
        G2b(3, 4, 9, 14, msg, offset + 2 * s[j++]);
      }
      this.v0l ^= BBUF[0] ^ BBUF[16];
      this.v0h ^= BBUF[1] ^ BBUF[17];
      this.v1l ^= BBUF[2] ^ BBUF[18];
      this.v1h ^= BBUF[3] ^ BBUF[19];
      this.v2l ^= BBUF[4] ^ BBUF[20];
      this.v2h ^= BBUF[5] ^ BBUF[21];
      this.v3l ^= BBUF[6] ^ BBUF[22];
      this.v3h ^= BBUF[7] ^ BBUF[23];
      this.v4l ^= BBUF[8] ^ BBUF[24];
      this.v4h ^= BBUF[9] ^ BBUF[25];
      this.v5l ^= BBUF[10] ^ BBUF[26];
      this.v5h ^= BBUF[11] ^ BBUF[27];
      this.v6l ^= BBUF[12] ^ BBUF[28];
      this.v6h ^= BBUF[13] ^ BBUF[29];
      this.v7l ^= BBUF[14] ^ BBUF[30];
      this.v7h ^= BBUF[15] ^ BBUF[31];
      clean(BBUF);
    }
    destroy() {
      this.destroyed = true;
      clean(this.buffer32);
      this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
  }
  const blake2b = /* @__PURE__ */ createHasher((opts) => new _BLAKE2b(opts));
  function hashTypedData(typeTag, data) {
    const typeTagBytes = Array.from(`${typeTag}::`).map((e) => e.charCodeAt(0));
    const dataWithTag = new Uint8Array(typeTagBytes.length + data.length);
    dataWithTag.set(typeTagBytes);
    dataWithTag.set(data, typeTagBytes.length);
    return blake2b(dataWithTag, { dkLen: 32 });
  }
  function prepareSuiAddress(address) {
    return normalizeSuiAddress(address).replace("0x", "");
  }
  var TransactionDataBuilder = class TransactionDataBuilder2 {
    static fromKindBytes(bytes) {
      const programmableTx = suiBcs.TransactionKind.parse(bytes).ProgrammableTransaction;
      if (!programmableTx) throw new Error("Unable to deserialize from bytes.");
      return TransactionDataBuilder2.restore({
        version: 2,
        sender: null,
        expiration: null,
        gasData: {
          budget: null,
          owner: null,
          payment: null,
          price: null
        },
        inputs: programmableTx.inputs,
        commands: programmableTx.commands
      });
    }
    static fromBytes(bytes) {
      const data = suiBcs.TransactionData.parse(bytes)?.V1;
      const programmableTx = data.kind.ProgrammableTransaction;
      if (!data || !programmableTx) throw new Error("Unable to deserialize from bytes.");
      return TransactionDataBuilder2.restore({
        version: 2,
        sender: data.sender,
        expiration: data.expiration,
        gasData: data.gasData,
        inputs: programmableTx.inputs,
        commands: programmableTx.commands
      });
    }
    static restore(data) {
      if (data.version === 2) return new TransactionDataBuilder2(parse(TransactionDataSchema, data));
      else return new TransactionDataBuilder2(parse(TransactionDataSchema, transactionDataFromV1(data)));
    }
    /**
    * Generate transaction digest.
    *
    * @param bytes BCS serialized transaction data
    * @returns transaction digest.
    */
    static getDigestFromBytes(bytes) {
      return toBase58(hashTypedData("TransactionData", bytes));
    }
    constructor(clone) {
      this.version = 2;
      this.sender = clone?.sender ?? null;
      this.expiration = clone?.expiration ?? null;
      this.inputs = clone?.inputs ?? [];
      this.commands = clone?.commands ?? [];
      this.gasData = clone?.gasData ?? {
        budget: null,
        price: null,
        owner: null,
        payment: null
      };
    }
    build({ maxSizeBytes = Infinity, overrides, onlyTransactionKind } = {}) {
      const inputs = this.inputs;
      const commands = this.commands;
      const kind = { ProgrammableTransaction: {
        inputs,
        commands
      } };
      if (onlyTransactionKind) return suiBcs.TransactionKind.serialize(kind, { maxSize: maxSizeBytes }).toBytes();
      const expiration = overrides?.expiration ?? this.expiration;
      const sender = overrides?.sender ?? this.sender;
      const gasData = {
        ...this.gasData,
        ...overrides?.gasData
      };
      if (!sender) throw new Error("Missing transaction sender");
      if (!gasData.budget) throw new Error("Missing gas budget");
      if (!gasData.payment) throw new Error("Missing gas payment");
      if (!gasData.price) throw new Error("Missing gas price");
      const transactionData = {
        sender: prepareSuiAddress(sender),
        expiration: expiration ? expiration : { None: true },
        gasData: {
          payment: gasData.payment,
          owner: prepareSuiAddress(this.gasData.owner ?? sender),
          price: BigInt(gasData.price),
          budget: BigInt(gasData.budget)
        },
        kind: { ProgrammableTransaction: {
          inputs,
          commands
        } }
      };
      return suiBcs.TransactionData.serialize({ V1: transactionData }, { maxSize: maxSizeBytes }).toBytes();
    }
    addInput(type, arg) {
      const index = this.inputs.length;
      this.inputs.push(arg);
      return {
        Input: index,
        type,
        $kind: "Input"
      };
    }
    getInputUses(index, fn) {
      this.mapArguments((arg, command) => {
        if (arg.$kind === "Input" && arg.Input === index) fn(arg, command);
        return arg;
      });
    }
    mapCommandArguments(index, fn) {
      const command = this.commands[index];
      switch (command.$kind) {
        case "MoveCall":
          command.MoveCall.arguments = command.MoveCall.arguments.map((arg) => fn(arg, command, index));
          break;
        case "TransferObjects":
          command.TransferObjects.objects = command.TransferObjects.objects.map((arg) => fn(arg, command, index));
          command.TransferObjects.address = fn(command.TransferObjects.address, command, index);
          break;
        case "SplitCoins":
          command.SplitCoins.coin = fn(command.SplitCoins.coin, command, index);
          command.SplitCoins.amounts = command.SplitCoins.amounts.map((arg) => fn(arg, command, index));
          break;
        case "MergeCoins":
          command.MergeCoins.destination = fn(command.MergeCoins.destination, command, index);
          command.MergeCoins.sources = command.MergeCoins.sources.map((arg) => fn(arg, command, index));
          break;
        case "MakeMoveVec":
          command.MakeMoveVec.elements = command.MakeMoveVec.elements.map((arg) => fn(arg, command, index));
          break;
        case "Upgrade":
          command.Upgrade.ticket = fn(command.Upgrade.ticket, command, index);
          break;
        case "$Intent":
          const inputs = command.$Intent.inputs;
          command.$Intent.inputs = {};
          for (const [key, value] of Object.entries(inputs)) command.$Intent.inputs[key] = Array.isArray(value) ? value.map((arg) => fn(arg, command, index)) : fn(value, command, index);
          break;
        case "Publish":
          break;
        default:
          throw new Error(`Unexpected transaction kind: ${command.$kind}`);
      }
    }
    mapArguments(fn) {
      for (const commandIndex of this.commands.keys()) this.mapCommandArguments(commandIndex, fn);
    }
    replaceCommand(index, replacement, resultIndex = index) {
      if (!Array.isArray(replacement)) {
        this.commands[index] = replacement;
        return;
      }
      const sizeDiff = replacement.length - 1;
      this.commands.splice(index, 1, ...structuredClone(replacement));
      this.mapArguments((arg, _command, commandIndex) => {
        if (commandIndex < index + replacement.length) return arg;
        if (typeof resultIndex !== "number") {
          if (arg.$kind === "Result" && arg.Result === index || arg.$kind === "NestedResult" && arg.NestedResult[0] === index) if (!("NestedResult" in arg) || arg.NestedResult[1] === 0) return parse(ArgumentSchema, structuredClone(resultIndex));
          else throw new Error(`Cannot replace command ${index} with a specific result type: NestedResult[${index}, ${arg.NestedResult[1]}] references a nested element that cannot be mapped to the replacement result`);
        }
        switch (arg.$kind) {
          case "Result":
            if (arg.Result === index && typeof resultIndex === "number") arg.Result = resultIndex;
            if (arg.Result > index) arg.Result += sizeDiff;
            break;
          case "NestedResult":
            if (arg.NestedResult[0] === index && typeof resultIndex === "number") return {
              $kind: "NestedResult",
              NestedResult: [resultIndex, arg.NestedResult[1]]
            };
            if (arg.NestedResult[0] > index) arg.NestedResult[0] += sizeDiff;
            break;
        }
        return arg;
      });
    }
    replaceCommandWithTransaction(index, otherTransaction, result) {
      if (result.$kind !== "Result" && result.$kind !== "NestedResult") throw new Error("Result must be of kind Result or NestedResult");
      this.insertTransaction(index, otherTransaction);
      this.replaceCommand(index + otherTransaction.commands.length, [], "Result" in result ? { NestedResult: [result.Result + index, 0] } : { NestedResult: [result.NestedResult[0] + index, result.NestedResult[1]] });
    }
    insertTransaction(atCommandIndex, otherTransaction) {
      const inputMapping = /* @__PURE__ */ new Map();
      const commandMapping = /* @__PURE__ */ new Map();
      for (let i = 0; i < otherTransaction.inputs.length; i++) {
        const otherInput = otherTransaction.inputs[i];
        const id = getIdFromCallArg(otherInput);
        let existingIndex = -1;
        if (id !== void 0) {
          existingIndex = this.inputs.findIndex((input) => getIdFromCallArg(input) === id);
          if (existingIndex !== -1 && this.inputs[existingIndex].Object?.SharedObject && otherInput.Object?.SharedObject) this.inputs[existingIndex].Object.SharedObject.mutable = this.inputs[existingIndex].Object.SharedObject.mutable || otherInput.Object.SharedObject.mutable;
        }
        if (existingIndex !== -1) inputMapping.set(i, existingIndex);
        else {
          const newIndex = this.inputs.length;
          this.inputs.push(otherInput);
          inputMapping.set(i, newIndex);
        }
      }
      for (let i = 0; i < otherTransaction.commands.length; i++) commandMapping.set(i, atCommandIndex + i);
      const remappedCommands = [];
      for (let i = 0; i < otherTransaction.commands.length; i++) {
        const command = structuredClone(otherTransaction.commands[i]);
        remapCommandArguments(command, inputMapping, commandMapping);
        remappedCommands.push(command);
      }
      this.commands.splice(atCommandIndex, 0, ...remappedCommands);
      const sizeDiff = remappedCommands.length;
      if (sizeDiff > 0) this.mapArguments((arg, _command, commandIndex) => {
        if (commandIndex >= atCommandIndex && commandIndex < atCommandIndex + remappedCommands.length) return arg;
        switch (arg.$kind) {
          case "Result":
            if (arg.Result >= atCommandIndex) arg.Result += sizeDiff;
            break;
          case "NestedResult":
            if (arg.NestedResult[0] >= atCommandIndex) arg.NestedResult[0] += sizeDiff;
            break;
        }
        return arg;
      });
    }
    getDigest() {
      const bytes = this.build({ onlyTransactionKind: false });
      return TransactionDataBuilder2.getDigestFromBytes(bytes);
    }
    snapshot() {
      return parse(TransactionDataSchema, this);
    }
    getData() {
      return this.snapshot();
    }
    shallowClone() {
      return new TransactionDataBuilder2({
        version: this.version,
        sender: this.sender,
        expiration: this.expiration,
        gasData: { ...this.gasData },
        inputs: [...this.inputs],
        commands: [...this.commands]
      });
    }
    applyResolvedData(resolved) {
      if (!this.sender) this.sender = resolved.sender ?? null;
      if (!this.expiration) this.expiration = resolved.expiration ?? null;
      if (!this.gasData.budget) this.gasData.budget = resolved.gasData.budget;
      if (!this.gasData.owner) this.gasData.owner = resolved.gasData.owner ?? null;
      if (!this.gasData.payment) this.gasData.payment = resolved.gasData.payment;
      if (!this.gasData.price) this.gasData.price = resolved.gasData.price;
      for (let i = 0; i < this.inputs.length; i++) {
        const input = this.inputs[i];
        const resolvedInput = resolved.inputs[i];
        switch (input.$kind) {
          case "UnresolvedPure":
            if (resolvedInput.$kind !== "Pure") throw new Error(`Expected input at index ${i} to resolve to a Pure argument, but got ${JSON.stringify(resolvedInput)}`);
            this.inputs[i] = resolvedInput;
            break;
          case "UnresolvedObject":
            if (resolvedInput.$kind !== "Object") throw new Error(`Expected input at index ${i} to resolve to an Object argument, but got ${JSON.stringify(resolvedInput)}`);
            if (resolvedInput.Object.$kind === "ImmOrOwnedObject" || resolvedInput.Object.$kind === "Receiving") {
              const original = input.UnresolvedObject;
              const resolved$1 = resolvedInput.Object.ImmOrOwnedObject ?? resolvedInput.Object.Receiving;
              if (normalizeSuiAddress(original.objectId) !== normalizeSuiAddress(resolved$1.objectId) || original.version != null && original.version !== resolved$1.version || original.digest != null && original.digest !== resolved$1.digest || original.mutable != null || original.initialSharedVersion != null) throw new Error(`Input at index ${i} did not match unresolved object. ${JSON.stringify(original)} is not compatible with ${JSON.stringify(resolved$1)}`);
            } else if (resolvedInput.Object.$kind === "SharedObject") {
              const original = input.UnresolvedObject;
              const resolved$1 = resolvedInput.Object.SharedObject;
              if (normalizeSuiAddress(original.objectId) !== normalizeSuiAddress(resolved$1.objectId) || original.initialSharedVersion != null && original.initialSharedVersion !== resolved$1.initialSharedVersion || original.mutable != null && original.mutable !== resolved$1.mutable || original.version != null || original.digest != null) throw new Error(`Input at index ${i} did not match unresolved object. ${JSON.stringify(original)} is not compatible with ${JSON.stringify(resolved$1)}`);
            } else throw new Error(`Input at index ${i} resolved to an unexpected Object kind: ${JSON.stringify(resolvedInput.Object)}`);
            this.inputs[i] = resolvedInput;
            break;
        }
      }
    }
  };
  const TransactionCommands = {
    MoveCall(input) {
      const [pkg, mod = "", fn = ""] = "target" in input ? input.target.split("::") : [
        input.package,
        input.module,
        input.function
      ];
      return {
        $kind: "MoveCall",
        MoveCall: {
          package: pkg,
          module: mod,
          function: fn,
          typeArguments: input.typeArguments ?? [],
          arguments: input.arguments ?? []
        }
      };
    },
    TransferObjects(objects, address) {
      return {
        $kind: "TransferObjects",
        TransferObjects: {
          objects: objects.map((o) => parse(ArgumentSchema, o)),
          address: parse(ArgumentSchema, address)
        }
      };
    },
    SplitCoins(coin, amounts) {
      return {
        $kind: "SplitCoins",
        SplitCoins: {
          coin: parse(ArgumentSchema, coin),
          amounts: amounts.map((o) => parse(ArgumentSchema, o))
        }
      };
    },
    MergeCoins(destination, sources) {
      return {
        $kind: "MergeCoins",
        MergeCoins: {
          destination: parse(ArgumentSchema, destination),
          sources: sources.map((o) => parse(ArgumentSchema, o))
        }
      };
    },
    Publish({ modules, dependencies }) {
      return {
        $kind: "Publish",
        Publish: {
          modules: modules.map((module) => typeof module === "string" ? module : toBase64(new Uint8Array(module))),
          dependencies: dependencies.map((dep) => normalizeSuiObjectId(dep))
        }
      };
    },
    Upgrade({ modules, dependencies, package: packageId, ticket }) {
      return {
        $kind: "Upgrade",
        Upgrade: {
          modules: modules.map((module) => typeof module === "string" ? module : toBase64(new Uint8Array(module))),
          dependencies: dependencies.map((dep) => normalizeSuiObjectId(dep)),
          package: packageId,
          ticket: parse(ArgumentSchema, ticket)
        }
      };
    },
    MakeMoveVec({ type, elements }) {
      return {
        $kind: "MakeMoveVec",
        MakeMoveVec: {
          type: type ?? null,
          elements: elements.map((o) => parse(ArgumentSchema, o))
        }
      };
    },
    Intent({ name, inputs = {}, data = {} }) {
      return {
        $kind: "$Intent",
        $Intent: {
          name,
          inputs: Object.fromEntries(Object.entries(inputs).map(([key, value]) => [key, Array.isArray(value) ? value.map((o) => parse(ArgumentSchema, o)) : parse(ArgumentSchema, value)])),
          data
        }
      };
    }
  };
  function Pure(data) {
    return {
      $kind: "Pure",
      Pure: { bytes: data instanceof Uint8Array ? toBase64(data) : data.toBase64() }
    };
  }
  const Inputs = {
    Pure,
    ObjectRef({ objectId, digest, version }) {
      return {
        $kind: "Object",
        Object: {
          $kind: "ImmOrOwnedObject",
          ImmOrOwnedObject: {
            digest,
            version,
            objectId: normalizeSuiAddress(objectId)
          }
        }
      };
    },
    SharedObjectRef({ objectId, mutable, initialSharedVersion }) {
      return {
        $kind: "Object",
        Object: {
          $kind: "SharedObject",
          SharedObject: {
            mutable,
            initialSharedVersion,
            objectId: normalizeSuiAddress(objectId)
          }
        }
      };
    },
    ReceivingRef({ objectId, digest, version }) {
      return {
        $kind: "Object",
        Object: {
          $kind: "Receiving",
          Receiving: {
            digest,
            version,
            objectId: normalizeSuiAddress(objectId)
          }
        }
      };
    },
    FundsWithdrawal({ reservation, typeArg, withdrawFrom }) {
      return {
        $kind: "FundsWithdrawal",
        FundsWithdrawal: {
          reservation,
          typeArg,
          withdrawFrom
        }
      };
    }
  };
  BigInt(1e9);
  const MOVE_STDLIB_ADDRESS = "0x0000000000000000000000000000000000000000000000000000000000000001";
  const SUI_FRAMEWORK_ADDRESS = "0x0000000000000000000000000000000000000000000000000000000000000002";
  const SUI_CLOCK_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000006";
  const SUI_TYPE_ARG = `${SUI_FRAMEWORK_ADDRESS}::sui::SUI`;
  const SUI_SYSTEM_STATE_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000005";
  const SUI_RANDOM_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000008";
  const SUI_DENY_LIST_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000403";
  function parseTypeName(typeName) {
    const parts = typeName.split("::");
    if (parts.length !== 3) throw new Error(`Invalid type name format: ${typeName}`);
    return {
      package: parts[0],
      module: parts[1],
      name: parts[2]
    };
  }
  function isTxContext(param) {
    if (param.body.$kind !== "datatype") return false;
    const { package: pkg, module, name } = parseTypeName(param.body.datatype.typeName);
    return normalizeSuiAddress(pkg) === SUI_FRAMEWORK_ADDRESS && module === "tx_context" && name === "TxContext";
  }
  function getPureBcsSchema(typeSignature) {
    switch (typeSignature.$kind) {
      case "address":
        return suiBcs.Address;
      case "bool":
        return suiBcs.Bool;
      case "u8":
        return suiBcs.U8;
      case "u16":
        return suiBcs.U16;
      case "u32":
        return suiBcs.U32;
      case "u64":
        return suiBcs.U64;
      case "u128":
        return suiBcs.U128;
      case "u256":
        return suiBcs.U256;
      case "vector": {
        if (typeSignature.vector.$kind === "u8") return suiBcs.byteVector().transform({
          input: (val) => typeof val === "string" ? new TextEncoder().encode(val) : val,
          output: (val) => val
        });
        const type = getPureBcsSchema(typeSignature.vector);
        return type ? suiBcs.vector(type) : null;
      }
      case "datatype": {
        const { package: pkg, module, name } = parseTypeName(typeSignature.datatype.typeName);
        const normalizedPkg = normalizeSuiAddress(pkg);
        if (normalizedPkg === MOVE_STDLIB_ADDRESS) {
          if (module === "ascii" && name === "String") return suiBcs.String;
          if (module === "string" && name === "String") return suiBcs.String;
          if (module === "option" && name === "Option") {
            const type = getPureBcsSchema(typeSignature.datatype.typeParameters[0]);
            return type ? suiBcs.vector(type) : null;
          }
        }
        if (normalizedPkg === SUI_FRAMEWORK_ADDRESS) {
          if (module === "object" && name === "ID") return suiBcs.Address;
        }
        return null;
      }
      case "typeParameter":
      case "unknown":
        return null;
    }
  }
  const ALLOWANCE_BALANCE = "AllowanceBalance";
  const COIN_WITH_BALANCE = "CoinWithBalance";
  const isValidNamedType = (type) => {
    const splitType = type.split(/::|<|>|,/);
    for (const t of splitType) if (t.includes(NAME_SEPARATOR$1) && !isValidNamedPackage(t)) return false;
    return isValidStructTag(type);
  };
  const NAME_SEPARATOR = "/";
  function hasMvrName(nameOrType) {
    return nameOrType.includes(NAME_SEPARATOR) || nameOrType.includes("@") || nameOrType.includes(".sui");
  }
  function findNamesInTransaction(builder) {
    const packages = /* @__PURE__ */ new Set();
    const types = /* @__PURE__ */ new Set();
    for (const command of builder.commands) switch (command.$kind) {
      case "MakeMoveVec":
        if (command.MakeMoveVec.type) getNamesFromTypeList([command.MakeMoveVec.type]).forEach((type) => {
          types.add(type);
        });
        break;
      case "MoveCall":
        const moveCall = command.MoveCall;
        const pkg = moveCall.package.split("::")[0];
        if (hasMvrName(pkg)) {
          if (!isValidNamedPackage(pkg)) throw new Error(`Invalid package name: ${pkg}`);
          packages.add(pkg);
        }
        getNamesFromTypeList(moveCall.typeArguments ?? []).forEach((type) => {
          types.add(type);
        });
        break;
    }
    return {
      packages: [...packages],
      types: [...types]
    };
  }
  function replaceNames(builder, resolved) {
    for (const command of builder.commands) {
      if (command.MakeMoveVec?.type) {
        if (!hasMvrName(command.MakeMoveVec.type)) continue;
        if (!resolved.types[command.MakeMoveVec.type]) throw new Error(`No resolution found for type: ${command.MakeMoveVec.type}`);
        command.MakeMoveVec.type = resolved.types[command.MakeMoveVec.type].type;
      }
      const tx = command.MoveCall;
      if (!tx) continue;
      const nameParts = tx.package.split("::");
      const name = nameParts[0];
      if (hasMvrName(name) && !resolved.packages[name]) throw new Error(`No address found for package: ${name}`);
      if (hasMvrName(name)) {
        nameParts[0] = resolved.packages[name].package;
        tx.package = nameParts.join("::");
      }
      const types = tx.typeArguments;
      if (!types) continue;
      for (let i = 0; i < types.length; i++) {
        if (!hasMvrName(types[i])) continue;
        if (!resolved.types[types[i]]) throw new Error(`No resolution found for type: ${types[i]}`);
        types[i] = resolved.types[types[i]].type;
      }
      tx.typeArguments = types;
    }
  }
  function getNamesFromTypeList(types) {
    const names = /* @__PURE__ */ new Set();
    for (const type of types) if (hasMvrName(type)) {
      if (!isValidNamedType(type)) throw new Error(`Invalid type with names: ${type}`);
      names.add(type);
    }
    return names;
  }
  function transactionUsesGasCoin(transactionData) {
    let usesGasCoin = false;
    transactionData.mapArguments((arg) => {
      if (arg.$kind === "GasCoin") usesGasCoin = true;
      return arg;
    });
    return usesGasCoin;
  }
  var SuiClientError = class extends Error {
  };
  var SimulationError = class extends SuiClientError {
    constructor(message, options) {
      super(message, { cause: options?.cause });
      this.executionError = options?.executionError;
    }
  };
  function deriveDynamicFieldID(parentId, typeTag, key) {
    const address = suiBcs.Address.serialize(parentId).toBytes();
    const tag = suiBcs.TypeTag.serialize(typeTag).toBytes();
    const keyLength = suiBcs.u64().serialize(key.length).toBytes();
    const hash = blake2b.create({ dkLen: 32 });
    hash.update(new Uint8Array([240]));
    hash.update(address);
    hash.update(keyLength);
    hash.update(key);
    hash.update(tag);
    return `0x${toHex(hash.digest().slice(0, 32))}`;
  }
  const SUI_ACCUMULATOR_ROOT_OBJECT_ID = normalizeSuiAddress("0xacc");
  const ACCUMULATOR_KEY_TYPE_TAG = TypeTagSerializer.parseFromStr("0x2::accumulator::Key<0x2::balance::Balance<0x2::sui::SUI>>");
  const COIN_RESERVATION_MAGIC = new Uint8Array([
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172
  ]);
  function deriveReservationObjectId(owner, chainIdentifier) {
    const accBytes = fromHex(deriveDynamicFieldID(SUI_ACCUMULATOR_ROOT_OBJECT_ID, ACCUMULATOR_KEY_TYPE_TAG, suiBcs.Address.serialize(owner).toBytes()).slice(2));
    const chainBytes = fromBase58(chainIdentifier);
    if (chainBytes.length !== 32) throw new Error(`Invalid chain identifier length: expected 32 bytes, got ${chainBytes.length}`);
    const xored = new Uint8Array(32);
    for (let i = 0; i < 32; i++) xored[i] = accBytes[i] ^ chainBytes[i];
    return `0x${toHex(xored)}`;
  }
  function createCoinReservationRef(reservedBalance, owner, chainIdentifier, epoch) {
    const digestBytes = new Uint8Array(32);
    const view = new DataView(digestBytes.buffer);
    view.setBigUint64(0, reservedBalance, true);
    const epochNum = Number(epoch);
    if (!Number.isSafeInteger(epochNum) || epochNum < 0 || epochNum > 4294967295) throw new Error(`Epoch ${epoch} out of u32 range for coin reservation digest`);
    view.setUint32(8, epochNum, true);
    digestBytes.set(COIN_RESERVATION_MAGIC, 12);
    return parse(ObjectRefSchema, {
      objectId: deriveReservationObjectId(owner, chainIdentifier),
      version: "0",
      digest: toBase58(digestBytes)
    });
  }
  const MAX_OBJECTS_PER_FETCH = 50;
  const MAX_GAS_PAYMENT_OBJECTS = 256;
  const GAS_SAFE_OVERHEAD = 1000n;
  const MAX_GAS = 5e10;
  function computeGasBudget(gasUsed, gasPrice = 1n) {
    const safeOverhead = GAS_SAFE_OVERHEAD * BigInt(gasPrice);
    const baseComputationCostWithOverhead = BigInt(gasUsed.computationCost) + safeOverhead;
    const gasBudget = baseComputationCostWithOverhead + BigInt(gasUsed.storageCost) - BigInt(gasUsed.storageRebate);
    return String(gasBudget > baseComputationCostWithOverhead ? gasBudget : baseComputationCostWithOverhead);
  }
  function getClient$1(options) {
    if (!options.client) throw new Error(`No sui client passed to Transaction#build, but transaction data was not sufficient to build offline.`);
    return options.client;
  }
  async function coreClientResolveTransactionPlugin(transactionData, options, next) {
    const client = getClient$1(options);
    const needsGasPrice = !options.onlyTransactionKind && !transactionData.gasData.price;
    const needsPayment = !options.onlyTransactionKind && !transactionData.gasData.payment;
    const gasPayer = transactionData.gasData.owner ?? transactionData.sender;
    const usesGasCoin = transactionUsesGasCoin(transactionData);
    let withdrawals = 0n;
    const normalizedGasPayer = gasPayer ? normalizeSuiAddress(gasPayer) : null;
    for (const input of transactionData.inputs) {
      if (input.$kind !== "FundsWithdrawal" || !normalizedGasPayer) continue;
      if (normalizeStructTag(input.FundsWithdrawal.typeArg.Balance) !== SUI_TYPE_ARG) continue;
      const source = input.FundsWithdrawal.withdrawFrom;
      const withdrawalOwner = source.SenderAllowance ? source.SenderAllowance.funder : source.Sender ? transactionData.sender : gasPayer;
      if (withdrawalOwner && normalizeSuiAddress(withdrawalOwner) === normalizedGasPayer && input.FundsWithdrawal.reservation.$kind === "MaxAmountU64") withdrawals += BigInt(input.FundsWithdrawal.reservation.MaxAmountU64);
    }
    const needsSimulateExpiration = !options.onlyTransactionKind && !transactionData.expiration && !transactionData.gasData.budget;
    const needsSystemState = needsGasPrice || needsPayment && usesGasCoin || needsSimulateExpiration;
    const needsChainId = needsPayment && usesGasCoin || needsSimulateExpiration;
    const [, systemStateResult, balanceResult, coinsResult, chainIdResult] = await Promise.all([
      normalizeInputs(transactionData, client),
      needsSystemState ? client.core.getCurrentSystemState() : null,
      needsPayment && gasPayer ? client.core.getBalance({ owner: gasPayer }) : null,
      needsPayment && gasPayer ? client.core.listCoins({
        owner: gasPayer,
        coinType: SUI_TYPE_ARG
      }) : null,
      needsChainId ? client.core.getChainIdentifier() : null
    ]);
    await resolveObjectReferences(transactionData, client);
    if (!options.onlyTransactionKind) {
      const systemState = systemStateResult?.systemState ?? null;
      const chainIdentifier = chainIdResult?.chainIdentifier ?? null;
      if (systemState && !transactionData.gasData.price) transactionData.gasData.price = systemState.referenceGasPrice;
      await setGasBudget(transactionData, client, needsSimulateExpiration && systemState && chainIdentifier ? buildValidDuringExpiration(systemState, chainIdentifier) : void 0);
      if (needsPayment) {
        if (!balanceResult || !coinsResult) throw new Error("Could not resolve gas payment: a gas owner or sender must be set to fetch balance and coins.");
        setGasPayment({
          transactionData,
          balance: balanceResult,
          coins: coinsResult,
          usesGasCoin,
          withdrawals,
          gasPayer,
          chainIdentifier,
          epoch: systemState?.epoch ?? null
        });
      }
      if (!transactionData.expiration && transactionData.gasData.payment?.length === 0) await setExpiration(transactionData, client, systemState, chainIdentifier);
    }
    return await next();
  }
  async function setGasBudget(transactionData, client, simulateExpiration) {
    if (transactionData.gasData.budget) return;
    const simulateResult = await client.core.simulateTransaction({
      transaction: transactionData.build({ overrides: {
        gasData: {
          budget: String(MAX_GAS),
          payment: []
        },
        ...simulateExpiration && { expiration: simulateExpiration }
      } }),
      include: { effects: true },
      doGasSelection: false
    });
    if (simulateResult.$kind === "FailedTransaction") {
      const executionError = simulateResult.FailedTransaction.status.error ?? void 0;
      throw new SimulationError(`Transaction resolution failed: ${executionError?.message ?? "Unknown error"}`, {
        cause: simulateResult,
        executionError
      });
    }
    transactionData.gasData.budget = computeGasBudget(simulateResult.Transaction.effects.gasUsed, transactionData.gasData.price ? String(transactionData.gasData.price) : void 0);
  }
  function setGasPayment({ transactionData, balance, coins, usesGasCoin, withdrawals, gasPayer, chainIdentifier, epoch }) {
    const budget = BigInt(transactionData.gasData.budget);
    const addressBalance = BigInt(balance.balance.addressBalance);
    if (budget === 0n || !usesGasCoin && addressBalance >= budget + withdrawals) {
      transactionData.gasData.payment = [];
      return;
    }
    const filteredCoins = coins.objects.filter((coin) => {
      return !transactionData.inputs.find((input) => {
        if (input.Object?.ImmOrOwnedObject) return coin.objectId === input.Object.ImmOrOwnedObject.objectId;
        return false;
      });
    });
    const paymentCoins = filteredCoins.map((coin) => ({
      objectId: coin.objectId,
      digest: coin.digest,
      version: coin.version
    }));
    const reservationAmount = addressBalance - withdrawals;
    if (usesGasCoin && reservationAmount > 0n && chainIdentifier && epoch) transactionData.gasData.payment = [createCoinReservationRef(reservationAmount, gasPayer, chainIdentifier, epoch), ...paymentCoins.slice(0, MAX_GAS_PAYMENT_OBJECTS - 1)];
    else if (!filteredCoins.length) throw new Error("No valid gas coins found for the transaction.");
    else transactionData.gasData.payment = paymentCoins.slice(0, MAX_GAS_PAYMENT_OBJECTS);
  }
  async function setExpiration(transactionData, client, systemState, existingChainIdentifier = null) {
    const [chainIdentifier, resolvedSystemState] = await Promise.all([existingChainIdentifier ?? client.core.getChainIdentifier().then((r) => r.chainIdentifier), systemState ?? client.core.getCurrentSystemState().then((r) => r.systemState)]);
    transactionData.expiration = buildValidDuringExpiration(resolvedSystemState, chainIdentifier);
  }
  function buildValidDuringExpiration(systemState, chainIdentifier) {
    const currentEpoch = BigInt(systemState.epoch);
    return {
      $kind: "ValidDuring",
      ValidDuring: {
        minEpoch: String(currentEpoch),
        maxEpoch: String(currentEpoch + 1n),
        minTimestamp: null,
        maxTimestamp: null,
        chain: chainIdentifier,
        nonce: Math.random() * 4294967296 >>> 0
      }
    };
  }
  async function resolveObjectReferences(transactionData, client) {
    const objectsToResolve = transactionData.inputs.filter((input) => {
      return input.UnresolvedObject && !(input.UnresolvedObject.version || input.UnresolvedObject?.initialSharedVersion);
    });
    const dedupedIds = [...new Set(objectsToResolve.map((input) => normalizeSuiObjectId(input.UnresolvedObject.objectId)))];
    const objectChunks = dedupedIds.length ? chunk(dedupedIds, MAX_OBJECTS_PER_FETCH) : [];
    const resolved = (await Promise.all(objectChunks.map((chunkIds) => client.core.getObjects({ objectIds: chunkIds })))).flatMap((result) => result.objects);
    const responsesById = new Map(dedupedIds.map((id, index) => {
      return [id, resolved[index]];
    }));
    const invalidObjects = Array.from(responsesById).filter(([_, obj]) => obj instanceof Error).map(([_, obj]) => obj.message);
    if (invalidObjects.length) throw new Error(`The following input objects are invalid: ${invalidObjects.join(", ")}`);
    const objects = resolved.map((object2) => {
      if (object2 instanceof Error) throw new Error(`Failed to fetch object: ${object2.message}`);
      const owner = object2.owner;
      const initialSharedVersion = owner && typeof owner === "object" ? owner.$kind === "Shared" ? owner.Shared.initialSharedVersion : owner.$kind === "ConsensusAddressOwner" ? owner.ConsensusAddressOwner.startVersion : null : null;
      return {
        objectId: object2.objectId,
        digest: object2.digest,
        version: object2.version,
        initialSharedVersion
      };
    });
    const objectsById = new Map(dedupedIds.map((id, index) => {
      return [id, objects[index]];
    }));
    for (const [index, input] of transactionData.inputs.entries()) {
      if (!input.UnresolvedObject) continue;
      let updated;
      const id = normalizeSuiAddress(input.UnresolvedObject.objectId);
      const object2 = objectsById.get(id);
      if (input.UnresolvedObject.initialSharedVersion ?? object2?.initialSharedVersion) updated = Inputs.SharedObjectRef({
        objectId: id,
        initialSharedVersion: input.UnresolvedObject.initialSharedVersion || object2?.initialSharedVersion,
        mutable: input.UnresolvedObject.mutable || isUsedAsMutable(transactionData, index)
      });
      else if (isUsedAsReceiving(transactionData, index)) updated = Inputs.ReceivingRef({
        objectId: id,
        digest: input.UnresolvedObject.digest ?? object2?.digest,
        version: input.UnresolvedObject.version ?? object2?.version
      });
      transactionData.inputs[transactionData.inputs.indexOf(input)] = updated ?? Inputs.ObjectRef({
        objectId: id,
        digest: input.UnresolvedObject.digest ?? object2?.digest,
        version: input.UnresolvedObject.version ?? object2?.version
      });
    }
  }
  async function normalizeInputs(transactionData, client) {
    const { inputs, commands } = transactionData;
    const moveCallsToResolve = [];
    const moveFunctionsToResolve = /* @__PURE__ */ new Set();
    commands.forEach((command) => {
      if (command.MoveCall) {
        if (command.MoveCall._argumentTypes) return;
        if (command.MoveCall.arguments.map((arg) => {
          if (arg.$kind === "Input") return transactionData.inputs[arg.Input];
          return null;
        }).some((input) => input?.UnresolvedPure || input?.UnresolvedObject && typeof input?.UnresolvedObject.mutable !== "boolean")) {
          const functionName = `${command.MoveCall.package}::${command.MoveCall.module}::${command.MoveCall.function}`;
          moveFunctionsToResolve.add(functionName);
          moveCallsToResolve.push(command.MoveCall);
        }
      }
    });
    const moveFunctionParameters = /* @__PURE__ */ new Map();
    if (moveFunctionsToResolve.size > 0) await Promise.all([...moveFunctionsToResolve].map(async (functionName) => {
      const [packageId, moduleName, name] = functionName.split("::");
      const { function: def } = await client.core.getMoveFunction({
        packageId,
        moduleName,
        name
      });
      moveFunctionParameters.set(functionName, def.parameters);
    }));
    if (moveCallsToResolve.length) await Promise.all(moveCallsToResolve.map(async (moveCall) => {
      const parameters = moveFunctionParameters.get(`${moveCall.package}::${moveCall.module}::${moveCall.function}`);
      if (!parameters) return;
      moveCall._argumentTypes = parameters.length > 0 && isTxContext(parameters.at(-1)) ? parameters.slice(0, parameters.length - 1) : parameters;
    }));
    commands.forEach((command) => {
      if (!command.MoveCall) return;
      const moveCall = command.MoveCall;
      const fnName = `${moveCall.package}::${moveCall.module}::${moveCall.function}`;
      const params = moveCall._argumentTypes;
      if (!params) return;
      if (params.length !== command.MoveCall.arguments.length) throw new Error(`Incorrect number of arguments for ${fnName}`);
      params.forEach((param, i) => {
        const arg = moveCall.arguments[i];
        if (arg.$kind !== "Input") return;
        const input = inputs[arg.Input];
        if (!input.UnresolvedPure && !input.UnresolvedObject) return;
        const inputValue = input.UnresolvedPure?.value ?? input.UnresolvedObject?.objectId;
        const schema = getPureBcsSchema(param.body);
        if (schema) {
          arg.type = "pure";
          inputs[inputs.indexOf(input)] = Inputs.Pure(schema.serialize(inputValue));
          return;
        }
        if (typeof inputValue !== "string") throw new Error(`Expect the argument to be an object id string, got ${JSON.stringify(inputValue, null, 2)}`);
        arg.type = "object";
        const unresolvedObject = input.UnresolvedPure ? {
          $kind: "UnresolvedObject",
          UnresolvedObject: { objectId: inputValue }
        } : input;
        inputs[arg.Input] = unresolvedObject;
      });
    });
  }
  function isUsedAsMutable(transactionData, index) {
    let usedAsMutable = false;
    transactionData.getInputUses(index, (arg, tx) => {
      if (tx.MoveCall && tx.MoveCall._argumentTypes) {
        const argIndex = tx.MoveCall.arguments.indexOf(arg);
        usedAsMutable = tx.MoveCall._argumentTypes[argIndex].reference !== "immutable" || usedAsMutable;
      }
      if (tx.$kind === "MakeMoveVec" || tx.$kind === "MergeCoins" || tx.$kind === "SplitCoins" || tx.$kind === "TransferObjects") usedAsMutable = true;
    });
    return usedAsMutable;
  }
  function isUsedAsReceiving(transactionData, index) {
    let usedAsReceiving = false;
    transactionData.getInputUses(index, (arg, tx) => {
      if (tx.MoveCall && tx.MoveCall._argumentTypes) {
        const argIndex = tx.MoveCall.arguments.indexOf(arg);
        usedAsReceiving = isReceivingType(tx.MoveCall._argumentTypes[argIndex]) || usedAsReceiving;
      }
    });
    return usedAsReceiving;
  }
  const RECEIVING_TYPE = "0x0000000000000000000000000000000000000000000000000000000000000002::transfer::Receiving";
  function isReceivingType(type) {
    if (type.body.$kind !== "datatype") return false;
    return type.body.datatype.typeName === RECEIVING_TYPE;
  }
  function needsTransactionResolution(data, options) {
    if (data.inputs.some((input) => {
      return input.UnresolvedObject || input.UnresolvedPure;
    })) return true;
    if (!options.onlyTransactionKind) {
      if (!data.gasData.price || !data.gasData.budget) return true;
      if (!data.gasData.payment) {
        if (!(options.assumeSufficientAddressBalances && !transactionUsesGasCoin(data)) || data.expiration?.$kind !== "ValidDuring" && data.expiration?.$kind !== "Validity") return true;
      } else if (data.gasData.payment.length === 0 && !data.expiration) return true;
    }
    return false;
  }
  async function resolveTransactionPlugin(transactionData, options, next) {
    normalizeRawArguments(transactionData);
    if (!needsTransactionResolution(transactionData, options)) {
      if (!options.onlyTransactionKind && !transactionData.gasData.payment) transactionData.gasData.payment = [];
      await validate(transactionData);
      return next();
    }
    return (getClient(options).core?.resolveTransactionPlugin() ?? coreClientResolveTransactionPlugin)(transactionData, options, async () => {
      await validate(transactionData);
      await next();
    });
  }
  function validate(transactionData) {
    transactionData.inputs.forEach((input, index) => {
      if (input.$kind !== "Object" && input.$kind !== "Pure" && input.$kind !== "FundsWithdrawal") throw new Error(`Input at index ${index} has not been resolved.  Expected a Pure, Object, or FundsWithdrawal input, but found ${JSON.stringify(input)}`);
    });
  }
  function getClient(options) {
    if (!options.client) throw new Error(`No sui client passed to Transaction#build, but transaction data was not sufficient to build offline.`);
    return options.client;
  }
  function normalizeRawArguments(transactionData) {
    for (const command of transactionData.commands) switch (command.$kind) {
      case "SplitCoins":
        command.SplitCoins.amounts.forEach((amount) => {
          normalizeRawArgument(amount, suiBcs.U64, transactionData);
        });
        break;
      case "TransferObjects":
        normalizeRawArgument(command.TransferObjects.address, suiBcs.Address, transactionData);
        break;
    }
  }
  function normalizeRawArgument(arg, schema, transactionData) {
    if (arg.$kind !== "Input") return;
    const input = transactionData.inputs[arg.Input];
    if (input.$kind !== "UnresolvedPure") return;
    transactionData.inputs[arg.Input] = Inputs.Pure(schema.serialize(input.UnresolvedPure.value));
  }
  const AllowanceBalanceData = /* @__PURE__ */ object({
    objectId: /* @__PURE__ */ string(),
    funder: /* @__PURE__ */ optional(/* @__PURE__ */ string()),
    appType: /* @__PURE__ */ optional(/* @__PURE__ */ string()),
    type: /* @__PURE__ */ string(),
    amount: /* @__PURE__ */ string(),
    outputKind: /* @__PURE__ */ picklist(["coin", "balance"])
  });
  const AllowanceMetadata = suiBcs.struct("AllowanceMetadata", {
    id: suiBcs.Address,
    funder: suiBcs.Address,
    spender: suiBcs.option(suiBcs.Address),
    app: suiBcs.option(suiBcs.string())
  });
  function allowanceBalance({ allowance, amount, type = "0x2::sui::SUI", outputKind }) {
    suiBcs.U64.validate(amount);
    const objectId = normalizeSuiAddress(typeof allowance === "string" ? allowance : allowance.objectId);
    const reference = typeof allowance === "string" ? {} : allowance;
    return (tx) => {
      tx.addIntentResolver(ALLOWANCE_BALANCE, resolveBalances);
      return tx.add(TransactionCommands.Intent({
        name: ALLOWANCE_BALANCE,
        inputs: {
          allowance: tx.object(objectId),
          clock: tx.object.clock(),
          ...reference.app ? { permit: tx.object(reference.app.permit) } : {}
        },
        data: {
          objectId,
          funder: reference.funder ? normalizeSuiAddress(reference.funder) : void 0,
          appType: reference.app ? normalizeStructTag(reference.app.type) : void 0,
          type: normalizeStructTag(type),
          amount: String(amount),
          outputKind
        }
      }));
    };
  }
  const resolveAllowanceBalance = async (transactionData, options, next) => {
    const ids = /* @__PURE__ */ new Set();
    const namedTypes = /* @__PURE__ */ new Set();
    for (const command of transactionData.commands) {
      if (command.$kind !== "$Intent" || command.$Intent.name !== ALLOWANCE_BALANCE) continue;
      const data = parse(AllowanceBalanceData, command.$Intent.data);
      if (!data.funder) ids.add(data.objectId);
      for (const type of [data.type, data.appType]) if (type && hasMvrName(type)) namedTypes.add(type);
    }
    const [resolvedTypes, objects] = await Promise.all([namedTypes.size ? getClient(options).core.mvr.resolve({ types: [...namedTypes] }) : void 0, ids.size ? getClient(options).core.getObjects({
      objectIds: [...ids],
      include: { content: true }
    }).then((result) => result.objects) : []]);
    const allowances = /* @__PURE__ */ new Map();
    for (const object$1 of objects) {
      if (object$1 instanceof Error) throw object$1;
      allowances.set(object$1.objectId, object$1);
    }
    for (let index = 0; index < transactionData.commands.length; index++) {
      const command = transactionData.commands[index];
      if (command.$kind !== "$Intent" || command.$Intent.name !== ALLOWANCE_BALANCE) continue;
      const data = parse(AllowanceBalanceData, command.$Intent.data);
      if (hasMvrName(data.type)) {
        const resolved = resolvedTypes?.types[data.type];
        if (!resolved) throw new Error(`No resolution found for type: ${data.type}`);
        data.type = normalizeStructTag(resolved.type);
      }
      if (data.appType && hasMvrName(data.appType)) {
        const resolved = resolvedTypes?.types[data.appType];
        if (!resolved) throw new Error(`No resolution found for type: ${data.appType}`);
        data.appType = normalizeStructTag(resolved.type);
      }
      let funder = data.funder;
      if (!funder) {
        const allowance = allowances.get(data.objectId);
        const expectedType = normalizeStructTag(`0x2::allowance::Allowance<0x2::balance::Balance<${data.type}>>`);
        if (!allowance || allowance.type !== expectedType || allowance.owner.$kind !== "Shared") throw new Error(`Expected a shared ${expectedType} allowance at ${data.objectId}`);
        const metadata = AllowanceMetadata.parse(allowance.content);
        if (metadata.app !== null && !data.appType) throw new Error(`Allowance ${data.objectId} is app-bound; pass allowance.app with the app type and SpendPermit`);
        if (data.appType && (metadata.app === null || normalizeStructTag(metadata.app) !== data.appType)) throw new Error(`Allowance ${data.objectId} is not bound to app ${data.appType}`);
        funder = metadata.funder;
        const input = command.$Intent.inputs.allowance;
        if (input.$kind === "Input") transactionData.inputs[input.Input] = Inputs.SharedObjectRef({
          objectId: data.objectId,
          initialSharedVersion: allowance.owner.Shared.initialSharedVersion,
          mutable: true
        });
      }
      const allowanceArgument = command.$Intent.inputs.allowance;
      if (allowanceArgument.$kind === "Input") {
        const input = transactionData.inputs[allowanceArgument.Input];
        if (input.Object?.SharedObject) input.Object.SharedObject.mutable = true;
        if (input.UnresolvedObject) input.UnresolvedObject.mutable = true;
      }
      const withdrawal = transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
        reservation: {
          $kind: "MaxAmountU64",
          MaxAmountU64: data.amount
        },
        typeArg: {
          $kind: "Balance",
          Balance: data.type
        },
        withdrawFrom: {
          $kind: "SenderAllowance",
          SenderAllowance: {
            funder,
            allowance: data.objectId
          }
        }
      }));
      const commands = [TransactionCommands.MoveCall({
        target: data.appType ? "0x2::allowance::app_balance_spend" : "0x2::allowance::balance_spend",
        typeArguments: data.appType ? [data.type, data.appType] : [data.type],
        arguments: [
          command.$Intent.inputs.allowance,
          ...data.appType ? [command.$Intent.inputs.permit] : [],
          withdrawal,
          command.$Intent.inputs.clock
        ]
      })];
      if (data.outputKind === "coin") commands.push(TransactionCommands.MoveCall({
        target: "0x2::coin::from_balance",
        typeArguments: [data.type],
        arguments: [{
          $kind: "Result",
          Result: index
        }]
      }));
      transactionData.replaceCommand(index, commands, { NestedResult: [index + commands.length - 1, 0] });
      index += commands.length - 1;
    }
    return next();
  };
  async function resolveBalances(transactionData, options, next) {
    const intents = new Set(options.intentNames ?? [ALLOWANCE_BALANCE, COIN_WITH_BALANCE]);
    const shouldResolve = (name) => intents.has(name) && !options.supportedIntents?.includes(name) && transactionData.commands.some((command) => command.$Intent?.name === name);
    if (shouldResolve(ALLOWANCE_BALANCE)) await resolveAllowanceBalance(transactionData, options, async () => {
    });
    if (shouldResolve(COIN_WITH_BALANCE)) await resolveCoinBalance(transactionData, options, async () => {
    });
    await next();
  }
  const SUI_TYPE = normalizeStructTag("0x2::sui::SUI");
  function coinWithBalance({ type = SUI_TYPE, balance, useGasCoin = true }) {
    let coinResult = null;
    return (tx) => {
      if (coinResult) return coinResult;
      tx.addIntentResolver(COIN_WITH_BALANCE, resolveBalances);
      const coinType = type === "gas" ? type : normalizeStructTag(type);
      coinResult = tx.add(TransactionCommands.Intent({
        name: COIN_WITH_BALANCE,
        inputs: {},
        data: {
          type: coinType === SUI_TYPE && useGasCoin ? "gas" : coinType,
          balance: BigInt(balance),
          outputKind: "coin"
        }
      }));
      return coinResult;
    };
  }
  function createBalance({ type = SUI_TYPE, balance, useGasCoin = true }) {
    let balanceResult = null;
    return (tx) => {
      if (balanceResult) return balanceResult;
      tx.addIntentResolver(COIN_WITH_BALANCE, resolveBalances);
      const coinType = type === "gas" ? type : normalizeStructTag(type);
      balanceResult = tx.add(TransactionCommands.Intent({
        name: COIN_WITH_BALANCE,
        inputs: {},
        data: {
          type: coinType === SUI_TYPE && useGasCoin ? "gas" : coinType,
          balance: BigInt(balance),
          outputKind: "balance"
        }
      }));
      return balanceResult;
    };
  }
  const CoinWithBalanceData = /* @__PURE__ */ object({
    type: /* @__PURE__ */ string(),
    balance: /* @__PURE__ */ pipe(/* @__PURE__ */ union([
      /* @__PURE__ */ bigint(),
      /* @__PURE__ */ string(),
      /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer())
    ]), /* @__PURE__ */ transform((value) => BigInt(value))),
    outputKind: /* @__PURE__ */ optional(/* @__PURE__ */ picklist(["coin", "balance"]))
  });
  async function resolveCoinBalance(transactionData, buildOptions, next) {
    const coinTypes = /* @__PURE__ */ new Set();
    const totalByType = /* @__PURE__ */ new Map();
    const intentsByType = /* @__PURE__ */ new Map();
    if (!transactionData.sender) throw new Error("Sender must be set to resolve CoinWithBalance");
    if (transactionData.commands.some((command) => command.$Intent?.name === ALLOWANCE_BALANCE)) throw new Error("Resolve AllowanceBalance together with CoinWithBalance, or preserve both intents");
    const reservedByType = /* @__PURE__ */ new Map();
    for (const input of transactionData.inputs) {
      if (!input.FundsWithdrawal) continue;
      const { withdrawFrom, typeArg, reservation } = input.FundsWithdrawal;
      if (normalizeSuiAddress(withdrawFrom.SenderAllowance?.funder ?? (withdrawFrom.Sender ? transactionData.sender : transactionData.gasData.owner ?? transactionData.sender)) !== normalizeSuiAddress(transactionData.sender)) continue;
      const type = normalizeStructTag(typeArg.Balance);
      reservedByType.set(type, (reservedByType.get(type) ?? 0n) + BigInt(reservation.MaxAmountU64));
    }
    for (const [i, command] of transactionData.commands.entries()) {
      if (command.$kind !== "$Intent" || command.$Intent.name !== COIN_WITH_BALANCE) continue;
      const { type, balance, outputKind } = parse(CoinWithBalanceData, command.$Intent.data);
      if (balance === 0n) {
        const coinType = type === "gas" ? SUI_TYPE : type;
        transactionData.replaceCommand(i, TransactionCommands.MoveCall({
          target: (outputKind ?? "coin") === "balance" ? "0x2::balance::zero" : "0x2::coin::zero",
          typeArguments: [coinType]
        }));
        continue;
      }
      if (type !== "gas") coinTypes.add(type);
      totalByType.set(type, (totalByType.get(type) ?? 0n) + balance);
      if (!intentsByType.has(type)) intentsByType.set(type, []);
      intentsByType.get(type).push({
        balance,
        outputKind: outputKind ?? "coin"
      });
    }
    if (totalByType.has("gas") && totalByType.has(SUI_TYPE)) throw new Error("Cannot mix SUI CoinWithBalance intents that use the gas coin with ones that do not (useGasCoin: false). Use one or the other.");
    const usedIds = /* @__PURE__ */ new Set();
    for (const input of transactionData.inputs) {
      if (input.Object?.ImmOrOwnedObject) usedIds.add(input.Object.ImmOrOwnedObject.objectId);
      if (input.UnresolvedObject?.objectId) usedIds.add(input.UnresolvedObject.objectId);
    }
    const coinsByType = /* @__PURE__ */ new Map();
    const addressBalanceByType = /* @__PURE__ */ new Map();
    const client = buildOptions.client;
    const assumeSufficientAddressBalances = buildOptions.assumeSufficientAddressBalances;
    if (!client && !assumeSufficientAddressBalances) throw new Error("Client must be provided to build or serialize transactions with CoinWithBalance intents");
    if (assumeSufficientAddressBalances) for (const [coinType, balance] of totalByType) addressBalanceByType.set(coinType, balance);
    else await Promise.all([...[...coinTypes].map(async (coinType) => {
      const { coins, addressBalance } = await getCoinsAndBalanceOfType({
        coinType,
        balance: totalByType.get(coinType),
        client,
        owner: transactionData.sender,
        usedIds,
        reserved: reservedByType.get(coinType) ?? 0n
      });
      coinsByType.set(coinType, coins);
      addressBalanceByType.set(coinType, addressBalance);
    }), totalByType.has("gas") ? await client.core.getBalance({
      owner: transactionData.sender,
      coinType: SUI_TYPE
    }).then(({ balance }) => {
      addressBalanceByType.set("gas", availableAddressBalance(balance.addressBalance, reservedByType.get(SUI_TYPE) ?? 0n));
    }) : null]);
    const exactBalanceByType = /* @__PURE__ */ new Map();
    const usedAddressBalance = /* @__PURE__ */ new Set();
    const typeState = /* @__PURE__ */ new Map();
    let index = 0;
    while (index < transactionData.commands.length) {
      const transaction = transactionData.commands[index];
      if (transaction.$kind !== "$Intent" || transaction.$Intent.name !== COIN_WITH_BALANCE) {
        index++;
        continue;
      }
      const { type, balance } = parse(CoinWithBalanceData, transaction.$Intent.data);
      const coinType = type === "gas" ? SUI_TYPE : type;
      const totalRequired = totalByType.get(type);
      const addressBalance = addressBalanceByType.get(type) ?? 0n;
      const commands = [];
      let intentResult;
      const intentsForType = intentsByType.get(type) ?? [];
      if (intentsForType.every((i) => i.outputKind === "balance") && addressBalance >= totalRequired) {
        commands.push(TransactionCommands.MoveCall({
          target: "0x2::balance::redeem_funds",
          typeArguments: [coinType],
          arguments: [transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
            reservation: {
              $kind: "MaxAmountU64",
              MaxAmountU64: String(balance)
            },
            typeArg: {
              $kind: "Balance",
              Balance: coinType
            },
            withdrawFrom: {
              $kind: "Sender",
              Sender: true
            }
          }))]
        }));
        intentResult = {
          $kind: "NestedResult",
          NestedResult: [index + commands.length - 1, 0]
        };
      } else {
        if (!typeState.has(type)) {
          const intents = intentsForType;
          const sources = [];
          if (addressBalance >= totalRequired) {
            usedAddressBalance.add(type);
            commands.push(TransactionCommands.MoveCall({
              target: "0x2::coin::redeem_funds",
              typeArguments: [coinType],
              arguments: [transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
                reservation: {
                  $kind: "MaxAmountU64",
                  MaxAmountU64: String(totalRequired)
                },
                typeArg: {
                  $kind: "Balance",
                  Balance: coinType
                },
                withdrawFrom: {
                  $kind: "Sender",
                  Sender: true
                }
              }))]
            }));
            sources.push({
              $kind: "Result",
              Result: index + commands.length - 1
            });
          } else if (type === "gas") sources.push({
            $kind: "GasCoin",
            GasCoin: true
          });
          else {
            const coins = coinsByType.get(type);
            const loadedCoinBalance = coins.reduce((sum, c) => sum + BigInt(c.balance), 0n);
            const abNeeded = totalRequired > loadedCoinBalance ? totalRequired - loadedCoinBalance : 0n;
            exactBalanceByType.set(type, loadedCoinBalance + abNeeded === totalRequired);
            for (const coin of coins) sources.push(transactionData.addInput("object", Inputs.ObjectRef({
              objectId: coin.objectId,
              digest: coin.digest,
              version: coin.version
            })));
            if (abNeeded > 0n) {
              usedAddressBalance.add(type);
              commands.push(TransactionCommands.MoveCall({
                target: "0x2::coin::redeem_funds",
                typeArguments: [coinType],
                arguments: [transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
                  reservation: {
                    $kind: "MaxAmountU64",
                    MaxAmountU64: String(abNeeded)
                  },
                  typeArg: {
                    $kind: "Balance",
                    Balance: coinType
                  },
                  withdrawFrom: {
                    $kind: "Sender",
                    Sender: true
                  }
                }))]
              }));
              sources.push({
                $kind: "Result",
                Result: index + commands.length - 1
              });
            }
          }
          const baseCoin = sources[0];
          const rest = sources.slice(1);
          for (let i = 0; i < rest.length; i += 500) commands.push(TransactionCommands.MergeCoins(baseCoin, rest.slice(i, i + 500)));
          const splitCmdIndex = index + commands.length;
          commands.push(TransactionCommands.SplitCoins(baseCoin, intents.map((i) => transactionData.addInput("pure", Inputs.Pure(suiBcs.u64().serialize(i.balance))))));
          const results = [];
          for (let i = 0; i < intents.length; i++) {
            const splitResult = {
              $kind: "NestedResult",
              NestedResult: [splitCmdIndex, i]
            };
            if (intents[i].outputKind === "balance") {
              commands.push(TransactionCommands.MoveCall({
                target: "0x2::coin::into_balance",
                typeArguments: [coinType],
                arguments: [splitResult]
              }));
              results.push({
                $kind: "NestedResult",
                NestedResult: [index + commands.length - 1, 0]
              });
            } else results.push(splitResult);
          }
          if (type !== "gas" || usedAddressBalance.has(type)) {
            const hasBalanceIntent = intents.some((intent) => intent.outputKind === "balance");
            const sourcedFromAB = usedAddressBalance.has(type);
            if (hasBalanceIntent || sourcedFromAB) commands.push(TransactionCommands.MoveCall({
              target: "0x2::coin::send_funds",
              typeArguments: [coinType],
              arguments: [baseCoin, transactionData.addInput("pure", Inputs.Pure(suiBcs.Address.serialize(transactionData.sender)))]
            }));
            else if (exactBalanceByType.get(type)) commands.push(TransactionCommands.MoveCall({
              target: "0x2::coin::destroy_zero",
              typeArguments: [coinType],
              arguments: [baseCoin]
            }));
          }
          typeState.set(type, {
            results,
            nextIntent: 0
          });
        }
        const state = typeState.get(type);
        intentResult = state.results[state.nextIntent++];
      }
      transactionData.replaceCommand(index, commands, intentResult);
      index += commands.length;
    }
    return next();
  }
  async function getCoinsAndBalanceOfType({ coinType, balance, client, owner, usedIds, reserved }) {
    let remainingBalance = balance;
    const coins = [];
    const balanceRequest = client.core.getBalance({
      owner,
      coinType
    }).then(({ balance: balance$1 }) => {
      const addressBalance = availableAddressBalance(balance$1.addressBalance, reserved);
      remainingBalance -= addressBalance;
      return {
        ...balance$1,
        addressBalance: String(addressBalance),
        balance: String(BigInt(balance$1.balance) - reserved)
      };
    });
    const [allCoins, balanceResponse] = await Promise.all([loadMoreCoins(), balanceRequest]);
    if (BigInt(balanceResponse.balance) < balance) throw new Error(`Insufficient balance of ${coinType} for owner ${owner}. Required: ${balance}, Available: ${balance - remainingBalance}`);
    return {
      coins: allCoins,
      balance: BigInt(balanceResponse.coinBalance),
      addressBalance: BigInt(balanceResponse.addressBalance),
      coinBalance: BigInt(balanceResponse.coinBalance)
    };
    async function loadMoreCoins(cursor = null) {
      const { objects, hasNextPage, cursor: nextCursor } = await client.core.listCoins({
        owner,
        coinType,
        cursor
      });
      await balanceRequest;
      for (const coin of objects) {
        if (usedIds.has(coin.objectId)) continue;
        coins.push(coin);
        remainingBalance -= BigInt(coin.balance);
      }
      if (remainingBalance > 0n && hasNextPage) return loadMoreCoins(nextCursor);
      return coins;
    }
  }
  function availableAddressBalance(balance, reserved) {
    const available = BigInt(balance) - reserved;
    if (available < 0n) throw new Error(`Insufficient address balance for existing withdrawals. Required: ${reserved}, Available: ${balance}`);
    return available;
  }
  function enumUnion(options) {
    return /* @__PURE__ */ union(Object.entries(options).map(([key, value]) => /* @__PURE__ */ object({ [key]: value })));
  }
  const Argument = enumUnion({
    GasCoin: /* @__PURE__ */ literal(true),
    Input: /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()),
    Result: /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()),
    NestedResult: /* @__PURE__ */ tuple([/* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()), /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer())])
  });
  const GasData = /* @__PURE__ */ object({
    budget: /* @__PURE__ */ nullable(JsonU64),
    price: /* @__PURE__ */ nullable(JsonU64),
    owner: /* @__PURE__ */ nullable(SuiAddress),
    payment: /* @__PURE__ */ nullable(/* @__PURE__ */ array(ObjectRefSchema))
  });
  const ProgrammableMoveCall = /* @__PURE__ */ object({
    package: ObjectID,
    module: /* @__PURE__ */ string(),
    function: /* @__PURE__ */ string(),
    typeArguments: /* @__PURE__ */ array(/* @__PURE__ */ string()),
    arguments: /* @__PURE__ */ array(Argument)
  });
  const $Intent = /* @__PURE__ */ object({
    name: /* @__PURE__ */ string(),
    inputs: /* @__PURE__ */ record(/* @__PURE__ */ string(), /* @__PURE__ */ union([Argument, /* @__PURE__ */ array(Argument)])),
    data: /* @__PURE__ */ record(/* @__PURE__ */ string(), /* @__PURE__ */ unknown())
  });
  const Command = enumUnion({
    MoveCall: ProgrammableMoveCall,
    TransferObjects: /* @__PURE__ */ object({
      objects: /* @__PURE__ */ array(Argument),
      address: Argument
    }),
    SplitCoins: /* @__PURE__ */ object({
      coin: Argument,
      amounts: /* @__PURE__ */ array(Argument)
    }),
    MergeCoins: /* @__PURE__ */ object({
      destination: Argument,
      sources: /* @__PURE__ */ array(Argument)
    }),
    Publish: /* @__PURE__ */ object({
      modules: /* @__PURE__ */ array(BCSBytes),
      dependencies: /* @__PURE__ */ array(ObjectID)
    }),
    MakeMoveVec: /* @__PURE__ */ object({
      type: /* @__PURE__ */ nullable(/* @__PURE__ */ string()),
      elements: /* @__PURE__ */ array(Argument)
    }),
    Upgrade: /* @__PURE__ */ object({
      modules: /* @__PURE__ */ array(BCSBytes),
      dependencies: /* @__PURE__ */ array(ObjectID),
      package: ObjectID,
      ticket: Argument
    }),
    $Intent
  });
  const CallArg = enumUnion({
    Object: enumUnion({
      ImmOrOwnedObject: ObjectRefSchema,
      SharedObject: /* @__PURE__ */ object({
        objectId: ObjectID,
        initialSharedVersion: JsonU64,
        mutable: /* @__PURE__ */ boolean()
      }),
      Receiving: ObjectRefSchema
    }),
    Pure: /* @__PURE__ */ object({ bytes: BCSBytes }),
    UnresolvedPure: /* @__PURE__ */ object({ value: /* @__PURE__ */ unknown() }),
    UnresolvedObject: /* @__PURE__ */ object({
      objectId: ObjectID,
      version: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(JsonU64)),
      digest: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(/* @__PURE__ */ string())),
      initialSharedVersion: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(JsonU64)),
      mutable: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(/* @__PURE__ */ boolean()))
    }),
    FundsWithdrawal: FundsWithdrawalArgSchema
  });
  const TransactionExpiration = enumUnion({
    None: /* @__PURE__ */ literal(true),
    Epoch: JsonU64,
    ValidDuring: ValidDuringSchema,
    Validity: ValiditySchema
  });
  const SerializedTransactionDataV2Schema = /* @__PURE__ */ object({
    version: /* @__PURE__ */ literal(2),
    sender: /* @__PURE__ */ nullish(SuiAddress),
    expiration: /* @__PURE__ */ nullish(TransactionExpiration),
    gasData: GasData,
    inputs: /* @__PURE__ */ array(CallArg),
    commands: /* @__PURE__ */ array(Command),
    digest: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(/* @__PURE__ */ string()))
  });
  function createObjectMethods(makeObject) {
    function object2(value) {
      return makeObject(value);
    }
    object2.system = (options) => {
      const mutable = options?.mutable;
      if (mutable !== void 0) return object2(Inputs.SharedObjectRef({
        objectId: SUI_SYSTEM_STATE_OBJECT_ID,
        initialSharedVersion: 1,
        mutable
      }));
      return object2({
        $kind: "UnresolvedObject",
        UnresolvedObject: {
          objectId: SUI_SYSTEM_STATE_OBJECT_ID,
          initialSharedVersion: 1
        }
      });
    };
    object2.clock = () => object2(Inputs.SharedObjectRef({
      objectId: SUI_CLOCK_OBJECT_ID,
      initialSharedVersion: 1,
      mutable: false
    }));
    object2.random = () => object2({
      $kind: "UnresolvedObject",
      UnresolvedObject: {
        objectId: SUI_RANDOM_OBJECT_ID,
        mutable: false
      }
    });
    object2.denyList = (options) => {
      return object2({
        $kind: "UnresolvedObject",
        UnresolvedObject: {
          objectId: SUI_DENY_LIST_OBJECT_ID,
          mutable: options?.mutable
        }
      });
    };
    object2.option = ({ type, value }) => (tx) => tx.moveCall({
      typeArguments: [type],
      target: `${MOVE_STDLIB_ADDRESS}::option::${value === null ? "none" : "some"}`,
      arguments: value === null ? [] : [tx.object(value)]
    });
    return object2;
  }
  function createPure(makePure) {
    function pure(typeOrSerializedValue, value) {
      if (typeof typeOrSerializedValue === "string") return makePure(pureBcsSchemaFromTypeName(typeOrSerializedValue).serialize(value));
      if (typeOrSerializedValue instanceof Uint8Array || isSerializedBcs(typeOrSerializedValue)) return makePure(typeOrSerializedValue);
      throw new Error("tx.pure must be called either a bcs type name, or a serialized bcs value");
    }
    pure.u8 = (value) => makePure(suiBcs.U8.serialize(value));
    pure.u16 = (value) => makePure(suiBcs.U16.serialize(value));
    pure.u32 = (value) => makePure(suiBcs.U32.serialize(value));
    pure.u64 = (value) => makePure(suiBcs.U64.serialize(value));
    pure.u128 = (value) => makePure(suiBcs.U128.serialize(value));
    pure.u256 = (value) => makePure(suiBcs.U256.serialize(value));
    pure.bool = (value) => makePure(suiBcs.Bool.serialize(value));
    pure.string = (value) => makePure(suiBcs.String.serialize(value));
    pure.address = (value) => makePure(suiBcs.Address.serialize(value));
    pure.id = pure.address;
    pure.vector = (type, value) => {
      return makePure(suiBcs.vector(pureBcsSchemaFromTypeName(type)).serialize(value));
    };
    pure.option = (type, value) => {
      return makePure(suiBcs.option(pureBcsSchemaFromTypeName(type)).serialize(value));
    };
    return pure;
  }
  function namedPackagesPlugin() {
    return async (transactionData, buildOptions, next) => {
      const names = findNamesInTransaction(transactionData);
      if (names.types.length === 0 && names.packages.length === 0) return next();
      if (!buildOptions.client) throw new Error(`Transaction contains MVR names but no client was provided to resolve them. Please pass a client to Transaction#build()`);
      replaceNames(transactionData, await buildOptions.client.core.mvr.resolve({
        types: names.types,
        packages: names.packages
      }));
      await next();
    };
  }
  function normalizeBalance(options) {
    if (options.allowance !== void 0 && options.useGasCoin !== void 0) throw new Error("useGasCoin cannot be combined with allowance");
    const amount = options.balance;
    if (typeof amount === "string" && !/^[0-9]+$/.test(amount)) throw new Error("Amount must be a non-empty string of decimal digits");
    if (typeof amount === "number" && !Number.isSafeInteger(amount)) throw new Error("Amount must be a safe integer; use bigint or a string for larger amounts");
    return BigInt(amount);
  }
  function createTransactionResult(index, length = Infinity) {
    const baseResult = {
      $kind: "Result",
      get Result() {
        return typeof index === "function" ? index() : index;
      }
    };
    const nestedResults = [];
    const nestedResultFor = (resultIndex) => nestedResults[resultIndex] ??= {
      $kind: "NestedResult",
      get NestedResult() {
        return [typeof index === "function" ? index() : index, resultIndex];
      }
    };
    return new Proxy(baseResult, {
      set() {
        throw new Error("The transaction result is a proxy, and does not support setting properties directly");
      },
      get(target, property) {
        if (property in target) return Reflect.get(target, property);
        if (property === Symbol.iterator) return function* () {
          let i = 0;
          while (i < length) {
            yield nestedResultFor(i);
            i++;
          }
        };
        if (typeof property === "symbol") return;
        const resultIndex = parseInt(property, 10);
        if (Number.isNaN(resultIndex) || resultIndex < 0) return;
        return nestedResultFor(resultIndex);
      }
    });
  }
  const TRANSACTION_BRAND = /* @__PURE__ */ Symbol.for("@mysten/transaction");
  var Transaction = class Transaction2 {
    #serializationPlugins;
    #buildPlugins;
    #intentResolvers = /* @__PURE__ */ new Map();
    #inputSection = [];
    #commandSection = [];
    #availableResults = /* @__PURE__ */ new Set();
    #pendingPromises = /* @__PURE__ */ new Set();
    #added = /* @__PURE__ */ new Map();
    /**
    * Converts from a serialize transaction kind (built with `build({ onlyTransactionKind: true })`) to a `Transaction` class.
    * Supports either a byte array, or base64-encoded bytes.
    */
    static fromKind(serialized) {
      const tx = new Transaction2();
      tx.#data = TransactionDataBuilder.fromKindBytes(typeof serialized === "string" ? fromBase64(serialized) : serialized);
      tx.#inputSection = tx.#data.inputs.slice();
      tx.#commandSection = tx.#data.commands.slice();
      tx.#availableResults = new Set(tx.#commandSection.map((_, i) => i));
      return tx;
    }
    /**
    * Converts from a serialized transaction format to a `Transaction` class.
    * There are two supported serialized formats:
    * - A string returned from `Transaction#serialize`. The serialized format must be compatible, or it will throw an error.
    * - A byte array (or base64-encoded bytes) containing BCS transaction data.
    *
    * It can also copy an existing `Transaction` or `TransactionDataBuilder` instance. The data is
    * copied, so changes to the new transaction do not affect the original.
    *
    * When copying an in-memory transaction that uses custom intents, pass resolvers for those intents
    * via `options.intentResolvers` so the copy can be created synchronously without first awaiting
    * `prepareForSerialization`. Built-in intents (such as `CoinWithBalance`) are handled automatically.
    */
    static from(transaction, options = {}) {
      const newTransaction = new Transaction2();
      if (typeof transaction === "object" && "getData" in transaction) newTransaction.#data = TransactionDataBuilder.restore(transaction.getData());
      else if (typeof transaction !== "string" || !transaction.startsWith("{")) newTransaction.#data = TransactionDataBuilder.fromBytes(typeof transaction === "string" ? fromBase64(transaction) : transaction);
      else newTransaction.#data = TransactionDataBuilder.restore(JSON.parse(transaction));
      newTransaction.#inputSection = newTransaction.#data.inputs.slice();
      newTransaction.#commandSection = newTransaction.#data.commands.slice();
      newTransaction.#availableResults = new Set(newTransaction.#commandSection.map((_, i) => i));
      const intentResolvers = new Map([
        [COIN_WITH_BALANCE, resolveBalances],
        [ALLOWANCE_BALANCE, resolveBalances],
        ...Object.entries(options.intentResolvers ?? {})
      ]);
      if (!newTransaction.isPreparedForSerialization({ supportedIntents: [...intentResolvers.keys()] })) throw new Error("Transaction has unresolved intents or async thunks. Provide resolvers for any custom intents via the `intentResolvers` option, or call `prepareForSerialization` before copying.");
      for (const [intent, resolver] of intentResolvers) newTransaction.addIntentResolver(intent, resolver);
      return newTransaction;
    }
    addSerializationPlugin(step) {
      this.#serializationPlugins.push(step);
    }
    addBuildPlugin(step) {
      this.#buildPlugins.push(step);
    }
    addIntentResolver(intent, resolver) {
      if (this.#intentResolvers.has(intent) && this.#intentResolvers.get(intent) !== resolver) throw new Error(`Intent resolver for ${intent} already exists`);
      this.#intentResolvers.set(intent, resolver);
    }
    setSender(sender) {
      this.#data.sender = sender;
    }
    /**
    * Sets the sender only if it has not already been set.
    * This is useful for sponsored transaction flows where the sender may not be the same as the signer address.
    */
    setSenderIfNotSet(sender) {
      if (!this.#data.sender) this.#data.sender = sender;
    }
    setExpiration(expiration) {
      this.#data.expiration = expiration ? parse(TransactionExpiration$1, expiration) : null;
    }
    setGasPrice(price) {
      this.#data.gasData.price = String(price);
    }
    setGasBudget(budget) {
      this.#data.gasData.budget = String(budget);
    }
    setGasBudgetIfNotSet(budget) {
      if (this.#data.gasData.budget == null) this.#data.gasData.budget = String(budget);
    }
    setGasOwner(owner) {
      this.#data.gasData.owner = owner;
    }
    setGasPayment(payments) {
      this.#data.gasData.payment = payments.map((payment) => parse(ObjectRefSchema, payment));
    }
    #data;
    /** Get a snapshot of the transaction data, in JSON form: */
    getData() {
      return this.#data.snapshot();
    }
    get [TRANSACTION_BRAND]() {
      return true;
    }
    get pure() {
      Object.defineProperty(this, "pure", {
        enumerable: false,
        value: createPure((value) => {
          if (isSerializedBcs(value)) return this.#addInput("pure", {
            $kind: "Pure",
            Pure: { bytes: value.toBase64() }
          });
          return this.#addInput("pure", /* @__PURE__ */ is(NormalizedCallArg$1, value) ? parse(NormalizedCallArg$1, value) : value instanceof Uint8Array ? Inputs.Pure(value) : {
            $kind: "UnresolvedPure",
            UnresolvedPure: { value }
          });
        })
      });
      return this.pure;
    }
    constructor() {
      this.object = createObjectMethods((value) => {
        if (typeof value === "function") return this.object(this.add(value));
        if (typeof value === "object" && /* @__PURE__ */ is(ArgumentSchema, value)) return value;
        const id = getIdFromCallArg(value);
        const inserted = this.#data.inputs.find((i) => id === getIdFromCallArg(i));
        if (inserted?.Object?.SharedObject && typeof value === "object" && value.Object?.SharedObject) inserted.Object.SharedObject.mutable = inserted.Object.SharedObject.mutable || value.Object.SharedObject.mutable;
        return inserted ? {
          $kind: "Input",
          Input: this.#data.inputs.indexOf(inserted),
          type: "object"
        } : this.#addInput("object", typeof value === "string" ? {
          $kind: "UnresolvedObject",
          UnresolvedObject: { objectId: normalizeSuiAddress(value) }
        } : value);
      });
      this.#data = new TransactionDataBuilder();
      this.#buildPlugins = [];
      this.#serializationPlugins = [];
    }
    /** Returns an argument for the gas coin, to be used in a transaction. */
    get gas() {
      return {
        $kind: "GasCoin",
        GasCoin: true
      };
    }
    /**
    * Creates a Coin<T> of the specified type and amount (defaults to SUI).
    * Sourced from address balance when available, falling back to owned coins. For SUI, falls back
    * to the gas coin instead unless `useGasCoin` is `false`.
    * With `allowance`, spends only from the funder's address balance under that allowance.
    * Allowance IDs are resolved using the build client; app-bound allowances also require an app type and SpendPermit.
    */
    coin(options) {
      const amount = normalizeBalance(options);
      return this.add(options.allowance !== void 0 ? allowanceBalance({
        ...options,
        amount,
        outputKind: "coin"
      }) : coinWithBalance({
        ...options,
        balance: amount
      }));
    }
    /**
    * Creates a Balance<T> of the specified type and amount (defaults to SUI).
    * Sourced from address balance when available, falling back to owned coins. For SUI, falls back
    * to the gas coin instead unless `useGasCoin` is `false`.
    * With `allowance`, spends only from the funder's address balance under that allowance.
    * Allowance IDs are resolved using the build client; app-bound allowances also require an app type and SpendPermit.
    */
    balance(options) {
      const amount = normalizeBalance(options);
      return this.add(options.allowance !== void 0 ? allowanceBalance({
        ...options,
        amount,
        outputKind: "balance"
      }) : createBalance({
        ...options,
        balance: amount
      }));
    }
    /**
    * Add a new object input to the transaction using the fully-resolved object reference.
    * If you only have an object ID, use `builder.object(id)` instead.
    */
    objectRef(...args) {
      return this.object(Inputs.ObjectRef(...args));
    }
    /**
    * Add a new receiving input to the transaction using the fully-resolved object reference.
    * If you only have an object ID, use `builder.object(id)` instead.
    */
    receivingRef(...args) {
      return this.object(Inputs.ReceivingRef(...args));
    }
    /**
    * Add a new shared object input to the transaction using the fully-resolved shared object reference.
    * If you only have an object ID, use `builder.object(id)` instead.
    */
    sharedObjectRef(...args) {
      return this.object(Inputs.SharedObjectRef(...args));
    }
    #fork() {
      const fork = new Transaction2();
      fork.#data = this.#data;
      fork.#serializationPlugins = this.#serializationPlugins;
      fork.#buildPlugins = this.#buildPlugins;
      fork.#intentResolvers = this.#intentResolvers;
      fork.#pendingPromises = this.#pendingPromises;
      fork.#availableResults = new Set(this.#availableResults);
      fork.#added = this.#added;
      this.#inputSection.push(fork.#inputSection);
      this.#commandSection.push(fork.#commandSection);
      return fork;
    }
    add(command) {
      if (typeof command === "function") {
        if (this.#added.has(command)) return this.#added.get(command);
        const fork = this.#fork();
        const result = command(fork);
        if (!(result && typeof result === "object" && "then" in result)) {
          this.#availableResults = fork.#availableResults;
          this.#added.set(command, result);
          return result;
        }
        const placeholder = this.#addCommand({
          $kind: "$Intent",
          $Intent: {
            name: "AsyncTransactionThunk",
            inputs: {},
            data: {
              resultIndex: this.#data.commands.length,
              result: null
            }
          }
        });
        this.#pendingPromises.add(Promise.resolve(result).then((result$1) => {
          placeholder.$Intent.data.result = result$1;
        }));
        const txResult = createTransactionResult(() => placeholder.$Intent.data.resultIndex);
        this.#added.set(command, txResult);
        return txResult;
      } else this.#addCommand(command);
      return createTransactionResult(this.#data.commands.length - 1);
    }
    #addCommand(command) {
      const resultIndex = this.#data.commands.length;
      this.#commandSection.push(command);
      this.#availableResults.add(resultIndex);
      this.#data.commands.push(command);
      this.#data.mapCommandArguments(resultIndex, (arg) => {
        if (arg.$kind === "Result" && !this.#availableResults.has(arg.Result)) throw new Error(`Result { Result: ${arg.Result} } is not available to use in the current transaction`);
        if (arg.$kind === "NestedResult" && !this.#availableResults.has(arg.NestedResult[0])) throw new Error(`Result { NestedResult: [${arg.NestedResult[0]}, ${arg.NestedResult[1]}] } is not available to use in the current transaction`);
        if (arg.$kind === "Input" && arg.Input >= this.#data.inputs.length) throw new Error(`Input { Input: ${arg.Input} } references an input that does not exist in the current transaction`);
        return arg;
      });
      return command;
    }
    #addInput(type, input) {
      this.#inputSection.push(input);
      return this.#data.addInput(type, input);
    }
    #normalizeTransactionArgument(arg) {
      if (isSerializedBcs(arg)) return this.pure(arg);
      return this.#resolveArgument(arg);
    }
    #resolveArgument(arg) {
      if (typeof arg === "function") {
        const resolved = this.add(arg);
        if (typeof resolved === "function") return this.#resolveArgument(resolved);
        return parse(ArgumentSchema, resolved);
      }
      return parse(ArgumentSchema, arg);
    }
    splitCoins(coin, amounts) {
      const command = TransactionCommands.SplitCoins(typeof coin === "string" ? this.object(coin) : this.#resolveArgument(coin), amounts.map((amount) => typeof amount === "number" || typeof amount === "bigint" || typeof amount === "string" ? this.pure.u64(amount) : this.#normalizeTransactionArgument(amount)));
      this.#addCommand(command);
      return createTransactionResult(this.#data.commands.length - 1, amounts.length);
    }
    mergeCoins(destination, sources) {
      return this.add(TransactionCommands.MergeCoins(this.object(destination), sources.map((src) => this.object(src))));
    }
    publish({ modules, dependencies }) {
      return this.add(TransactionCommands.Publish({
        modules,
        dependencies
      }));
    }
    upgrade({ modules, dependencies, package: packageId, ticket }) {
      return this.add(TransactionCommands.Upgrade({
        modules,
        dependencies,
        package: packageId,
        ticket: this.object(ticket)
      }));
    }
    moveCall({ arguments: args, ...input }) {
      return this.add(TransactionCommands.MoveCall({
        ...input,
        arguments: args?.map((arg) => this.#normalizeTransactionArgument(arg))
      }));
    }
    transferObjects(objects, address) {
      return this.add(TransactionCommands.TransferObjects(objects.map((obj) => this.object(obj)), typeof address === "string" ? this.pure.address(address) : this.#normalizeTransactionArgument(address)));
    }
    makeMoveVec({ type, elements }) {
      return this.add(TransactionCommands.MakeMoveVec({
        type,
        elements: elements.map((obj) => this.object(obj))
      }));
    }
    /**
    * Creates a FundsWithdrawal input for withdrawing Balance<T> from an address balance.
    *
    * @param options.amount - The amount to withdraw (u64).
    * @param options.type - The coin type T (e.g., "0x2::sui::SUI"), not Balance<T>. Defaults to SUI.
    * @param options.from - The withdrawal source. Defaults to the transaction sender.
    * @param options.allowance - The allowance ID, required when from is 'allowance'.
    * @param options.funder - The funder's address, required when from is 'allowance'.
    */
    withdrawal(options) {
      const input = {
        $kind: "FundsWithdrawal",
        FundsWithdrawal: {
          reservation: {
            $kind: "MaxAmountU64",
            MaxAmountU64: String(options.amount)
          },
          typeArg: {
            $kind: "Balance",
            Balance: options.type ?? "0x2::sui::SUI"
          },
          withdrawFrom: options.from === "allowance" ? {
            $kind: "SenderAllowance",
            SenderAllowance: {
              funder: normalizeSuiAddress(options.funder),
              allowance: normalizeSuiAddress(options.allowance)
            }
          } : options.from === "sponsor" ? {
            $kind: "Sponsor",
            Sponsor: true
          } : {
            $kind: "Sender",
            Sender: true
          }
        }
      };
      return this.#addInput("object", input);
    }
    /**
    * @deprecated Use toJSON instead.
    * For synchronous serialization, you can use `getData()`
    * */
    serialize() {
      return JSON.stringify(serializeV1TransactionData(this.#data.snapshot()));
    }
    async toJSON(options = {}) {
      await this.prepareForSerialization(options);
      const fullyResolved = this.isFullyResolved();
      return JSON.stringify(parse(SerializedTransactionDataV2Schema, fullyResolved ? {
        ...this.#data.snapshot(),
        digest: this.#data.getDigest()
      } : this.#data.snapshot()), (_key, value) => typeof value === "bigint" ? value.toString() : value, 2);
    }
    /** Build the transaction to BCS bytes, and sign it with the provided keypair. */
    async sign(options) {
      const { signer, ...buildOptions } = options;
      const bytes = await this.build(buildOptions);
      return signer.signTransaction(bytes);
    }
    /**
    * Checks if the transaction is prepared for serialization to JSON.
    * This means:
    *  - All async thunks have been fully resolved
    *  - All transaction intents have been resolved (unless in supportedIntents)
    *
    * Unlike `isFullyResolved()`, this does not require the sender, gas payment,
    * budget, or object versions to be set.
    */
    isPreparedForSerialization(options = {}) {
      if (this.#pendingPromises.size > 0) return false;
      if (this.#data.commands.some((cmd) => cmd.$Intent && !options.supportedIntents?.includes(cmd.$Intent.name))) return false;
      return true;
    }
    /**
    *  Ensures that:
    *  - All objects have been fully resolved to a specific version
    *  - All pure inputs have been serialized to bytes
    *  - All async thunks have been fully resolved
    *  - All transaction intents have been resolved
    * 	- The gas payment, budget, and price have been set
    *  - The transaction sender has been set
    *
    *  When true, the transaction will always be built to the same bytes and digest (unless the transaction is mutated)
    */
    isFullyResolved() {
      if (!this.isPreparedForSerialization()) return false;
      if (!this.#data.sender) return false;
      if (needsTransactionResolution(this.#data, {})) return false;
      return true;
    }
    /** Build the transaction to BCS bytes. */
    async build(options = {}) {
      await this.prepareForSerialization(options);
      await this.#prepareBuild(options);
      return this.#data.build({ onlyTransactionKind: options.onlyTransactionKind });
    }
    /** Derive transaction digest */
    async getDigest(options = {}) {
      await this.prepareForSerialization(options);
      await this.#prepareBuild(options);
      return this.#data.getDigest();
    }
    /**
    * Prepare the transaction by validating the transaction data and resolving all inputs
    * so that it can be built into bytes.
    */
    async #prepareBuild(options) {
      if (!options.onlyTransactionKind && !this.#data.sender) throw new Error("Missing transaction sender");
      await this.#runPlugins([...this.#buildPlugins, resolveTransactionPlugin], options);
    }
    async #runPlugins(plugins, options) {
      try {
        const createNext = (i) => {
          if (i >= plugins.length) return () => {
          };
          const plugin = plugins[i];
          return async () => {
            const next = createNext(i + 1);
            let calledNext = false;
            let nextResolved = false;
            await plugin(this.#data, options, async () => {
              if (calledNext) throw new Error(`next() was call multiple times in TransactionPlugin ${i}`);
              calledNext = true;
              await next();
              nextResolved = true;
            });
            if (!calledNext) throw new Error(`next() was not called in TransactionPlugin ${i}`);
            if (!nextResolved) throw new Error(`next() was not awaited in TransactionPlugin ${i}`);
          };
        };
        await createNext(0)();
      } finally {
        this.#inputSection = this.#data.inputs.slice();
        this.#commandSection = this.#data.commands.slice();
        this.#availableResults = new Set(this.#commandSection.map((_, i) => i));
      }
    }
    async #waitForPendingTasks() {
      while (this.#pendingPromises.size > 0) {
        const newPromise = Promise.all(this.#pendingPromises);
        this.#pendingPromises.clear();
        this.#pendingPromises.add(newPromise);
        await newPromise;
        this.#pendingPromises.delete(newPromise);
      }
    }
    #sortCommandsAndInputs() {
      const unorderedCommands = this.#data.commands;
      const unorderedInputs = this.#data.inputs;
      const orderedCommands = this.#commandSection.flat(Infinity);
      const orderedInputs = this.#inputSection.flat(Infinity);
      if (orderedCommands.length !== unorderedCommands.length) throw new Error("Unexpected number of commands found in transaction data");
      if (orderedInputs.length !== unorderedInputs.length) throw new Error("Unexpected number of inputs found in transaction data");
      const filteredCommands = orderedCommands.filter((cmd) => cmd.$Intent?.name !== "AsyncTransactionThunk");
      this.#data.commands = filteredCommands;
      this.#data.inputs = orderedInputs;
      this.#commandSection = filteredCommands;
      this.#inputSection = orderedInputs;
      this.#availableResults = new Set(filteredCommands.map((_, i) => i));
      function getOriginalIndex(index) {
        const command = unorderedCommands[index];
        if (command.$Intent?.name === "AsyncTransactionThunk") {
          const result = command.$Intent.data.result;
          if (result == null) throw new Error("AsyncTransactionThunk has not been resolved");
          return getOriginalIndex(result.Result);
        }
        const updated = filteredCommands.indexOf(command);
        if (updated === -1) throw new Error("Unable to find original index for command");
        return updated;
      }
      this.#data.mapArguments((arg) => {
        if (arg.$kind === "Input") {
          const updated = orderedInputs.indexOf(unorderedInputs[arg.Input]);
          if (updated === -1) throw new Error("Input has not been resolved");
          return {
            ...arg,
            Input: updated
          };
        } else if (arg.$kind === "Result") {
          const updated = getOriginalIndex(arg.Result);
          return {
            ...arg,
            Result: updated
          };
        } else if (arg.$kind === "NestedResult") {
          const updated = getOriginalIndex(arg.NestedResult[0]);
          return {
            ...arg,
            NestedResult: [updated, arg.NestedResult[1]]
          };
        }
        return arg;
      });
      for (const [i, cmd] of unorderedCommands.entries()) if (cmd.$Intent?.name === "AsyncTransactionThunk") try {
        cmd.$Intent.data.resultIndex = getOriginalIndex(i);
      } catch {
      }
    }
    async prepareForSerialization(options) {
      await this.#waitForPendingTasks();
      this.#sortCommandsAndInputs();
      const intents = /* @__PURE__ */ new Set();
      for (const command of this.#data.commands) if (command.$Intent) intents.add(command.$Intent.name);
      const steps = [...this.#serializationPlugins];
      const resolverIntents = /* @__PURE__ */ new Map();
      for (const intent of intents) {
        if (options.supportedIntents?.includes(intent)) continue;
        const resolver = this.#intentResolvers.get(intent);
        if (!resolver) throw new Error(`Missing intent resolver for ${intent}`);
        const names = resolverIntents.get(resolver) ?? [];
        names.push(intent);
        resolverIntents.set(resolver, names);
      }
      for (const [resolver, intentNames] of resolverIntents) steps.push((data, buildOptions, next) => {
        return resolver(data, {
          ...buildOptions,
          intentNames
        }, next);
      });
      steps.push(namedPackagesPlugin());
      await this.#runPlugins(steps, options);
    }
  };
  const WORKER_URL = "https://api.soothia.fun";
  const STAKE_PACKAGE = "0xf9507a1cb35b01c191614a67bf5ca3f22c7c3a7745fdc7ddea67369686a6720f";
  const STAKE_CONFIG = "0x7ba41f413b54f1f04b592694ad3304caa87df7cf9f1afda98b42c45362d2b3be";
  const BASE64 = /^[A-Za-z0-9+/]+={0,2}$/;
  const CLOCK = normalizeSuiAddress("0x6");
  const STAKE_ARGUMENTS = 6;
  const HASH_BYTES = 32;
  class Refusal extends Error {
  }
  function refuseIf(condition, reason) {
    if (condition) throw new Refusal(reason);
  }
  const sameAddress = (a, b) => normalizeSuiAddress(a) === normalizeSuiAddress(b);
  function inputOf(data, argument, what) {
    const input = argument?.$kind === "Input" ? data.inputs[argument.Input] : void 0;
    if (!input) throw new Refusal(`${what} is not a plain input.`);
    return input;
  }
  function sharedObjectId(data, argument, what) {
    const id = inputOf(data, argument, what).Object?.SharedObject?.objectId;
    if (!id) throw new Refusal(`${what} is not a shared object.`);
    return id;
  }
  function pureBytes(data, argument, what) {
    const bytes = inputOf(data, argument, what).Pure?.bytes;
    if (bytes === void 0) throw new Refusal(`${what} is not a plain value.`);
    return fromBase64(bytes);
  }
  function checkTarget(command, fn) {
    const call = command?.MoveCall;
    if (!call) throw new Refusal(`Expected a call to ${fn}.`);
    refuseIf(!sameAddress(call.package, STAKE_PACKAGE), "It calls a contract that is not Soothia's.");
    refuseIf(call.module !== "pool" || call.function !== fn, `It calls something other than ${fn}.`);
    refuseIf((call.typeArguments ?? []).length !== 0, "It has unexpected type arguments.");
    return call;
  }
  function checkStake(data, expected) {
    refuseIf(data.commands.length !== 2, "It does more than split a coin and stake.");
    const split = data.commands[0].SplitCoins;
    if (!split) throw new Refusal("The first step is not a coin split.");
    refuseIf(split.coin.$kind !== "GasCoin", "The stake does not come from your SUI balance.");
    refuseIf(split.amounts.length !== 1, "It splits more than one coin.");
    const amountBytes = pureBytes(data, split.amounts[0], "The amount");
    refuseIf(amountBytes.length !== 8, "The amount is malformed.");
    refuseIf(suiBcs.u64().parse(amountBytes) !== expected.amountMist, "The amount differs from what you chose.");
    const call = checkTarget(data.commands[1], "stake");
    refuseIf(call.arguments.length !== STAKE_ARGUMENTS, "The stake call has the wrong arguments.");
    const [config, pool, side, coin, pickHash, clock] = call.arguments;
    refuseIf(!sameAddress(sharedObjectId(data, config, "The config"), STAKE_CONFIG), "It uses a different config.");
    refuseIf(!sameAddress(sharedObjectId(data, pool, "The pool"), expected.poolId), "It stakes in a different pool.");
    const sideBytes = pureBytes(data, side, "The side");
    refuseIf(sideBytes.length !== 1 || suiBcs.bool().parse(sideBytes) !== expected.side, "It backs the other side.");
    const fromSplit = coin.$kind === "NestedResult" && coin.NestedResult[0] === 0 && coin.NestedResult[1] === 0 || coin.$kind === "Result" && coin.Result === 0;
    refuseIf(!fromSplit, "The stake does not use the split coin.");
    const hash = suiBcs.vector(suiBcs.u8()).parse(pureBytes(data, pickHash, "The call's hash"));
    refuseIf(hash.length !== HASH_BYTES, "The call's hash is malformed.");
    if (expected.pickHash !== void 0) {
      const hex = hash.map((byte) => byte.toString(16).padStart(2, "0")).join("");
      refuseIf(hex !== expected.pickHash.toLowerCase(), "It is tied to a different call.");
    }
    refuseIf(!sameAddress(sharedObjectId(data, clock, "The clock"), CLOCK), "It does not use the Sui clock.");
    refuseIf(data.inputs.length !== STAKE_ARGUMENTS, "It carries extra inputs.");
  }
  function checkClaim(data, expected) {
    refuseIf(data.commands.length !== 1, "It does more than claim.");
    const call = checkTarget(data.commands[0], "claim");
    refuseIf(call.arguments.length !== 2, "The claim call has the wrong arguments.");
    refuseIf(!sameAddress(sharedObjectId(data, call.arguments[0], "The pool"), expected.poolId), "It claims from a different pool.");
    refuseIf(!sameAddress(sharedObjectId(data, call.arguments[1], "The clock"), CLOCK), "It does not use the Sui clock.");
    refuseIf(data.inputs.length !== 2, "It carries extra inputs.");
  }
  function checkTransaction(txBytes, expected, sender) {
    try {
      refuseIf(typeof txBytes !== "string" || !BASE64.test(txBytes), "It is not a built transaction.");
      const data = Transaction.from(fromBase64(txBytes)).getData();
      refuseIf(!data.sender || !sameAddress(data.sender, sender), "It would be sent from a different address.");
      refuseIf(Boolean(data.gasData.owner) && !sameAddress(data.gasData.owner, sender), "Someone else would pay its gas.");
      if (expected.kind === "stake") checkStake(data, expected);
      else if (expected.kind === "claim") checkClaim(data, expected);
      else throw new Refusal("Unknown transaction type.");
      return { ok: true };
    } catch (error) {
      const reason = error instanceof Refusal ? error.message : "It could not be read.";
      return { ok: false, reason: `Transaction refused. ${reason}` };
    }
  }
  const HEALTH_REQUEST = "soothia:v1:health";
  const DETECT_REQUEST = "soothia:v1:detect";
  const API_REQUEST = "soothia:v1:api";
  const OPEN_WELCOME = "soothia:v1:open-welcome";
  const MUSIC_CONTROL = "soothia:v1:music";
  const API_ROUTES = {
    "/recall/status": "GET",
    "/recall/record": "GET",
    "/recall/proof": "GET",
    "/recall/insights": "POST",
    "/recall/pick": "POST",
    "/recall/pref": "POST",
    "/stake/pool": "POST",
    "/stake/build": "POST",
    "/stake/confirm": "POST",
    "/stake/positions": "GET",
    "/stake/balance": "GET",
    "/stake/claim/build": "POST",
    "/social/profile/challenge": "POST",
    "/social/profile/publish": "POST",
    "/social/profile/update": "POST",
    "/social/profile/unpublish": "POST",
    "/social/profile/by-address": "GET",
    "/social/suins": "GET",
    "/social/leaderboard": "GET"
  };
  const RECALL_ID_KEY = "soothia.recallId";
  const SUI_WALLET_KEY = "soothia.suiWallet";
  const CHECK_TX = "soothia:v1:check-tx";
  const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  function isRecallId(value) {
    return typeof value === "string" && UUID.test(value);
  }
  const INSTALL_KEY = "soothia:installId";
  const RESULT_PREFIX = "soothia:detect:v2:";
  const RESULT_TTL_MS = 10 * 60 * 1e3;
  const ERROR_TTL_MS = 60 * 1e3;
  async function checkHealth() {
    try {
      const res = await fetch(`${WORKER_URL}/health`, { signal: AbortSignal.timeout(5e3) });
      if (!res.ok) return { online: false };
      const body = await res.json();
      return { online: body.ok === true };
    } catch {
      return { online: false };
    }
  }
  async function installId() {
    const stored = (await chrome.storage.local.get(INSTALL_KEY))[INSTALL_KEY];
    if (typeof stored === "string" && stored) return stored;
    const created = crypto.randomUUID();
    await chrome.storage.local.set({ [INSTALL_KEY]: created });
    return created;
  }
  async function recallHeaders(path) {
    if (!path.startsWith("/recall/") && path !== "/stake/build" && path !== "/stake/confirm" && path !== "/social/profile/publish") return {};
    const stored = (await chrome.storage.local.get(RECALL_ID_KEY))[RECALL_ID_KEY];
    return isRecallId(stored) ? { "X-Soothia-Recall": stored } : {};
  }
  async function post(path, body, refresh = false) {
    const headers = {
      "Content-Type": "application/json",
      "X-Soothia-Install": await installId(),
      ...await recallHeaders(path)
    };
    if (refresh) headers["X-Soothia-Refresh"] = "1";
    return fetch(`${WORKER_URL}${path}`, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      // Chrome stops a service worker whose fetch takes over 30 seconds.
      signal: AbortSignal.timeout(28e3)
    });
  }
  async function detect(page, refresh, fixture) {
    const debug = {
      httpStatus: null,
      cache: null,
      fromClientCache: false,
      claimsReturned: 0,
      dropped: []
    };
    try {
      const detected = await post("/detect", fixture ? { ...page, fixture } : page, refresh);
      debug.httpStatus = detected.status;
      const cache = detected.headers.get("X-Soothia-Cache");
      debug.cache = cache === "HIT" || cache === "MISS" ? cache : null;
      if (detected.status === 429) return { status: "error", reason: "limit", debug };
      if (!detected.ok) return { status: "error", reason: "unavailable", debug };
      const body = await detected.json();
      const claims = body.claims;
      debug.claimsReturned = claims.length;
      debug.dropped = body.dropped ?? [];
      debug.path = body.path;
      if (claims.length === 0) return { status: "ok", tiles: [], debug };
      const tiles = claims.map((claim) => ({ claim }));
      return { status: "ok", tiles, debug };
    } catch {
      return { status: "error", reason: "unavailable", debug };
    }
  }
  function isLive(stored, now) {
    if (!stored) return false;
    return now - stored.at < (stored.result.status === "ok" ? RESULT_TTL_MS : ERROR_TTL_MS);
  }
  async function pruneResults(now) {
    const all = await chrome.storage.session.get(null);
    const dead = Object.keys(all).filter((key) => key.startsWith(RESULT_PREFIX) && !isLive(all[key], now));
    if (dead.length > 0) await chrome.storage.session.remove(dead);
  }
  const inFlight = /* @__PURE__ */ new Map();
  async function detectOnce(page, refresh, fixture) {
    const key = RESULT_PREFIX + page.url + (fixture ? "#fixture" : "");
    const now = Date.now();
    if (!refresh) {
      const stored = (await chrome.storage.session.get(key))[key];
      if (isLive(stored, now)) {
        return { ...stored.result, debug: { ...stored.result.debug, fromClientCache: true } };
      }
    }
    const running = inFlight.get(key);
    if (running) return running;
    const request = detect(page, refresh, fixture).then(async (result) => {
      await chrome.storage.session.set({ [key]: { at: Date.now(), result } });
      await pruneResults(Date.now());
      return result;
    }).finally(() => inFlight.delete(key));
    inFlight.set(key, request);
    return request;
  }
  const FAILED = {
    status: "error",
    reason: "unavailable",
    debug: { httpStatus: null, cache: null, fromClientCache: false, claimsReturned: 0, dropped: [] }
  };
  async function relay(message) {
    if (!Object.hasOwn(API_ROUTES, message.path)) return { ok: false, status: 0, body: null };
    try {
      const response = API_ROUTES[message.path] === "GET" ? await fetch(`${WORKER_URL}${message.path}?${new URLSearchParams(message.body)}`, {
        headers: { "X-Soothia-Install": await installId(), ...await recallHeaders(message.path) },
        signal: AbortSignal.timeout(28e3)
      }) : await post(message.path, message.body);
      return { ok: response.ok, status: response.status, body: await response.json().catch(() => null) };
    } catch {
      return { ok: false, status: 0, body: null };
    }
  }
  const MUTED_KEY = "soothia:muted";
  const WELCOME_URL = chrome.runtime.getURL("welcome.html");
  const welcomeTabs = /* @__PURE__ */ new Set();
  async function hasOffscreen() {
    try {
      const contexts = await chrome.runtime.getContexts({
        contextTypes: ["OFFSCREEN_DOCUMENT"]
      });
      return contexts.length > 0;
    } catch {
      return false;
    }
  }
  let musicStarting = null;
  function startMusic() {
    if (!musicStarting) {
      musicStarting = startMusicNow().finally(() => {
        musicStarting = null;
      });
    }
    return musicStarting;
  }
  async function startMusicNow() {
    try {
      if (!chrome.offscreen) return { playing: false, muted: false, error: "offscreen API unavailable" };
      if (!await hasOffscreen()) {
        await chrome.offscreen.createDocument({
          url: "offscreen.html",
          reasons: ["AUDIO_PLAYBACK"],
          justification: "Plays onboarding music while the welcome page is open"
        });
      }
      const muted = (await chrome.storage.local.get(MUTED_KEY))[MUTED_KEY] === true;
      const status = await chrome.runtime.sendMessage({ type: MUSIC_CONTROL, action: "start", muted });
      return status ?? { playing: false, muted, error: "no answer from the player" };
    } catch (error) {
      return { playing: false, muted: false, error: String(error?.message ?? error) };
    }
  }
  async function stopMusic() {
    if (!await hasOffscreen()) return;
    await chrome.runtime.sendMessage({ type: MUSIC_CONTROL, action: "stop" }).catch(() => {
    });
  }
  async function openWelcome() {
    const tab = await chrome.tabs.create({ url: WELCOME_URL });
    if (tab.id !== void 0) welcomeTabs.add(tab.id);
    void startMusic();
  }
  chrome.tabs.onRemoved.addListener((tabId) => {
    if (!welcomeTabs.delete(tabId)) return;
    if (welcomeTabs.size === 0) void stopMusic();
  });
  chrome.tabs.onUpdated.addListener((tabId, change) => {
    if (!change.url) return;
    if (change.url.startsWith(WELCOME_URL)) welcomeTabs.add(tabId);
    else if (welcomeTabs.delete(tabId) && welcomeTabs.size === 0) void stopMusic();
  });
  chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === "install") openWelcome().catch(() => {
    });
  });
  self.addEventListener("unhandledrejection", (event) => event.preventDefault());
  self.addEventListener("error", (event) => event.preventDefault());
  const respondSafely = (work, sendResponse, fallback) => {
    work.then(
      (value) => {
        try {
          sendResponse(value);
        } catch {
        }
      },
      () => {
        try {
          sendResponse(fallback);
        } catch {
        }
      }
    );
  };
  async function verifyForSigning(message) {
    const stored = await chrome.storage.local.get(SUI_WALLET_KEY);
    const address = stored[SUI_WALLET_KEY]?.address;
    if (typeof address !== "string") return { ok: false, reason: "No Sui wallet is connected." };
    return checkTransaction(message.txBytes, message.expected, address);
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    try {
      return handleMessage(message, sender, sendResponse);
    } catch {
      try {
        sendResponse(void 0);
      } catch {
      }
      return false;
    }
  });
  function handleMessage(message, sender, sendResponse) {
    switch (message?.type) {
      case HEALTH_REQUEST:
        respondSafely(checkHealth(), sendResponse, { online: false });
        return true;
      // keep the channel open for the async response
      case DETECT_REQUEST:
        respondSafely(
          detectOnce(
            message.page,
            message.refresh === true,
            message.fixture
          ),
          sendResponse,
          FAILED
        );
        return true;
      case API_REQUEST:
        respondSafely(relay(message), sendResponse, { ok: false, status: 0, body: null });
        return true;
      case OPEN_WELCOME:
        respondSafely(
          openWelcome().then(() => true),
          sendResponse,
          false
        );
        return true;
      case CHECK_TX:
        respondSafely(verifyForSigning(message), sendResponse, { ok: false, reason: "The transaction could not be checked." });
        return true;
      case MUSIC_CONTROL:
        if (message.action === "ensure") {
          if (sender.tab?.id !== void 0) welcomeTabs.add(sender.tab.id);
          respondSafely(startMusic(), sendResponse, { playing: false, muted: false, error: "background failed" });
          return true;
        }
        return void 0;
    }
    return void 0;
  }
})();
