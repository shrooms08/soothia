(function() {
  "use strict";
  const WORKER_URL = "https://soothia-proxy.heylana.workers.dev";
  const HEALTH_REQUEST = "soothia:v1:health";
  const DETECT_REQUEST = "soothia:v1:detect";
  const API_REQUEST = "soothia:v1:api";
  const INJECT_SIGNER = "soothia:v1:inject-signer";
  const IMAGE_REQUEST = "soothia:v1:image";
  const API_ROUTES = {
    "/wallet/balances": "POST",
    "/create/quote": "POST",
    "/create/build": "POST",
    "/create/simulate": "POST",
    "/create/send": "POST",
    "/create/register-retry": "POST",
    "/tx/simulate": "POST",
    "/tx/status": "POST",
    "/buy/quote": "POST",
    "/buy/build": "POST",
    "/buy/send": "POST",
    "/buy/status": "POST",
    "/claim/build": "POST",
    "/claim/send": "POST",
    "/creator/markets": "GET",
    "/positions": "GET",
    "/market": "GET"
  };
  const INSTALL_KEY = "soothia:installId";
  const RESULT_PREFIX = "soothia:detect:v2:";
  const RESULT_TTL_MS = 10 * 60 * 1e3;
  const ERROR_TTL_MS = 60 * 1e3;
  async function checkHealth() {
    try {
      const res = await fetch(`${WORKER_URL}/health`, { signal: AbortSignal.timeout(5e3) });
      if (!res.ok) return { online: false };
      const body = await res.json();
      return { online: body.ok === true };
    } catch {
      return { online: false };
    }
  }
  async function installId() {
    const stored = (await chrome.storage.local.get(INSTALL_KEY))[INSTALL_KEY];
    if (typeof stored === "string" && stored) return stored;
    const created = crypto.randomUUID();
    await chrome.storage.local.set({ [INSTALL_KEY]: created });
    return created;
  }
  async function post(path, body, refresh = false) {
    const headers = {
      "Content-Type": "application/json",
      "X-Soothia-Install": await installId()
    };
    if (refresh) headers["X-Soothia-Refresh"] = "1";
    return fetch(`${WORKER_URL}${path}`, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      // Chrome stops a service worker whose fetch takes over 30 seconds.
      signal: AbortSignal.timeout(28e3)
    });
  }
  async function detect(page, refresh) {
    const debug = {
      httpStatus: null,
      cache: null,
      fromClientCache: false,
      claimsReturned: 0,
      dropped: []
    };
    try {
      const detected = await post("/detect", page, refresh);
      debug.httpStatus = detected.status;
      const cache = detected.headers.get("X-Soothia-Cache");
      debug.cache = cache === "HIT" || cache === "MISS" ? cache : null;
      if (detected.status === 429) return { status: "error", reason: "limit", debug };
      if (!detected.ok) return { status: "error", reason: "unavailable", debug };
      const body = await detected.json();
      const claims = body.claims;
      debug.claimsReturned = claims.length;
      debug.dropped = body.dropped ?? [];
      if (claims.length === 0) return { status: "ok", tiles: [], debug };
      const markets = /* @__PURE__ */ new Map();
      try {
        const matched = await post("/match", { claims });
        if (matched.ok) {
          const { matches } = await matched.json();
          for (const match of matches) markets.set(match.claimId, match.market);
        }
      } catch {
      }
      const tiles = claims.map((claim) => ({ claim, market: markets.get(claim.id) ?? null }));
      return { status: "ok", tiles, debug };
    } catch {
      return { status: "error", reason: "unavailable", debug };
    }
  }
  function isLive(stored, now) {
    if (!stored) return false;
    return now - stored.at < (stored.result.status === "ok" ? RESULT_TTL_MS : ERROR_TTL_MS);
  }
  async function pruneResults(now) {
    const all = await chrome.storage.session.get(null);
    const dead = Object.keys(all).filter((key) => key.startsWith(RESULT_PREFIX) && !isLive(all[key], now));
    if (dead.length > 0) await chrome.storage.session.remove(dead);
  }
  const inFlight = /* @__PURE__ */ new Map();
  async function detectOnce(page, refresh) {
    const key = RESULT_PREFIX + page.url;
    const now = Date.now();
    if (!refresh) {
      const stored = (await chrome.storage.session.get(key))[key];
      if (isLive(stored, now)) {
        return { ...stored.result, debug: { ...stored.result.debug, fromClientCache: true } };
      }
    }
    const running = inFlight.get(key);
    if (running) return running;
    const request = detect(page, refresh).then(async (result) => {
      await chrome.storage.session.set({ [key]: { at: Date.now(), result } });
      await pruneResults(Date.now());
      return result;
    }).finally(() => inFlight.delete(key));
    inFlight.set(key, request);
    return request;
  }
  const FAILED = {
    status: "error",
    reason: "unavailable",
    debug: { httpStatus: null, cache: null, fromClientCache: false, claimsReturned: 0, dropped: [] }
  };
  async function relay(message) {
    if (!Object.hasOwn(API_ROUTES, message.path)) return { ok: false, status: 0, body: null };
    try {
      const response = API_ROUTES[message.path] === "GET" ? await fetch(`${WORKER_URL}${message.path}?${new URLSearchParams(message.body)}`, {
        headers: { "X-Soothia-Install": await installId() },
        signal: AbortSignal.timeout(28e3)
      }) : await post(message.path, message.body);
      return { ok: response.ok, status: response.status, body: await response.json().catch(() => null) };
    } catch {
      return { ok: false, status: 0, body: null };
    }
  }
  async function categoryImage(category) {
    if (typeof category !== "string" || !/^[a-z-]{1,30}$/.test(category)) return null;
    try {
      const response = await fetch(`${WORKER_URL}/img/${category}.png`, { signal: AbortSignal.timeout(1e4) });
      if (!response.ok) return null;
      const bytes = new Uint8Array(await response.arrayBuffer());
      let binary = "";
      for (let i = 0; i < bytes.length; i += 32768) binary += String.fromCharCode(...bytes.subarray(i, i + 32768));
      return `data:image/png;base64,${btoa(binary)}`;
    } catch {
      return null;
    }
  }
  async function injectSigner(tabId) {
    if (tabId === void 0) return false;
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ["wallet-sign.js"], world: "MAIN" });
      return true;
    } catch {
      return false;
    }
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message?.type) {
      case HEALTH_REQUEST:
        checkHealth().then(sendResponse);
        return true;
      // keep the channel open for the async response
      case DETECT_REQUEST:
        detectOnce(message.page, message.refresh === true).then(
          sendResponse,
          () => sendResponse(FAILED)
        );
        return true;
      case API_REQUEST:
        relay(message).then(sendResponse);
        return true;
      case IMAGE_REQUEST:
        categoryImage(message.category).then(sendResponse);
        return true;
      case INJECT_SIGNER:
        injectSigner(sender.tab?.id).then(sendResponse);
        return true;
    }
  });
})();
