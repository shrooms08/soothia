(function() {
  "use strict";
  const WORKER_URL = "https://api.soothia.fun";
  const HEALTH_REQUEST = "soothia:v1:health";
  const DETECT_REQUEST = "soothia:v1:detect";
  const API_REQUEST = "soothia:v1:api";
  const INJECT_SIGNER = "soothia:v1:inject-signer";
  const IMAGE_REQUEST = "soothia:v1:image";
  const OPEN_WELCOME = "soothia:v1:open-welcome";
  const MUSIC_CONTROL = "soothia:v1:music";
  const API_ROUTES = {
    "/wallet/balances": "POST",
    "/create/quote": "POST",
    "/create/build": "POST",
    "/create/simulate": "POST",
    "/create/send": "POST",
    "/create/register-retry": "POST",
    "/tx/simulate": "POST",
    "/tx/status": "POST",
    "/buy/quote": "POST",
    "/buy/build": "POST",
    "/buy/send": "POST",
    "/buy/status": "POST",
    "/claim/build": "POST",
    "/claim/send": "POST",
    "/claim/creator-fees/build": "POST",
    "/creator/markets": "GET",
    "/positions": "GET",
    "/market": "GET"
  };
  const INSTALL_KEY = "soothia:installId";
  const RESULT_PREFIX = "soothia:detect:v2:";
  const RESULT_TTL_MS = 10 * 60 * 1e3;
  const ERROR_TTL_MS = 60 * 1e3;
  async function checkHealth() {
    try {
      const res = await fetch(`${WORKER_URL}/health`, { signal: AbortSignal.timeout(5e3) });
      if (!res.ok) return { online: false };
      const body = await res.json();
      return { online: body.ok === true };
    } catch {
      return { online: false };
    }
  }
  async function installId() {
    const stored = (await chrome.storage.local.get(INSTALL_KEY))[INSTALL_KEY];
    if (typeof stored === "string" && stored) return stored;
    const created = crypto.randomUUID();
    await chrome.storage.local.set({ [INSTALL_KEY]: created });
    return created;
  }
  async function post(path, body, refresh = false) {
    const headers = {
      "Content-Type": "application/json",
      "X-Soothia-Install": await installId()
    };
    if (refresh) headers["X-Soothia-Refresh"] = "1";
    return fetch(`${WORKER_URL}${path}`, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      // Chrome stops a service worker whose fetch takes over 30 seconds.
      signal: AbortSignal.timeout(28e3)
    });
  }
  async function detect(page, refresh, fixture) {
    const debug = {
      httpStatus: null,
      cache: null,
      fromClientCache: false,
      claimsReturned: 0,
      dropped: []
    };
    try {
      const detected = await post("/detect", fixture ? { ...page, fixture } : page, refresh);
      debug.httpStatus = detected.status;
      const cache = detected.headers.get("X-Soothia-Cache");
      debug.cache = cache === "HIT" || cache === "MISS" ? cache : null;
      if (detected.status === 429) return { status: "error", reason: "limit", debug };
      if (!detected.ok) return { status: "error", reason: "unavailable", debug };
      const body = await detected.json();
      const claims = body.claims;
      debug.claimsReturned = claims.length;
      debug.dropped = body.dropped ?? [];
      debug.path = body.path;
      if (claims.length === 0) return { status: "ok", tiles: [], debug };
      const markets = /* @__PURE__ */ new Map();
      try {
        const matched = await post("/match", { claims });
        if (matched.ok) {
          const { matches } = await matched.json();
          for (const match of matches) markets.set(match.claimId, match.market);
        }
      } catch {
      }
      const tiles = claims.map((claim) => ({ claim, market: markets.get(claim.id) ?? null }));
      return { status: "ok", tiles, debug };
    } catch {
      return { status: "error", reason: "unavailable", debug };
    }
  }
  function isLive(stored, now) {
    if (!stored) return false;
    return now - stored.at < (stored.result.status === "ok" ? RESULT_TTL_MS : ERROR_TTL_MS);
  }
  async function pruneResults(now) {
    const all = await chrome.storage.session.get(null);
    const dead = Object.keys(all).filter((key) => key.startsWith(RESULT_PREFIX) && !isLive(all[key], now));
    if (dead.length > 0) await chrome.storage.session.remove(dead);
  }
  const inFlight = /* @__PURE__ */ new Map();
  async function detectOnce(page, refresh, fixture) {
    const key = RESULT_PREFIX + page.url + (fixture ? "#fixture" : "");
    const now = Date.now();
    if (!refresh) {
      const stored = (await chrome.storage.session.get(key))[key];
      if (isLive(stored, now)) {
        return { ...stored.result, debug: { ...stored.result.debug, fromClientCache: true } };
      }
    }
    const running = inFlight.get(key);
    if (running) return running;
    const request = detect(page, refresh, fixture).then(async (result) => {
      await chrome.storage.session.set({ [key]: { at: Date.now(), result } });
      await pruneResults(Date.now());
      return result;
    }).finally(() => inFlight.delete(key));
    inFlight.set(key, request);
    return request;
  }
  const FAILED = {
    status: "error",
    reason: "unavailable",
    debug: { httpStatus: null, cache: null, fromClientCache: false, claimsReturned: 0, dropped: [] }
  };
  async function relay(message) {
    if (!Object.hasOwn(API_ROUTES, message.path)) return { ok: false, status: 0, body: null };
    try {
      const response = API_ROUTES[message.path] === "GET" ? await fetch(`${WORKER_URL}${message.path}?${new URLSearchParams(message.body)}`, {
        headers: { "X-Soothia-Install": await installId() },
        signal: AbortSignal.timeout(28e3)
      }) : await post(message.path, message.body);
      return { ok: response.ok, status: response.status, body: await response.json().catch(() => null) };
    } catch {
      return { ok: false, status: 0, body: null };
    }
  }
  async function categoryImage(category) {
    if (typeof category !== "string" || !/^[a-z-]{1,30}$/.test(category)) return null;
    try {
      const response = await fetch(`${WORKER_URL}/img/${category}.png`, { signal: AbortSignal.timeout(1e4) });
      if (!response.ok) return null;
      const bytes = new Uint8Array(await response.arrayBuffer());
      let binary = "";
      for (let i = 0; i < bytes.length; i += 32768) binary += String.fromCharCode(...bytes.subarray(i, i + 32768));
      return `data:image/png;base64,${btoa(binary)}`;
    } catch {
      return null;
    }
  }
  async function injectSigner(tabId) {
    if (tabId === void 0) return false;
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ["wallet-sign.js"], world: "MAIN" });
      return true;
    } catch {
      return false;
    }
  }
  const MUTED_KEY = "soothia:muted";
  const WELCOME_URL = chrome.runtime.getURL("welcome.html");
  const welcomeTabs = /* @__PURE__ */ new Set();
  async function hasOffscreen() {
    try {
      const contexts = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
      return contexts.length > 0;
    } catch {
      return false;
    }
  }
  let musicStarting = null;
  function startMusic() {
    if (!musicStarting) {
      musicStarting = startMusicNow().finally(() => {
        musicStarting = null;
      });
    }
    return musicStarting;
  }
  async function startMusicNow() {
    try {
      if (!chrome.offscreen) return { playing: false, muted: false, error: "offscreen API unavailable" };
      if (!await hasOffscreen()) {
        await chrome.offscreen.createDocument({
          url: "offscreen.html",
          reasons: ["AUDIO_PLAYBACK"],
          justification: "Plays onboarding music while the welcome page is open"
        });
      }
      const muted = (await chrome.storage.local.get(MUTED_KEY))[MUTED_KEY] === true;
      const status = await chrome.runtime.sendMessage({ type: MUSIC_CONTROL, action: "start", muted });
      return status ?? { playing: false, muted, error: "no answer from the player" };
    } catch (error) {
      return { playing: false, muted: false, error: String(error?.message ?? error) };
    }
  }
  async function stopMusic() {
    if (!await hasOffscreen()) return;
    await chrome.runtime.sendMessage({ type: MUSIC_CONTROL, action: "stop" }).catch(() => {
    });
  }
  async function openWelcome() {
    const tab = await chrome.tabs.create({ url: WELCOME_URL });
    if (tab.id !== void 0) welcomeTabs.add(tab.id);
    void startMusic();
  }
  chrome.tabs.onRemoved.addListener((tabId) => {
    if (!welcomeTabs.delete(tabId)) return;
    if (welcomeTabs.size === 0) void stopMusic();
  });
  chrome.tabs.onUpdated.addListener((tabId, change) => {
    if (!change.url) return;
    if (change.url.startsWith(WELCOME_URL)) welcomeTabs.add(tabId);
    else if (welcomeTabs.delete(tabId) && welcomeTabs.size === 0) void stopMusic();
  });
  chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === "install") openWelcome().catch(() => {
    });
  });
  self.addEventListener("unhandledrejection", (event) => event.preventDefault());
  self.addEventListener("error", (event) => event.preventDefault());
  const respondSafely = (work, sendResponse, fallback) => {
    work.then(
      (value) => {
        try {
          sendResponse(value);
        } catch {
        }
      },
      () => {
        try {
          sendResponse(fallback);
        } catch {
        }
      }
    );
  };
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    try {
      return handleMessage(message, sender, sendResponse);
    } catch {
      try {
        sendResponse(void 0);
      } catch {
      }
      return false;
    }
  });
  function handleMessage(message, sender, sendResponse) {
    switch (message?.type) {
      case HEALTH_REQUEST:
        respondSafely(checkHealth(), sendResponse, { online: false });
        return true;
      // keep the channel open for the async response
      case DETECT_REQUEST:
        respondSafely(detectOnce(message.page, message.refresh === true, message.fixture), sendResponse, FAILED);
        return true;
      case API_REQUEST:
        respondSafely(relay(message), sendResponse, { ok: false, status: 0, body: null });
        return true;
      case IMAGE_REQUEST:
        respondSafely(categoryImage(message.category ?? ""), sendResponse, null);
        return true;
      case INJECT_SIGNER:
        respondSafely(injectSigner(sender.tab?.id), sendResponse, false);
        return true;
      case OPEN_WELCOME:
        respondSafely(openWelcome().then(() => true), sendResponse, false);
        return true;
      case MUSIC_CONTROL:
        if (message.action === "ensure") {
          if (sender.tab?.id !== void 0) welcomeTabs.add(sender.tab.id);
          respondSafely(startMusic(), sendResponse, { playing: false, muted: false, error: "background failed" });
          return true;
        }
        return void 0;
    }
    return void 0;
  }
})();
