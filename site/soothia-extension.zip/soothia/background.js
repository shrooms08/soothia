(function() {
  "use strict";
  const SUI_NS_NAME_REGEX = /^(?!.*(^(?!@)|[-.@])($|[-.@]))(?:[a-z0-9-]{0,63}(?:\.[a-z0-9-]{0,63})*)?@[a-z0-9-]{0,63}$/i;
  const SUI_NS_DOMAIN_REGEX = /^(?!.*(^|[-.])($|[-.]))(?:[a-z0-9-]{0,63}\.)+sui$/i;
  const MAX_SUI_NS_NAME_LENGTH = 235;
  function isValidSuiNSName(name) {
    if (name.length > MAX_SUI_NS_NAME_LENGTH) return false;
    if (name.includes("@")) return SUI_NS_NAME_REGEX.test(name);
    return SUI_NS_DOMAIN_REGEX.test(name);
  }
  const NAME_PATTERN = /^([a-z0-9]+(?:-[a-z0-9]+)*)$/;
  const VERSION_REGEX = /^\d+$/;
  const MAX_APP_SIZE = 64;
  const NAME_SEPARATOR$1 = "/";
  const isValidNamedPackage = (name) => {
    const parts = name.split(NAME_SEPARATOR$1);
    if (parts.length < 2 || parts.length > 3) return false;
    const [org, app, version] = parts;
    if (version !== void 0 && !VERSION_REGEX.test(version)) return false;
    if (!isValidSuiNSName(org)) return false;
    return NAME_PATTERN.test(app) && app.length < MAX_APP_SIZE;
  };
  var BcsReader = class {
    /**
    * @param {Uint8Array} data Data to use as a buffer.
    */
    constructor(data) {
      this.bytePosition = 0;
      this.dataView = new DataView(data.buffer, data.byteOffset, data.byteLength);
      this.bytes = new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    }
    /**
    * Shift current cursor position by `bytes`.
    *
    * @param {Number} bytes Number of bytes to
    * @returns {this} Self for possible chaining.
    */
    shift(bytes) {
      this.bytePosition += bytes;
      return this;
    }
    /**
    * Read U8 value from the buffer and shift cursor by 1.
    * @returns
    */
    read8() {
      const position = this.bytePosition;
      if (position >= this.bytes.length) throw new RangeError("Offset is outside the bounds of the DataView");
      this.bytePosition = position + 1;
      return this.bytes[position];
    }
    /**
    * Read U16 value from the buffer and shift cursor by 2.
    * @returns
    */
    read16() {
      const value = this.dataView.getUint16(this.bytePosition, true);
      this.shift(2);
      return value;
    }
    /**
    * Read U32 value from the buffer and shift cursor by 4.
    * @returns
    */
    read32() {
      const value = this.dataView.getUint32(this.bytePosition, true);
      this.shift(4);
      return value;
    }
    /**
    * Read U64 value from the buffer and shift cursor by 8.
    * @returns
    */
    read64() {
      const value = this.dataView.getBigUint64(this.bytePosition, true);
      this.shift(8);
      return value.toString(10);
    }
    /**
    * Read U128 value from the buffer and shift cursor by 16.
    */
    read128() {
      const value1 = BigInt(this.read64());
      const result = BigInt(this.read64()).toString(16) + value1.toString(16).padStart(16, "0");
      return BigInt("0x" + result).toString(10);
    }
    /**
    * Read U128 value from the buffer and shift cursor by 32.
    * @returns
    */
    read256() {
      const value1 = BigInt(this.read128());
      const result = BigInt(this.read128()).toString(16) + value1.toString(16).padStart(32, "0");
      return BigInt("0x" + result).toString(10);
    }
    /**
    * Read `num` number of bytes from the buffer and shift cursor by `num`.
    * @param num Number of bytes to read.
    */
    readBytes(num) {
      if (this.bytePosition + num > this.bytes.length) throw new RangeError("Offset is outside the bounds of the DataView");
      const start = this.bytePosition + this.dataView.byteOffset;
      const value = new Uint8Array(this.dataView.buffer, start, num);
      this.shift(num);
      return value;
    }
    /**
    * Read ULEB value - an integer of varying size. Used for enum indexes and
    * vector lengths.
    * @returns {Number} The ULEB value.
    */
    readULEB() {
      const bytes = this.bytes;
      let position = this.bytePosition;
      let value = 0;
      let multiplier = 1;
      while (true) {
        if (position >= bytes.length) throw new Error("ULEB decode error: buffer overflow");
        const byte = bytes[position++];
        value += (byte & 127) * multiplier;
        if ((byte & 128) === 0) {
          if (byte === 0 && position - this.bytePosition > 1) throw new Error("ULEB decode error: non-canonical encoding");
          break;
        }
        multiplier *= 128;
      }
      if (!(value <= Number.MAX_SAFE_INTEGER)) throw new Error("ULEB decode error: value exceeds MAX_SAFE_INTEGER");
      this.bytePosition = position;
      return value;
    }
    /**
    * Read a BCS vector: read a length and then apply function `cb` X times
    * where X is the length of the vector, defined as ULEB in BCS bytes.
    * @param cb Callback to process elements of vector.
    * @returns {Array<Any>} Array of the resulting values, returned by callback.
    */
    readVec(cb) {
      const length = this.readULEB();
      const result = [];
      for (let i = 0; i < length; i++) result.push(cb(this, i, length));
      return result;
    }
  };
  const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  const ALPHABET_CODES = Array.from(ALPHABET, (char) => char.charCodeAt(0));
  const DIGIT_VALUES = new Int8Array(128).fill(-1);
  for (let i = 0; i < 58; i++) DIGIT_VALUES[ALPHABET.charCodeAt(i)] = i;
  const B58_5 = 58 ** 5;
  function isBytes$3(value) {
    return value instanceof Uint8Array || ArrayBuffer.isView(value) && value.constructor.name === "Uint8Array" && value.BYTES_PER_ELEMENT === 1;
  }
  function toBase58(buffer) {
    if (!isBytes$3(buffer)) throw new TypeError("toBase58 expects a Uint8Array");
    const length = buffer.length;
    let zeros = 0;
    while (zeros < length && buffer[zeros] === 0) zeros++;
    const limbs = [];
    let i = zeros;
    if ((length - zeros) % 2 === 1) limbs.push(buffer[i++]);
    for (; i < length; i += 2) {
      let carry = buffer[i] * 256 + buffer[i + 1];
      for (let j = 0; j < limbs.length; j++) {
        const x = limbs[j] * 65536 + carry;
        carry = Math.floor(x / B58_5);
        limbs[j] = x - carry * B58_5;
      }
      while (carry > 0) {
        const next = Math.floor(carry / B58_5);
        limbs.push(carry - next * B58_5);
        carry = next;
      }
    }
    const digits = [];
    for (let k = 0; k < zeros; k++) digits.push(ALPHABET_CODES[0]);
    for (let j = limbs.length - 1; j >= 0; j--) {
      let limb = limbs[j];
      const start = digits.length;
      const width = j === limbs.length - 1 ? 0 : 5;
      for (let k = 0; k < 5 && (limb > 0 || k < width); k++) {
        const next = Math.floor(limb / 58);
        digits.push(ALPHABET_CODES[limb - next * 58]);
        limb = next;
      }
      for (let a = start, b = digits.length - 1; a < b; a++, b--) {
        const tmp = digits[a];
        digits[a] = digits[b];
        digits[b] = tmp;
      }
    }
    let result = "";
    for (let start = 0; start < digits.length; start += 8192) result += String.fromCharCode.apply(null, digits.slice(start, start + 8192));
    return result;
  }
  function fromBase58(str) {
    if (typeof str !== "string") throw new TypeError("fromBase58 expects a string");
    const length = str.length;
    let zeros = 0;
    while (zeros < length && str.charCodeAt(zeros) === 49) zeros++;
    const limbs = [];
    let i = zeros;
    const head = (length - zeros) % 5;
    while (i < length) {
      const chunkLength = i === zeros && head !== 0 ? head : 5;
      let carry = 0;
      let multiplier = 1;
      for (let k = 0; k < chunkLength; k++) {
        const code = str.charCodeAt(i + k);
        const digit = code < 128 ? DIGIT_VALUES[code] : -1;
        if (digit < 0) throw new Error(`Invalid base58 character "${str[i + k]}"`);
        carry = carry * 58 + digit;
        multiplier *= 58;
      }
      i += chunkLength;
      for (let j = 0; j < limbs.length; j++) {
        const x = limbs[j] * multiplier + carry;
        carry = Math.floor(x / 65536);
        limbs[j] = x - carry * 65536;
      }
      while (carry > 0) {
        limbs.push(carry % 65536);
        carry = Math.floor(carry / 65536);
      }
    }
    let byteLength = limbs.length * 2;
    if (byteLength > 0 && limbs[limbs.length - 1] < 256) byteLength--;
    const out = new Uint8Array(zeros + byteLength);
    let pos = out.length - 1;
    for (let j = 0; j < limbs.length; j++) {
      out[pos--] = limbs[j] & 255;
      if (pos >= zeros) out[pos--] = limbs[j] >> 8;
    }
    return out;
  }
  function fromBase64(base64String2) {
    const binary = atob(base64String2);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }
  const CHUNK_SIZE = 8192;
  function toBase64(bytes) {
    if (bytes.length <= CHUNK_SIZE) return btoa(String.fromCharCode.apply(null, bytes));
    let output = "";
    for (let i = 0; i < bytes.length; i += CHUNK_SIZE) {
      const chunk2 = bytes.slice(i, i + CHUNK_SIZE);
      output += String.fromCharCode.apply(null, chunk2);
    }
    return btoa(output);
  }
  function fromHex(hexStr) {
    const normalized = hexStr.startsWith("0x") ? hexStr.slice(2) : hexStr;
    const padded = normalized.length % 2 === 0 ? normalized : `0${normalized}`;
    const bytes = new Uint8Array(padded.length / 2);
    for (let i = 0; i < bytes.length; i++) {
      const high = hexDigit(padded.charCodeAt(i * 2));
      const low = hexDigit(padded.charCodeAt(i * 2 + 1));
      if (high < 0 || low < 0) throw new Error(`Invalid hex string ${hexStr}`);
      bytes[i] = high * 16 + low;
    }
    return bytes;
  }
  function hexDigit(code) {
    if (code >= 48 && code <= 57) return code - 48;
    if (code >= 97 && code <= 102) return code - 87;
    if (code >= 65 && code <= 70) return code - 55;
    return -1;
  }
  const HEX_BYTES = Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
  function toHex(bytes) {
    let hex = "";
    for (let i = 0; i < bytes.length; i++) hex += HEX_BYTES[bytes[i]];
    return hex;
  }
  function chunk(array2, size) {
    return Array.from({ length: Math.ceil(array2.length / size) }, (_, i) => {
      return array2.slice(i * size, (i + 1) * size);
    });
  }
  function encodeStr(data, encoding) {
    switch (encoding) {
      case "base58":
        return toBase58(data);
      case "base64":
        return toBase64(data);
      case "hex":
        return toHex(data);
      default:
        throw new Error("Unsupported encoding, supported values are: base64, hex");
    }
  }
  function splitGenericParameters(str, genericSeparators = ["<", ">"]) {
    const [left, right] = genericSeparators;
    const tok = [];
    let word = "";
    let nestedAngleBrackets = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str[i];
      if (char === left) nestedAngleBrackets++;
      if (char === right) nestedAngleBrackets--;
      if (nestedAngleBrackets === 0 && char === ",") {
        tok.push(word.trim());
        word = "";
        continue;
      }
      word += char;
    }
    tok.push(word.trim());
    return tok;
  }
  function ulebEncode(num) {
    let bigNum = BigInt(num);
    const arr = [];
    let len = 0;
    if (bigNum < 0n) throw new TypeError(`Invalid ULEB128 value: ${num}. Expected a non-negative integer`);
    if (bigNum === 0n) return [0];
    while (bigNum > 0) {
      arr[len] = Number(bigNum & 127n);
      bigNum >>= 7n;
      if (bigNum > 0n) arr[len] |= 128;
      len += 1;
    }
    return arr;
  }
  var BcsWriter = class {
    constructor({ initialSize = 1024, maxSize = Infinity, allocateSize = 1024 } = {}) {
      this.bytePosition = 0;
      this.size = initialSize;
      this.maxSize = maxSize;
      this.allocateSize = allocateSize;
      this.dataView = new DataView(new ArrayBuffer(initialSize));
      this.bytes = new Uint8Array(this.dataView.buffer);
    }
    ensureSizeOrGrow(bytes) {
      const requiredSize = this.bytePosition + bytes;
      if (requiredSize > this.size) {
        const nextSize = Math.min(this.maxSize, Math.max(this.size + requiredSize, this.size + this.allocateSize));
        if (requiredSize > nextSize) throw new Error(`Attempting to serialize to BCS, but buffer does not have enough size. Allocated size: ${this.size}, Max size: ${this.maxSize}, Required size: ${requiredSize}`);
        this.size = nextSize;
        const nextBuffer = new ArrayBuffer(this.size);
        const nextBytes = new Uint8Array(nextBuffer);
        nextBytes.set(this.bytes);
        this.dataView = new DataView(nextBuffer);
        this.bytes = nextBytes;
      }
    }
    /**
    * Shift current cursor position by `bytes`.
    *
    * @param {Number} bytes Number of bytes to
    * @returns {this} Self for possible chaining.
    */
    shift(bytes) {
      this.bytePosition += bytes;
      return this;
    }
    /**
    * Write a U8 value into a buffer and shift cursor position by 1.
    * @param {Number} value Value to write.
    * @returns {this}
    */
    write8(value) {
      this.ensureSizeOrGrow(1);
      this.bytes[this.bytePosition] = Number(value);
      return this.shift(1);
    }
    /**
    * Write a U8 value into a buffer and shift cursor position by 1.
    * @param {Number} value Value to write.
    * @returns {this}
    */
    writeBytes(bytes) {
      this.ensureSizeOrGrow(bytes.length);
      this.bytes.set(bytes, this.bytePosition);
      return this.shift(bytes.length);
    }
    /**
    * Write a U16 value into a buffer and shift cursor position by 2.
    * @param {Number} value Value to write.
    * @returns {this}
    */
    write16(value) {
      this.ensureSizeOrGrow(2);
      this.dataView.setUint16(this.bytePosition, Number(value), true);
      return this.shift(2);
    }
    /**
    * Write a U32 value into a buffer and shift cursor position by 4.
    * @param {Number} value Value to write.
    * @returns {this}
    */
    write32(value) {
      this.ensureSizeOrGrow(4);
      this.dataView.setUint32(this.bytePosition, Number(value), true);
      return this.shift(4);
    }
    /**
    * Write a U64 value into a buffer and shift cursor position by 8.
    * @param {bigint} value Value to write.
    * @returns {this}
    */
    write64(value) {
      return this.writeBigLittleEndian(BigInt(value), 8);
    }
    /**
    * Write a U128 value into a buffer and shift cursor position by 16.
    *
    * @param {bigint} value Value to write.
    * @returns {this}
    */
    write128(value) {
      return this.writeBigLittleEndian(BigInt(value), 16);
    }
    /**
    * Write a U256 value into a buffer and shift cursor position by 16.
    *
    * @param {bigint} value Value to write.
    * @returns {this}
    */
    write256(value) {
      return this.writeBigLittleEndian(BigInt(value), 32);
    }
    writeBigLittleEndian(value, size) {
      this.ensureSizeOrGrow(size);
      let remaining = value > 0n ? value : 0n;
      for (let offset = 0; offset < size; offset += 8) {
        this.dataView.setBigUint64(this.bytePosition + offset, BigInt.asUintN(64, remaining), true);
        remaining >>= 64n;
      }
      return this.shift(size);
    }
    /**
    * Write a ULEB value into a buffer and shift cursor position by number of bytes
    * written.
    * @param {Number} value Value to write.
    * @returns {this}
    */
    writeULEB(value) {
      if (value >= 0 && Number.isSafeInteger(value)) {
        let remaining = value;
        while (remaining >= 128) {
          this.write8(remaining % 128 | 128);
          remaining = Math.floor(remaining / 128);
        }
        return this.write8(remaining);
      }
      ulebEncode(value).forEach((el) => this.write8(el));
      return this;
    }
    /**
    * Write a vector into a buffer by first writing the vector length and then calling
    * a callback on each passed value.
    *
    * @param {Array<Any>} vector Array of elements to write.
    * @param {WriteVecCb} cb Callback to call on each element of the vector.
    * @returns {this}
    */
    writeVec(vector2, cb) {
      this.writeULEB(vector2.length);
      Array.from(vector2).forEach((el, i) => cb(this, el, i, vector2.length));
      return this;
    }
    /**
    * Adds support for iterations over the object.
    * @returns {Uint8Array}
    */
    *[Symbol.iterator]() {
      for (let i = 0; i < this.bytePosition; i++) yield this.dataView.getUint8(i);
      return this.toBytes();
    }
    /**
    * Get underlying buffer taking only value bytes (in case initial buffer size was bigger).
    * @returns {Uint8Array} Resulting bcs.
    */
    toBytes() {
      return new Uint8Array(this.dataView.buffer.slice(0, this.bytePosition));
    }
    /**
    * Represent data as 'hex' or 'base64'
    * @param encoding Encoding to use: 'base64' or 'hex'
    */
    toString(encoding) {
      return encodeStr(this.toBytes(), encoding);
    }
  };
  var BcsType = class BcsType2 {
    #write;
    #serialize;
    #validatedWrite = null;
    #validatedSerialize = null;
    #transformValidate = null;
    constructor(options) {
      this.name = options.name;
      this.read = options.read;
      this.serializedSize = options.serializedSize ?? (() => null);
      this.#write = options.write;
      this.#serialize = options.serialize ?? ((value, options$1) => {
        const writer = new BcsWriter({
          initialSize: this.serializedSize(value) ?? void 0,
          ...options$1
        });
        this.#write(value, writer);
        return writer.toBytes();
      });
      this.validate = options.validate ?? (() => {
      });
    }
    write(value, writer) {
      if (this.#validatedWrite && this.validate === this.#transformValidate) {
        this.#validatedWrite(value, writer);
        return;
      }
      this.validate(value);
      this.#write(value, writer);
    }
    serialize(value, options) {
      if (this.#validatedSerialize && this.validate === this.#transformValidate) return new SerializedBcs(this, this.#validatedSerialize(value, options));
      this.validate(value);
      return new SerializedBcs(this, this.#serialize(value, options));
    }
    parse(bytes) {
      const reader = new BcsReader(bytes);
      return this.read(reader);
    }
    fromHex(hex) {
      return this.parse(fromHex(hex));
    }
    fromBase58(b64) {
      return this.parse(fromBase58(b64));
    }
    fromBase64(b64) {
      return this.parse(fromBase64(b64));
    }
    transform({ name, input, output, validate: validate2 }) {
      const type = new BcsType2({
        name: name ?? this.name,
        read: (reader) => output ? output(this.read(reader)) : this.read(reader),
        write: (value, writer) => this.#write(input ? input(value) : value, writer),
        serializedSize: (value) => this.serializedSize(input ? input(value) : value),
        serialize: (value, options) => this.#serialize(input ? input(value) : value, options),
        validate: (value) => {
          validate2?.(value);
          this.validate(input ? input(value) : value);
        }
      });
      type.#transformValidate = type.validate;
      type.#validatedWrite = (value, writer) => {
        validate2?.(value);
        const converted = input ? input(value) : value;
        this.validate(converted);
        this.#write(converted, writer);
      };
      type.#validatedSerialize = (value, options) => {
        validate2?.(value);
        const converted = input ? input(value) : value;
        this.validate(converted);
        return this.#serialize(converted, options);
      };
      return type;
    }
  };
  const SERIALIZED_BCS_BRAND = /* @__PURE__ */ Symbol.for("@mysten/serialized-bcs");
  function isSerializedBcs(obj) {
    return !!obj && typeof obj === "object" && obj[SERIALIZED_BCS_BRAND] === true;
  }
  var SerializedBcs = class {
    #schema;
    #bytes;
    get [SERIALIZED_BCS_BRAND]() {
      return true;
    }
    constructor(schema, bytes) {
      this.#schema = schema;
      this.#bytes = bytes;
    }
    toBytes() {
      return this.#bytes;
    }
    toHex() {
      return toHex(this.#bytes);
    }
    toBase64() {
      return toBase64(this.#bytes);
    }
    toBase58() {
      return toBase58(this.#bytes);
    }
    parse() {
      return this.#schema.parse(this.#bytes);
    }
  };
  function fixedSizeBcsType({ size, ...options }) {
    return new BcsType({
      ...options,
      serializedSize: () => size
    });
  }
  function uIntBcsType({ readMethod, writeMethod, ...options }) {
    return fixedSizeBcsType({
      ...options,
      read: (reader) => reader[readMethod](),
      write: (value, writer) => writer[writeMethod](value),
      validate: (value) => {
        if (typeof value === "number" && !Number.isInteger(value) || value < 0 || value > options.maxValue) throw new TypeError(`Invalid ${options.name} value: ${value}. Expected value in range 0-${options.maxValue}`);
        options.validate?.(value);
      }
    });
  }
  function bigUIntBcsType({ readMethod, writeMethod, ...options }) {
    return fixedSizeBcsType({
      ...options,
      read: (reader) => reader[readMethod](),
      write: (value, writer) => writer[writeMethod](BigInt(value)),
      validate: (val) => {
        const value = BigInt(val);
        if (value < 0 || value > options.maxValue) throw new TypeError(`Invalid ${options.name} value: ${value}. Expected value in range 0-${options.maxValue}`);
        options.validate?.(value);
      }
    });
  }
  function dynamicSizeBcsType({ serialize, ...options }) {
    const type = new BcsType({
      ...options,
      serialize,
      write: (value, writer) => {
        for (const byte of type.serialize(value).toBytes()) writer.write8(byte);
      }
    });
    return type;
  }
  function stringLikeBcsType({ toBytes, fromBytes, ...options }) {
    return new BcsType({
      ...options,
      read: (reader) => {
        const length = reader.readULEB();
        return fromBytes(reader.readBytes(length));
      },
      write: (hex, writer) => {
        const bytes = toBytes(hex);
        writer.writeULEB(bytes.length);
        writer.writeBytes(bytes);
      },
      serialize: (value) => {
        const bytes = toBytes(value);
        const size = ulebEncode(bytes.length);
        const result = new Uint8Array(size.length + bytes.length);
        result.set(size, 0);
        result.set(bytes, size.length);
        return result;
      },
      validate: (value) => {
        if (typeof value !== "string") throw new TypeError(`Invalid ${options.name} value: ${value}. Expected string`);
        options.validate?.(value);
      }
    });
  }
  function lazyBcsType(cb) {
    let lazyType = null;
    function getType() {
      if (!lazyType) lazyType = cb();
      return lazyType;
    }
    return new BcsType({
      name: "lazy",
      read: (data) => getType().read(data),
      serializedSize: (value) => getType().serializedSize(value),
      write: (value, writer) => getType().write(value, writer),
      serialize: (value, options) => getType().serialize(value, options).toBytes()
    });
  }
  var BcsStruct = class extends BcsType {
    constructor({ name, fields, ...options }) {
      const fieldNames = Object.keys(fields);
      const fieldTypes = fieldNames.map((field) => fields[field]);
      const fieldCount = fieldNames.length;
      super({
        name,
        serializedSize: (values) => {
          let total = 0;
          for (let i = 0; i < fieldCount; i++) {
            const size = fieldTypes[i].serializedSize(values[fieldNames[i]]);
            if (size == null) return null;
            total += size;
          }
          return total;
        },
        read: (reader) => {
          const result = {};
          for (let i = 0; i < fieldCount; i++) result[fieldNames[i]] = fieldTypes[i].read(reader);
          return result;
        },
        write: (value, writer) => {
          for (let i = 0; i < fieldCount; i++) fieldTypes[i].write(value[fieldNames[i]], writer);
        },
        ...options,
        validate: (value) => {
          options?.validate?.(value);
          if (typeof value !== "object" || value == null) throw new TypeError(`Expected object, found ${typeof value}`);
        }
      });
    }
  };
  var BcsEnum = class extends BcsType {
    constructor({ fields, ...options }) {
      const canonicalOrder = Object.entries(fields);
      const variantIndex = new Map(canonicalOrder.map(([name], i) => [name, i]));
      super({
        read: (reader) => {
          const index = reader.readULEB();
          const enumEntry = canonicalOrder[index];
          if (!enumEntry) throw new TypeError(`Unknown value ${index} for enum ${options.name}`);
          const [kind, type] = enumEntry;
          const value = type?.read(reader) ?? true;
          if (kind === "__proto__") return {
            [kind]: value,
            $kind: kind
          };
          const result = {};
          result[kind] = value;
          result.$kind = kind;
          return result;
        },
        write: (value, writer) => {
          for (const name of Object.keys(value)) {
            const index = variantIndex.get(name);
            if (index !== void 0) {
              writer.writeULEB(index);
              canonicalOrder[index][1]?.write(value[name], writer);
              return;
            }
          }
        },
        ...options,
        validate: (value) => {
          options?.validate?.(value);
          if (typeof value !== "object" || value == null) throw new TypeError(`Expected object, found ${typeof value}`);
          let variantCount = 0;
          for (const key of Object.keys(value)) if (value[key] !== void 0 && variantIndex.has(key)) variantCount++;
          if (variantCount !== 1) throw new TypeError(`Expected object with one key, but found ${variantCount} for type ${options.name}}`);
        }
      });
    }
  };
  var BcsTuple = class extends BcsType {
    constructor({ fields, name, ...options }) {
      super({
        name: name ?? `(${fields.map((t) => t.name).join(", ")})`,
        serializedSize: (values) => {
          let total = 0;
          for (let i = 0; i < fields.length; i++) {
            const size = fields[i].serializedSize(values[i]);
            if (size == null) return null;
            total += size;
          }
          return total;
        },
        read: (reader) => {
          const result = [];
          for (const field of fields) result.push(field.read(reader));
          return result;
        },
        write: (value, writer) => {
          for (let i = 0; i < fields.length; i++) fields[i].write(value[i], writer);
        },
        ...options,
        validate: (value) => {
          options?.validate?.(value);
          if (!Array.isArray(value)) throw new TypeError(`Expected array, found ${typeof value}`);
          if (value.length !== fields.length) throw new TypeError(`Expected array of length ${fields.length}, found ${value.length}`);
        }
      });
    }
  };
  function fixedArray(size, type, options) {
    return new BcsType({
      read: (reader) => {
        const result = new Array(size);
        for (let i = 0; i < size; i++) result[i] = type.read(reader);
        return result;
      },
      write: (value, writer) => {
        for (const item of value) type.write(item, writer);
      },
      ...options,
      name: options?.name ?? `${type.name}[${size}]`,
      validate: (value) => {
        options?.validate?.(value);
        if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
        if (value.length !== size) throw new TypeError(`Expected array of length ${size}, found ${value.length}`);
      }
    });
  }
  function option(type) {
    const name = `Option<${type.name}>`;
    return new BcsType({
      name,
      read: (reader) => {
        const index = reader.readULEB();
        if (index === 0) return null;
        if (index === 1) return type.read(reader);
        throw new TypeError(`Unknown value ${index} for enum ${name}`);
      },
      write: (value, writer) => {
        if (value == null) {
          writer.write8(0);
          return;
        }
        writer.write8(1);
        type.write(value, writer);
      }
    });
  }
  function vector(type, options) {
    return new BcsType({
      read: (reader) => {
        const length = reader.readULEB();
        const result = new Array(length);
        for (let i = 0; i < length; i++) result[i] = type.read(reader);
        return result;
      },
      write: (value, writer) => {
        writer.writeULEB(value.length);
        for (const item of value) type.write(item, writer);
      },
      ...options,
      name: options?.name ?? `vector<${type.name}>`,
      validate: (value) => {
        options?.validate?.(value);
        if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
      }
    });
  }
  function compareBcsBytes(a, b) {
    for (let i = 0; i < Math.min(a.length, b.length); i++) if (a[i] !== b[i]) return a[i] - b[i];
    return a.length - b.length;
  }
  function map(keyType, valueType) {
    return new BcsType({
      name: `Map<${keyType.name}, ${valueType.name}>`,
      read: (reader) => {
        const length = reader.readULEB();
        const result = /* @__PURE__ */ new Map();
        for (let i = 0; i < length; i++) result.set(keyType.read(reader), valueType.read(reader));
        return result;
      },
      write: (value, writer) => {
        const entries = [...value.entries()].map(([key, val]) => [keyType.serialize(key).toBytes(), val]);
        entries.sort(([a], [b]) => compareBcsBytes(a, b));
        writer.writeULEB(entries.length);
        for (const [keyBytes, val] of entries) {
          writer.writeBytes(keyBytes);
          valueType.write(val, writer);
        }
      }
    });
  }
  let utf8Encoder;
  let utf8Decoder;
  function decoder() {
    return utf8Decoder ??= new TextDecoder("utf-8", {
      fatal: true,
      ignoreBOM: true
    });
  }
  const ASCII_FAST_PATH_MAX_LENGTH = 64;
  function decodeUtf8(bytes) {
    if (bytes.length <= ASCII_FAST_PATH_MAX_LENGTH) {
      let result = "";
      for (let i = 0; i < bytes.length; i++) {
        const byte = bytes[i];
        if (byte >= 128) return decoder().decode(bytes);
        result += String.fromCharCode(byte);
      }
      return result;
    }
    return decoder().decode(bytes);
  }
  const bcs = {
    u8(options) {
      return uIntBcsType({
        readMethod: "read8",
        writeMethod: "write8",
        size: 1,
        maxValue: 2 ** 8 - 1,
        ...options,
        name: options?.name ?? "u8"
      });
    },
    u16(options) {
      return uIntBcsType({
        readMethod: "read16",
        writeMethod: "write16",
        size: 2,
        maxValue: 2 ** 16 - 1,
        ...options,
        name: options?.name ?? "u16"
      });
    },
    u32(options) {
      return uIntBcsType({
        readMethod: "read32",
        writeMethod: "write32",
        size: 4,
        maxValue: 2 ** 32 - 1,
        ...options,
        name: options?.name ?? "u32"
      });
    },
    u64(options) {
      return bigUIntBcsType({
        readMethod: "read64",
        writeMethod: "write64",
        size: 8,
        maxValue: 2n ** 64n - 1n,
        ...options,
        name: options?.name ?? "u64"
      });
    },
    u128(options) {
      return bigUIntBcsType({
        readMethod: "read128",
        writeMethod: "write128",
        size: 16,
        maxValue: 2n ** 128n - 1n,
        ...options,
        name: options?.name ?? "u128"
      });
    },
    u256(options) {
      return bigUIntBcsType({
        readMethod: "read256",
        writeMethod: "write256",
        size: 32,
        maxValue: 2n ** 256n - 1n,
        ...options,
        name: options?.name ?? "u256"
      });
    },
    bool(options) {
      return fixedSizeBcsType({
        size: 1,
        read: (reader) => {
          const value = reader.read8();
          if (value > 1) throw new TypeError(`Invalid bool value: expected 0 or 1, found ${value}`);
          return value === 1;
        },
        write: (value, writer) => writer.write8(value ? 1 : 0),
        ...options,
        name: options?.name ?? "bool",
        validate: (value) => {
          options?.validate?.(value);
          if (typeof value !== "boolean") throw new TypeError(`Expected boolean, found ${typeof value}`);
        }
      });
    },
    uleb128(options) {
      return dynamicSizeBcsType({
        read: (reader) => reader.readULEB(),
        serialize: (value) => {
          return Uint8Array.from(ulebEncode(value));
        },
        ...options,
        name: options?.name ?? "uleb128"
      });
    },
    bytes(size, options) {
      return fixedSizeBcsType({
        size,
        read: (reader) => reader.readBytes(size),
        write: (value, writer) => {
          writer.writeBytes(value instanceof Uint8Array ? value : new Uint8Array(value));
        },
        ...options,
        name: options?.name ?? `bytes[${size}]`,
        validate: (value) => {
          options?.validate?.(value);
          if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
          if (value.length !== size) throw new TypeError(`Expected array of length ${size}, found ${value.length}`);
        }
      });
    },
    byteVector(options) {
      return new BcsType({
        read: (reader) => {
          const length = reader.readULEB();
          return reader.readBytes(length);
        },
        write: (value, writer) => {
          const array2 = value instanceof Uint8Array ? value : new Uint8Array(value);
          writer.writeULEB(array2.length);
          writer.writeBytes(array2);
        },
        ...options,
        name: options?.name ?? "vector<u8>",
        serializedSize: (value) => {
          const length = "length" in value ? value.length : null;
          return length == null ? null : ulebEncode(length).length + length;
        },
        validate: (value) => {
          options?.validate?.(value);
          if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
        }
      });
    },
    string(options) {
      return stringLikeBcsType({
        toBytes: (value) => (utf8Encoder ??= new TextEncoder()).encode(value),
        fromBytes: decodeUtf8,
        ...options,
        name: options?.name ?? "string"
      });
    },
    fixedArray,
    option,
    vector,
    tuple(fields, options) {
      return new BcsTuple({
        fields,
        ...options
      });
    },
    struct(name, fields, options) {
      return new BcsStruct({
        name,
        fields,
        ...options
      });
    },
    enum(name, fields, options) {
      return new BcsEnum({
        name,
        fields,
        ...options
      });
    },
    map,
    lazy(cb) {
      return lazyBcsType(cb);
    }
  };
  const SUI_ADDRESS_LENGTH = 32;
  function isValidSuiAddress(value) {
    return isHex(value) && getHexByteLength(value) === SUI_ADDRESS_LENGTH;
  }
  const MOVE_IDENTIFIER_REGEX = /^[a-zA-Z][a-zA-Z0-9_]*$/;
  function isValidMoveIdentifier(name) {
    return MOVE_IDENTIFIER_REGEX.test(name);
  }
  const PRIMITIVE_TYPE_TAGS = [
    "bool",
    "u8",
    "u16",
    "u32",
    "u64",
    "u128",
    "u256",
    "address",
    "signer"
  ];
  const VECTOR_TYPE_REGEX = /^vector<(.+)>$/;
  function isValidTypeTag(type) {
    if (PRIMITIVE_TYPE_TAGS.includes(type)) return true;
    const vectorMatch = type.match(VECTOR_TYPE_REGEX);
    if (vectorMatch) return isValidTypeTag(vectorMatch[1]);
    if (type.includes("::")) return isValidStructTag(type);
    return false;
  }
  function isValidParsedStructTag(tag) {
    if (!isValidSuiAddress(tag.address) && !isValidNamedPackage(tag.address)) return false;
    if (!isValidMoveIdentifier(tag.module) || !isValidMoveIdentifier(tag.name)) return false;
    return tag.typeParams.every((param) => {
      if (typeof param === "string") return isValidTypeTag(param);
      return isValidParsedStructTag(param);
    });
  }
  function isValidStructTag(type) {
    try {
      return isValidParsedStructTag(parseStructTag(type));
    } catch {
      return false;
    }
  }
  function parseTypeTag(type) {
    if (type.startsWith("vector<")) {
      if (!type.endsWith(">")) throw new Error(`Invalid type tag: ${type}`);
      const inner = type.slice(7, -1);
      if (!inner) throw new Error(`Invalid type tag: ${type}`);
      const parsed = parseTypeTag(inner);
      if (typeof parsed === "string") return `vector<${parsed}>`;
      return `vector<${normalizeStructTag(parsed)}>`;
    }
    if (!type.includes("::")) return type;
    return parseStructTag(type);
  }
  function parseStructTag(type) {
    const parts = type.split("::");
    if (parts.length < 3) throw new Error(`Invalid struct tag: ${type}`);
    const [address, module] = parts;
    if (!address || !module) throw new Error(`Invalid struct tag: ${type}`);
    const isMvrPackage = isValidNamedPackage(address);
    const rest = type.slice(address.length + module.length + 4);
    const name = rest.includes("<") ? rest.slice(0, rest.indexOf("<")) : rest;
    if (!name || rest.includes("<") && !rest.endsWith(">")) throw new Error(`Invalid struct tag: ${type}`);
    const typeParams = rest.includes("<") ? splitGenericParameters(rest.slice(rest.indexOf("<") + 1, rest.lastIndexOf(">"))).map((typeParam) => parseTypeTag(typeParam.trim())) : [];
    return {
      address: isMvrPackage ? address : normalizeSuiAddress(address),
      module,
      name,
      typeParams
    };
  }
  function normalizeStructTag(type) {
    if (typeof type === "string" && type.startsWith("vector<")) throw new Error("normalizeStructTag does not support vector types. Use normalizeTypeTag instead.");
    const { address, module, name, typeParams } = typeof type === "string" ? parseStructTag(type) : type;
    return `${address}::${module}::${name}${typeParams?.length > 0 ? `<${typeParams.map((typeParam) => typeof typeParam === "string" ? typeParam : normalizeStructTag(typeParam)).join(",")}>` : ""}`;
  }
  function normalizeSuiAddress(value, forceAdd0x = false) {
    let address = value.toLowerCase();
    if (!forceAdd0x && address.startsWith("0x")) address = address.slice(2);
    return `0x${address.padStart(SUI_ADDRESS_LENGTH * 2, "0")}`;
  }
  function normalizeSuiObjectId(value, forceAdd0x = false) {
    return normalizeSuiAddress(value, forceAdd0x);
  }
  function isHex(value) {
    return /^(0x|0X)?[a-fA-F0-9]+$/.test(value) && value.length % 2 === 0;
  }
  function getHexByteLength(value) {
    return /^(0x|0X)/.test(value) ? (value.length - 2) / 2 : value.length / 2;
  }
  const VECTOR_REGEX = /^vector<(.+)>$/;
  const STRUCT_REGEX = /^([^:]+)::([^:]+)::([^<]+)(<(.+)>)?/;
  var TypeTagSerializer = class TypeTagSerializer2 {
    static parseFromStr(str, normalizeAddress = false) {
      if (str === "address") return { address: null };
      else if (str === "bool") return { bool: null };
      else if (str === "u8") return { u8: null };
      else if (str === "u16") return { u16: null };
      else if (str === "u32") return { u32: null };
      else if (str === "u64") return { u64: null };
      else if (str === "u128") return { u128: null };
      else if (str === "u256") return { u256: null };
      else if (str === "signer") return { signer: null };
      const vectorMatch = str.match(VECTOR_REGEX);
      if (vectorMatch) return { vector: TypeTagSerializer2.parseFromStr(vectorMatch[1], normalizeAddress) };
      const structMatch = str.match(STRUCT_REGEX);
      if (structMatch) return { struct: {
        address: normalizeAddress ? normalizeSuiAddress(structMatch[1]) : structMatch[1],
        module: structMatch[2],
        name: structMatch[3],
        typeParams: structMatch[5] === void 0 ? [] : TypeTagSerializer2.parseStructTypeArgs(structMatch[5], normalizeAddress)
      } };
      throw new Error(`Encountered unexpected token when parsing type args for ${str}`);
    }
    static parseStructTypeArgs(str, normalizeAddress = false) {
      return splitGenericParameters(str).map((tok) => TypeTagSerializer2.parseFromStr(tok, normalizeAddress));
    }
    static tagToString(tag) {
      if ("bool" in tag) return "bool";
      if ("u8" in tag) return "u8";
      if ("u16" in tag) return "u16";
      if ("u32" in tag) return "u32";
      if ("u64" in tag) return "u64";
      if ("u128" in tag) return "u128";
      if ("u256" in tag) return "u256";
      if ("address" in tag) return "address";
      if ("signer" in tag) return "signer";
      if ("vector" in tag) return `vector<${TypeTagSerializer2.tagToString(tag.vector)}>`;
      if ("struct" in tag) {
        const struct = tag.struct;
        const typeParams = struct.typeParams.map(TypeTagSerializer2.tagToString).join(", ");
        return `${struct.address}::${struct.module}::${struct.name}${typeParams ? `<${typeParams}>` : ""}`;
      }
      throw new Error("Invalid TypeTag");
    }
  };
  function unsafe_u64(options) {
    return bcs.u64({
      name: "unsafe_u64",
      ...options
    }).transform({
      input: (val) => val,
      output: (val) => Number(val)
    });
  }
  function optionEnum(type) {
    return bcs.enum("Option", {
      None: null,
      Some: type
    });
  }
  const HEX_NIBBLES = new Int8Array(128).fill(-1);
  for (let i = 0; i < 16; i++) {
    HEX_NIBBLES["0123456789abcdef".charCodeAt(i)] = i;
    HEX_NIBBLES["0123456789ABCDEF".charCodeAt(i)] = i;
  }
  function hexNibble(code) {
    return code < 128 ? HEX_NIBBLES[code] : -1;
  }
  function decodeAddress(value) {
    if (!value) return null;
    const start = value.length >= 2 && value[0] === "0" && (value[1] === "x" || value[1] === "X") ? 2 : 0;
    if (value.length - start > SUI_ADDRESS_LENGTH * 2) return null;
    const bytes = new Uint8Array(SUI_ADDRESS_LENGTH);
    let byteIndex = SUI_ADDRESS_LENGTH - 1;
    let i = value.length - 1;
    for (; i >= start + 1; i -= 2) {
      const low = hexNibble(value.charCodeAt(i));
      const high = hexNibble(value.charCodeAt(i - 1));
      if (low < 0 || high < 0) return null;
      bytes[byteIndex--] = high << 4 | low;
    }
    if (i === start) {
      const low = hexNibble(value.charCodeAt(i));
      if (low < 0) return null;
      bytes[byteIndex] = low;
    }
    return bytes;
  }
  const Address = bcs.bytes(SUI_ADDRESS_LENGTH).transform({
    input: (val) => {
      if (typeof val === "string") {
        const bytes = decodeAddress(val);
        if (!bytes) throw new Error(`Invalid Sui address ${val}`);
        return bytes;
      }
      const address = toHex(val);
      if (!address || !isValidSuiAddress(normalizeSuiAddress(address))) throw new Error(`Invalid Sui address ${address}`);
      return val;
    },
    output: (val) => `0x${toHex(val)}`
  });
  const ObjectDigest = bcs.byteVector().transform({
    name: "ObjectDigest",
    input: (value) => {
      const bytes = fromBase58(value);
      if (bytes.length !== 32) throw new Error("ObjectDigest must be 32 bytes");
      return bytes;
    },
    output: (value) => toBase58(value)
  });
  const SuiObjectRef = bcs.struct("SuiObjectRef", {
    objectId: Address,
    version: bcs.u64(),
    digest: ObjectDigest
  });
  const SharedObjectRef = bcs.struct("SharedObjectRef", {
    objectId: Address,
    initialSharedVersion: bcs.u64(),
    mutable: bcs.bool()
  });
  const ObjectArg$1 = bcs.enum("ObjectArg", {
    ImmOrOwnedObject: SuiObjectRef,
    SharedObject: SharedObjectRef,
    Receiving: SuiObjectRef
  });
  const Owner = bcs.enum("Owner", {
    AddressOwner: Address,
    ObjectOwner: Address,
    Shared: bcs.struct("Shared", { initialSharedVersion: bcs.u64() }),
    Immutable: null,
    ConsensusAddressOwner: bcs.struct("ConsensusAddressOwner", {
      startVersion: bcs.u64(),
      owner: Address
    })
  });
  const Reservation = bcs.enum("Reservation", { MaxAmountU64: bcs.u64() });
  const WithdrawalType = bcs.enum("WithdrawalType", { Balance: bcs.lazy(() => TypeTag) });
  const WithdrawFrom = bcs.enum("WithdrawFrom", {
    Sender: null,
    Sponsor: null,
    SenderAllowance: bcs.struct("SenderAllowance", {
      funder: Address,
      allowance: Address
    })
  });
  const FundsWithdrawal = bcs.struct("FundsWithdrawal", {
    reservation: Reservation,
    typeArg: WithdrawalType,
    withdrawFrom: WithdrawFrom
  });
  const CallArg$1 = bcs.enum("CallArg", {
    Pure: bcs.struct("Pure", { bytes: bcs.byteVector().transform({
      input: (val) => typeof val === "string" ? fromBase64(val) : val,
      output: (val) => toBase64(val)
    }) }),
    Object: ObjectArg$1,
    FundsWithdrawal
  });
  const InnerTypeTag = bcs.enum("TypeTag", {
    bool: null,
    u8: null,
    u64: null,
    u128: null,
    address: null,
    signer: null,
    vector: bcs.lazy(() => InnerTypeTag),
    struct: bcs.lazy(() => StructTag),
    u16: null,
    u32: null,
    u256: null
  });
  const TypeTag = InnerTypeTag.transform({
    input: (typeTag) => typeof typeTag === "string" ? TypeTagSerializer.parseFromStr(typeTag, true) : typeTag,
    output: (typeTag) => TypeTagSerializer.tagToString(typeTag)
  });
  const Argument$1 = bcs.enum("Argument", {
    GasCoin: null,
    Input: bcs.u16(),
    Result: bcs.u16(),
    NestedResult: bcs.tuple([bcs.u16(), bcs.u16()])
  });
  const ProgrammableMoveCall$1 = bcs.struct("ProgrammableMoveCall", {
    package: Address,
    module: bcs.string(),
    function: bcs.string(),
    typeArguments: bcs.vector(TypeTag),
    arguments: bcs.vector(Argument$1)
  });
  const Command$1 = bcs.enum("Command", {
    MoveCall: ProgrammableMoveCall$1,
    TransferObjects: bcs.struct("TransferObjects", {
      objects: bcs.vector(Argument$1),
      address: Argument$1
    }),
    SplitCoins: bcs.struct("SplitCoins", {
      coin: Argument$1,
      amounts: bcs.vector(Argument$1)
    }),
    MergeCoins: bcs.struct("MergeCoins", {
      destination: Argument$1,
      sources: bcs.vector(Argument$1)
    }),
    Publish: bcs.struct("Publish", {
      modules: bcs.vector(bcs.byteVector().transform({
        input: (val) => typeof val === "string" ? fromBase64(val) : val,
        output: (val) => toBase64(val)
      })),
      dependencies: bcs.vector(Address)
    }),
    MakeMoveVec: bcs.struct("MakeMoveVec", {
      type: optionEnum(TypeTag).transform({
        input: (val) => val === null ? { None: true } : { Some: val },
        output: (val) => val.Some ?? null
      }),
      elements: bcs.vector(Argument$1)
    }),
    Upgrade: bcs.struct("Upgrade", {
      modules: bcs.vector(bcs.byteVector().transform({
        input: (val) => typeof val === "string" ? fromBase64(val) : val,
        output: (val) => toBase64(val)
      })),
      dependencies: bcs.vector(Address),
      package: Address,
      ticket: Argument$1
    })
  });
  const ProgrammableTransaction = bcs.struct("ProgrammableTransaction", {
    inputs: bcs.vector(CallArg$1),
    commands: bcs.vector(Command$1)
  });
  const ValidDuring = bcs.struct("ValidDuring", {
    minEpoch: bcs.option(bcs.u64()),
    maxEpoch: bcs.option(bcs.u64()),
    minTimestamp: bcs.option(bcs.u64()),
    maxTimestamp: bcs.option(bcs.u64()),
    chain: ObjectDigest,
    nonce: bcs.u32()
  });
  function assertAllowedProposersNotEmpty(proposers) {
    if (proposers.length === 0) throw new Error("Allowed proposers must not be empty");
    return proposers;
  }
  function assertAllowedProposersStrictlyIncreasing(proposers) {
    assertAllowedProposersNotEmpty(proposers);
    for (let i = 1; i < proposers.length; i++) if (proposers[i] <= proposers[i - 1]) throw new Error("Allowed proposers must be strictly increasing");
    return proposers;
  }
  const AllowedProposerIndices = bcs.vector(bcs.u32()).transform({
    input: assertAllowedProposersStrictlyIncreasing,
    output: assertAllowedProposersNotEmpty
  });
  const AllowedProposers = bcs.struct("AllowedProposers", {
    epoch: bcs.u64(),
    proposers: AllowedProposerIndices
  });
  const Validity = bcs.struct("Validity", {
    minEpoch: bcs.option(bcs.u64()),
    maxEpoch: bcs.option(bcs.u64()),
    minTimestamp: bcs.option(bcs.u64()),
    maxTimestamp: bcs.option(bcs.u64()),
    chain: ObjectDigest,
    nonce: bcs.u32(),
    allowedProposers: bcs.option(AllowedProposers)
  });
  const TransactionExpiration$2 = bcs.enum("TransactionExpiration", {
    None: null,
    Epoch: unsafe_u64(),
    ValidDuring,
    Validity
  });
  const StructTag = bcs.struct("StructTag", {
    address: Address,
    module: bcs.string(),
    name: bcs.string(),
    typeParams: bcs.vector(InnerTypeTag)
  });
  const GasData$1 = bcs.struct("GasData", {
    payment: bcs.vector(SuiObjectRef),
    owner: Address,
    price: bcs.u64(),
    budget: bcs.u64()
  });
  const IntentScope = bcs.enum("IntentScope", {
    TransactionData: null,
    TransactionEffects: null,
    CheckpointSummary: null,
    PersonalMessage: null
  });
  const IntentVersion = bcs.enum("IntentVersion", { V0: null });
  const AppId = bcs.enum("AppId", { Sui: null });
  const Intent = bcs.struct("Intent", {
    scope: IntentScope,
    version: IntentVersion,
    appId: AppId
  });
  function IntentMessage(T) {
    return bcs.struct(`IntentMessage<${T.name}>`, {
      intent: Intent,
      value: T
    });
  }
  const CompressedSignature = bcs.enum("CompressedSignature", {
    ED25519: bcs.bytes(64),
    Secp256k1: bcs.bytes(64),
    Secp256r1: bcs.bytes(64),
    ZkLogin: bcs.byteVector(),
    Passkey: bcs.byteVector(),
    MLDSA65: bcs.bytes(3309)
  });
  const PublicKey$1 = bcs.enum("PublicKey", {
    ED25519: bcs.bytes(32),
    Secp256k1: bcs.bytes(33),
    Secp256r1: bcs.bytes(33),
    ZkLogin: bcs.byteVector(),
    Passkey: bcs.bytes(33),
    MLDSA65: bcs.bytes(1952)
  });
  const MultiSigPkMap = bcs.struct("MultiSigPkMap", {
    pubKey: PublicKey$1,
    weight: bcs.u8()
  });
  const MultiSigPublicKey = bcs.struct("MultiSigPublicKey", {
    pk_map: bcs.vector(MultiSigPkMap),
    threshold: bcs.u16()
  });
  const MultiSig = bcs.struct("MultiSig", {
    sigs: bcs.vector(CompressedSignature),
    bitmap: bcs.u16(),
    multisig_pk: MultiSigPublicKey
  });
  const base64String = bcs.byteVector().transform({
    input: (val) => typeof val === "string" ? fromBase64(val) : val,
    output: (val) => toBase64(val)
  });
  const PasskeyAuthenticator = bcs.struct("PasskeyAuthenticator", {
    authenticatorData: bcs.byteVector(),
    clientDataJson: bcs.string(),
    userSignature: bcs.byteVector()
  });
  const MoveObjectType = bcs.enum("MoveObjectType", {
    Other: StructTag,
    GasCoin: null,
    StakedSui: null,
    Coin: TypeTag,
    AccumulatorBalanceWrapper: null
  });
  const TypeOrigin = bcs.struct("TypeOrigin", {
    moduleName: bcs.string(),
    datatypeName: bcs.string(),
    package: Address
  });
  const UpgradeInfo = bcs.struct("UpgradeInfo", {
    upgradedId: Address,
    upgradedVersion: bcs.u64()
  });
  const MovePackage = bcs.struct("MovePackage", {
    id: Address,
    version: bcs.u64(),
    moduleMap: bcs.map(bcs.string(), bcs.byteVector()),
    typeOriginTable: bcs.vector(TypeOrigin),
    linkageTable: bcs.map(Address, UpgradeInfo)
  });
  const MoveObject = bcs.struct("MoveObject", {
    type: MoveObjectType,
    hasPublicTransfer: bcs.bool(),
    version: bcs.u64(),
    contents: bcs.byteVector()
  });
  const Data = bcs.enum("Data", {
    Move: MoveObject,
    Package: MovePackage
  });
  const ObjectInner = bcs.struct("ObjectInner", {
    data: Data,
    owner: Owner,
    previousTransaction: ObjectDigest,
    storageRebate: bcs.u64()
  });
  const ChangeEpoch = bcs.struct("ChangeEpoch", {
    epoch: bcs.u64(),
    protocolVersion: bcs.u64(),
    storageCharge: bcs.u64(),
    computationCharge: bcs.u64(),
    storageRebate: bcs.u64(),
    nonRefundableStorageFee: bcs.u64(),
    epochStartTimestampMs: bcs.u64(),
    systemPackages: bcs.vector(bcs.tuple([
      bcs.u64(),
      bcs.vector(bcs.byteVector()),
      bcs.vector(Address)
    ]))
  });
  const GenesisObject = bcs.enum("GenesisObject", { RawObject: bcs.struct("RawObject", {
    data: Data,
    owner: Owner
  }) });
  const GenesisTransaction = bcs.struct("GenesisTransaction", { objects: bcs.vector(GenesisObject) });
  const ConsensusCommitPrologue = bcs.struct("ConsensusCommitPrologue", {
    epoch: bcs.u64(),
    round: bcs.u64(),
    commitTimestampMs: bcs.u64()
  });
  const ConsensusCommitPrologueV2 = bcs.struct("ConsensusCommitPrologueV2", {
    epoch: bcs.u64(),
    round: bcs.u64(),
    commitTimestampMs: bcs.u64(),
    consensusCommitDigest: ObjectDigest
  });
  const ConsensusDeterminedVersionAssignments = bcs.enum("ConsensusDeterminedVersionAssignments", {
    CancelledTransactions: bcs.vector(bcs.tuple([ObjectDigest, bcs.vector(bcs.tuple([Address, bcs.u64()]))])),
    CancelledTransactionsV2: bcs.vector(bcs.tuple([ObjectDigest, bcs.vector(bcs.tuple([bcs.tuple([Address, bcs.u64()]), bcs.u64()]))]))
  });
  const ConsensusCommitPrologueV3 = bcs.struct("ConsensusCommitPrologueV3", {
    epoch: bcs.u64(),
    round: bcs.u64(),
    subDagIndex: bcs.option(bcs.u64()),
    commitTimestampMs: bcs.u64(),
    consensusCommitDigest: ObjectDigest,
    consensusDeterminedVersionAssignments: ConsensusDeterminedVersionAssignments
  });
  const ConsensusCommitPrologueV4 = bcs.struct("ConsensusCommitPrologueV4", {
    epoch: bcs.u64(),
    round: bcs.u64(),
    subDagIndex: bcs.option(bcs.u64()),
    commitTimestampMs: bcs.u64(),
    consensusCommitDigest: ObjectDigest,
    consensusDeterminedVersionAssignments: ConsensusDeterminedVersionAssignments,
    additionalStateDigest: ObjectDigest
  });
  const ActiveJwk = bcs.struct("ActiveJwk", {
    jwkId: bcs.struct("JwkId", {
      iss: bcs.string(),
      kid: bcs.string()
    }),
    jwk: bcs.struct("JWK", {
      kty: bcs.string(),
      e: bcs.string(),
      n: bcs.string(),
      alg: bcs.string()
    }),
    epoch: bcs.u64()
  });
  const AuthenticatorStateUpdate = bcs.struct("AuthenticatorStateUpdate", {
    epoch: bcs.u64(),
    round: bcs.u64(),
    newActiveJwks: bcs.vector(ActiveJwk),
    authenticatorObjInitialSharedVersion: bcs.u64()
  });
  const RandomnessStateUpdate = bcs.struct("RandomnessStateUpdate", {
    epoch: bcs.u64(),
    randomnessRound: bcs.u64(),
    randomBytes: bcs.byteVector(),
    randomnessObjInitialSharedVersion: bcs.u64()
  });
  const AuthenticatorStateExpire = bcs.struct("AuthenticatorStateExpire", {
    minEpoch: bcs.u64(),
    authenticatorObjInitialSharedVersion: bcs.u64()
  });
  const ExecutionTimeObservationKey = bcs.enum("ExecutionTimeObservationKey", {
    MoveEntryPoint: bcs.struct("MoveEntryPoint", {
      package: Address,
      module: bcs.string(),
      function: bcs.string(),
      typeArguments: bcs.vector(TypeTag)
    }),
    TransferObjects: null,
    SplitCoins: null,
    MergeCoins: null,
    Publish: null,
    MakeMoveVec: null,
    Upgrade: null
  });
  const StoredExecutionTimeObservations = bcs.enum("StoredExecutionTimeObservations", { V1: bcs.vector(bcs.tuple([ExecutionTimeObservationKey, bcs.vector(bcs.tuple([bcs.byteVector(), bcs.struct("Duration", {
    secs: bcs.u64(),
    nanos: bcs.u32()
  })]))])) });
  const WriteAccumulatorStorageCost = bcs.struct("WriteAccumulatorStorageCost", { storageCost: bcs.u64() });
  const EndOfEpochTransactionKind = bcs.enum("EndOfEpochTransactionKind", {
    ChangeEpoch,
    AuthenticatorStateCreate: null,
    AuthenticatorStateExpire,
    RandomnessStateCreate: null,
    DenyListStateCreate: null,
    BridgeStateCreate: ObjectDigest,
    BridgeCommitteeInit: bcs.u64(),
    StoreExecutionTimeObservations: StoredExecutionTimeObservations,
    AccumulatorRootCreate: null,
    CoinRegistryCreate: null,
    DisplayRegistryCreate: null,
    AddressAliasStateCreate: null,
    WriteAccumulatorStorageCost,
    ForwardingAddressRegistryCreate: null
  });
  const TransactionKind = bcs.enum("TransactionKind", {
    ProgrammableTransaction,
    ChangeEpoch,
    Genesis: GenesisTransaction,
    ConsensusCommitPrologue,
    AuthenticatorStateUpdate,
    EndOfEpochTransaction: bcs.vector(EndOfEpochTransactionKind),
    RandomnessStateUpdate,
    ConsensusCommitPrologueV2,
    ConsensusCommitPrologueV3,
    ConsensusCommitPrologueV4,
    ProgrammableSystemTransaction: ProgrammableTransaction
  });
  const TransactionDataV1 = bcs.struct("TransactionDataV1", {
    kind: TransactionKind,
    sender: Address,
    gasData: GasData$1,
    expiration: TransactionExpiration$2
  });
  const TransactionData = bcs.enum("TransactionData", { V1: TransactionDataV1 });
  const SenderSignedTransaction = bcs.struct("SenderSignedTransaction", {
    intentMessage: IntentMessage(TransactionData),
    txSignatures: bcs.vector(base64String)
  });
  const SenderSignedData = bcs.vector(SenderSignedTransaction, { name: "SenderSignedData" });
  const PackageUpgradeError = bcs.enum("PackageUpgradeError", {
    UnableToFetchPackage: bcs.struct("UnableToFetchPackage", { packageId: Address }),
    NotAPackage: bcs.struct("NotAPackage", { objectId: Address }),
    IncompatibleUpgrade: null,
    DigestDoesNotMatch: bcs.struct("DigestDoesNotMatch", { digest: bcs.byteVector() }),
    UnknownUpgradePolicy: bcs.struct("UnknownUpgradePolicy", { policy: bcs.u8() }),
    PackageIDDoesNotMatch: bcs.struct("PackageIDDoesNotMatch", {
      packageId: Address,
      ticketId: Address
    })
  });
  const ModuleId = bcs.struct("ModuleId", {
    address: Address,
    name: bcs.string()
  });
  const MoveLocation = bcs.struct("MoveLocation", {
    module: ModuleId,
    function: bcs.u16(),
    instruction: bcs.u16(),
    functionName: bcs.option(bcs.string())
  });
  const CommandArgumentError = bcs.enum("CommandArgumentError", {
    TypeMismatch: null,
    InvalidBCSBytes: null,
    InvalidUsageOfPureArg: null,
    InvalidArgumentToPrivateEntryFunction: null,
    IndexOutOfBounds: bcs.struct("IndexOutOfBounds", { idx: bcs.u16() }),
    SecondaryIndexOutOfBounds: bcs.struct("SecondaryIndexOutOfBounds", {
      resultIdx: bcs.u16(),
      secondaryIdx: bcs.u16()
    }),
    InvalidResultArity: bcs.struct("InvalidResultArity", { resultIdx: bcs.u16() }),
    InvalidGasCoinUsage: null,
    InvalidValueUsage: null,
    InvalidObjectByValue: null,
    InvalidObjectByMutRef: null,
    SharedObjectOperationNotAllowed: null,
    InvalidArgumentArity: null,
    InvalidTransferObject: null,
    InvalidMakeMoveVecNonObjectArgument: null,
    ArgumentWithoutValue: null,
    CannotMoveBorrowedValue: null,
    CannotWriteToExtendedReference: null,
    InvalidReferenceArgument: null,
    InvalidTxContext: null
  });
  const TypeArgumentError = bcs.enum("TypeArgumentError", {
    TypeNotFound: null,
    ConstraintNotSatisfied: null
  });
  const ExecutionFailureStatus = bcs.enum("ExecutionFailureStatus", {
    InsufficientGas: null,
    InvalidGasObject: null,
    InvariantViolation: null,
    FeatureNotYetSupported: null,
    MoveObjectTooBig: bcs.struct("MoveObjectTooBig", {
      objectSize: bcs.u64(),
      maxObjectSize: bcs.u64()
    }),
    MovePackageTooBig: bcs.struct("MovePackageTooBig", {
      objectSize: bcs.u64(),
      maxObjectSize: bcs.u64()
    }),
    CircularObjectOwnership: bcs.struct("CircularObjectOwnership", { object: Address }),
    InsufficientCoinBalance: null,
    CoinBalanceOverflow: null,
    PublishErrorNonZeroAddress: null,
    SuiMoveVerificationError: null,
    MovePrimitiveRuntimeError: bcs.option(MoveLocation),
    MoveAbort: bcs.tuple([MoveLocation, bcs.u64()]),
    VMVerificationOrDeserializationError: null,
    VMInvariantViolation: null,
    FunctionNotFound: null,
    ArityMismatch: null,
    TypeArityMismatch: null,
    NonEntryFunctionInvoked: null,
    CommandArgumentError: bcs.struct("CommandArgumentError", {
      argIdx: bcs.u16(),
      kind: CommandArgumentError
    }),
    TypeArgumentError: bcs.struct("TypeArgumentError", {
      argumentIdx: bcs.u16(),
      kind: TypeArgumentError
    }),
    UnusedValueWithoutDrop: bcs.struct("UnusedValueWithoutDrop", {
      resultIdx: bcs.u16(),
      secondaryIdx: bcs.u16()
    }),
    InvalidPublicFunctionReturnType: bcs.struct("InvalidPublicFunctionReturnType", { idx: bcs.u16() }),
    InvalidTransferObject: null,
    EffectsTooLarge: bcs.struct("EffectsTooLarge", {
      currentSize: bcs.u64(),
      maxSize: bcs.u64()
    }),
    PublishUpgradeMissingDependency: null,
    PublishUpgradeDependencyDowngrade: null,
    PackageUpgradeError: bcs.struct("PackageUpgradeError", { upgradeError: PackageUpgradeError }),
    WrittenObjectsTooLarge: bcs.struct("WrittenObjectsTooLarge", {
      currentSize: bcs.u64(),
      maxSize: bcs.u64()
    }),
    CertificateDenied: null,
    SuiMoveVerificationTimedout: null,
    SharedObjectOperationNotAllowed: null,
    InputObjectDeleted: null,
    ExecutionCancelledDueToSharedObjectCongestion: bcs.struct("ExecutionCancelledDueToSharedObjectCongestion", { congested_objects: bcs.vector(Address) }),
    AddressDeniedForCoin: bcs.struct("AddressDeniedForCoin", {
      address: Address,
      coinType: bcs.string()
    }),
    CoinTypeGlobalPause: bcs.struct("CoinTypeGlobalPause", { coinType: bcs.string() }),
    ExecutionCancelledDueToRandomnessUnavailable: null,
    MoveVectorElemTooBig: bcs.struct("MoveVectorElemTooBig", {
      valueSize: bcs.u64(),
      maxScaledSize: bcs.u64()
    }),
    MoveRawValueTooBig: bcs.struct("MoveRawValueTooBig", {
      valueSize: bcs.u64(),
      maxScaledSize: bcs.u64()
    }),
    InvalidLinkage: null,
    InsufficientBalanceForWithdraw: null,
    NonExclusiveWriteInputObjectModified: bcs.struct("NonExclusiveWriteInputObjectModified", { id: Address }),
    TransactionExpired: null
  });
  const ExecutionStatus = bcs.enum("ExecutionStatus", {
    Success: null,
    Failure: bcs.struct("Failure", {
      error: ExecutionFailureStatus,
      command: bcs.option(bcs.u64())
    })
  });
  const GasCostSummary = bcs.struct("GasCostSummary", {
    computationCost: bcs.u64(),
    storageCost: bcs.u64(),
    storageRebate: bcs.u64(),
    nonRefundableStorageFee: bcs.u64()
  });
  const TransactionEffectsV1 = bcs.struct("TransactionEffectsV1", {
    status: ExecutionStatus,
    executedEpoch: bcs.u64(),
    gasUsed: GasCostSummary,
    modifiedAtVersions: bcs.vector(bcs.tuple([Address, bcs.u64()])),
    sharedObjects: bcs.vector(SuiObjectRef),
    transactionDigest: ObjectDigest,
    created: bcs.vector(bcs.tuple([SuiObjectRef, Owner])),
    mutated: bcs.vector(bcs.tuple([SuiObjectRef, Owner])),
    unwrapped: bcs.vector(bcs.tuple([SuiObjectRef, Owner])),
    deleted: bcs.vector(SuiObjectRef),
    unwrappedThenDeleted: bcs.vector(SuiObjectRef),
    wrapped: bcs.vector(SuiObjectRef),
    gasObject: bcs.tuple([SuiObjectRef, Owner]),
    eventsDigest: bcs.option(ObjectDigest),
    dependencies: bcs.vector(ObjectDigest)
  });
  const VersionDigest = bcs.tuple([bcs.u64(), ObjectDigest]);
  const ObjectIn = bcs.enum("ObjectIn", {
    NotExist: null,
    Exist: bcs.tuple([VersionDigest, Owner])
  });
  const AccumulatorAddress = bcs.struct("AccumulatorAddress", {
    address: Address,
    ty: TypeTag
  });
  const AccumulatorOperation = bcs.enum("AccumulatorOperation", {
    Merge: null,
    Split: null
  });
  const AccumulatorValue = bcs.enum("AccumulatorValue", {
    Integer: bcs.u64(),
    IntegerTuple: bcs.tuple([bcs.u64(), bcs.u64()]),
    EventDigest: bcs.vector(bcs.tuple([bcs.u64(), ObjectDigest]))
  });
  const AccumulatorWriteV1 = bcs.struct("AccumulatorWriteV1", {
    address: AccumulatorAddress,
    operation: AccumulatorOperation,
    value: AccumulatorValue
  });
  const ObjectOut = bcs.enum("ObjectOut", {
    NotExist: null,
    ObjectWrite: bcs.tuple([ObjectDigest, Owner]),
    PackageWrite: VersionDigest,
    AccumulatorWriteV1
  });
  const IDOperation = bcs.enum("IDOperation", {
    None: null,
    Created: null,
    Deleted: null
  });
  const EffectsObjectChange = bcs.struct("EffectsObjectChange", {
    inputState: ObjectIn,
    outputState: ObjectOut,
    idOperation: IDOperation
  });
  const UnchangedConsensusKind = bcs.enum("UnchangedConsensusKind", {
    ReadOnlyRoot: VersionDigest,
    MutateConsensusStreamEnded: bcs.u64(),
    ReadConsensusStreamEnded: bcs.u64(),
    Cancelled: bcs.u64(),
    PerEpochConfig: null
  });
  const TransactionEffectsV2 = bcs.struct("TransactionEffectsV2", {
    status: ExecutionStatus,
    executedEpoch: bcs.u64(),
    gasUsed: GasCostSummary,
    transactionDigest: ObjectDigest,
    gasObjectIndex: bcs.option(bcs.u32()),
    eventsDigest: bcs.option(ObjectDigest),
    dependencies: bcs.vector(ObjectDigest),
    lamportVersion: bcs.u64(),
    changedObjects: bcs.vector(bcs.tuple([Address, EffectsObjectChange])),
    unchangedConsensusObjects: bcs.vector(bcs.tuple([Address, UnchangedConsensusKind])),
    auxDataDigest: bcs.option(ObjectDigest)
  });
  const TransactionEffects = bcs.enum("TransactionEffects", {
    V1: TransactionEffectsV1,
    V2: TransactionEffectsV2
  });
  function pureBcsSchemaFromTypeName(name) {
    switch (name) {
      case "u8":
        return bcs.u8();
      case "u16":
        return bcs.u16();
      case "u32":
        return bcs.u32();
      case "u64":
        return bcs.u64();
      case "u128":
        return bcs.u128();
      case "u256":
        return bcs.u256();
      case "bool":
        return bcs.bool();
      case "string":
        return bcs.string();
      case "id":
      case "address":
        return Address;
    }
    const generic = name.match(/^(vector|option)<(.+)>$/);
    if (generic) {
      const [kind, inner] = generic.slice(1);
      if (kind === "vector") return bcs.vector(pureBcsSchemaFromTypeName(inner));
      else return bcs.option(pureBcsSchemaFromTypeName(inner));
    }
    throw new Error(`Invalid Pure type name: ${name}`);
  }
  const suiBcs = {
    ...bcs,
    U8: bcs.u8(),
    U16: bcs.u16(),
    U32: bcs.u32(),
    U64: bcs.u64(),
    U128: bcs.u128(),
    U256: bcs.u256(),
    ULEB128: bcs.uleb128(),
    Bool: bcs.bool(),
    String: bcs.string(),
    Address,
    AppId,
    Argument: Argument$1,
    CallArg: CallArg$1,
    Command: Command$1,
    CompressedSignature,
    Data,
    GasData: GasData$1,
    Intent,
    IntentMessage,
    IntentScope,
    IntentVersion,
    MoveObject,
    MoveObjectType,
    MovePackage,
    MultiSig,
    MultiSigPkMap,
    MultiSigPublicKey,
    Object: ObjectInner,
    ObjectArg: ObjectArg$1,
    ObjectDigest,
    Owner,
    PasskeyAuthenticator,
    ProgrammableMoveCall: ProgrammableMoveCall$1,
    ProgrammableTransaction,
    PublicKey: PublicKey$1,
    SenderSignedData,
    SenderSignedTransaction,
    SharedObjectRef,
    StructTag,
    SuiObjectRef,
    TransactionData,
    TransactionDataV1,
    TransactionEffects,
    TransactionExpiration: TransactionExpiration$2,
    TransactionKind,
    TypeOrigin,
    TypeTag,
    UpgradeInfo
  };
  const DEFAULT_CONFIG = {
    lang: void 0,
    message: void 0,
    abortEarly: void 0,
    abortPipeEarly: void 0
  };
  // @__NO_SIDE_EFFECTS__
  function getGlobalConfig(config$1) {
    return DEFAULT_CONFIG;
  }
  let store$3;
  // @__NO_SIDE_EFFECTS__
  function getGlobalMessage(lang) {
    return store$3?.get(lang);
  }
  let store$2;
  // @__NO_SIDE_EFFECTS__
  function getSchemaMessage(lang) {
    return store$2?.get(lang);
  }
  let store$1;
  // @__NO_SIDE_EFFECTS__
  function getSpecificMessage(reference, lang) {
    return store$1?.get(reference)?.get(lang);
  }
  // @__NO_SIDE_EFFECTS__
  function _stringify(input) {
    const type = typeof input;
    if (type === "string") return `"${input}"`;
    if (type === "number" || type === "bigint" || type === "boolean") return `${input}`;
    if (type === "object" || type === "function") return (input && Object.getPrototypeOf(input)?.constructor?.name) ?? "null";
    return type;
  }
  function _addIssue(context, label, dataset, config$1, other) {
    const input = other && "input" in other ? other.input : dataset.value;
    const expected = other?.expected ?? context.expects ?? null;
    const received = other?.received ?? /* @__PURE__ */ _stringify(input);
    const issue = {
      kind: context.kind,
      type: context.type,
      input,
      expected,
      received,
      message: `Invalid ${label}: ${expected ? `Expected ${expected} but r` : "R"}eceived ${received}`,
      requirement: context.requirement,
      path: other?.path,
      issues: other?.issues,
      lang: config$1.lang,
      abortEarly: config$1.abortEarly,
      abortPipeEarly: config$1.abortPipeEarly
    };
    const isSchema = context.kind === "schema";
    const message$1 = other?.message ?? context.message ?? /* @__PURE__ */ getSpecificMessage(context.reference, issue.lang) ?? (isSchema ? /* @__PURE__ */ getSchemaMessage(issue.lang) : null) ?? config$1.message ?? /* @__PURE__ */ getGlobalMessage(issue.lang);
    if (message$1 !== void 0) issue.message = typeof message$1 === "function" ? message$1(issue) : message$1;
    if (isSchema) dataset.typed = false;
    if (dataset.issues) dataset.issues.push(issue);
    else dataset.issues = [issue];
  }
  // @__NO_SIDE_EFFECTS__
  function _isSameValueZero(value1, value2) {
    return value1 === value2 || Number.isNaN(value1) && Number.isNaN(value2);
  }
  // @__NO_SIDE_EFFECTS__
  function _isValidObjectKey(object$1, key) {
    return Object.prototype.hasOwnProperty.call(object$1, key) && key !== "__proto__" && key !== "prototype" && key !== "constructor";
  }
  // @__NO_SIDE_EFFECTS__
  function _joinExpects(values$1, separator) {
    const list = [...new Set(values$1)];
    if (list.length > 1) return `(${list.join(` ${separator} `)})`;
    return list[0] ?? "never";
  }
  function _standardSchema(schema) {
    schema["~standard"] = {
      version: 1,
      vendor: "valibot",
      validate: (value$1) => schema["~run"]({ value: value$1 }, /* @__PURE__ */ getGlobalConfig())
    };
    return schema;
  }
  var ValiError = class extends Error {
    /**
    * Creates a Valibot error with useful information.
    *
    * @param issues The error issues.
    */
    constructor(issues) {
      super(issues[0].message);
      this.name = "ValiError";
      this.issues = issues;
    }
  };
  // @__NO_SIDE_EFFECTS__
  function check(requirement, message$1) {
    return {
      kind: "validation",
      type: "check",
      reference: check,
      async: false,
      expects: null,
      requirement,
      message: message$1,
      "~run"(dataset, config$1) {
        if (dataset.typed && !this.requirement(dataset.value)) _addIssue(this, "input", dataset, config$1);
        return dataset;
      }
    };
  }
  // @__NO_SIDE_EFFECTS__
  function integer(message$1) {
    return {
      kind: "validation",
      type: "integer",
      reference: integer,
      async: false,
      expects: null,
      requirement: Number.isInteger,
      message: message$1,
      "~run"(dataset, config$1) {
        if (dataset.typed && !this.requirement(dataset.value)) _addIssue(this, "integer", dataset, config$1);
        return dataset;
      }
    };
  }
  // @__NO_SIDE_EFFECTS__
  function transform(operation) {
    return {
      kind: "transformation",
      type: "transform",
      reference: transform,
      async: false,
      operation,
      "~run"(dataset) {
        dataset.value = this.operation(dataset.value);
        return dataset;
      }
    };
  }
  const ABORT_EARLY_CONFIG = { abortEarly: true };
  // @__NO_SIDE_EFFECTS__
  function getFallback(schema, dataset, config$1) {
    return typeof schema.fallback === "function" ? schema.fallback(dataset, config$1) : schema.fallback;
  }
  // @__NO_SIDE_EFFECTS__
  function getDefault(schema, dataset, config$1) {
    return typeof schema.default === "function" ? schema.default(dataset, config$1) : schema.default;
  }
  // @__NO_SIDE_EFFECTS__
  function is(schema, input) {
    return !schema["~run"]({ value: input }, ABORT_EARLY_CONFIG).issues;
  }
  // @__NO_SIDE_EFFECTS__
  function array(item, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "array",
      reference: array,
      expects: "Array",
      async: false,
      item,
      message: message$1,
      "~run"(dataset, config$1) {
        const input = dataset.value;
        if (Array.isArray(input)) {
          dataset.typed = true;
          dataset.value = [];
          for (let key = 0; key < input.length; key++) {
            const value$1 = input[key];
            const itemDataset = this.item["~run"]({ value: value$1 }, config$1);
            if (itemDataset.issues) {
              const pathItem = {
                type: "array",
                origin: "value",
                input,
                key,
                value: value$1
              };
              for (const issue of itemDataset.issues) {
                if (issue.path) issue.path.unshift(pathItem);
                else issue.path = [pathItem];
                dataset.issues?.push(issue);
              }
              if (!dataset.issues) dataset.issues = itemDataset.issues;
              if (config$1.abortEarly) {
                dataset.typed = false;
                break;
              }
            }
            if (!itemDataset.typed) dataset.typed = false;
            dataset.value.push(itemDataset.value);
          }
        } else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function bigint(message$1) {
    return _standardSchema({
      kind: "schema",
      type: "bigint",
      reference: bigint,
      expects: "bigint",
      async: false,
      message: message$1,
      "~run"(dataset, config$1) {
        if (typeof dataset.value === "bigint") dataset.typed = true;
        else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function boolean(message$1) {
    return _standardSchema({
      kind: "schema",
      type: "boolean",
      reference: boolean,
      expects: "boolean",
      async: false,
      message: message$1,
      "~run"(dataset, config$1) {
        if (typeof dataset.value === "boolean") dataset.typed = true;
        else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function lazy(getter) {
    return _standardSchema({
      kind: "schema",
      type: "lazy",
      reference: lazy,
      expects: "unknown",
      async: false,
      getter,
      "~run"(dataset, config$1) {
        return this.getter(dataset.value)["~run"](dataset, config$1);
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function literal(literal_, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "literal",
      reference: literal,
      expects: /* @__PURE__ */ _stringify(literal_),
      async: false,
      literal: literal_,
      message: message$1,
      "~run"(dataset, config$1) {
        if (/* @__PURE__ */ _isSameValueZero(dataset.value, this.literal)) dataset.typed = true;
        else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function nullable(wrapped, default_) {
    return _standardSchema({
      kind: "schema",
      type: "nullable",
      reference: nullable,
      expects: `(${wrapped.expects} | null)`,
      async: false,
      wrapped,
      default: default_,
      "~run"(dataset, config$1) {
        if (dataset.value === null) {
          if (this.default !== void 0) dataset.value = /* @__PURE__ */ getDefault(this, dataset, config$1);
          if (dataset.value === null) {
            dataset.typed = true;
            return dataset;
          }
        }
        return this.wrapped["~run"](dataset, config$1);
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function nullish(wrapped, default_) {
    return _standardSchema({
      kind: "schema",
      type: "nullish",
      reference: nullish,
      expects: `(${wrapped.expects} | null | undefined)`,
      async: false,
      wrapped,
      default: default_,
      "~run"(dataset, config$1) {
        if (dataset.value === null || dataset.value === void 0) {
          if (this.default !== void 0) dataset.value = /* @__PURE__ */ getDefault(this, dataset, config$1);
          if (dataset.value === null || dataset.value === void 0) {
            dataset.typed = true;
            return dataset;
          }
        }
        return this.wrapped["~run"](dataset, config$1);
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function number(message$1) {
    return _standardSchema({
      kind: "schema",
      type: "number",
      reference: number,
      expects: "number",
      async: false,
      message: message$1,
      "~run"(dataset, config$1) {
        if (typeof dataset.value === "number" && !isNaN(dataset.value)) dataset.typed = true;
        else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function object(entries$1, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "object",
      reference: object,
      expects: "Object",
      async: false,
      entries: entries$1,
      message: message$1,
      "~run"(dataset, config$1) {
        const input = dataset.value;
        if (input && typeof input === "object") {
          dataset.typed = true;
          dataset.value = {};
          for (const key in this.entries) {
            const valueSchema = this.entries[key];
            if (key in input || (valueSchema.type === "exact_optional" || valueSchema.type === "optional" || valueSchema.type === "nullish") && valueSchema.default !== void 0) {
              const value$1 = key in input ? input[key] : /* @__PURE__ */ getDefault(valueSchema);
              const valueDataset = valueSchema["~run"]({ value: value$1 }, config$1);
              if (valueDataset.issues) {
                const pathItem = {
                  type: "object",
                  origin: "value",
                  input,
                  key,
                  value: value$1
                };
                for (const issue of valueDataset.issues) {
                  if (issue.path) issue.path.unshift(pathItem);
                  else issue.path = [pathItem];
                  dataset.issues?.push(issue);
                }
                if (!dataset.issues) dataset.issues = valueDataset.issues;
                if (config$1.abortEarly) {
                  dataset.typed = false;
                  break;
                }
              }
              if (!valueDataset.typed) dataset.typed = false;
              dataset.value[key] = valueDataset.value;
            } else if (valueSchema.fallback !== void 0) dataset.value[key] = /* @__PURE__ */ getFallback(valueSchema);
            else if (valueSchema.type !== "exact_optional" && valueSchema.type !== "optional" && valueSchema.type !== "nullish") {
              _addIssue(this, "key", dataset, config$1, {
                input: void 0,
                expected: `"${key}"`,
                path: [{
                  type: "object",
                  origin: "key",
                  input,
                  key,
                  value: input[key]
                }]
              });
              if (config$1.abortEarly) break;
            }
          }
        } else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function optional(wrapped, default_) {
    return _standardSchema({
      kind: "schema",
      type: "optional",
      reference: optional,
      expects: `(${wrapped.expects} | undefined)`,
      async: false,
      wrapped,
      default: default_,
      "~run"(dataset, config$1) {
        if (dataset.value === void 0) {
          if (this.default !== void 0) dataset.value = /* @__PURE__ */ getDefault(this, dataset, config$1);
          if (dataset.value === void 0) {
            dataset.typed = true;
            return dataset;
          }
        }
        return this.wrapped["~run"](dataset, config$1);
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function picklist(options, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "picklist",
      reference: picklist,
      expects: /* @__PURE__ */ _joinExpects(options.map(_stringify), "|"),
      async: false,
      options,
      message: message$1,
      "~run"(dataset, config$1) {
        if (this.options.includes(dataset.value)) dataset.typed = true;
        else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function record(key, value$1, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "record",
      reference: record,
      expects: "Object",
      async: false,
      key,
      value: value$1,
      message: message$1,
      "~run"(dataset, config$1) {
        const input = dataset.value;
        if (input && typeof input === "object") {
          dataset.typed = true;
          dataset.value = {};
          for (const entryKey in input) if (/* @__PURE__ */ _isValidObjectKey(input, entryKey)) {
            const entryValue = input[entryKey];
            const keyDataset = this.key["~run"]({ value: entryKey }, config$1);
            if (keyDataset.issues) {
              const pathItem = {
                type: "object",
                origin: "key",
                input,
                key: entryKey,
                value: entryValue
              };
              for (const issue of keyDataset.issues) {
                issue.path = [pathItem];
                dataset.issues?.push(issue);
              }
              if (!dataset.issues) dataset.issues = keyDataset.issues;
              if (config$1.abortEarly) {
                dataset.typed = false;
                break;
              }
            }
            const valueDataset = this.value["~run"]({ value: entryValue }, config$1);
            if (valueDataset.issues) {
              const pathItem = {
                type: "object",
                origin: "value",
                input,
                key: entryKey,
                value: entryValue
              };
              for (const issue of valueDataset.issues) {
                if (issue.path) issue.path.unshift(pathItem);
                else issue.path = [pathItem];
                dataset.issues?.push(issue);
              }
              if (!dataset.issues) dataset.issues = valueDataset.issues;
              if (config$1.abortEarly) {
                dataset.typed = false;
                break;
              }
            }
            if (!keyDataset.typed || !valueDataset.typed) dataset.typed = false;
            if (keyDataset.typed) dataset.value[keyDataset.value] = valueDataset.value;
          }
        } else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function string(message$1) {
    return _standardSchema({
      kind: "schema",
      type: "string",
      reference: string,
      expects: "string",
      async: false,
      message: message$1,
      "~run"(dataset, config$1) {
        if (typeof dataset.value === "string") dataset.typed = true;
        else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function tuple(items, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "tuple",
      reference: tuple,
      expects: "Array",
      async: false,
      items,
      message: message$1,
      "~run"(dataset, config$1) {
        const input = dataset.value;
        if (Array.isArray(input)) {
          dataset.typed = true;
          dataset.value = [];
          for (let key = 0; key < this.items.length; key++) {
            const value$1 = input[key];
            const itemDataset = this.items[key]["~run"]({ value: value$1 }, config$1);
            if (itemDataset.issues) {
              const pathItem = {
                type: "array",
                origin: "value",
                input,
                key,
                value: value$1
              };
              for (const issue of itemDataset.issues) {
                if (issue.path) issue.path.unshift(pathItem);
                else issue.path = [pathItem];
                dataset.issues?.push(issue);
              }
              if (!dataset.issues) dataset.issues = itemDataset.issues;
              if (config$1.abortEarly) {
                dataset.typed = false;
                break;
              }
            }
            if (!itemDataset.typed) dataset.typed = false;
            dataset.value.push(itemDataset.value);
          }
        } else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _subIssues(datasets) {
    let issues;
    if (datasets) for (const dataset of datasets) if (issues) for (const issue of dataset.issues) issues.push(issue);
    else issues = dataset.issues;
    return issues;
  }
  // @__NO_SIDE_EFFECTS__
  function union(options, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "union",
      reference: union,
      expects: /* @__PURE__ */ _joinExpects(options.map((option2) => option2.expects), "|"),
      async: false,
      options,
      message: message$1,
      "~run"(dataset, config$1) {
        let validDataset;
        let typedDatasets;
        let untypedDatasets;
        for (const schema of this.options) {
          const optionDataset = schema["~run"]({ value: dataset.value }, config$1);
          if (optionDataset.typed) if (optionDataset.issues) if (typedDatasets) typedDatasets.push(optionDataset);
          else typedDatasets = [optionDataset];
          else {
            validDataset = optionDataset;
            break;
          }
          else if (untypedDatasets) untypedDatasets.push(optionDataset);
          else untypedDatasets = [optionDataset];
        }
        if (validDataset) return validDataset;
        if (typedDatasets) {
          if (typedDatasets.length === 1) return typedDatasets[0];
          _addIssue(this, "type", dataset, config$1, { issues: /* @__PURE__ */ _subIssues(typedDatasets) });
          dataset.typed = true;
        } else if (untypedDatasets?.length === 1) return untypedDatasets[0];
        else _addIssue(this, "type", dataset, config$1, { issues: /* @__PURE__ */ _subIssues(untypedDatasets) });
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function unknown() {
    return _standardSchema({
      kind: "schema",
      type: "unknown",
      reference: unknown,
      expects: "unknown",
      async: false,
      "~run"(dataset) {
        dataset.typed = true;
        return dataset;
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function variant(key, options, message$1) {
    return _standardSchema({
      kind: "schema",
      type: "variant",
      reference: variant,
      expects: "Object",
      async: false,
      key,
      options,
      message: message$1,
      "~run"(dataset, config$1) {
        const input = dataset.value;
        if (input && typeof input === "object") {
          let outputDataset;
          let maxDiscriminatorPriority = 0;
          let invalidDiscriminatorKey = this.key;
          let expectedDiscriminators = [];
          const parseOptions = (variant$1, allKeys) => {
            for (const schema of variant$1.options) {
              if (schema.type === "variant") parseOptions(schema, new Set(allKeys).add(schema.key));
              else {
                let keysAreValid = true;
                let currentPriority = 0;
                for (const currentKey of allKeys) {
                  const discriminatorSchema = schema.entries[currentKey];
                  if (currentKey in input ? discriminatorSchema["~run"]({
                    typed: false,
                    value: input[currentKey]
                  }, ABORT_EARLY_CONFIG).issues : discriminatorSchema.type !== "exact_optional" && discriminatorSchema.type !== "optional" && discriminatorSchema.type !== "nullish") {
                    keysAreValid = false;
                    if (invalidDiscriminatorKey !== currentKey && (maxDiscriminatorPriority < currentPriority || maxDiscriminatorPriority === currentPriority && currentKey in input && !(invalidDiscriminatorKey in input))) {
                      maxDiscriminatorPriority = currentPriority;
                      invalidDiscriminatorKey = currentKey;
                      expectedDiscriminators = [];
                    }
                    if (invalidDiscriminatorKey === currentKey) expectedDiscriminators.push(schema.entries[currentKey].expects);
                    break;
                  }
                  currentPriority++;
                }
                if (keysAreValid) {
                  const optionDataset = schema["~run"]({ value: input }, config$1);
                  if (!outputDataset || !outputDataset.typed && optionDataset.typed) outputDataset = optionDataset;
                }
              }
              if (outputDataset && !outputDataset.issues) break;
            }
          };
          parseOptions(this, /* @__PURE__ */ new Set([this.key]));
          if (outputDataset) return outputDataset;
          _addIssue(this, "type", dataset, config$1, {
            input: input[invalidDiscriminatorKey],
            expected: /* @__PURE__ */ _joinExpects(expectedDiscriminators, "|"),
            path: [{
              type: "object",
              origin: "value",
              input,
              key: invalidDiscriminatorKey,
              value: input[invalidDiscriminatorKey]
            }]
          });
        } else _addIssue(this, "type", dataset, config$1);
        return dataset;
      }
    });
  }
  function parse(schema, input, config$1) {
    const dataset = schema["~run"]({ value: input }, /* @__PURE__ */ getGlobalConfig());
    if (dataset.issues) throw new ValiError(dataset.issues);
    return dataset.value;
  }
  // @__NO_SIDE_EFFECTS__
  function pipe(...pipe$1) {
    return _standardSchema({
      ...pipe$1[0],
      pipe: pipe$1,
      "~run"(dataset, config$1) {
        for (const item of pipe$1) if (item.kind !== "metadata") {
          if (dataset.issues && (item.kind === "schema" || item.kind === "transformation")) {
            dataset.typed = false;
            break;
          }
          if (!dataset.issues || !config$1.abortEarly && !config$1.abortPipeEarly) dataset = item["~run"](dataset, config$1);
        }
        return dataset;
      }
    });
  }
  function safeEnum(options) {
    const schemas = Object.keys(options).map((key) => /* @__PURE__ */ object({
      [key]: options[key],
      $kind: /* @__PURE__ */ literal(key)
    }));
    return /* @__PURE__ */ pipe(/* @__PURE__ */ unknown(), /* @__PURE__ */ check((input) => unsupportedEnumVariantMessage(input, options) === void 0, ({ input, message: message2 }) => unsupportedEnumVariantMessage(input, options) ?? message2), /* @__PURE__ */ transform(addMissingEnumKind), /* @__PURE__ */ variant("$kind", schemas));
  }
  function getEnumKind(input) {
    if (typeof input !== "object" || input === null) return null;
    if ("$kind" in input && typeof input.$kind === "string") return input.$kind;
    return Object.keys(input).find((key) => key !== "$kind") ?? null;
  }
  function addMissingEnumKind(input) {
    if (typeof input !== "object" || input === null || "$kind" in input) return input;
    const kind = getEnumKind(input);
    return kind === null ? input : {
      ...input,
      $kind: kind
    };
  }
  function unsupportedEnumVariantMessage(input, options) {
    const kind = getEnumKind(input);
    if (kind === null || Object.hasOwn(options, kind)) return void 0;
    return `Unsupported enum variant "${kind}". Expected one of: ${Object.keys(options).map((key) => `"${key}"`).join(", ")}.`;
  }
  function withKind(key, schema) {
    return /* @__PURE__ */ pipe(/* @__PURE__ */ object({
      ...schema.entries,
      $kind: /* @__PURE__ */ optional(/* @__PURE__ */ literal(key))
    }), /* @__PURE__ */ transform((value) => ({
      ...value,
      $kind: key
    })));
  }
  const SuiAddress = /* @__PURE__ */ pipe(/* @__PURE__ */ string(), /* @__PURE__ */ transform((value) => normalizeSuiAddress(value)), /* @__PURE__ */ check(isValidSuiAddress));
  const ObjectID = SuiAddress;
  const BCSBytes = /* @__PURE__ */ string();
  const JsonU64 = /* @__PURE__ */ pipe(/* @__PURE__ */ union([/* @__PURE__ */ string(), /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer())]), /* @__PURE__ */ check((val) => {
    try {
      BigInt(val);
      return BigInt(val) >= 0 && BigInt(val) <= 18446744073709551615n;
    } catch {
      return false;
    }
  }, "Invalid u64"));
  const U32 = /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer(), /* @__PURE__ */ check((val) => val >= 0 && val < 2 ** 32, "Invalid u32"));
  const ObjectRefSchema = /* @__PURE__ */ object({
    objectId: SuiAddress,
    version: JsonU64,
    digest: /* @__PURE__ */ string()
  });
  const ArgumentSchema = /* @__PURE__ */ union([
    withKind("GasCoin", /* @__PURE__ */ object({ GasCoin: /* @__PURE__ */ literal(true) })),
    withKind("Input", /* @__PURE__ */ object({
      Input: /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()),
      type: /* @__PURE__ */ optional(/* @__PURE__ */ union([
        /* @__PURE__ */ literal("pure"),
        /* @__PURE__ */ literal("object"),
        /* @__PURE__ */ literal("withdrawal")
      ]))
    })),
    withKind("Result", /* @__PURE__ */ object({ Result: /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()) })),
    withKind("NestedResult", /* @__PURE__ */ object({ NestedResult: /* @__PURE__ */ tuple([/* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()), /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer())]) }))
  ]);
  const GasDataSchema = /* @__PURE__ */ object({
    budget: /* @__PURE__ */ nullable(JsonU64),
    price: /* @__PURE__ */ nullable(JsonU64),
    owner: /* @__PURE__ */ nullable(SuiAddress),
    payment: /* @__PURE__ */ nullable(/* @__PURE__ */ array(ObjectRefSchema))
  });
  const OpenSignatureBodySchema = /* @__PURE__ */ union([
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("address") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("bool") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("u8") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("u16") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("u32") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("u64") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("u128") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("u256") }),
    /* @__PURE__ */ object({ $kind: /* @__PURE__ */ literal("unknown") }),
    /* @__PURE__ */ object({
      $kind: /* @__PURE__ */ literal("vector"),
      vector: /* @__PURE__ */ lazy(() => OpenSignatureBodySchema)
    }),
    /* @__PURE__ */ object({
      $kind: /* @__PURE__ */ literal("datatype"),
      datatype: /* @__PURE__ */ object({
        typeName: /* @__PURE__ */ string(),
        typeParameters: /* @__PURE__ */ array(/* @__PURE__ */ lazy(() => OpenSignatureBodySchema))
      })
    }),
    /* @__PURE__ */ object({
      $kind: /* @__PURE__ */ literal("typeParameter"),
      index: /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer())
    })
  ]);
  const OpenSignatureSchema = /* @__PURE__ */ object({
    reference: /* @__PURE__ */ nullable(/* @__PURE__ */ union([
      /* @__PURE__ */ literal("mutable"),
      /* @__PURE__ */ literal("immutable"),
      /* @__PURE__ */ literal("unknown")
    ])),
    body: OpenSignatureBodySchema
  });
  const ProgrammableMoveCallSchema = /* @__PURE__ */ object({
    package: ObjectID,
    module: /* @__PURE__ */ string(),
    function: /* @__PURE__ */ string(),
    typeArguments: /* @__PURE__ */ array(/* @__PURE__ */ string()),
    arguments: /* @__PURE__ */ array(ArgumentSchema),
    _argumentTypes: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(/* @__PURE__ */ array(OpenSignatureSchema)))
  });
  const $Intent$1 = /* @__PURE__ */ object({
    name: /* @__PURE__ */ string(),
    inputs: /* @__PURE__ */ record(/* @__PURE__ */ string(), /* @__PURE__ */ union([ArgumentSchema, /* @__PURE__ */ array(ArgumentSchema)])),
    data: /* @__PURE__ */ record(/* @__PURE__ */ string(), /* @__PURE__ */ unknown())
  });
  const CommandSchema = safeEnum({
    MoveCall: ProgrammableMoveCallSchema,
    TransferObjects: /* @__PURE__ */ object({
      objects: /* @__PURE__ */ array(ArgumentSchema),
      address: ArgumentSchema
    }),
    SplitCoins: /* @__PURE__ */ object({
      coin: ArgumentSchema,
      amounts: /* @__PURE__ */ array(ArgumentSchema)
    }),
    MergeCoins: /* @__PURE__ */ object({
      destination: ArgumentSchema,
      sources: /* @__PURE__ */ array(ArgumentSchema)
    }),
    Publish: /* @__PURE__ */ object({
      modules: /* @__PURE__ */ array(BCSBytes),
      dependencies: /* @__PURE__ */ array(ObjectID)
    }),
    MakeMoveVec: /* @__PURE__ */ object({
      type: /* @__PURE__ */ nullable(/* @__PURE__ */ string()),
      elements: /* @__PURE__ */ array(ArgumentSchema)
    }),
    Upgrade: /* @__PURE__ */ object({
      modules: /* @__PURE__ */ array(BCSBytes),
      dependencies: /* @__PURE__ */ array(ObjectID),
      package: ObjectID,
      ticket: ArgumentSchema
    }),
    $Intent: $Intent$1
  });
  const ObjectArgSchema = safeEnum({
    ImmOrOwnedObject: ObjectRefSchema,
    SharedObject: /* @__PURE__ */ object({
      objectId: ObjectID,
      initialSharedVersion: JsonU64,
      mutable: /* @__PURE__ */ boolean()
    }),
    Receiving: ObjectRefSchema
  });
  const ReservationSchema = safeEnum({ MaxAmountU64: JsonU64 });
  const WithdrawalTypeArgSchema = safeEnum({ Balance: /* @__PURE__ */ string() });
  const WithdrawFromSchema = safeEnum({
    Sender: /* @__PURE__ */ literal(true),
    Sponsor: /* @__PURE__ */ literal(true),
    SenderAllowance: /* @__PURE__ */ object({
      funder: SuiAddress,
      allowance: ObjectID
    })
  });
  const FundsWithdrawalArgSchema = /* @__PURE__ */ object({
    reservation: ReservationSchema,
    typeArg: WithdrawalTypeArgSchema,
    withdrawFrom: WithdrawFromSchema
  });
  const CallArgSchema = safeEnum({
    Object: ObjectArgSchema,
    Pure: /* @__PURE__ */ object({ bytes: BCSBytes }),
    UnresolvedPure: /* @__PURE__ */ object({ value: /* @__PURE__ */ unknown() }),
    UnresolvedObject: /* @__PURE__ */ object({
      objectId: ObjectID,
      version: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(JsonU64)),
      digest: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(/* @__PURE__ */ string())),
      initialSharedVersion: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(JsonU64)),
      mutable: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(/* @__PURE__ */ boolean()))
    }),
    FundsWithdrawal: FundsWithdrawalArgSchema
  });
  const NormalizedCallArg$1 = safeEnum({
    Object: ObjectArgSchema,
    Pure: /* @__PURE__ */ object({ bytes: BCSBytes })
  });
  const ValidDuringSchema = /* @__PURE__ */ object({
    minEpoch: /* @__PURE__ */ nullable(JsonU64),
    maxEpoch: /* @__PURE__ */ nullable(JsonU64),
    minTimestamp: /* @__PURE__ */ nullable(JsonU64),
    maxTimestamp: /* @__PURE__ */ nullable(JsonU64),
    chain: /* @__PURE__ */ string(),
    nonce: U32
  });
  const AllowedProposersSchema = /* @__PURE__ */ object({
    epoch: JsonU64,
    proposers: /* @__PURE__ */ pipe(/* @__PURE__ */ array(U32), /* @__PURE__ */ check((proposers) => proposers.length > 0, "Allowed proposers must not be empty"))
  });
  const ValiditySchema = /* @__PURE__ */ object({
    ...ValidDuringSchema.entries,
    allowedProposers: /* @__PURE__ */ nullable(AllowedProposersSchema)
  });
  const TransactionExpiration$1 = safeEnum({
    None: /* @__PURE__ */ literal(true),
    Epoch: JsonU64,
    ValidDuring: ValidDuringSchema,
    Validity: ValiditySchema
  });
  const TransactionDataSchema = /* @__PURE__ */ object({
    version: /* @__PURE__ */ literal(2),
    sender: /* @__PURE__ */ nullish(SuiAddress),
    expiration: /* @__PURE__ */ nullish(TransactionExpiration$1),
    gasData: GasDataSchema,
    inputs: /* @__PURE__ */ array(CallArgSchema),
    commands: /* @__PURE__ */ array(CommandSchema)
  });
  function getIdFromCallArg(arg) {
    if (typeof arg === "string") return normalizeSuiAddress(arg);
    if (arg.Object) {
      if (arg.Object.ImmOrOwnedObject) return normalizeSuiAddress(arg.Object.ImmOrOwnedObject.objectId);
      if (arg.Object.Receiving) return normalizeSuiAddress(arg.Object.Receiving.objectId);
      return normalizeSuiAddress(arg.Object.SharedObject.objectId);
    }
    if (arg.UnresolvedObject) return normalizeSuiAddress(arg.UnresolvedObject.objectId);
  }
  function remapCommandArguments(command, inputMapping, commandMapping) {
    const remapArg = (arg) => {
      switch (arg.$kind) {
        case "Input": {
          const newInputIndex = inputMapping.get(arg.Input);
          if (newInputIndex === void 0) throw new Error(`Input ${arg.Input} not found in input mapping`);
          return {
            ...arg,
            Input: newInputIndex
          };
        }
        case "Result": {
          const newCommandIndex = commandMapping.get(arg.Result);
          if (newCommandIndex !== void 0) return {
            ...arg,
            Result: newCommandIndex
          };
          return arg;
        }
        case "NestedResult": {
          const newCommandIndex = commandMapping.get(arg.NestedResult[0]);
          if (newCommandIndex !== void 0) return {
            ...arg,
            NestedResult: [newCommandIndex, arg.NestedResult[1]]
          };
          return arg;
        }
        default:
          return arg;
      }
    };
    switch (command.$kind) {
      case "MoveCall":
        command.MoveCall.arguments = command.MoveCall.arguments.map(remapArg);
        break;
      case "TransferObjects":
        command.TransferObjects.objects = command.TransferObjects.objects.map(remapArg);
        command.TransferObjects.address = remapArg(command.TransferObjects.address);
        break;
      case "SplitCoins":
        command.SplitCoins.coin = remapArg(command.SplitCoins.coin);
        command.SplitCoins.amounts = command.SplitCoins.amounts.map(remapArg);
        break;
      case "MergeCoins":
        command.MergeCoins.destination = remapArg(command.MergeCoins.destination);
        command.MergeCoins.sources = command.MergeCoins.sources.map(remapArg);
        break;
      case "MakeMoveVec":
        command.MakeMoveVec.elements = command.MakeMoveVec.elements.map(remapArg);
        break;
      case "Upgrade":
        command.Upgrade.ticket = remapArg(command.Upgrade.ticket);
        break;
      case "$Intent": {
        const inputs = command.$Intent.inputs;
        command.$Intent.inputs = {};
        for (const [key, value] of Object.entries(inputs)) command.$Intent.inputs[key] = Array.isArray(value) ? value.map(remapArg) : remapArg(value);
        break;
      }
    }
  }
  const ObjectRef = /* @__PURE__ */ object({
    digest: /* @__PURE__ */ string(),
    objectId: /* @__PURE__ */ string(),
    version: /* @__PURE__ */ union([
      /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()),
      /* @__PURE__ */ string(),
      /* @__PURE__ */ bigint()
    ])
  });
  const ObjectArg = safeEnum({
    ImmOrOwned: ObjectRef,
    Shared: /* @__PURE__ */ object({
      objectId: ObjectID,
      initialSharedVersion: JsonU64,
      mutable: /* @__PURE__ */ boolean()
    }),
    Receiving: ObjectRef
  });
  const NormalizedCallArg = safeEnum({
    Object: ObjectArg,
    Pure: /* @__PURE__ */ array(/* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()))
  });
  function expirationToV1(expiration) {
    if (!expiration) return null;
    switch (expiration.$kind) {
      case "Epoch":
        return { Epoch: Number(expiration.Epoch) };
      case "ValidDuring":
        return { ValidDuring: expiration.ValidDuring };
      case "Validity":
        return { Validity: expiration.Validity };
      case "None":
        return { None: true };
      default:
        throw new Error(`Unknown transaction expiration: ${JSON.stringify(expiration)}`);
    }
  }
  function expirationFromV1(expiration) {
    if (!expiration) return null;
    if ("Epoch" in expiration) return { Epoch: expiration.Epoch };
    if ("ValidDuring" in expiration) return { ValidDuring: expiration.ValidDuring };
    if ("Validity" in expiration) return { Validity: expiration.Validity };
    if ("None" in expiration) return { None: true };
    throw new Error(`Unknown transaction expiration in v1 transaction data: ${Object.keys(expiration).join(", ")}`);
  }
  function serializeV1TransactionData(transactionData) {
    const inputs = transactionData.inputs.map((input, index) => {
      if (input.Object) return {
        kind: "Input",
        index,
        value: { Object: input.Object.ImmOrOwnedObject ? { ImmOrOwned: input.Object.ImmOrOwnedObject } : input.Object.Receiving ? { Receiving: {
          digest: input.Object.Receiving.digest,
          version: input.Object.Receiving.version,
          objectId: input.Object.Receiving.objectId
        } } : { Shared: {
          mutable: input.Object.SharedObject.mutable,
          initialSharedVersion: input.Object.SharedObject.initialSharedVersion,
          objectId: input.Object.SharedObject.objectId
        } } },
        type: "object"
      };
      if (input.Pure) return {
        kind: "Input",
        index,
        value: { Pure: Array.from(fromBase64(input.Pure.bytes)) },
        type: "pure"
      };
      if (input.UnresolvedPure) return {
        kind: "Input",
        type: "pure",
        index,
        value: input.UnresolvedPure.value
      };
      if (input.UnresolvedObject) return {
        kind: "Input",
        type: "object",
        index,
        value: input.UnresolvedObject.objectId
      };
      throw new Error("Invalid input");
    });
    return {
      version: 1,
      sender: transactionData.sender ?? void 0,
      expiration: expirationToV1(transactionData.expiration),
      gasConfig: {
        owner: transactionData.gasData.owner ?? void 0,
        budget: transactionData.gasData.budget ?? void 0,
        price: transactionData.gasData.price ?? void 0,
        payment: transactionData.gasData.payment ?? void 0
      },
      inputs,
      transactions: transactionData.commands.map((command) => {
        if (command.MakeMoveVec) return {
          kind: "MakeMoveVec",
          type: command.MakeMoveVec.type === null ? { None: true } : { Some: TypeTagSerializer.parseFromStr(command.MakeMoveVec.type) },
          objects: command.MakeMoveVec.elements.map((arg) => convertTransactionArgument(arg, inputs))
        };
        if (command.MergeCoins) return {
          kind: "MergeCoins",
          destination: convertTransactionArgument(command.MergeCoins.destination, inputs),
          sources: command.MergeCoins.sources.map((arg) => convertTransactionArgument(arg, inputs))
        };
        if (command.MoveCall) return {
          kind: "MoveCall",
          target: `${command.MoveCall.package}::${command.MoveCall.module}::${command.MoveCall.function}`,
          typeArguments: command.MoveCall.typeArguments,
          arguments: command.MoveCall.arguments.map((arg) => convertTransactionArgument(arg, inputs))
        };
        if (command.Publish) return {
          kind: "Publish",
          modules: command.Publish.modules.map((mod2) => Array.from(fromBase64(mod2))),
          dependencies: command.Publish.dependencies
        };
        if (command.SplitCoins) return {
          kind: "SplitCoins",
          coin: convertTransactionArgument(command.SplitCoins.coin, inputs),
          amounts: command.SplitCoins.amounts.map((arg) => convertTransactionArgument(arg, inputs))
        };
        if (command.TransferObjects) return {
          kind: "TransferObjects",
          objects: command.TransferObjects.objects.map((arg) => convertTransactionArgument(arg, inputs)),
          address: convertTransactionArgument(command.TransferObjects.address, inputs)
        };
        if (command.Upgrade) return {
          kind: "Upgrade",
          modules: command.Upgrade.modules.map((mod2) => Array.from(fromBase64(mod2))),
          dependencies: command.Upgrade.dependencies,
          packageId: command.Upgrade.package,
          ticket: convertTransactionArgument(command.Upgrade.ticket, inputs)
        };
        throw new Error(`Unknown transaction ${Object.keys(command)}`);
      })
    };
  }
  function convertTransactionArgument(arg, inputs) {
    if (arg.$kind === "GasCoin") return { kind: "GasCoin" };
    if (arg.$kind === "Result") return {
      kind: "Result",
      index: arg.Result
    };
    if (arg.$kind === "NestedResult") return {
      kind: "NestedResult",
      index: arg.NestedResult[0],
      resultIndex: arg.NestedResult[1]
    };
    if (arg.$kind === "Input") return inputs[arg.Input];
    throw new Error(`Invalid argument ${Object.keys(arg)}`);
  }
  function transactionDataFromV1(data) {
    return parse(TransactionDataSchema, {
      version: 2,
      sender: data.sender ?? null,
      expiration: expirationFromV1(data.expiration),
      gasData: {
        owner: data.gasConfig.owner ?? null,
        budget: data.gasConfig.budget?.toString() ?? null,
        price: data.gasConfig.price?.toString() ?? null,
        payment: data.gasConfig.payment?.map((ref) => ({
          digest: ref.digest,
          objectId: ref.objectId,
          version: ref.version.toString()
        })) ?? null
      },
      inputs: data.inputs.map((input) => {
        if (input.kind === "Input") {
          if (/* @__PURE__ */ is(NormalizedCallArg, input.value)) {
            const value = parse(NormalizedCallArg, input.value);
            if (value.Object) {
              if (value.Object.ImmOrOwned) return { Object: { ImmOrOwnedObject: {
                objectId: value.Object.ImmOrOwned.objectId,
                version: String(value.Object.ImmOrOwned.version),
                digest: value.Object.ImmOrOwned.digest
              } } };
              if (value.Object.Shared) return { Object: { SharedObject: {
                mutable: value.Object.Shared.mutable ?? null,
                initialSharedVersion: value.Object.Shared.initialSharedVersion,
                objectId: value.Object.Shared.objectId
              } } };
              if (value.Object.Receiving) return { Object: { Receiving: {
                digest: value.Object.Receiving.digest,
                version: String(value.Object.Receiving.version),
                objectId: value.Object.Receiving.objectId
              } } };
              throw new Error("Invalid object input");
            }
            return { Pure: { bytes: toBase64(new Uint8Array(value.Pure)) } };
          }
          if (input.type === "object") return { UnresolvedObject: { objectId: input.value } };
          return { UnresolvedPure: { value: input.value } };
        }
        throw new Error("Invalid input");
      }),
      commands: data.transactions.map((transaction) => {
        switch (transaction.kind) {
          case "MakeMoveVec":
            return { MakeMoveVec: {
              type: "Some" in transaction.type ? TypeTagSerializer.tagToString(transaction.type.Some) : null,
              elements: transaction.objects.map((arg) => parseV1TransactionArgument(arg))
            } };
          case "MergeCoins":
            return { MergeCoins: {
              destination: parseV1TransactionArgument(transaction.destination),
              sources: transaction.sources.map((arg) => parseV1TransactionArgument(arg))
            } };
          case "MoveCall": {
            const [pkg, mod2, fn] = transaction.target.split("::");
            return { MoveCall: {
              package: pkg,
              module: mod2,
              function: fn,
              typeArguments: transaction.typeArguments,
              arguments: transaction.arguments.map((arg) => parseV1TransactionArgument(arg))
            } };
          }
          case "Publish":
            return { Publish: {
              modules: transaction.modules.map((mod2) => toBase64(Uint8Array.from(mod2))),
              dependencies: transaction.dependencies
            } };
          case "SplitCoins":
            return { SplitCoins: {
              coin: parseV1TransactionArgument(transaction.coin),
              amounts: transaction.amounts.map((arg) => parseV1TransactionArgument(arg))
            } };
          case "TransferObjects":
            return { TransferObjects: {
              objects: transaction.objects.map((arg) => parseV1TransactionArgument(arg)),
              address: parseV1TransactionArgument(transaction.address)
            } };
          case "Upgrade":
            return { Upgrade: {
              modules: transaction.modules.map((mod2) => toBase64(Uint8Array.from(mod2))),
              dependencies: transaction.dependencies,
              package: transaction.packageId,
              ticket: parseV1TransactionArgument(transaction.ticket)
            } };
        }
        throw new Error(`Unknown transaction ${Object.keys(transaction)}`);
      })
    });
  }
  function parseV1TransactionArgument(arg) {
    switch (arg.kind) {
      case "GasCoin":
        return { GasCoin: true };
      case "Result":
        return { Result: arg.index };
      case "NestedResult":
        return { NestedResult: [arg.index, arg.resultIndex] };
      case "Input":
        return { Input: arg.index };
    }
  }
  function isBytes$2(a) {
    return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a && a.BYTES_PER_ELEMENT === 1;
  }
  const atitle$1 = (title) => title ? `"${title}" ` : "";
  function anumber$2(n, title = "") {
    if (typeof n !== "number")
      throw new TypeError(atitle$1(title) + "expected number, got " + typeof n);
    if (!Number.isSafeInteger(n) || n < 0)
      throw new RangeError(atitle$1(title) + "expected integer >= 0, got " + n);
    return n;
  }
  function abytes$2(value, length, title = "") {
    if (isBytes$2(value) && (length === void 0 || value.length === length))
      return value;
    if (length !== void 0)
      anumber$2(length, "length");
    const bytes = isBytes$2(value);
    const ofLen = length !== void 0 ? ` of length ${length}` : "";
    const got = bytes ? `length=${value.length}` : `type=${typeof value}`;
    const message2 = atitle$1(title) + "expected Uint8Array" + ofLen + ", got " + got;
    if (!bytes)
      throw new TypeError(message2);
    throw new RangeError(message2);
  }
  function copyBytes$1(bytes) {
    return Uint8Array.from(abytes$2(bytes));
  }
  function ahash(h) {
    if (typeof h !== "function" || typeof h.create !== "function")
      throw new TypeError("expected hash wrapped by utils.createHasher");
    anumber$2(h.outputLen);
    anumber$2(h.blockLen);
    if (h.outputLen < 1 || h.blockLen < 1)
      throw new Error("hash blockLen / outputLen must be >= 1");
  }
  const aobject$1 = (value, label) => {
    if (value === null || typeof value !== "object" || Array.isArray(value))
      throw new TypeError((label === "object" ? "" : `"${label}" `) + "expected object, got type=" + typeof value);
  };
  const aopts = (value, label) => {
    aobject$1(value, label);
    const proto = Object.getPrototypeOf(value);
    if (proto !== Object.prototype && proto !== null)
      throw new TypeError(`"${label}" expected plain object`);
    if (Object.hasOwn(value, "__proto__"))
      throw new TypeError(`"${label}.__proto__" is not allowed`);
  };
  function aexists(instance, checkFinished = true) {
    if (instance.destroyed)
      throw new Error("hash was destroyed");
    if (checkFinished && instance.finished)
      throw new Error("digest() was already called");
  }
  function aoutput(out, instance) {
    abytes$2(out, void 0, "output");
    const min = instance.outputLen;
    if (!(out.length >= min)) {
      throw new RangeError('"output" expected length >= ' + min);
    }
  }
  function u32(arr) {
    return new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
  }
  function clean(...arrays) {
    for (let i = 0; i < arrays.length; i++) {
      arrays[i].fill(0);
    }
  }
  function createView(arr) {
    return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
  }
  const isLE = /* @__PURE__ */ (() => new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68)();
  function byteSwap(word) {
    return word << 24 & 4278190080 | word << 8 & 16711680 | word >>> 8 & 65280 | word >>> 24 & 255;
  }
  const swap8IfBE = isLE ? (n) => n : (n) => byteSwap(n) >>> 0;
  function byteSwap32(arr) {
    for (let i = 0; i < arr.length; i++) {
      arr[i] = byteSwap(arr[i]);
    }
    return arr;
  }
  const swap32IfBE = isLE ? (u) => u : byteSwap32;
  const hasHexBuiltin = /* @__PURE__ */ (() => (
    // @ts-ignore
    typeof Uint8Array.from([]).toHex === "function" && typeof Uint8Array.fromHex === "function"
  ))();
  const hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
  function bytesToHex$1(bytes) {
    abytes$2(bytes);
    if (hasHexBuiltin)
      return bytes.toHex();
    let hex = "";
    for (let i = 0; i < bytes.length; i++) {
      hex += hexes[bytes[i]];
    }
    return hex;
  }
  function asciiToBase16(ch) {
    return ch >= 48 && ch <= 57 ? ch - 48 : ch >= 65 && ch <= 70 ? ch - (65 - 10) : ch >= 97 && ch <= 102 ? ch - (97 - 10) : void 0;
  }
  function hexToBytes$1(hex) {
    if (typeof hex !== "string")
      throw new TypeError("hex string expected, got " + typeof hex);
    if (hasHexBuiltin) {
      try {
        return Uint8Array.fromHex(hex);
      } catch (error) {
        if (error instanceof SyntaxError)
          throw new RangeError(error.message);
        throw error;
      }
    }
    const hl = hex.length;
    const al = hl / 2;
    if (hl % 2)
      throw new RangeError("hex string expected, got unpadded hex of length " + hl);
    const array2 = new Uint8Array(al);
    for (let ai = 0, hi = 0; ai < al; ai++, hi += 2) {
      const n1 = asciiToBase16(hex.charCodeAt(hi));
      const n2 = asciiToBase16(hex.charCodeAt(hi + 1));
      if (n1 === void 0 || n2 === void 0) {
        const char = hex[hi] + hex[hi + 1];
        throw new RangeError('hex string expected, got non-hex character "' + char + '" at index ' + hi);
      }
      array2[ai] = n1 * 16 + n2;
    }
    return array2;
  }
  function utf8ToBytes(str) {
    if (typeof str !== "string")
      throw new TypeError("string expected");
    const encoded = new TextEncoder().encode(str);
    try {
      return new Uint8Array(encoded);
    } finally {
      clean(encoded);
    }
  }
  function kdfInputToBytes(data, errorTitle = "") {
    if (typeof data === "string")
      return utf8ToBytes(data);
    return abytes$2(data, void 0, errorTitle);
  }
  function concatBytes$1(...arrays) {
    let sum = 0;
    for (let i = 0; i < arrays.length; i++) {
      const a = arrays[i];
      abytes$2(a);
      sum += a.length;
    }
    const res = new Uint8Array(sum);
    for (let i = 0, pad = 0; i < arrays.length; i++) {
      const a = arrays[i];
      res.set(a, pad);
      pad += a.length;
    }
    return res;
  }
  function checkOpts(defaults, opts, title = "opts") {
    aopts(defaults, "defaults");
    if (opts !== void 0)
      aopts(opts, title);
    const merged = Object.assign(/* @__PURE__ */ Object.create(null), defaults, opts);
    return merged;
  }
  function createHasher(hashCons, info = {}) {
    if (typeof hashCons !== "function")
      throw new TypeError('"hashCons" expected function, got type=' + typeof hashCons);
    info = checkOpts({}, info, "info");
    const hashC = (msg, opts) => hashCons(opts).update(msg).digest();
    const tmp = hashCons(void 0);
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.canXOF = tmp.canXOF;
    hashC.create = (opts) => hashCons(opts);
    Object.assign(hashC, info);
    return Object.freeze(hashC);
  }
  function randomBytes$1(bytesLength = 32) {
    anumber$2(bytesLength, "bytesLength");
    const cr = typeof globalThis === "object" ? globalThis.crypto : null;
    if (typeof cr?.getRandomValues !== "function")
      throw new Error("crypto.getRandomValues must be defined");
    if (bytesLength > 65536)
      throw new RangeError(`"bytesLength" expected <= 65536, got ${bytesLength}`);
    return cr.getRandomValues(new Uint8Array(bytesLength));
  }
  const oidNist = (suffix) => ({
    // Current NIST hashAlgs suffixes used here fit in one DER subidentifier octet.
    // Larger suffix values would need base-128 OID encoding and a different length byte.
    oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, suffix])
  });
  const BSIGMA = /* @__PURE__ */ Uint8Array.from([
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    14,
    10,
    4,
    8,
    9,
    15,
    13,
    6,
    1,
    12,
    0,
    2,
    11,
    7,
    5,
    3,
    11,
    8,
    12,
    0,
    5,
    2,
    15,
    13,
    10,
    14,
    3,
    6,
    7,
    1,
    9,
    4,
    7,
    9,
    3,
    1,
    13,
    12,
    11,
    14,
    2,
    6,
    5,
    10,
    4,
    0,
    15,
    8,
    9,
    0,
    5,
    7,
    2,
    4,
    10,
    15,
    14,
    1,
    11,
    12,
    6,
    8,
    3,
    13,
    2,
    12,
    6,
    10,
    0,
    11,
    8,
    3,
    4,
    13,
    7,
    5,
    15,
    14,
    1,
    9,
    12,
    5,
    1,
    15,
    14,
    13,
    4,
    10,
    0,
    7,
    6,
    3,
    9,
    2,
    8,
    11,
    13,
    11,
    7,
    14,
    12,
    1,
    3,
    9,
    5,
    0,
    15,
    4,
    8,
    6,
    2,
    10,
    6,
    15,
    14,
    9,
    11,
    3,
    0,
    8,
    12,
    2,
    13,
    7,
    1,
    4,
    10,
    5,
    10,
    2,
    8,
    4,
    7,
    6,
    1,
    5,
    15,
    11,
    9,
    14,
    3,
    12,
    13,
    0,
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    14,
    10,
    4,
    8,
    9,
    15,
    13,
    6,
    1,
    12,
    0,
    2,
    11,
    7,
    5,
    3,
    // Blake1, unused in others
    11,
    8,
    12,
    0,
    5,
    2,
    15,
    13,
    10,
    14,
    3,
    6,
    7,
    1,
    9,
    4,
    7,
    9,
    3,
    1,
    13,
    12,
    11,
    14,
    2,
    6,
    5,
    10,
    4,
    0,
    15,
    8,
    9,
    0,
    5,
    7,
    2,
    4,
    10,
    15,
    14,
    1,
    11,
    12,
    6,
    8,
    3,
    13,
    2,
    12,
    6,
    10,
    0,
    11,
    8,
    3,
    4,
    13,
    7,
    5,
    15,
    14,
    1,
    9
  ]);
  const U32_MASK64 = /* @__PURE__ */ (() => BigInt(2 ** 32 - 1))();
  const _32n = /* @__PURE__ */ BigInt(32);
  function fromBig(n, le = false) {
    if (le)
      return { h: Number(n & U32_MASK64), l: Number(n >> _32n & U32_MASK64) };
    return { h: Number(n >> _32n & U32_MASK64) | 0, l: Number(n & U32_MASK64) | 0 };
  }
  function split$1(lst, le = false) {
    const len = lst.length;
    let Ah = new Uint32Array(len);
    let Al = new Uint32Array(len);
    for (let i = 0; i < len; i++) {
      const { h, l } = fromBig(lst[i], le);
      [Ah[i], Al[i]] = [h, l];
    }
    return [Ah, Al];
  }
  const fromNumH = (n) => n / 2 ** 32 | 0;
  const fromNumL = (n) => n >>> 0;
  function setU64FromNum(view, byteOffset, n, isLE2) {
    const h = fromNumH(n);
    const l = fromNumL(n);
    view.setUint32(byteOffset, isLE2 ? l : h, isLE2);
    view.setUint32(byteOffset + 4, isLE2 ? h : l, isLE2);
  }
  const shrSH = (h, _l, s) => h >>> s;
  const shrSL = (h, l, s) => h << 32 - s | l >>> s;
  const rotrSH = (h, l, s) => h >>> s | l << 32 - s;
  const rotrSL = (h, l, s) => h << 32 - s | l >>> s;
  const rotrBH = (h, l, s) => h << 64 - s | l >>> s - 32;
  const rotrBL = (h, l, s) => h >>> s - 32 | l << 64 - s;
  const rotr32H = (_h, l) => l;
  const rotr32L = (h, _l) => h;
  function add(Ah, Al, Bh, Bl) {
    const l = (Al >>> 0) + (Bl >>> 0);
    return { h: Ah + Bh + (l / 2 ** 32 | 0) | 0, l: l | 0 };
  }
  const add3L = (Al, Bl, Cl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0);
  const add3H = (low, Ah, Bh, Ch) => Ah + Bh + Ch + (low / 2 ** 32 | 0) | 0;
  const add4L = (Al, Bl, Cl, Dl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0);
  const add4H = (low, Ah, Bh, Ch, Dh) => Ah + Bh + Ch + Dh + (low / 2 ** 32 | 0) | 0;
  const add5L = (Al, Bl, Cl, Dl, El) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0) + (El >>> 0);
  const add5H = (low, Ah, Bh, Ch, Dh, Eh) => Ah + Bh + Ch + Dh + Eh + (low / 2 ** 32 | 0) | 0;
  class HashMD {
    blockLen;
    outputLen;
    canXOF = false;
    padOffset;
    isLE;
    // For partial updates less than block size
    buffer;
    view;
    finished = false;
    length = 0;
    pos = 0;
    destroyed = false;
    constructor(blockLen, outputLen, padOffset, isLE2) {
      this.blockLen = blockLen;
      this.outputLen = outputLen;
      this.padOffset = padOffset;
      this.isLE = isLE2;
      this.buffer = new Uint8Array(blockLen);
      this.view = createView(this.buffer);
    }
    update(data) {
      aexists(this);
      abytes$2(data);
      const { view, buffer, blockLen } = this;
      const len = data.length;
      let processed = false;
      for (let pos = 0; pos < len; ) {
        const take = Math.min(blockLen - this.pos, len - pos);
        if (take === blockLen) {
          const dataView = createView(data);
          for (; blockLen <= len - pos; pos += blockLen)
            this.process(dataView, pos);
          processed = true;
          continue;
        }
        buffer.set(pos === 0 && take === len ? data : data.subarray(pos, pos + take), this.pos);
        this.pos += take;
        pos += take;
        if (this.pos === blockLen) {
          this.process(view, 0);
          this.pos = 0;
          processed = true;
        }
      }
      this.length += data.length;
      if (processed)
        this.roundClean();
      return this;
    }
    digestInto(out) {
      aexists(this);
      aoutput(out, this);
      this.finished = true;
      const { buffer, view, blockLen, isLE: isLE2 } = this;
      let { pos } = this;
      buffer[pos++] = 128;
      buffer.fill(0, pos);
      if (this.padOffset > blockLen - pos) {
        this.process(view, 0);
        buffer.fill(0);
      }
      setU64FromNum(view, blockLen - 8, this.length * 8, isLE2);
      this.process(view, 0);
      this.roundClean();
      const oview = out === buffer ? view : createView(out);
      const len = this.outputLen;
      const outLen = len / 4;
      const state = this.get();
      if (len % 4 || outLen > state.length)
        throw new Error("invalid outputLen");
      for (let i = 0; i < outLen; i++)
        oview.setUint32(4 * i, state[i], isLE2);
    }
    digest() {
      const { buffer, outputLen } = this;
      this.digestInto(buffer);
      const res = buffer.slice(0, outputLen);
      this.destroy();
      return res;
    }
    _cloneIntoMeta(to) {
      const { buffer, length, finished, destroyed, pos } = this;
      to.destroyed = destroyed;
      to.finished = finished;
      to.length = length;
      to.pos = pos;
      if (pos)
        to.buffer.set(buffer);
      return to;
    }
    clone() {
      return this._cloneInto();
    }
  }
  const SHA512_IV = /* @__PURE__ */ Uint32Array.from([
    1779033703,
    4089235720,
    3144134277,
    2227873595,
    1013904242,
    4271175723,
    2773480762,
    1595750129,
    1359893119,
    2917565137,
    2600822924,
    725511199,
    528734635,
    4215389547,
    1541459225,
    327033209
  ]);
  const B2B_IV = /* @__PURE__ */ Uint32Array.from([
    4089235720,
    1779033703,
    2227873595,
    3144134277,
    4271175723,
    1013904242,
    1595750129,
    2773480762,
    2917565137,
    1359893119,
    725511199,
    2600822924,
    4215389547,
    528734635,
    327033209,
    1541459225
  ]);
  const BBUF = /* @__PURE__ */ new Uint32Array(32);
  function G1b(a, b, c, d, msg, x) {
    const Xl = msg[x], Xh = msg[x + 1];
    let Al = BBUF[2 * a], Ah = BBUF[2 * a + 1];
    let Bl = BBUF[2 * b], Bh = BBUF[2 * b + 1];
    let Cl = BBUF[2 * c], Ch = BBUF[2 * c + 1];
    let Dl = BBUF[2 * d], Dh = BBUF[2 * d + 1];
    const ll = add3L(Al, Bl, Xl);
    Ah = add3H(ll, Ah, Bh, Xh);
    Al = ll | 0;
    let xh = Dh ^ Ah, xl = Dl ^ Al;
    Dh = rotr32H(xh, xl);
    Dl = rotr32L(xh);
    ({ h: Ch, l: Cl } = add(Ch, Cl, Dh, Dl));
    xh = Bh ^ Ch;
    xl = Bl ^ Cl;
    Bh = rotrSH(xh, xl, 24);
    Bl = rotrSL(xh, xl, 24);
    BBUF[2 * a] = Al;
    BBUF[2 * a + 1] = Ah;
    BBUF[2 * b] = Bl;
    BBUF[2 * b + 1] = Bh;
    BBUF[2 * c] = Cl;
    BBUF[2 * c + 1] = Ch;
    BBUF[2 * d] = Dl;
    BBUF[2 * d + 1] = Dh;
  }
  function G2b(a, b, c, d, msg, x) {
    const Xl = msg[x], Xh = msg[x + 1];
    let Al = BBUF[2 * a], Ah = BBUF[2 * a + 1];
    let Bl = BBUF[2 * b], Bh = BBUF[2 * b + 1];
    let Cl = BBUF[2 * c], Ch = BBUF[2 * c + 1];
    let Dl = BBUF[2 * d], Dh = BBUF[2 * d + 1];
    const ll = add3L(Al, Bl, Xl);
    Ah = add3H(ll, Ah, Bh, Xh);
    Al = ll | 0;
    let xh = Dh ^ Ah, xl = Dl ^ Al;
    Dh = rotrSH(xh, xl, 16);
    Dl = rotrSL(xh, xl, 16);
    ({ h: Ch, l: Cl } = add(Ch, Cl, Dh, Dl));
    xh = Bh ^ Ch;
    xl = Bl ^ Cl;
    Bh = rotrBH(xh, xl, 63);
    Bl = rotrBL(xh, xl, 63);
    BBUF[2 * a] = Al;
    BBUF[2 * a + 1] = Ah;
    BBUF[2 * b] = Bl;
    BBUF[2 * b + 1] = Bh;
    BBUF[2 * c] = Cl;
    BBUF[2 * c + 1] = Ch;
    BBUF[2 * d] = Dl;
    BBUF[2 * d + 1] = Dh;
  }
  function checkBlake2Opts(outputLen, opts = {}, keyLen, saltLen, persLen) {
    anumber$2(keyLen);
    if (outputLen <= 0 || outputLen > keyLen)
      throw new Error('"dkLen" must be 1..' + keyLen + ", got " + outputLen);
    const { key, salt, personalization } = opts;
    if (key !== void 0 && (key.length < 1 || key.length > keyLen))
      throw new Error('"key" expected to be undefined or of length=1..' + keyLen);
    if (salt !== void 0)
      abytes$2(salt, saltLen, "salt");
    if (personalization !== void 0)
      abytes$2(personalization, persLen, "personalization");
  }
  class _BLAKE2 {
    buffer;
    buffer32;
    finished = false;
    destroyed = false;
    length = 0;
    pos = 0;
    blockLen;
    outputLen;
    canXOF = false;
    constructor(blockLen, outputLen) {
      anumber$2(blockLen);
      anumber$2(outputLen);
      this.blockLen = blockLen;
      this.outputLen = outputLen;
      this.buffer = new Uint8Array(blockLen);
      this.buffer32 = u32(this.buffer);
    }
    update(data) {
      aexists(this);
      abytes$2(data);
      const { blockLen, buffer, buffer32 } = this;
      const len = data.length;
      const offset = data.byteOffset;
      const buf = data.buffer;
      for (let pos = 0; pos < len; ) {
        if (this.pos === blockLen) {
          swap32IfBE(buffer32);
          this.compress(buffer32, 0, false);
          swap32IfBE(buffer32);
          this.pos = 0;
        }
        const take = Math.min(blockLen - this.pos, len - pos);
        const dataOffset = offset + pos;
        if (take === blockLen && !(dataOffset % 4) && pos + take < len) {
          const data32 = new Uint32Array(buf, dataOffset, Math.floor((len - pos) / 4));
          swap32IfBE(data32);
          for (let pos32 = 0; pos + blockLen < len; pos32 += buffer32.length, pos += blockLen) {
            this.length += blockLen;
            this.compress(data32, pos32, false);
          }
          swap32IfBE(data32);
          continue;
        }
        buffer.set(pos === 0 && take === len ? data : data.subarray(pos, pos + take), this.pos);
        this.pos += take;
        this.length += take;
        pos += take;
      }
      return this;
    }
    digestInto(out) {
      aexists(this);
      aoutput(out, this);
      if (out.byteOffset & 3)
        throw new RangeError('"output" expected 4-byte aligned byteOffset, got ' + out.byteOffset);
      const { pos, buffer32 } = this;
      this.finished = true;
      this.buffer.fill(0, pos);
      swap32IfBE(buffer32);
      this.compress(buffer32, 0, true);
      swap32IfBE(buffer32);
      const state = this.get();
      const out32 = out === this.buffer ? buffer32 : u32(out);
      const full = Math.floor(this.outputLen / 4);
      for (let i = 0; i < full; i++)
        out32[i] = swap8IfBE(state[i]);
      const tail = this.outputLen % 4;
      if (!tail)
        return;
      const off = full * 4;
      const word = state[full];
      for (let i = 0; i < tail; i++)
        out[off + i] = word >>> 8 * i;
    }
    digest() {
      const { buffer, outputLen } = this;
      this.digestInto(buffer);
      const res = buffer.slice(0, outputLen);
      this.destroy();
      return res;
    }
    _cloneInto(to) {
      const { buffer, length, finished, destroyed, outputLen, pos } = this;
      to ||= new this.constructor({ dkLen: outputLen });
      to.set(...this.get());
      to.buffer.set(buffer);
      to.destroyed = destroyed;
      to.finished = finished;
      to.length = length;
      to.pos = pos;
      to.outputLen = outputLen;
      return to;
    }
    clone() {
      return this._cloneInto();
    }
  }
  class _BLAKE2b extends _BLAKE2 {
    // Same IV words as SHA-512 / BLAKE2b, encoded as LE u32 low/high halves.
    v0l = B2B_IV[0] | 0;
    v0h = B2B_IV[1] | 0;
    v1l = B2B_IV[2] | 0;
    v1h = B2B_IV[3] | 0;
    v2l = B2B_IV[4] | 0;
    v2h = B2B_IV[5] | 0;
    v3l = B2B_IV[6] | 0;
    v3h = B2B_IV[7] | 0;
    v4l = B2B_IV[8] | 0;
    v4h = B2B_IV[9] | 0;
    v5l = B2B_IV[10] | 0;
    v5h = B2B_IV[11] | 0;
    v6l = B2B_IV[12] | 0;
    v6h = B2B_IV[13] | 0;
    v7l = B2B_IV[14] | 0;
    v7h = B2B_IV[15] | 0;
    constructor(opts = {}) {
      opts = checkOpts({}, opts);
      const olen = opts.dkLen === void 0 ? 64 : opts.dkLen;
      super(128, olen);
      checkBlake2Opts(olen, opts, 64, 16, 16);
      let { key, personalization, salt } = opts;
      let keyLength = 0;
      if (key !== void 0) {
        abytes$2(key, void 0, "key");
        keyLength = key.length;
      }
      this.v0l ^= this.outputLen | keyLength << 8 | 1 << 16 | 1 << 24;
      if (salt !== void 0) {
        abytes$2(salt, void 0, "salt");
        const slt = u32(copyBytes$1(salt));
        this.v4l ^= swap8IfBE(slt[0]);
        this.v4h ^= swap8IfBE(slt[1]);
        this.v5l ^= swap8IfBE(slt[2]);
        this.v5h ^= swap8IfBE(slt[3]);
      }
      if (personalization !== void 0) {
        abytes$2(personalization, void 0, "personalization");
        const pers = u32(copyBytes$1(personalization));
        this.v6l ^= swap8IfBE(pers[0]);
        this.v6h ^= swap8IfBE(pers[1]);
        this.v7l ^= swap8IfBE(pers[2]);
        this.v7h ^= swap8IfBE(pers[3]);
      }
      if (key !== void 0) {
        const tmp = new Uint8Array(this.blockLen);
        tmp.set(key);
        this.update(tmp);
        clean(tmp);
      }
    }
    // prettier-ignore
    get() {
      let { v0l, v0h, v1l, v1h, v2l, v2h, v3l, v3h, v4l, v4h, v5l, v5h, v6l, v6h, v7l, v7h } = this;
      return [v0l, v0h, v1l, v1h, v2l, v2h, v3l, v3h, v4l, v4h, v5l, v5h, v6l, v6h, v7l, v7h];
    }
    // prettier-ignore
    set(v0l, v0h, v1l, v1h, v2l, v2h, v3l, v3h, v4l, v4h, v5l, v5h, v6l, v6h, v7l, v7h) {
      this.v0l = v0l | 0;
      this.v0h = v0h | 0;
      this.v1l = v1l | 0;
      this.v1h = v1h | 0;
      this.v2l = v2l | 0;
      this.v2h = v2h | 0;
      this.v3l = v3l | 0;
      this.v3h = v3h | 0;
      this.v4l = v4l | 0;
      this.v4h = v4h | 0;
      this.v5l = v5l | 0;
      this.v5h = v5h | 0;
      this.v6l = v6l | 0;
      this.v6h = v6h | 0;
      this.v7l = v7l | 0;
      this.v7h = v7h | 0;
    }
    compress(msg, offset, isLast) {
      const { v0l, v0h, v1l, v1h, v2l, v2h, v3l, v3h, v4l, v4h, v5l, v5h, v6l, v6h, v7l, v7h } = this;
      {
        BBUF[0] = v0l;
        BBUF[1] = v0h;
        BBUF[2] = v1l;
        BBUF[3] = v1h;
        BBUF[4] = v2l;
        BBUF[5] = v2h;
        BBUF[6] = v3l;
        BBUF[7] = v3h;
        BBUF[8] = v4l;
        BBUF[9] = v4h;
        BBUF[10] = v5l;
        BBUF[11] = v5h;
        BBUF[12] = v6l;
        BBUF[13] = v6h;
        BBUF[14] = v7l;
        BBUF[15] = v7h;
      }
      BBUF.set(B2B_IV, 16);
      const l = fromNumL(this.length);
      const h = fromNumH(this.length);
      BBUF[24] = B2B_IV[8] ^ l;
      BBUF[25] = B2B_IV[9] ^ h;
      if (isLast) {
        BBUF[28] = ~BBUF[28];
        BBUF[29] = ~BBUF[29];
      }
      let j = 0;
      const s = BSIGMA;
      for (let i = 0; i < 12; i++) {
        G1b(0, 4, 8, 12, msg, offset + 2 * s[j++]);
        G2b(0, 4, 8, 12, msg, offset + 2 * s[j++]);
        G1b(1, 5, 9, 13, msg, offset + 2 * s[j++]);
        G2b(1, 5, 9, 13, msg, offset + 2 * s[j++]);
        G1b(2, 6, 10, 14, msg, offset + 2 * s[j++]);
        G2b(2, 6, 10, 14, msg, offset + 2 * s[j++]);
        G1b(3, 7, 11, 15, msg, offset + 2 * s[j++]);
        G2b(3, 7, 11, 15, msg, offset + 2 * s[j++]);
        G1b(0, 5, 10, 15, msg, offset + 2 * s[j++]);
        G2b(0, 5, 10, 15, msg, offset + 2 * s[j++]);
        G1b(1, 6, 11, 12, msg, offset + 2 * s[j++]);
        G2b(1, 6, 11, 12, msg, offset + 2 * s[j++]);
        G1b(2, 7, 8, 13, msg, offset + 2 * s[j++]);
        G2b(2, 7, 8, 13, msg, offset + 2 * s[j++]);
        G1b(3, 4, 9, 14, msg, offset + 2 * s[j++]);
        G2b(3, 4, 9, 14, msg, offset + 2 * s[j++]);
      }
      this.v0l ^= BBUF[0] ^ BBUF[16];
      this.v0h ^= BBUF[1] ^ BBUF[17];
      this.v1l ^= BBUF[2] ^ BBUF[18];
      this.v1h ^= BBUF[3] ^ BBUF[19];
      this.v2l ^= BBUF[4] ^ BBUF[20];
      this.v2h ^= BBUF[5] ^ BBUF[21];
      this.v3l ^= BBUF[6] ^ BBUF[22];
      this.v3h ^= BBUF[7] ^ BBUF[23];
      this.v4l ^= BBUF[8] ^ BBUF[24];
      this.v4h ^= BBUF[9] ^ BBUF[25];
      this.v5l ^= BBUF[10] ^ BBUF[26];
      this.v5h ^= BBUF[11] ^ BBUF[27];
      this.v6l ^= BBUF[12] ^ BBUF[28];
      this.v6h ^= BBUF[13] ^ BBUF[29];
      this.v7l ^= BBUF[14] ^ BBUF[30];
      this.v7h ^= BBUF[15] ^ BBUF[31];
      clean(BBUF);
    }
    destroy() {
      this.destroyed = true;
      clean(this.buffer32);
      this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
  }
  const blake2b = /* @__PURE__ */ createHasher((opts) => new _BLAKE2b(opts));
  function hashTypedData(typeTag, data) {
    const typeTagBytes = Array.from(`${typeTag}::`).map((e) => e.charCodeAt(0));
    const dataWithTag = new Uint8Array(typeTagBytes.length + data.length);
    dataWithTag.set(typeTagBytes);
    dataWithTag.set(data, typeTagBytes.length);
    return blake2b(dataWithTag, { dkLen: 32 });
  }
  function prepareSuiAddress(address) {
    return normalizeSuiAddress(address).replace("0x", "");
  }
  var TransactionDataBuilder = class TransactionDataBuilder2 {
    static fromKindBytes(bytes) {
      const programmableTx = suiBcs.TransactionKind.parse(bytes).ProgrammableTransaction;
      if (!programmableTx) throw new Error("Unable to deserialize from bytes.");
      return TransactionDataBuilder2.restore({
        version: 2,
        sender: null,
        expiration: null,
        gasData: {
          budget: null,
          owner: null,
          payment: null,
          price: null
        },
        inputs: programmableTx.inputs,
        commands: programmableTx.commands
      });
    }
    static fromBytes(bytes) {
      const data = suiBcs.TransactionData.parse(bytes)?.V1;
      const programmableTx = data.kind.ProgrammableTransaction;
      if (!data || !programmableTx) throw new Error("Unable to deserialize from bytes.");
      return TransactionDataBuilder2.restore({
        version: 2,
        sender: data.sender,
        expiration: data.expiration,
        gasData: data.gasData,
        inputs: programmableTx.inputs,
        commands: programmableTx.commands
      });
    }
    static restore(data) {
      if (data.version === 2) return new TransactionDataBuilder2(parse(TransactionDataSchema, data));
      else return new TransactionDataBuilder2(parse(TransactionDataSchema, transactionDataFromV1(data)));
    }
    /**
    * Generate transaction digest.
    *
    * @param bytes BCS serialized transaction data
    * @returns transaction digest.
    */
    static getDigestFromBytes(bytes) {
      return toBase58(hashTypedData("TransactionData", bytes));
    }
    constructor(clone) {
      this.version = 2;
      this.sender = clone?.sender ?? null;
      this.expiration = clone?.expiration ?? null;
      this.inputs = clone?.inputs ?? [];
      this.commands = clone?.commands ?? [];
      this.gasData = clone?.gasData ?? {
        budget: null,
        price: null,
        owner: null,
        payment: null
      };
    }
    build({ maxSizeBytes = Infinity, overrides, onlyTransactionKind } = {}) {
      const inputs = this.inputs;
      const commands = this.commands;
      const kind = { ProgrammableTransaction: {
        inputs,
        commands
      } };
      if (onlyTransactionKind) return suiBcs.TransactionKind.serialize(kind, { maxSize: maxSizeBytes }).toBytes();
      const expiration = overrides?.expiration ?? this.expiration;
      const sender = overrides?.sender ?? this.sender;
      const gasData = {
        ...this.gasData,
        ...overrides?.gasData
      };
      if (!sender) throw new Error("Missing transaction sender");
      if (!gasData.budget) throw new Error("Missing gas budget");
      if (!gasData.payment) throw new Error("Missing gas payment");
      if (!gasData.price) throw new Error("Missing gas price");
      const transactionData = {
        sender: prepareSuiAddress(sender),
        expiration: expiration ? expiration : { None: true },
        gasData: {
          payment: gasData.payment,
          owner: prepareSuiAddress(this.gasData.owner ?? sender),
          price: BigInt(gasData.price),
          budget: BigInt(gasData.budget)
        },
        kind: { ProgrammableTransaction: {
          inputs,
          commands
        } }
      };
      return suiBcs.TransactionData.serialize({ V1: transactionData }, { maxSize: maxSizeBytes }).toBytes();
    }
    addInput(type, arg) {
      const index = this.inputs.length;
      this.inputs.push(arg);
      return {
        Input: index,
        type,
        $kind: "Input"
      };
    }
    getInputUses(index, fn) {
      this.mapArguments((arg, command) => {
        if (arg.$kind === "Input" && arg.Input === index) fn(arg, command);
        return arg;
      });
    }
    mapCommandArguments(index, fn) {
      const command = this.commands[index];
      switch (command.$kind) {
        case "MoveCall":
          command.MoveCall.arguments = command.MoveCall.arguments.map((arg) => fn(arg, command, index));
          break;
        case "TransferObjects":
          command.TransferObjects.objects = command.TransferObjects.objects.map((arg) => fn(arg, command, index));
          command.TransferObjects.address = fn(command.TransferObjects.address, command, index);
          break;
        case "SplitCoins":
          command.SplitCoins.coin = fn(command.SplitCoins.coin, command, index);
          command.SplitCoins.amounts = command.SplitCoins.amounts.map((arg) => fn(arg, command, index));
          break;
        case "MergeCoins":
          command.MergeCoins.destination = fn(command.MergeCoins.destination, command, index);
          command.MergeCoins.sources = command.MergeCoins.sources.map((arg) => fn(arg, command, index));
          break;
        case "MakeMoveVec":
          command.MakeMoveVec.elements = command.MakeMoveVec.elements.map((arg) => fn(arg, command, index));
          break;
        case "Upgrade":
          command.Upgrade.ticket = fn(command.Upgrade.ticket, command, index);
          break;
        case "$Intent":
          const inputs = command.$Intent.inputs;
          command.$Intent.inputs = {};
          for (const [key, value] of Object.entries(inputs)) command.$Intent.inputs[key] = Array.isArray(value) ? value.map((arg) => fn(arg, command, index)) : fn(value, command, index);
          break;
        case "Publish":
          break;
        default:
          throw new Error(`Unexpected transaction kind: ${command.$kind}`);
      }
    }
    mapArguments(fn) {
      for (const commandIndex of this.commands.keys()) this.mapCommandArguments(commandIndex, fn);
    }
    replaceCommand(index, replacement, resultIndex = index) {
      if (!Array.isArray(replacement)) {
        this.commands[index] = replacement;
        return;
      }
      const sizeDiff = replacement.length - 1;
      this.commands.splice(index, 1, ...structuredClone(replacement));
      this.mapArguments((arg, _command, commandIndex) => {
        if (commandIndex < index + replacement.length) return arg;
        if (typeof resultIndex !== "number") {
          if (arg.$kind === "Result" && arg.Result === index || arg.$kind === "NestedResult" && arg.NestedResult[0] === index) if (!("NestedResult" in arg) || arg.NestedResult[1] === 0) return parse(ArgumentSchema, structuredClone(resultIndex));
          else throw new Error(`Cannot replace command ${index} with a specific result type: NestedResult[${index}, ${arg.NestedResult[1]}] references a nested element that cannot be mapped to the replacement result`);
        }
        switch (arg.$kind) {
          case "Result":
            if (arg.Result === index && typeof resultIndex === "number") arg.Result = resultIndex;
            if (arg.Result > index) arg.Result += sizeDiff;
            break;
          case "NestedResult":
            if (arg.NestedResult[0] === index && typeof resultIndex === "number") return {
              $kind: "NestedResult",
              NestedResult: [resultIndex, arg.NestedResult[1]]
            };
            if (arg.NestedResult[0] > index) arg.NestedResult[0] += sizeDiff;
            break;
        }
        return arg;
      });
    }
    replaceCommandWithTransaction(index, otherTransaction, result) {
      if (result.$kind !== "Result" && result.$kind !== "NestedResult") throw new Error("Result must be of kind Result or NestedResult");
      this.insertTransaction(index, otherTransaction);
      this.replaceCommand(index + otherTransaction.commands.length, [], "Result" in result ? { NestedResult: [result.Result + index, 0] } : { NestedResult: [result.NestedResult[0] + index, result.NestedResult[1]] });
    }
    insertTransaction(atCommandIndex, otherTransaction) {
      const inputMapping = /* @__PURE__ */ new Map();
      const commandMapping = /* @__PURE__ */ new Map();
      for (let i = 0; i < otherTransaction.inputs.length; i++) {
        const otherInput = otherTransaction.inputs[i];
        const id = getIdFromCallArg(otherInput);
        let existingIndex = -1;
        if (id !== void 0) {
          existingIndex = this.inputs.findIndex((input) => getIdFromCallArg(input) === id);
          if (existingIndex !== -1 && this.inputs[existingIndex].Object?.SharedObject && otherInput.Object?.SharedObject) this.inputs[existingIndex].Object.SharedObject.mutable = this.inputs[existingIndex].Object.SharedObject.mutable || otherInput.Object.SharedObject.mutable;
        }
        if (existingIndex !== -1) inputMapping.set(i, existingIndex);
        else {
          const newIndex = this.inputs.length;
          this.inputs.push(otherInput);
          inputMapping.set(i, newIndex);
        }
      }
      for (let i = 0; i < otherTransaction.commands.length; i++) commandMapping.set(i, atCommandIndex + i);
      const remappedCommands = [];
      for (let i = 0; i < otherTransaction.commands.length; i++) {
        const command = structuredClone(otherTransaction.commands[i]);
        remapCommandArguments(command, inputMapping, commandMapping);
        remappedCommands.push(command);
      }
      this.commands.splice(atCommandIndex, 0, ...remappedCommands);
      const sizeDiff = remappedCommands.length;
      if (sizeDiff > 0) this.mapArguments((arg, _command, commandIndex) => {
        if (commandIndex >= atCommandIndex && commandIndex < atCommandIndex + remappedCommands.length) return arg;
        switch (arg.$kind) {
          case "Result":
            if (arg.Result >= atCommandIndex) arg.Result += sizeDiff;
            break;
          case "NestedResult":
            if (arg.NestedResult[0] >= atCommandIndex) arg.NestedResult[0] += sizeDiff;
            break;
        }
        return arg;
      });
    }
    getDigest() {
      const bytes = this.build({ onlyTransactionKind: false });
      return TransactionDataBuilder2.getDigestFromBytes(bytes);
    }
    snapshot() {
      return parse(TransactionDataSchema, this);
    }
    getData() {
      return this.snapshot();
    }
    shallowClone() {
      return new TransactionDataBuilder2({
        version: this.version,
        sender: this.sender,
        expiration: this.expiration,
        gasData: { ...this.gasData },
        inputs: [...this.inputs],
        commands: [...this.commands]
      });
    }
    applyResolvedData(resolved) {
      if (!this.sender) this.sender = resolved.sender ?? null;
      if (!this.expiration) this.expiration = resolved.expiration ?? null;
      if (!this.gasData.budget) this.gasData.budget = resolved.gasData.budget;
      if (!this.gasData.owner) this.gasData.owner = resolved.gasData.owner ?? null;
      if (!this.gasData.payment) this.gasData.payment = resolved.gasData.payment;
      if (!this.gasData.price) this.gasData.price = resolved.gasData.price;
      for (let i = 0; i < this.inputs.length; i++) {
        const input = this.inputs[i];
        const resolvedInput = resolved.inputs[i];
        switch (input.$kind) {
          case "UnresolvedPure":
            if (resolvedInput.$kind !== "Pure") throw new Error(`Expected input at index ${i} to resolve to a Pure argument, but got ${JSON.stringify(resolvedInput)}`);
            this.inputs[i] = resolvedInput;
            break;
          case "UnresolvedObject":
            if (resolvedInput.$kind !== "Object") throw new Error(`Expected input at index ${i} to resolve to an Object argument, but got ${JSON.stringify(resolvedInput)}`);
            if (resolvedInput.Object.$kind === "ImmOrOwnedObject" || resolvedInput.Object.$kind === "Receiving") {
              const original = input.UnresolvedObject;
              const resolved$1 = resolvedInput.Object.ImmOrOwnedObject ?? resolvedInput.Object.Receiving;
              if (normalizeSuiAddress(original.objectId) !== normalizeSuiAddress(resolved$1.objectId) || original.version != null && original.version !== resolved$1.version || original.digest != null && original.digest !== resolved$1.digest || original.mutable != null || original.initialSharedVersion != null) throw new Error(`Input at index ${i} did not match unresolved object. ${JSON.stringify(original)} is not compatible with ${JSON.stringify(resolved$1)}`);
            } else if (resolvedInput.Object.$kind === "SharedObject") {
              const original = input.UnresolvedObject;
              const resolved$1 = resolvedInput.Object.SharedObject;
              if (normalizeSuiAddress(original.objectId) !== normalizeSuiAddress(resolved$1.objectId) || original.initialSharedVersion != null && original.initialSharedVersion !== resolved$1.initialSharedVersion || original.mutable != null && original.mutable !== resolved$1.mutable || original.version != null || original.digest != null) throw new Error(`Input at index ${i} did not match unresolved object. ${JSON.stringify(original)} is not compatible with ${JSON.stringify(resolved$1)}`);
            } else throw new Error(`Input at index ${i} resolved to an unexpected Object kind: ${JSON.stringify(resolvedInput.Object)}`);
            this.inputs[i] = resolvedInput;
            break;
        }
      }
    }
  };
  const TransactionCommands = {
    MoveCall(input) {
      const [pkg, mod2 = "", fn = ""] = "target" in input ? input.target.split("::") : [
        input.package,
        input.module,
        input.function
      ];
      return {
        $kind: "MoveCall",
        MoveCall: {
          package: pkg,
          module: mod2,
          function: fn,
          typeArguments: input.typeArguments ?? [],
          arguments: input.arguments ?? []
        }
      };
    },
    TransferObjects(objects, address) {
      return {
        $kind: "TransferObjects",
        TransferObjects: {
          objects: objects.map((o) => parse(ArgumentSchema, o)),
          address: parse(ArgumentSchema, address)
        }
      };
    },
    SplitCoins(coin, amounts) {
      return {
        $kind: "SplitCoins",
        SplitCoins: {
          coin: parse(ArgumentSchema, coin),
          amounts: amounts.map((o) => parse(ArgumentSchema, o))
        }
      };
    },
    MergeCoins(destination, sources) {
      return {
        $kind: "MergeCoins",
        MergeCoins: {
          destination: parse(ArgumentSchema, destination),
          sources: sources.map((o) => parse(ArgumentSchema, o))
        }
      };
    },
    Publish({ modules, dependencies }) {
      return {
        $kind: "Publish",
        Publish: {
          modules: modules.map((module) => typeof module === "string" ? module : toBase64(new Uint8Array(module))),
          dependencies: dependencies.map((dep) => normalizeSuiObjectId(dep))
        }
      };
    },
    Upgrade({ modules, dependencies, package: packageId, ticket }) {
      return {
        $kind: "Upgrade",
        Upgrade: {
          modules: modules.map((module) => typeof module === "string" ? module : toBase64(new Uint8Array(module))),
          dependencies: dependencies.map((dep) => normalizeSuiObjectId(dep)),
          package: packageId,
          ticket: parse(ArgumentSchema, ticket)
        }
      };
    },
    MakeMoveVec({ type, elements }) {
      return {
        $kind: "MakeMoveVec",
        MakeMoveVec: {
          type: type ?? null,
          elements: elements.map((o) => parse(ArgumentSchema, o))
        }
      };
    },
    Intent({ name, inputs = {}, data = {} }) {
      return {
        $kind: "$Intent",
        $Intent: {
          name,
          inputs: Object.fromEntries(Object.entries(inputs).map(([key, value]) => [key, Array.isArray(value) ? value.map((o) => parse(ArgumentSchema, o)) : parse(ArgumentSchema, value)])),
          data
        }
      };
    }
  };
  function Pure(data) {
    return {
      $kind: "Pure",
      Pure: { bytes: data instanceof Uint8Array ? toBase64(data) : data.toBase64() }
    };
  }
  const Inputs = {
    Pure,
    ObjectRef({ objectId, digest, version }) {
      return {
        $kind: "Object",
        Object: {
          $kind: "ImmOrOwnedObject",
          ImmOrOwnedObject: {
            digest,
            version,
            objectId: normalizeSuiAddress(objectId)
          }
        }
      };
    },
    SharedObjectRef({ objectId, mutable, initialSharedVersion }) {
      return {
        $kind: "Object",
        Object: {
          $kind: "SharedObject",
          SharedObject: {
            mutable,
            initialSharedVersion,
            objectId: normalizeSuiAddress(objectId)
          }
        }
      };
    },
    ReceivingRef({ objectId, digest, version }) {
      return {
        $kind: "Object",
        Object: {
          $kind: "Receiving",
          Receiving: {
            digest,
            version,
            objectId: normalizeSuiAddress(objectId)
          }
        }
      };
    },
    FundsWithdrawal({ reservation, typeArg, withdrawFrom }) {
      return {
        $kind: "FundsWithdrawal",
        FundsWithdrawal: {
          reservation,
          typeArg,
          withdrawFrom
        }
      };
    }
  };
  BigInt(1e9);
  const MOVE_STDLIB_ADDRESS = "0x0000000000000000000000000000000000000000000000000000000000000001";
  const SUI_FRAMEWORK_ADDRESS = "0x0000000000000000000000000000000000000000000000000000000000000002";
  const SUI_CLOCK_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000006";
  const SUI_TYPE_ARG = `${SUI_FRAMEWORK_ADDRESS}::sui::SUI`;
  const SUI_SYSTEM_STATE_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000005";
  const SUI_RANDOM_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000008";
  const SUI_DENY_LIST_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000403";
  function parseTypeName(typeName) {
    const parts = typeName.split("::");
    if (parts.length !== 3) throw new Error(`Invalid type name format: ${typeName}`);
    return {
      package: parts[0],
      module: parts[1],
      name: parts[2]
    };
  }
  function isTxContext(param) {
    if (param.body.$kind !== "datatype") return false;
    const { package: pkg, module, name } = parseTypeName(param.body.datatype.typeName);
    return normalizeSuiAddress(pkg) === SUI_FRAMEWORK_ADDRESS && module === "tx_context" && name === "TxContext";
  }
  function getPureBcsSchema(typeSignature) {
    switch (typeSignature.$kind) {
      case "address":
        return suiBcs.Address;
      case "bool":
        return suiBcs.Bool;
      case "u8":
        return suiBcs.U8;
      case "u16":
        return suiBcs.U16;
      case "u32":
        return suiBcs.U32;
      case "u64":
        return suiBcs.U64;
      case "u128":
        return suiBcs.U128;
      case "u256":
        return suiBcs.U256;
      case "vector": {
        if (typeSignature.vector.$kind === "u8") return suiBcs.byteVector().transform({
          input: (val) => typeof val === "string" ? new TextEncoder().encode(val) : val,
          output: (val) => val
        });
        const type = getPureBcsSchema(typeSignature.vector);
        return type ? suiBcs.vector(type) : null;
      }
      case "datatype": {
        const { package: pkg, module, name } = parseTypeName(typeSignature.datatype.typeName);
        const normalizedPkg = normalizeSuiAddress(pkg);
        if (normalizedPkg === MOVE_STDLIB_ADDRESS) {
          if (module === "ascii" && name === "String") return suiBcs.String;
          if (module === "string" && name === "String") return suiBcs.String;
          if (module === "option" && name === "Option") {
            const type = getPureBcsSchema(typeSignature.datatype.typeParameters[0]);
            return type ? suiBcs.vector(type) : null;
          }
        }
        if (normalizedPkg === SUI_FRAMEWORK_ADDRESS) {
          if (module === "object" && name === "ID") return suiBcs.Address;
        }
        return null;
      }
      case "typeParameter":
      case "unknown":
        return null;
    }
  }
  const ALLOWANCE_BALANCE = "AllowanceBalance";
  const COIN_WITH_BALANCE = "CoinWithBalance";
  const isValidNamedType = (type) => {
    const splitType = type.split(/::|<|>|,/);
    for (const t of splitType) if (t.includes(NAME_SEPARATOR$1) && !isValidNamedPackage(t)) return false;
    return isValidStructTag(type);
  };
  const NAME_SEPARATOR = "/";
  function hasMvrName(nameOrType) {
    return nameOrType.includes(NAME_SEPARATOR) || nameOrType.includes("@") || nameOrType.includes(".sui");
  }
  function findNamesInTransaction(builder) {
    const packages = /* @__PURE__ */ new Set();
    const types = /* @__PURE__ */ new Set();
    for (const command of builder.commands) switch (command.$kind) {
      case "MakeMoveVec":
        if (command.MakeMoveVec.type) getNamesFromTypeList([command.MakeMoveVec.type]).forEach((type) => {
          types.add(type);
        });
        break;
      case "MoveCall":
        const moveCall = command.MoveCall;
        const pkg = moveCall.package.split("::")[0];
        if (hasMvrName(pkg)) {
          if (!isValidNamedPackage(pkg)) throw new Error(`Invalid package name: ${pkg}`);
          packages.add(pkg);
        }
        getNamesFromTypeList(moveCall.typeArguments ?? []).forEach((type) => {
          types.add(type);
        });
        break;
    }
    return {
      packages: [...packages],
      types: [...types]
    };
  }
  function replaceNames(builder, resolved) {
    for (const command of builder.commands) {
      if (command.MakeMoveVec?.type) {
        if (!hasMvrName(command.MakeMoveVec.type)) continue;
        if (!resolved.types[command.MakeMoveVec.type]) throw new Error(`No resolution found for type: ${command.MakeMoveVec.type}`);
        command.MakeMoveVec.type = resolved.types[command.MakeMoveVec.type].type;
      }
      const tx = command.MoveCall;
      if (!tx) continue;
      const nameParts = tx.package.split("::");
      const name = nameParts[0];
      if (hasMvrName(name) && !resolved.packages[name]) throw new Error(`No address found for package: ${name}`);
      if (hasMvrName(name)) {
        nameParts[0] = resolved.packages[name].package;
        tx.package = nameParts.join("::");
      }
      const types = tx.typeArguments;
      if (!types) continue;
      for (let i = 0; i < types.length; i++) {
        if (!hasMvrName(types[i])) continue;
        if (!resolved.types[types[i]]) throw new Error(`No resolution found for type: ${types[i]}`);
        types[i] = resolved.types[types[i]].type;
      }
      tx.typeArguments = types;
    }
  }
  function getNamesFromTypeList(types) {
    const names = /* @__PURE__ */ new Set();
    for (const type of types) if (hasMvrName(type)) {
      if (!isValidNamedType(type)) throw new Error(`Invalid type with names: ${type}`);
      names.add(type);
    }
    return names;
  }
  function transactionUsesGasCoin(transactionData) {
    let usesGasCoin = false;
    transactionData.mapArguments((arg) => {
      if (arg.$kind === "GasCoin") usesGasCoin = true;
      return arg;
    });
    return usesGasCoin;
  }
  var SuiClientError = class extends Error {
  };
  var SimulationError = class extends SuiClientError {
    constructor(message2, options) {
      super(message2, { cause: options?.cause });
      this.executionError = options?.executionError;
    }
  };
  function deriveDynamicFieldID(parentId, typeTag, key) {
    const address = suiBcs.Address.serialize(parentId).toBytes();
    const tag = suiBcs.TypeTag.serialize(typeTag).toBytes();
    const keyLength = suiBcs.u64().serialize(key.length).toBytes();
    const hash = blake2b.create({ dkLen: 32 });
    hash.update(new Uint8Array([240]));
    hash.update(address);
    hash.update(keyLength);
    hash.update(key);
    hash.update(tag);
    return `0x${toHex(hash.digest().slice(0, 32))}`;
  }
  const SUI_ACCUMULATOR_ROOT_OBJECT_ID = normalizeSuiAddress("0xacc");
  const ACCUMULATOR_KEY_TYPE_TAG = TypeTagSerializer.parseFromStr("0x2::accumulator::Key<0x2::balance::Balance<0x2::sui::SUI>>");
  const COIN_RESERVATION_MAGIC = new Uint8Array([
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172,
    172
  ]);
  function deriveReservationObjectId(owner, chainIdentifier) {
    const accBytes = fromHex(deriveDynamicFieldID(SUI_ACCUMULATOR_ROOT_OBJECT_ID, ACCUMULATOR_KEY_TYPE_TAG, suiBcs.Address.serialize(owner).toBytes()).slice(2));
    const chainBytes = fromBase58(chainIdentifier);
    if (chainBytes.length !== 32) throw new Error(`Invalid chain identifier length: expected 32 bytes, got ${chainBytes.length}`);
    const xored = new Uint8Array(32);
    for (let i = 0; i < 32; i++) xored[i] = accBytes[i] ^ chainBytes[i];
    return `0x${toHex(xored)}`;
  }
  function createCoinReservationRef(reservedBalance, owner, chainIdentifier, epoch) {
    const digestBytes = new Uint8Array(32);
    const view = new DataView(digestBytes.buffer);
    view.setBigUint64(0, reservedBalance, true);
    const epochNum = Number(epoch);
    if (!Number.isSafeInteger(epochNum) || epochNum < 0 || epochNum > 4294967295) throw new Error(`Epoch ${epoch} out of u32 range for coin reservation digest`);
    view.setUint32(8, epochNum, true);
    digestBytes.set(COIN_RESERVATION_MAGIC, 12);
    return parse(ObjectRefSchema, {
      objectId: deriveReservationObjectId(owner, chainIdentifier),
      version: "0",
      digest: toBase58(digestBytes)
    });
  }
  const MAX_OBJECTS_PER_FETCH = 50;
  const MAX_GAS_PAYMENT_OBJECTS = 256;
  const GAS_SAFE_OVERHEAD = 1000n;
  const MAX_GAS = 5e10;
  function computeGasBudget(gasUsed, gasPrice = 1n) {
    const safeOverhead = GAS_SAFE_OVERHEAD * BigInt(gasPrice);
    const baseComputationCostWithOverhead = BigInt(gasUsed.computationCost) + safeOverhead;
    const gasBudget = baseComputationCostWithOverhead + BigInt(gasUsed.storageCost) - BigInt(gasUsed.storageRebate);
    return String(gasBudget > baseComputationCostWithOverhead ? gasBudget : baseComputationCostWithOverhead);
  }
  function getClient$1(options) {
    if (!options.client) throw new Error(`No sui client passed to Transaction#build, but transaction data was not sufficient to build offline.`);
    return options.client;
  }
  async function coreClientResolveTransactionPlugin(transactionData, options, next) {
    const client = getClient$1(options);
    const needsGasPrice = !options.onlyTransactionKind && !transactionData.gasData.price;
    const needsPayment = !options.onlyTransactionKind && !transactionData.gasData.payment;
    const gasPayer = transactionData.gasData.owner ?? transactionData.sender;
    const usesGasCoin = transactionUsesGasCoin(transactionData);
    let withdrawals = 0n;
    const normalizedGasPayer = gasPayer ? normalizeSuiAddress(gasPayer) : null;
    for (const input of transactionData.inputs) {
      if (input.$kind !== "FundsWithdrawal" || !normalizedGasPayer) continue;
      if (normalizeStructTag(input.FundsWithdrawal.typeArg.Balance) !== SUI_TYPE_ARG) continue;
      const source = input.FundsWithdrawal.withdrawFrom;
      const withdrawalOwner = source.SenderAllowance ? source.SenderAllowance.funder : source.Sender ? transactionData.sender : gasPayer;
      if (withdrawalOwner && normalizeSuiAddress(withdrawalOwner) === normalizedGasPayer && input.FundsWithdrawal.reservation.$kind === "MaxAmountU64") withdrawals += BigInt(input.FundsWithdrawal.reservation.MaxAmountU64);
    }
    const needsSimulateExpiration = !options.onlyTransactionKind && !transactionData.expiration && !transactionData.gasData.budget;
    const needsSystemState = needsGasPrice || needsPayment && usesGasCoin || needsSimulateExpiration;
    const needsChainId = needsPayment && usesGasCoin || needsSimulateExpiration;
    const [, systemStateResult, balanceResult, coinsResult, chainIdResult] = await Promise.all([
      normalizeInputs(transactionData, client),
      needsSystemState ? client.core.getCurrentSystemState() : null,
      needsPayment && gasPayer ? client.core.getBalance({ owner: gasPayer }) : null,
      needsPayment && gasPayer ? client.core.listCoins({
        owner: gasPayer,
        coinType: SUI_TYPE_ARG
      }) : null,
      needsChainId ? client.core.getChainIdentifier() : null
    ]);
    await resolveObjectReferences(transactionData, client);
    if (!options.onlyTransactionKind) {
      const systemState = systemStateResult?.systemState ?? null;
      const chainIdentifier = chainIdResult?.chainIdentifier ?? null;
      if (systemState && !transactionData.gasData.price) transactionData.gasData.price = systemState.referenceGasPrice;
      await setGasBudget(transactionData, client, needsSimulateExpiration && systemState && chainIdentifier ? buildValidDuringExpiration(systemState, chainIdentifier) : void 0);
      if (needsPayment) {
        if (!balanceResult || !coinsResult) throw new Error("Could not resolve gas payment: a gas owner or sender must be set to fetch balance and coins.");
        setGasPayment({
          transactionData,
          balance: balanceResult,
          coins: coinsResult,
          usesGasCoin,
          withdrawals,
          gasPayer,
          chainIdentifier,
          epoch: systemState?.epoch ?? null
        });
      }
      if (!transactionData.expiration && transactionData.gasData.payment?.length === 0) await setExpiration(transactionData, client, systemState, chainIdentifier);
    }
    return await next();
  }
  async function setGasBudget(transactionData, client, simulateExpiration) {
    if (transactionData.gasData.budget) return;
    const simulateResult = await client.core.simulateTransaction({
      transaction: transactionData.build({ overrides: {
        gasData: {
          budget: String(MAX_GAS),
          payment: []
        },
        ...simulateExpiration && { expiration: simulateExpiration }
      } }),
      include: { effects: true },
      doGasSelection: false
    });
    if (simulateResult.$kind === "FailedTransaction") {
      const executionError = simulateResult.FailedTransaction.status.error ?? void 0;
      throw new SimulationError(`Transaction resolution failed: ${executionError?.message ?? "Unknown error"}`, {
        cause: simulateResult,
        executionError
      });
    }
    transactionData.gasData.budget = computeGasBudget(simulateResult.Transaction.effects.gasUsed, transactionData.gasData.price ? String(transactionData.gasData.price) : void 0);
  }
  function setGasPayment({ transactionData, balance, coins, usesGasCoin, withdrawals, gasPayer, chainIdentifier, epoch }) {
    const budget = BigInt(transactionData.gasData.budget);
    const addressBalance = BigInt(balance.balance.addressBalance);
    if (budget === 0n || !usesGasCoin && addressBalance >= budget + withdrawals) {
      transactionData.gasData.payment = [];
      return;
    }
    const filteredCoins = coins.objects.filter((coin) => {
      return !transactionData.inputs.find((input) => {
        if (input.Object?.ImmOrOwnedObject) return coin.objectId === input.Object.ImmOrOwnedObject.objectId;
        return false;
      });
    });
    const paymentCoins = filteredCoins.map((coin) => ({
      objectId: coin.objectId,
      digest: coin.digest,
      version: coin.version
    }));
    const reservationAmount = addressBalance - withdrawals;
    if (usesGasCoin && reservationAmount > 0n && chainIdentifier && epoch) transactionData.gasData.payment = [createCoinReservationRef(reservationAmount, gasPayer, chainIdentifier, epoch), ...paymentCoins.slice(0, MAX_GAS_PAYMENT_OBJECTS - 1)];
    else if (!filteredCoins.length) throw new Error("No valid gas coins found for the transaction.");
    else transactionData.gasData.payment = paymentCoins.slice(0, MAX_GAS_PAYMENT_OBJECTS);
  }
  async function setExpiration(transactionData, client, systemState, existingChainIdentifier = null) {
    const [chainIdentifier, resolvedSystemState] = await Promise.all([existingChainIdentifier ?? client.core.getChainIdentifier().then((r) => r.chainIdentifier), systemState ?? client.core.getCurrentSystemState().then((r) => r.systemState)]);
    transactionData.expiration = buildValidDuringExpiration(resolvedSystemState, chainIdentifier);
  }
  function buildValidDuringExpiration(systemState, chainIdentifier) {
    const currentEpoch = BigInt(systemState.epoch);
    return {
      $kind: "ValidDuring",
      ValidDuring: {
        minEpoch: String(currentEpoch),
        maxEpoch: String(currentEpoch + 1n),
        minTimestamp: null,
        maxTimestamp: null,
        chain: chainIdentifier,
        nonce: Math.random() * 4294967296 >>> 0
      }
    };
  }
  async function resolveObjectReferences(transactionData, client) {
    const objectsToResolve = transactionData.inputs.filter((input) => {
      return input.UnresolvedObject && !(input.UnresolvedObject.version || input.UnresolvedObject?.initialSharedVersion);
    });
    const dedupedIds = [...new Set(objectsToResolve.map((input) => normalizeSuiObjectId(input.UnresolvedObject.objectId)))];
    const objectChunks = dedupedIds.length ? chunk(dedupedIds, MAX_OBJECTS_PER_FETCH) : [];
    const resolved = (await Promise.all(objectChunks.map((chunkIds) => client.core.getObjects({ objectIds: chunkIds })))).flatMap((result) => result.objects);
    const responsesById = new Map(dedupedIds.map((id, index) => {
      return [id, resolved[index]];
    }));
    const invalidObjects = Array.from(responsesById).filter(([_, obj]) => obj instanceof Error).map(([_, obj]) => obj.message);
    if (invalidObjects.length) throw new Error(`The following input objects are invalid: ${invalidObjects.join(", ")}`);
    const objects = resolved.map((object2) => {
      if (object2 instanceof Error) throw new Error(`Failed to fetch object: ${object2.message}`);
      const owner = object2.owner;
      const initialSharedVersion = owner && typeof owner === "object" ? owner.$kind === "Shared" ? owner.Shared.initialSharedVersion : owner.$kind === "ConsensusAddressOwner" ? owner.ConsensusAddressOwner.startVersion : null : null;
      return {
        objectId: object2.objectId,
        digest: object2.digest,
        version: object2.version,
        initialSharedVersion
      };
    });
    const objectsById = new Map(dedupedIds.map((id, index) => {
      return [id, objects[index]];
    }));
    for (const [index, input] of transactionData.inputs.entries()) {
      if (!input.UnresolvedObject) continue;
      let updated;
      const id = normalizeSuiAddress(input.UnresolvedObject.objectId);
      const object2 = objectsById.get(id);
      if (input.UnresolvedObject.initialSharedVersion ?? object2?.initialSharedVersion) updated = Inputs.SharedObjectRef({
        objectId: id,
        initialSharedVersion: input.UnresolvedObject.initialSharedVersion || object2?.initialSharedVersion,
        mutable: input.UnresolvedObject.mutable || isUsedAsMutable(transactionData, index)
      });
      else if (isUsedAsReceiving(transactionData, index)) updated = Inputs.ReceivingRef({
        objectId: id,
        digest: input.UnresolvedObject.digest ?? object2?.digest,
        version: input.UnresolvedObject.version ?? object2?.version
      });
      transactionData.inputs[transactionData.inputs.indexOf(input)] = updated ?? Inputs.ObjectRef({
        objectId: id,
        digest: input.UnresolvedObject.digest ?? object2?.digest,
        version: input.UnresolvedObject.version ?? object2?.version
      });
    }
  }
  async function normalizeInputs(transactionData, client) {
    const { inputs, commands } = transactionData;
    const moveCallsToResolve = [];
    const moveFunctionsToResolve = /* @__PURE__ */ new Set();
    commands.forEach((command) => {
      if (command.MoveCall) {
        if (command.MoveCall._argumentTypes) return;
        if (command.MoveCall.arguments.map((arg) => {
          if (arg.$kind === "Input") return transactionData.inputs[arg.Input];
          return null;
        }).some((input) => input?.UnresolvedPure || input?.UnresolvedObject && typeof input?.UnresolvedObject.mutable !== "boolean")) {
          const functionName = `${command.MoveCall.package}::${command.MoveCall.module}::${command.MoveCall.function}`;
          moveFunctionsToResolve.add(functionName);
          moveCallsToResolve.push(command.MoveCall);
        }
      }
    });
    const moveFunctionParameters = /* @__PURE__ */ new Map();
    if (moveFunctionsToResolve.size > 0) await Promise.all([...moveFunctionsToResolve].map(async (functionName) => {
      const [packageId, moduleName, name] = functionName.split("::");
      const { function: def } = await client.core.getMoveFunction({
        packageId,
        moduleName,
        name
      });
      moveFunctionParameters.set(functionName, def.parameters);
    }));
    if (moveCallsToResolve.length) await Promise.all(moveCallsToResolve.map(async (moveCall) => {
      const parameters = moveFunctionParameters.get(`${moveCall.package}::${moveCall.module}::${moveCall.function}`);
      if (!parameters) return;
      moveCall._argumentTypes = parameters.length > 0 && isTxContext(parameters.at(-1)) ? parameters.slice(0, parameters.length - 1) : parameters;
    }));
    commands.forEach((command) => {
      if (!command.MoveCall) return;
      const moveCall = command.MoveCall;
      const fnName = `${moveCall.package}::${moveCall.module}::${moveCall.function}`;
      const params = moveCall._argumentTypes;
      if (!params) return;
      if (params.length !== command.MoveCall.arguments.length) throw new Error(`Incorrect number of arguments for ${fnName}`);
      params.forEach((param, i) => {
        const arg = moveCall.arguments[i];
        if (arg.$kind !== "Input") return;
        const input = inputs[arg.Input];
        if (!input.UnresolvedPure && !input.UnresolvedObject) return;
        const inputValue = input.UnresolvedPure?.value ?? input.UnresolvedObject?.objectId;
        const schema = getPureBcsSchema(param.body);
        if (schema) {
          arg.type = "pure";
          inputs[inputs.indexOf(input)] = Inputs.Pure(schema.serialize(inputValue));
          return;
        }
        if (typeof inputValue !== "string") throw new Error(`Expect the argument to be an object id string, got ${JSON.stringify(inputValue, null, 2)}`);
        arg.type = "object";
        const unresolvedObject = input.UnresolvedPure ? {
          $kind: "UnresolvedObject",
          UnresolvedObject: { objectId: inputValue }
        } : input;
        inputs[arg.Input] = unresolvedObject;
      });
    });
  }
  function isUsedAsMutable(transactionData, index) {
    let usedAsMutable = false;
    transactionData.getInputUses(index, (arg, tx) => {
      if (tx.MoveCall && tx.MoveCall._argumentTypes) {
        const argIndex = tx.MoveCall.arguments.indexOf(arg);
        usedAsMutable = tx.MoveCall._argumentTypes[argIndex].reference !== "immutable" || usedAsMutable;
      }
      if (tx.$kind === "MakeMoveVec" || tx.$kind === "MergeCoins" || tx.$kind === "SplitCoins" || tx.$kind === "TransferObjects") usedAsMutable = true;
    });
    return usedAsMutable;
  }
  function isUsedAsReceiving(transactionData, index) {
    let usedAsReceiving = false;
    transactionData.getInputUses(index, (arg, tx) => {
      if (tx.MoveCall && tx.MoveCall._argumentTypes) {
        const argIndex = tx.MoveCall.arguments.indexOf(arg);
        usedAsReceiving = isReceivingType(tx.MoveCall._argumentTypes[argIndex]) || usedAsReceiving;
      }
    });
    return usedAsReceiving;
  }
  const RECEIVING_TYPE = "0x0000000000000000000000000000000000000000000000000000000000000002::transfer::Receiving";
  function isReceivingType(type) {
    if (type.body.$kind !== "datatype") return false;
    return type.body.datatype.typeName === RECEIVING_TYPE;
  }
  function needsTransactionResolution(data, options) {
    if (data.inputs.some((input) => {
      return input.UnresolvedObject || input.UnresolvedPure;
    })) return true;
    if (!options.onlyTransactionKind) {
      if (!data.gasData.price || !data.gasData.budget) return true;
      if (!data.gasData.payment) {
        if (!(options.assumeSufficientAddressBalances && !transactionUsesGasCoin(data)) || data.expiration?.$kind !== "ValidDuring" && data.expiration?.$kind !== "Validity") return true;
      } else if (data.gasData.payment.length === 0 && !data.expiration) return true;
    }
    return false;
  }
  async function resolveTransactionPlugin(transactionData, options, next) {
    normalizeRawArguments(transactionData);
    if (!needsTransactionResolution(transactionData, options)) {
      if (!options.onlyTransactionKind && !transactionData.gasData.payment) transactionData.gasData.payment = [];
      await validate(transactionData);
      return next();
    }
    return (getClient(options).core?.resolveTransactionPlugin() ?? coreClientResolveTransactionPlugin)(transactionData, options, async () => {
      await validate(transactionData);
      await next();
    });
  }
  function validate(transactionData) {
    transactionData.inputs.forEach((input, index) => {
      if (input.$kind !== "Object" && input.$kind !== "Pure" && input.$kind !== "FundsWithdrawal") throw new Error(`Input at index ${index} has not been resolved.  Expected a Pure, Object, or FundsWithdrawal input, but found ${JSON.stringify(input)}`);
    });
  }
  function getClient(options) {
    if (!options.client) throw new Error(`No sui client passed to Transaction#build, but transaction data was not sufficient to build offline.`);
    return options.client;
  }
  function normalizeRawArguments(transactionData) {
    for (const command of transactionData.commands) switch (command.$kind) {
      case "SplitCoins":
        command.SplitCoins.amounts.forEach((amount) => {
          normalizeRawArgument(amount, suiBcs.U64, transactionData);
        });
        break;
      case "TransferObjects":
        normalizeRawArgument(command.TransferObjects.address, suiBcs.Address, transactionData);
        break;
    }
  }
  function normalizeRawArgument(arg, schema, transactionData) {
    if (arg.$kind !== "Input") return;
    const input = transactionData.inputs[arg.Input];
    if (input.$kind !== "UnresolvedPure") return;
    transactionData.inputs[arg.Input] = Inputs.Pure(schema.serialize(input.UnresolvedPure.value));
  }
  const AllowanceBalanceData = /* @__PURE__ */ object({
    objectId: /* @__PURE__ */ string(),
    funder: /* @__PURE__ */ optional(/* @__PURE__ */ string()),
    appType: /* @__PURE__ */ optional(/* @__PURE__ */ string()),
    type: /* @__PURE__ */ string(),
    amount: /* @__PURE__ */ string(),
    outputKind: /* @__PURE__ */ picklist(["coin", "balance"])
  });
  const AllowanceMetadata = suiBcs.struct("AllowanceMetadata", {
    id: suiBcs.Address,
    funder: suiBcs.Address,
    spender: suiBcs.option(suiBcs.Address),
    app: suiBcs.option(suiBcs.string())
  });
  function allowanceBalance({ allowance, amount, type = "0x2::sui::SUI", outputKind }) {
    suiBcs.U64.validate(amount);
    const objectId = normalizeSuiAddress(typeof allowance === "string" ? allowance : allowance.objectId);
    const reference = typeof allowance === "string" ? {} : allowance;
    return (tx) => {
      tx.addIntentResolver(ALLOWANCE_BALANCE, resolveBalances);
      return tx.add(TransactionCommands.Intent({
        name: ALLOWANCE_BALANCE,
        inputs: {
          allowance: tx.object(objectId),
          clock: tx.object.clock(),
          ...reference.app ? { permit: tx.object(reference.app.permit) } : {}
        },
        data: {
          objectId,
          funder: reference.funder ? normalizeSuiAddress(reference.funder) : void 0,
          appType: reference.app ? normalizeStructTag(reference.app.type) : void 0,
          type: normalizeStructTag(type),
          amount: String(amount),
          outputKind
        }
      }));
    };
  }
  const resolveAllowanceBalance = async (transactionData, options, next) => {
    const ids = /* @__PURE__ */ new Set();
    const namedTypes = /* @__PURE__ */ new Set();
    for (const command of transactionData.commands) {
      if (command.$kind !== "$Intent" || command.$Intent.name !== ALLOWANCE_BALANCE) continue;
      const data = parse(AllowanceBalanceData, command.$Intent.data);
      if (!data.funder) ids.add(data.objectId);
      for (const type of [data.type, data.appType]) if (type && hasMvrName(type)) namedTypes.add(type);
    }
    const [resolvedTypes, objects] = await Promise.all([namedTypes.size ? getClient(options).core.mvr.resolve({ types: [...namedTypes] }) : void 0, ids.size ? getClient(options).core.getObjects({
      objectIds: [...ids],
      include: { content: true }
    }).then((result) => result.objects) : []]);
    const allowances = /* @__PURE__ */ new Map();
    for (const object$1 of objects) {
      if (object$1 instanceof Error) throw object$1;
      allowances.set(object$1.objectId, object$1);
    }
    for (let index = 0; index < transactionData.commands.length; index++) {
      const command = transactionData.commands[index];
      if (command.$kind !== "$Intent" || command.$Intent.name !== ALLOWANCE_BALANCE) continue;
      const data = parse(AllowanceBalanceData, command.$Intent.data);
      if (hasMvrName(data.type)) {
        const resolved = resolvedTypes?.types[data.type];
        if (!resolved) throw new Error(`No resolution found for type: ${data.type}`);
        data.type = normalizeStructTag(resolved.type);
      }
      if (data.appType && hasMvrName(data.appType)) {
        const resolved = resolvedTypes?.types[data.appType];
        if (!resolved) throw new Error(`No resolution found for type: ${data.appType}`);
        data.appType = normalizeStructTag(resolved.type);
      }
      let funder = data.funder;
      if (!funder) {
        const allowance = allowances.get(data.objectId);
        const expectedType = normalizeStructTag(`0x2::allowance::Allowance<0x2::balance::Balance<${data.type}>>`);
        if (!allowance || allowance.type !== expectedType || allowance.owner.$kind !== "Shared") throw new Error(`Expected a shared ${expectedType} allowance at ${data.objectId}`);
        const metadata = AllowanceMetadata.parse(allowance.content);
        if (metadata.app !== null && !data.appType) throw new Error(`Allowance ${data.objectId} is app-bound; pass allowance.app with the app type and SpendPermit`);
        if (data.appType && (metadata.app === null || normalizeStructTag(metadata.app) !== data.appType)) throw new Error(`Allowance ${data.objectId} is not bound to app ${data.appType}`);
        funder = metadata.funder;
        const input = command.$Intent.inputs.allowance;
        if (input.$kind === "Input") transactionData.inputs[input.Input] = Inputs.SharedObjectRef({
          objectId: data.objectId,
          initialSharedVersion: allowance.owner.Shared.initialSharedVersion,
          mutable: true
        });
      }
      const allowanceArgument = command.$Intent.inputs.allowance;
      if (allowanceArgument.$kind === "Input") {
        const input = transactionData.inputs[allowanceArgument.Input];
        if (input.Object?.SharedObject) input.Object.SharedObject.mutable = true;
        if (input.UnresolvedObject) input.UnresolvedObject.mutable = true;
      }
      const withdrawal = transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
        reservation: {
          $kind: "MaxAmountU64",
          MaxAmountU64: data.amount
        },
        typeArg: {
          $kind: "Balance",
          Balance: data.type
        },
        withdrawFrom: {
          $kind: "SenderAllowance",
          SenderAllowance: {
            funder,
            allowance: data.objectId
          }
        }
      }));
      const commands = [TransactionCommands.MoveCall({
        target: data.appType ? "0x2::allowance::app_balance_spend" : "0x2::allowance::balance_spend",
        typeArguments: data.appType ? [data.type, data.appType] : [data.type],
        arguments: [
          command.$Intent.inputs.allowance,
          ...data.appType ? [command.$Intent.inputs.permit] : [],
          withdrawal,
          command.$Intent.inputs.clock
        ]
      })];
      if (data.outputKind === "coin") commands.push(TransactionCommands.MoveCall({
        target: "0x2::coin::from_balance",
        typeArguments: [data.type],
        arguments: [{
          $kind: "Result",
          Result: index
        }]
      }));
      transactionData.replaceCommand(index, commands, { NestedResult: [index + commands.length - 1, 0] });
      index += commands.length - 1;
    }
    return next();
  };
  async function resolveBalances(transactionData, options, next) {
    const intents = new Set(options.intentNames ?? [ALLOWANCE_BALANCE, COIN_WITH_BALANCE]);
    const shouldResolve = (name) => intents.has(name) && !options.supportedIntents?.includes(name) && transactionData.commands.some((command) => command.$Intent?.name === name);
    if (shouldResolve(ALLOWANCE_BALANCE)) await resolveAllowanceBalance(transactionData, options, async () => {
    });
    if (shouldResolve(COIN_WITH_BALANCE)) await resolveCoinBalance(transactionData, options, async () => {
    });
    await next();
  }
  const SUI_TYPE = normalizeStructTag("0x2::sui::SUI");
  function coinWithBalance({ type = SUI_TYPE, balance, useGasCoin = true }) {
    let coinResult = null;
    return (tx) => {
      if (coinResult) return coinResult;
      tx.addIntentResolver(COIN_WITH_BALANCE, resolveBalances);
      const coinType = type === "gas" ? type : normalizeStructTag(type);
      coinResult = tx.add(TransactionCommands.Intent({
        name: COIN_WITH_BALANCE,
        inputs: {},
        data: {
          type: coinType === SUI_TYPE && useGasCoin ? "gas" : coinType,
          balance: BigInt(balance),
          outputKind: "coin"
        }
      }));
      return coinResult;
    };
  }
  function createBalance({ type = SUI_TYPE, balance, useGasCoin = true }) {
    let balanceResult = null;
    return (tx) => {
      if (balanceResult) return balanceResult;
      tx.addIntentResolver(COIN_WITH_BALANCE, resolveBalances);
      const coinType = type === "gas" ? type : normalizeStructTag(type);
      balanceResult = tx.add(TransactionCommands.Intent({
        name: COIN_WITH_BALANCE,
        inputs: {},
        data: {
          type: coinType === SUI_TYPE && useGasCoin ? "gas" : coinType,
          balance: BigInt(balance),
          outputKind: "balance"
        }
      }));
      return balanceResult;
    };
  }
  const CoinWithBalanceData = /* @__PURE__ */ object({
    type: /* @__PURE__ */ string(),
    balance: /* @__PURE__ */ pipe(/* @__PURE__ */ union([
      /* @__PURE__ */ bigint(),
      /* @__PURE__ */ string(),
      /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer())
    ]), /* @__PURE__ */ transform((value) => BigInt(value))),
    outputKind: /* @__PURE__ */ optional(/* @__PURE__ */ picklist(["coin", "balance"]))
  });
  async function resolveCoinBalance(transactionData, buildOptions, next) {
    const coinTypes = /* @__PURE__ */ new Set();
    const totalByType = /* @__PURE__ */ new Map();
    const intentsByType = /* @__PURE__ */ new Map();
    if (!transactionData.sender) throw new Error("Sender must be set to resolve CoinWithBalance");
    if (transactionData.commands.some((command) => command.$Intent?.name === ALLOWANCE_BALANCE)) throw new Error("Resolve AllowanceBalance together with CoinWithBalance, or preserve both intents");
    const reservedByType = /* @__PURE__ */ new Map();
    for (const input of transactionData.inputs) {
      if (!input.FundsWithdrawal) continue;
      const { withdrawFrom, typeArg, reservation } = input.FundsWithdrawal;
      if (normalizeSuiAddress(withdrawFrom.SenderAllowance?.funder ?? (withdrawFrom.Sender ? transactionData.sender : transactionData.gasData.owner ?? transactionData.sender)) !== normalizeSuiAddress(transactionData.sender)) continue;
      const type = normalizeStructTag(typeArg.Balance);
      reservedByType.set(type, (reservedByType.get(type) ?? 0n) + BigInt(reservation.MaxAmountU64));
    }
    for (const [i, command] of transactionData.commands.entries()) {
      if (command.$kind !== "$Intent" || command.$Intent.name !== COIN_WITH_BALANCE) continue;
      const { type, balance, outputKind } = parse(CoinWithBalanceData, command.$Intent.data);
      if (balance === 0n) {
        const coinType = type === "gas" ? SUI_TYPE : type;
        transactionData.replaceCommand(i, TransactionCommands.MoveCall({
          target: (outputKind ?? "coin") === "balance" ? "0x2::balance::zero" : "0x2::coin::zero",
          typeArguments: [coinType]
        }));
        continue;
      }
      if (type !== "gas") coinTypes.add(type);
      totalByType.set(type, (totalByType.get(type) ?? 0n) + balance);
      if (!intentsByType.has(type)) intentsByType.set(type, []);
      intentsByType.get(type).push({
        balance,
        outputKind: outputKind ?? "coin"
      });
    }
    if (totalByType.has("gas") && totalByType.has(SUI_TYPE)) throw new Error("Cannot mix SUI CoinWithBalance intents that use the gas coin with ones that do not (useGasCoin: false). Use one or the other.");
    const usedIds = /* @__PURE__ */ new Set();
    for (const input of transactionData.inputs) {
      if (input.Object?.ImmOrOwnedObject) usedIds.add(input.Object.ImmOrOwnedObject.objectId);
      if (input.UnresolvedObject?.objectId) usedIds.add(input.UnresolvedObject.objectId);
    }
    const coinsByType = /* @__PURE__ */ new Map();
    const addressBalanceByType = /* @__PURE__ */ new Map();
    const client = buildOptions.client;
    const assumeSufficientAddressBalances = buildOptions.assumeSufficientAddressBalances;
    if (!client && !assumeSufficientAddressBalances) throw new Error("Client must be provided to build or serialize transactions with CoinWithBalance intents");
    if (assumeSufficientAddressBalances) for (const [coinType, balance] of totalByType) addressBalanceByType.set(coinType, balance);
    else await Promise.all([...[...coinTypes].map(async (coinType) => {
      const { coins, addressBalance } = await getCoinsAndBalanceOfType({
        coinType,
        balance: totalByType.get(coinType),
        client,
        owner: transactionData.sender,
        usedIds,
        reserved: reservedByType.get(coinType) ?? 0n
      });
      coinsByType.set(coinType, coins);
      addressBalanceByType.set(coinType, addressBalance);
    }), totalByType.has("gas") ? await client.core.getBalance({
      owner: transactionData.sender,
      coinType: SUI_TYPE
    }).then(({ balance }) => {
      addressBalanceByType.set("gas", availableAddressBalance(balance.addressBalance, reservedByType.get(SUI_TYPE) ?? 0n));
    }) : null]);
    const exactBalanceByType = /* @__PURE__ */ new Map();
    const usedAddressBalance = /* @__PURE__ */ new Set();
    const typeState = /* @__PURE__ */ new Map();
    let index = 0;
    while (index < transactionData.commands.length) {
      const transaction = transactionData.commands[index];
      if (transaction.$kind !== "$Intent" || transaction.$Intent.name !== COIN_WITH_BALANCE) {
        index++;
        continue;
      }
      const { type, balance } = parse(CoinWithBalanceData, transaction.$Intent.data);
      const coinType = type === "gas" ? SUI_TYPE : type;
      const totalRequired = totalByType.get(type);
      const addressBalance = addressBalanceByType.get(type) ?? 0n;
      const commands = [];
      let intentResult;
      const intentsForType = intentsByType.get(type) ?? [];
      if (intentsForType.every((i) => i.outputKind === "balance") && addressBalance >= totalRequired) {
        commands.push(TransactionCommands.MoveCall({
          target: "0x2::balance::redeem_funds",
          typeArguments: [coinType],
          arguments: [transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
            reservation: {
              $kind: "MaxAmountU64",
              MaxAmountU64: String(balance)
            },
            typeArg: {
              $kind: "Balance",
              Balance: coinType
            },
            withdrawFrom: {
              $kind: "Sender",
              Sender: true
            }
          }))]
        }));
        intentResult = {
          $kind: "NestedResult",
          NestedResult: [index + commands.length - 1, 0]
        };
      } else {
        if (!typeState.has(type)) {
          const intents = intentsForType;
          const sources = [];
          if (addressBalance >= totalRequired) {
            usedAddressBalance.add(type);
            commands.push(TransactionCommands.MoveCall({
              target: "0x2::coin::redeem_funds",
              typeArguments: [coinType],
              arguments: [transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
                reservation: {
                  $kind: "MaxAmountU64",
                  MaxAmountU64: String(totalRequired)
                },
                typeArg: {
                  $kind: "Balance",
                  Balance: coinType
                },
                withdrawFrom: {
                  $kind: "Sender",
                  Sender: true
                }
              }))]
            }));
            sources.push({
              $kind: "Result",
              Result: index + commands.length - 1
            });
          } else if (type === "gas") sources.push({
            $kind: "GasCoin",
            GasCoin: true
          });
          else {
            const coins = coinsByType.get(type);
            const loadedCoinBalance = coins.reduce((sum, c) => sum + BigInt(c.balance), 0n);
            const abNeeded = totalRequired > loadedCoinBalance ? totalRequired - loadedCoinBalance : 0n;
            exactBalanceByType.set(type, loadedCoinBalance + abNeeded === totalRequired);
            for (const coin of coins) sources.push(transactionData.addInput("object", Inputs.ObjectRef({
              objectId: coin.objectId,
              digest: coin.digest,
              version: coin.version
            })));
            if (abNeeded > 0n) {
              usedAddressBalance.add(type);
              commands.push(TransactionCommands.MoveCall({
                target: "0x2::coin::redeem_funds",
                typeArguments: [coinType],
                arguments: [transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
                  reservation: {
                    $kind: "MaxAmountU64",
                    MaxAmountU64: String(abNeeded)
                  },
                  typeArg: {
                    $kind: "Balance",
                    Balance: coinType
                  },
                  withdrawFrom: {
                    $kind: "Sender",
                    Sender: true
                  }
                }))]
              }));
              sources.push({
                $kind: "Result",
                Result: index + commands.length - 1
              });
            }
          }
          const baseCoin = sources[0];
          const rest = sources.slice(1);
          for (let i = 0; i < rest.length; i += 500) commands.push(TransactionCommands.MergeCoins(baseCoin, rest.slice(i, i + 500)));
          const splitCmdIndex = index + commands.length;
          commands.push(TransactionCommands.SplitCoins(baseCoin, intents.map((i) => transactionData.addInput("pure", Inputs.Pure(suiBcs.u64().serialize(i.balance))))));
          const results = [];
          for (let i = 0; i < intents.length; i++) {
            const splitResult = {
              $kind: "NestedResult",
              NestedResult: [splitCmdIndex, i]
            };
            if (intents[i].outputKind === "balance") {
              commands.push(TransactionCommands.MoveCall({
                target: "0x2::coin::into_balance",
                typeArguments: [coinType],
                arguments: [splitResult]
              }));
              results.push({
                $kind: "NestedResult",
                NestedResult: [index + commands.length - 1, 0]
              });
            } else results.push(splitResult);
          }
          if (type !== "gas" || usedAddressBalance.has(type)) {
            const hasBalanceIntent = intents.some((intent) => intent.outputKind === "balance");
            const sourcedFromAB = usedAddressBalance.has(type);
            if (hasBalanceIntent || sourcedFromAB) commands.push(TransactionCommands.MoveCall({
              target: "0x2::coin::send_funds",
              typeArguments: [coinType],
              arguments: [baseCoin, transactionData.addInput("pure", Inputs.Pure(suiBcs.Address.serialize(transactionData.sender)))]
            }));
            else if (exactBalanceByType.get(type)) commands.push(TransactionCommands.MoveCall({
              target: "0x2::coin::destroy_zero",
              typeArguments: [coinType],
              arguments: [baseCoin]
            }));
          }
          typeState.set(type, {
            results,
            nextIntent: 0
          });
        }
        const state = typeState.get(type);
        intentResult = state.results[state.nextIntent++];
      }
      transactionData.replaceCommand(index, commands, intentResult);
      index += commands.length;
    }
    return next();
  }
  async function getCoinsAndBalanceOfType({ coinType, balance, client, owner, usedIds, reserved }) {
    let remainingBalance = balance;
    const coins = [];
    const balanceRequest = client.core.getBalance({
      owner,
      coinType
    }).then(({ balance: balance$1 }) => {
      const addressBalance = availableAddressBalance(balance$1.addressBalance, reserved);
      remainingBalance -= addressBalance;
      return {
        ...balance$1,
        addressBalance: String(addressBalance),
        balance: String(BigInt(balance$1.balance) - reserved)
      };
    });
    const [allCoins, balanceResponse] = await Promise.all([loadMoreCoins(), balanceRequest]);
    if (BigInt(balanceResponse.balance) < balance) throw new Error(`Insufficient balance of ${coinType} for owner ${owner}. Required: ${balance}, Available: ${balance - remainingBalance}`);
    return {
      coins: allCoins,
      balance: BigInt(balanceResponse.coinBalance),
      addressBalance: BigInt(balanceResponse.addressBalance),
      coinBalance: BigInt(balanceResponse.coinBalance)
    };
    async function loadMoreCoins(cursor = null) {
      const { objects, hasNextPage, cursor: nextCursor } = await client.core.listCoins({
        owner,
        coinType,
        cursor
      });
      await balanceRequest;
      for (const coin of objects) {
        if (usedIds.has(coin.objectId)) continue;
        coins.push(coin);
        remainingBalance -= BigInt(coin.balance);
      }
      if (remainingBalance > 0n && hasNextPage) return loadMoreCoins(nextCursor);
      return coins;
    }
  }
  function availableAddressBalance(balance, reserved) {
    const available = BigInt(balance) - reserved;
    if (available < 0n) throw new Error(`Insufficient address balance for existing withdrawals. Required: ${reserved}, Available: ${balance}`);
    return available;
  }
  function enumUnion(options) {
    return /* @__PURE__ */ union(Object.entries(options).map(([key, value]) => /* @__PURE__ */ object({ [key]: value })));
  }
  const Argument = enumUnion({
    GasCoin: /* @__PURE__ */ literal(true),
    Input: /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()),
    Result: /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()),
    NestedResult: /* @__PURE__ */ tuple([/* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer()), /* @__PURE__ */ pipe(/* @__PURE__ */ number(), /* @__PURE__ */ integer())])
  });
  const GasData = /* @__PURE__ */ object({
    budget: /* @__PURE__ */ nullable(JsonU64),
    price: /* @__PURE__ */ nullable(JsonU64),
    owner: /* @__PURE__ */ nullable(SuiAddress),
    payment: /* @__PURE__ */ nullable(/* @__PURE__ */ array(ObjectRefSchema))
  });
  const ProgrammableMoveCall = /* @__PURE__ */ object({
    package: ObjectID,
    module: /* @__PURE__ */ string(),
    function: /* @__PURE__ */ string(),
    typeArguments: /* @__PURE__ */ array(/* @__PURE__ */ string()),
    arguments: /* @__PURE__ */ array(Argument)
  });
  const $Intent = /* @__PURE__ */ object({
    name: /* @__PURE__ */ string(),
    inputs: /* @__PURE__ */ record(/* @__PURE__ */ string(), /* @__PURE__ */ union([Argument, /* @__PURE__ */ array(Argument)])),
    data: /* @__PURE__ */ record(/* @__PURE__ */ string(), /* @__PURE__ */ unknown())
  });
  const Command = enumUnion({
    MoveCall: ProgrammableMoveCall,
    TransferObjects: /* @__PURE__ */ object({
      objects: /* @__PURE__ */ array(Argument),
      address: Argument
    }),
    SplitCoins: /* @__PURE__ */ object({
      coin: Argument,
      amounts: /* @__PURE__ */ array(Argument)
    }),
    MergeCoins: /* @__PURE__ */ object({
      destination: Argument,
      sources: /* @__PURE__ */ array(Argument)
    }),
    Publish: /* @__PURE__ */ object({
      modules: /* @__PURE__ */ array(BCSBytes),
      dependencies: /* @__PURE__ */ array(ObjectID)
    }),
    MakeMoveVec: /* @__PURE__ */ object({
      type: /* @__PURE__ */ nullable(/* @__PURE__ */ string()),
      elements: /* @__PURE__ */ array(Argument)
    }),
    Upgrade: /* @__PURE__ */ object({
      modules: /* @__PURE__ */ array(BCSBytes),
      dependencies: /* @__PURE__ */ array(ObjectID),
      package: ObjectID,
      ticket: Argument
    }),
    $Intent
  });
  const CallArg = enumUnion({
    Object: enumUnion({
      ImmOrOwnedObject: ObjectRefSchema,
      SharedObject: /* @__PURE__ */ object({
        objectId: ObjectID,
        initialSharedVersion: JsonU64,
        mutable: /* @__PURE__ */ boolean()
      }),
      Receiving: ObjectRefSchema
    }),
    Pure: /* @__PURE__ */ object({ bytes: BCSBytes }),
    UnresolvedPure: /* @__PURE__ */ object({ value: /* @__PURE__ */ unknown() }),
    UnresolvedObject: /* @__PURE__ */ object({
      objectId: ObjectID,
      version: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(JsonU64)),
      digest: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(/* @__PURE__ */ string())),
      initialSharedVersion: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(JsonU64)),
      mutable: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(/* @__PURE__ */ boolean()))
    }),
    FundsWithdrawal: FundsWithdrawalArgSchema
  });
  const TransactionExpiration = enumUnion({
    None: /* @__PURE__ */ literal(true),
    Epoch: JsonU64,
    ValidDuring: ValidDuringSchema,
    Validity: ValiditySchema
  });
  const SerializedTransactionDataV2Schema = /* @__PURE__ */ object({
    version: /* @__PURE__ */ literal(2),
    sender: /* @__PURE__ */ nullish(SuiAddress),
    expiration: /* @__PURE__ */ nullish(TransactionExpiration),
    gasData: GasData,
    inputs: /* @__PURE__ */ array(CallArg),
    commands: /* @__PURE__ */ array(Command),
    digest: /* @__PURE__ */ optional(/* @__PURE__ */ nullable(/* @__PURE__ */ string()))
  });
  function createObjectMethods(makeObject) {
    function object2(value) {
      return makeObject(value);
    }
    object2.system = (options) => {
      const mutable = options?.mutable;
      if (mutable !== void 0) return object2(Inputs.SharedObjectRef({
        objectId: SUI_SYSTEM_STATE_OBJECT_ID,
        initialSharedVersion: 1,
        mutable
      }));
      return object2({
        $kind: "UnresolvedObject",
        UnresolvedObject: {
          objectId: SUI_SYSTEM_STATE_OBJECT_ID,
          initialSharedVersion: 1
        }
      });
    };
    object2.clock = () => object2(Inputs.SharedObjectRef({
      objectId: SUI_CLOCK_OBJECT_ID,
      initialSharedVersion: 1,
      mutable: false
    }));
    object2.random = () => object2({
      $kind: "UnresolvedObject",
      UnresolvedObject: {
        objectId: SUI_RANDOM_OBJECT_ID,
        mutable: false
      }
    });
    object2.denyList = (options) => {
      return object2({
        $kind: "UnresolvedObject",
        UnresolvedObject: {
          objectId: SUI_DENY_LIST_OBJECT_ID,
          mutable: options?.mutable
        }
      });
    };
    object2.option = ({ type, value }) => (tx) => tx.moveCall({
      typeArguments: [type],
      target: `${MOVE_STDLIB_ADDRESS}::option::${value === null ? "none" : "some"}`,
      arguments: value === null ? [] : [tx.object(value)]
    });
    return object2;
  }
  function createPure(makePure) {
    function pure(typeOrSerializedValue, value) {
      if (typeof typeOrSerializedValue === "string") return makePure(pureBcsSchemaFromTypeName(typeOrSerializedValue).serialize(value));
      if (typeOrSerializedValue instanceof Uint8Array || isSerializedBcs(typeOrSerializedValue)) return makePure(typeOrSerializedValue);
      throw new Error("tx.pure must be called either a bcs type name, or a serialized bcs value");
    }
    pure.u8 = (value) => makePure(suiBcs.U8.serialize(value));
    pure.u16 = (value) => makePure(suiBcs.U16.serialize(value));
    pure.u32 = (value) => makePure(suiBcs.U32.serialize(value));
    pure.u64 = (value) => makePure(suiBcs.U64.serialize(value));
    pure.u128 = (value) => makePure(suiBcs.U128.serialize(value));
    pure.u256 = (value) => makePure(suiBcs.U256.serialize(value));
    pure.bool = (value) => makePure(suiBcs.Bool.serialize(value));
    pure.string = (value) => makePure(suiBcs.String.serialize(value));
    pure.address = (value) => makePure(suiBcs.Address.serialize(value));
    pure.id = pure.address;
    pure.vector = (type, value) => {
      return makePure(suiBcs.vector(pureBcsSchemaFromTypeName(type)).serialize(value));
    };
    pure.option = (type, value) => {
      return makePure(suiBcs.option(pureBcsSchemaFromTypeName(type)).serialize(value));
    };
    return pure;
  }
  function namedPackagesPlugin() {
    return async (transactionData, buildOptions, next) => {
      const names = findNamesInTransaction(transactionData);
      if (names.types.length === 0 && names.packages.length === 0) return next();
      if (!buildOptions.client) throw new Error(`Transaction contains MVR names but no client was provided to resolve them. Please pass a client to Transaction#build()`);
      replaceNames(transactionData, await buildOptions.client.core.mvr.resolve({
        types: names.types,
        packages: names.packages
      }));
      await next();
    };
  }
  function normalizeBalance(options) {
    if (options.allowance !== void 0 && options.useGasCoin !== void 0) throw new Error("useGasCoin cannot be combined with allowance");
    const amount = options.balance;
    if (typeof amount === "string" && !/^[0-9]+$/.test(amount)) throw new Error("Amount must be a non-empty string of decimal digits");
    if (typeof amount === "number" && !Number.isSafeInteger(amount)) throw new Error("Amount must be a safe integer; use bigint or a string for larger amounts");
    return BigInt(amount);
  }
  function createTransactionResult(index, length = Infinity) {
    const baseResult = {
      $kind: "Result",
      get Result() {
        return typeof index === "function" ? index() : index;
      }
    };
    const nestedResults = [];
    const nestedResultFor = (resultIndex) => nestedResults[resultIndex] ??= {
      $kind: "NestedResult",
      get NestedResult() {
        return [typeof index === "function" ? index() : index, resultIndex];
      }
    };
    return new Proxy(baseResult, {
      set() {
        throw new Error("The transaction result is a proxy, and does not support setting properties directly");
      },
      get(target, property) {
        if (property in target) return Reflect.get(target, property);
        if (property === Symbol.iterator) return function* () {
          let i = 0;
          while (i < length) {
            yield nestedResultFor(i);
            i++;
          }
        };
        if (typeof property === "symbol") return;
        const resultIndex = parseInt(property, 10);
        if (Number.isNaN(resultIndex) || resultIndex < 0) return;
        return nestedResultFor(resultIndex);
      }
    });
  }
  const TRANSACTION_BRAND = /* @__PURE__ */ Symbol.for("@mysten/transaction");
  var Transaction = class Transaction2 {
    #serializationPlugins;
    #buildPlugins;
    #intentResolvers = /* @__PURE__ */ new Map();
    #inputSection = [];
    #commandSection = [];
    #availableResults = /* @__PURE__ */ new Set();
    #pendingPromises = /* @__PURE__ */ new Set();
    #added = /* @__PURE__ */ new Map();
    /**
    * Converts from a serialize transaction kind (built with `build({ onlyTransactionKind: true })`) to a `Transaction` class.
    * Supports either a byte array, or base64-encoded bytes.
    */
    static fromKind(serialized) {
      const tx = new Transaction2();
      tx.#data = TransactionDataBuilder.fromKindBytes(typeof serialized === "string" ? fromBase64(serialized) : serialized);
      tx.#inputSection = tx.#data.inputs.slice();
      tx.#commandSection = tx.#data.commands.slice();
      tx.#availableResults = new Set(tx.#commandSection.map((_, i) => i));
      return tx;
    }
    /**
    * Converts from a serialized transaction format to a `Transaction` class.
    * There are two supported serialized formats:
    * - A string returned from `Transaction#serialize`. The serialized format must be compatible, or it will throw an error.
    * - A byte array (or base64-encoded bytes) containing BCS transaction data.
    *
    * It can also copy an existing `Transaction` or `TransactionDataBuilder` instance. The data is
    * copied, so changes to the new transaction do not affect the original.
    *
    * When copying an in-memory transaction that uses custom intents, pass resolvers for those intents
    * via `options.intentResolvers` so the copy can be created synchronously without first awaiting
    * `prepareForSerialization`. Built-in intents (such as `CoinWithBalance`) are handled automatically.
    */
    static from(transaction, options = {}) {
      const newTransaction = new Transaction2();
      if (typeof transaction === "object" && "getData" in transaction) newTransaction.#data = TransactionDataBuilder.restore(transaction.getData());
      else if (typeof transaction !== "string" || !transaction.startsWith("{")) newTransaction.#data = TransactionDataBuilder.fromBytes(typeof transaction === "string" ? fromBase64(transaction) : transaction);
      else newTransaction.#data = TransactionDataBuilder.restore(JSON.parse(transaction));
      newTransaction.#inputSection = newTransaction.#data.inputs.slice();
      newTransaction.#commandSection = newTransaction.#data.commands.slice();
      newTransaction.#availableResults = new Set(newTransaction.#commandSection.map((_, i) => i));
      const intentResolvers = new Map([
        [COIN_WITH_BALANCE, resolveBalances],
        [ALLOWANCE_BALANCE, resolveBalances],
        ...Object.entries(options.intentResolvers ?? {})
      ]);
      if (!newTransaction.isPreparedForSerialization({ supportedIntents: [...intentResolvers.keys()] })) throw new Error("Transaction has unresolved intents or async thunks. Provide resolvers for any custom intents via the `intentResolvers` option, or call `prepareForSerialization` before copying.");
      for (const [intent, resolver] of intentResolvers) newTransaction.addIntentResolver(intent, resolver);
      return newTransaction;
    }
    addSerializationPlugin(step) {
      this.#serializationPlugins.push(step);
    }
    addBuildPlugin(step) {
      this.#buildPlugins.push(step);
    }
    addIntentResolver(intent, resolver) {
      if (this.#intentResolvers.has(intent) && this.#intentResolvers.get(intent) !== resolver) throw new Error(`Intent resolver for ${intent} already exists`);
      this.#intentResolvers.set(intent, resolver);
    }
    setSender(sender) {
      this.#data.sender = sender;
    }
    /**
    * Sets the sender only if it has not already been set.
    * This is useful for sponsored transaction flows where the sender may not be the same as the signer address.
    */
    setSenderIfNotSet(sender) {
      if (!this.#data.sender) this.#data.sender = sender;
    }
    setExpiration(expiration) {
      this.#data.expiration = expiration ? parse(TransactionExpiration$1, expiration) : null;
    }
    setGasPrice(price) {
      this.#data.gasData.price = String(price);
    }
    setGasBudget(budget) {
      this.#data.gasData.budget = String(budget);
    }
    setGasBudgetIfNotSet(budget) {
      if (this.#data.gasData.budget == null) this.#data.gasData.budget = String(budget);
    }
    setGasOwner(owner) {
      this.#data.gasData.owner = owner;
    }
    setGasPayment(payments) {
      this.#data.gasData.payment = payments.map((payment) => parse(ObjectRefSchema, payment));
    }
    #data;
    /** Get a snapshot of the transaction data, in JSON form: */
    getData() {
      return this.#data.snapshot();
    }
    get [TRANSACTION_BRAND]() {
      return true;
    }
    get pure() {
      Object.defineProperty(this, "pure", {
        enumerable: false,
        value: createPure((value) => {
          if (isSerializedBcs(value)) return this.#addInput("pure", {
            $kind: "Pure",
            Pure: { bytes: value.toBase64() }
          });
          return this.#addInput("pure", /* @__PURE__ */ is(NormalizedCallArg$1, value) ? parse(NormalizedCallArg$1, value) : value instanceof Uint8Array ? Inputs.Pure(value) : {
            $kind: "UnresolvedPure",
            UnresolvedPure: { value }
          });
        })
      });
      return this.pure;
    }
    constructor() {
      this.object = createObjectMethods((value) => {
        if (typeof value === "function") return this.object(this.add(value));
        if (typeof value === "object" && /* @__PURE__ */ is(ArgumentSchema, value)) return value;
        const id = getIdFromCallArg(value);
        const inserted = this.#data.inputs.find((i) => id === getIdFromCallArg(i));
        if (inserted?.Object?.SharedObject && typeof value === "object" && value.Object?.SharedObject) inserted.Object.SharedObject.mutable = inserted.Object.SharedObject.mutable || value.Object.SharedObject.mutable;
        return inserted ? {
          $kind: "Input",
          Input: this.#data.inputs.indexOf(inserted),
          type: "object"
        } : this.#addInput("object", typeof value === "string" ? {
          $kind: "UnresolvedObject",
          UnresolvedObject: { objectId: normalizeSuiAddress(value) }
        } : value);
      });
      this.#data = new TransactionDataBuilder();
      this.#buildPlugins = [];
      this.#serializationPlugins = [];
    }
    /** Returns an argument for the gas coin, to be used in a transaction. */
    get gas() {
      return {
        $kind: "GasCoin",
        GasCoin: true
      };
    }
    /**
    * Creates a Coin<T> of the specified type and amount (defaults to SUI).
    * Sourced from address balance when available, falling back to owned coins. For SUI, falls back
    * to the gas coin instead unless `useGasCoin` is `false`.
    * With `allowance`, spends only from the funder's address balance under that allowance.
    * Allowance IDs are resolved using the build client; app-bound allowances also require an app type and SpendPermit.
    */
    coin(options) {
      const amount = normalizeBalance(options);
      return this.add(options.allowance !== void 0 ? allowanceBalance({
        ...options,
        amount,
        outputKind: "coin"
      }) : coinWithBalance({
        ...options,
        balance: amount
      }));
    }
    /**
    * Creates a Balance<T> of the specified type and amount (defaults to SUI).
    * Sourced from address balance when available, falling back to owned coins. For SUI, falls back
    * to the gas coin instead unless `useGasCoin` is `false`.
    * With `allowance`, spends only from the funder's address balance under that allowance.
    * Allowance IDs are resolved using the build client; app-bound allowances also require an app type and SpendPermit.
    */
    balance(options) {
      const amount = normalizeBalance(options);
      return this.add(options.allowance !== void 0 ? allowanceBalance({
        ...options,
        amount,
        outputKind: "balance"
      }) : createBalance({
        ...options,
        balance: amount
      }));
    }
    /**
    * Add a new object input to the transaction using the fully-resolved object reference.
    * If you only have an object ID, use `builder.object(id)` instead.
    */
    objectRef(...args) {
      return this.object(Inputs.ObjectRef(...args));
    }
    /**
    * Add a new receiving input to the transaction using the fully-resolved object reference.
    * If you only have an object ID, use `builder.object(id)` instead.
    */
    receivingRef(...args) {
      return this.object(Inputs.ReceivingRef(...args));
    }
    /**
    * Add a new shared object input to the transaction using the fully-resolved shared object reference.
    * If you only have an object ID, use `builder.object(id)` instead.
    */
    sharedObjectRef(...args) {
      return this.object(Inputs.SharedObjectRef(...args));
    }
    #fork() {
      const fork = new Transaction2();
      fork.#data = this.#data;
      fork.#serializationPlugins = this.#serializationPlugins;
      fork.#buildPlugins = this.#buildPlugins;
      fork.#intentResolvers = this.#intentResolvers;
      fork.#pendingPromises = this.#pendingPromises;
      fork.#availableResults = new Set(this.#availableResults);
      fork.#added = this.#added;
      this.#inputSection.push(fork.#inputSection);
      this.#commandSection.push(fork.#commandSection);
      return fork;
    }
    add(command) {
      if (typeof command === "function") {
        if (this.#added.has(command)) return this.#added.get(command);
        const fork = this.#fork();
        const result = command(fork);
        if (!(result && typeof result === "object" && "then" in result)) {
          this.#availableResults = fork.#availableResults;
          this.#added.set(command, result);
          return result;
        }
        const placeholder = this.#addCommand({
          $kind: "$Intent",
          $Intent: {
            name: "AsyncTransactionThunk",
            inputs: {},
            data: {
              resultIndex: this.#data.commands.length,
              result: null
            }
          }
        });
        this.#pendingPromises.add(Promise.resolve(result).then((result$1) => {
          placeholder.$Intent.data.result = result$1;
        }));
        const txResult = createTransactionResult(() => placeholder.$Intent.data.resultIndex);
        this.#added.set(command, txResult);
        return txResult;
      } else this.#addCommand(command);
      return createTransactionResult(this.#data.commands.length - 1);
    }
    #addCommand(command) {
      const resultIndex = this.#data.commands.length;
      this.#commandSection.push(command);
      this.#availableResults.add(resultIndex);
      this.#data.commands.push(command);
      this.#data.mapCommandArguments(resultIndex, (arg) => {
        if (arg.$kind === "Result" && !this.#availableResults.has(arg.Result)) throw new Error(`Result { Result: ${arg.Result} } is not available to use in the current transaction`);
        if (arg.$kind === "NestedResult" && !this.#availableResults.has(arg.NestedResult[0])) throw new Error(`Result { NestedResult: [${arg.NestedResult[0]}, ${arg.NestedResult[1]}] } is not available to use in the current transaction`);
        if (arg.$kind === "Input" && arg.Input >= this.#data.inputs.length) throw new Error(`Input { Input: ${arg.Input} } references an input that does not exist in the current transaction`);
        return arg;
      });
      return command;
    }
    #addInput(type, input) {
      this.#inputSection.push(input);
      return this.#data.addInput(type, input);
    }
    #normalizeTransactionArgument(arg) {
      if (isSerializedBcs(arg)) return this.pure(arg);
      return this.#resolveArgument(arg);
    }
    #resolveArgument(arg) {
      if (typeof arg === "function") {
        const resolved = this.add(arg);
        if (typeof resolved === "function") return this.#resolveArgument(resolved);
        return parse(ArgumentSchema, resolved);
      }
      return parse(ArgumentSchema, arg);
    }
    splitCoins(coin, amounts) {
      const command = TransactionCommands.SplitCoins(typeof coin === "string" ? this.object(coin) : this.#resolveArgument(coin), amounts.map((amount) => typeof amount === "number" || typeof amount === "bigint" || typeof amount === "string" ? this.pure.u64(amount) : this.#normalizeTransactionArgument(amount)));
      this.#addCommand(command);
      return createTransactionResult(this.#data.commands.length - 1, amounts.length);
    }
    mergeCoins(destination, sources) {
      return this.add(TransactionCommands.MergeCoins(this.object(destination), sources.map((src) => this.object(src))));
    }
    publish({ modules, dependencies }) {
      return this.add(TransactionCommands.Publish({
        modules,
        dependencies
      }));
    }
    upgrade({ modules, dependencies, package: packageId, ticket }) {
      return this.add(TransactionCommands.Upgrade({
        modules,
        dependencies,
        package: packageId,
        ticket: this.object(ticket)
      }));
    }
    moveCall({ arguments: args, ...input }) {
      return this.add(TransactionCommands.MoveCall({
        ...input,
        arguments: args?.map((arg) => this.#normalizeTransactionArgument(arg))
      }));
    }
    transferObjects(objects, address) {
      return this.add(TransactionCommands.TransferObjects(objects.map((obj) => this.object(obj)), typeof address === "string" ? this.pure.address(address) : this.#normalizeTransactionArgument(address)));
    }
    makeMoveVec({ type, elements }) {
      return this.add(TransactionCommands.MakeMoveVec({
        type,
        elements: elements.map((obj) => this.object(obj))
      }));
    }
    /**
    * Creates a FundsWithdrawal input for withdrawing Balance<T> from an address balance.
    *
    * @param options.amount - The amount to withdraw (u64).
    * @param options.type - The coin type T (e.g., "0x2::sui::SUI"), not Balance<T>. Defaults to SUI.
    * @param options.from - The withdrawal source. Defaults to the transaction sender.
    * @param options.allowance - The allowance ID, required when from is 'allowance'.
    * @param options.funder - The funder's address, required when from is 'allowance'.
    */
    withdrawal(options) {
      const input = {
        $kind: "FundsWithdrawal",
        FundsWithdrawal: {
          reservation: {
            $kind: "MaxAmountU64",
            MaxAmountU64: String(options.amount)
          },
          typeArg: {
            $kind: "Balance",
            Balance: options.type ?? "0x2::sui::SUI"
          },
          withdrawFrom: options.from === "allowance" ? {
            $kind: "SenderAllowance",
            SenderAllowance: {
              funder: normalizeSuiAddress(options.funder),
              allowance: normalizeSuiAddress(options.allowance)
            }
          } : options.from === "sponsor" ? {
            $kind: "Sponsor",
            Sponsor: true
          } : {
            $kind: "Sender",
            Sender: true
          }
        }
      };
      return this.#addInput("object", input);
    }
    /**
    * @deprecated Use toJSON instead.
    * For synchronous serialization, you can use `getData()`
    * */
    serialize() {
      return JSON.stringify(serializeV1TransactionData(this.#data.snapshot()));
    }
    async toJSON(options = {}) {
      await this.prepareForSerialization(options);
      const fullyResolved = this.isFullyResolved();
      return JSON.stringify(parse(SerializedTransactionDataV2Schema, fullyResolved ? {
        ...this.#data.snapshot(),
        digest: this.#data.getDigest()
      } : this.#data.snapshot()), (_key, value) => typeof value === "bigint" ? value.toString() : value, 2);
    }
    /** Build the transaction to BCS bytes, and sign it with the provided keypair. */
    async sign(options) {
      const { signer, ...buildOptions } = options;
      const bytes = await this.build(buildOptions);
      return signer.signTransaction(bytes);
    }
    /**
    * Checks if the transaction is prepared for serialization to JSON.
    * This means:
    *  - All async thunks have been fully resolved
    *  - All transaction intents have been resolved (unless in supportedIntents)
    *
    * Unlike `isFullyResolved()`, this does not require the sender, gas payment,
    * budget, or object versions to be set.
    */
    isPreparedForSerialization(options = {}) {
      if (this.#pendingPromises.size > 0) return false;
      if (this.#data.commands.some((cmd) => cmd.$Intent && !options.supportedIntents?.includes(cmd.$Intent.name))) return false;
      return true;
    }
    /**
    *  Ensures that:
    *  - All objects have been fully resolved to a specific version
    *  - All pure inputs have been serialized to bytes
    *  - All async thunks have been fully resolved
    *  - All transaction intents have been resolved
    * 	- The gas payment, budget, and price have been set
    *  - The transaction sender has been set
    *
    *  When true, the transaction will always be built to the same bytes and digest (unless the transaction is mutated)
    */
    isFullyResolved() {
      if (!this.isPreparedForSerialization()) return false;
      if (!this.#data.sender) return false;
      if (needsTransactionResolution(this.#data, {})) return false;
      return true;
    }
    /** Build the transaction to BCS bytes. */
    async build(options = {}) {
      await this.prepareForSerialization(options);
      await this.#prepareBuild(options);
      return this.#data.build({ onlyTransactionKind: options.onlyTransactionKind });
    }
    /** Derive transaction digest */
    async getDigest(options = {}) {
      await this.prepareForSerialization(options);
      await this.#prepareBuild(options);
      return this.#data.getDigest();
    }
    /**
    * Prepare the transaction by validating the transaction data and resolving all inputs
    * so that it can be built into bytes.
    */
    async #prepareBuild(options) {
      if (!options.onlyTransactionKind && !this.#data.sender) throw new Error("Missing transaction sender");
      await this.#runPlugins([...this.#buildPlugins, resolveTransactionPlugin], options);
    }
    async #runPlugins(plugins, options) {
      try {
        const createNext = (i) => {
          if (i >= plugins.length) return () => {
          };
          const plugin = plugins[i];
          return async () => {
            const next = createNext(i + 1);
            let calledNext = false;
            let nextResolved = false;
            await plugin(this.#data, options, async () => {
              if (calledNext) throw new Error(`next() was call multiple times in TransactionPlugin ${i}`);
              calledNext = true;
              await next();
              nextResolved = true;
            });
            if (!calledNext) throw new Error(`next() was not called in TransactionPlugin ${i}`);
            if (!nextResolved) throw new Error(`next() was not awaited in TransactionPlugin ${i}`);
          };
        };
        await createNext(0)();
      } finally {
        this.#inputSection = this.#data.inputs.slice();
        this.#commandSection = this.#data.commands.slice();
        this.#availableResults = new Set(this.#commandSection.map((_, i) => i));
      }
    }
    async #waitForPendingTasks() {
      while (this.#pendingPromises.size > 0) {
        const newPromise = Promise.all(this.#pendingPromises);
        this.#pendingPromises.clear();
        this.#pendingPromises.add(newPromise);
        await newPromise;
        this.#pendingPromises.delete(newPromise);
      }
    }
    #sortCommandsAndInputs() {
      const unorderedCommands = this.#data.commands;
      const unorderedInputs = this.#data.inputs;
      const orderedCommands = this.#commandSection.flat(Infinity);
      const orderedInputs = this.#inputSection.flat(Infinity);
      if (orderedCommands.length !== unorderedCommands.length) throw new Error("Unexpected number of commands found in transaction data");
      if (orderedInputs.length !== unorderedInputs.length) throw new Error("Unexpected number of inputs found in transaction data");
      const filteredCommands = orderedCommands.filter((cmd) => cmd.$Intent?.name !== "AsyncTransactionThunk");
      this.#data.commands = filteredCommands;
      this.#data.inputs = orderedInputs;
      this.#commandSection = filteredCommands;
      this.#inputSection = orderedInputs;
      this.#availableResults = new Set(filteredCommands.map((_, i) => i));
      function getOriginalIndex(index) {
        const command = unorderedCommands[index];
        if (command.$Intent?.name === "AsyncTransactionThunk") {
          const result = command.$Intent.data.result;
          if (result == null) throw new Error("AsyncTransactionThunk has not been resolved");
          return getOriginalIndex(result.Result);
        }
        const updated = filteredCommands.indexOf(command);
        if (updated === -1) throw new Error("Unable to find original index for command");
        return updated;
      }
      this.#data.mapArguments((arg) => {
        if (arg.$kind === "Input") {
          const updated = orderedInputs.indexOf(unorderedInputs[arg.Input]);
          if (updated === -1) throw new Error("Input has not been resolved");
          return {
            ...arg,
            Input: updated
          };
        } else if (arg.$kind === "Result") {
          const updated = getOriginalIndex(arg.Result);
          return {
            ...arg,
            Result: updated
          };
        } else if (arg.$kind === "NestedResult") {
          const updated = getOriginalIndex(arg.NestedResult[0]);
          return {
            ...arg,
            NestedResult: [updated, arg.NestedResult[1]]
          };
        }
        return arg;
      });
      for (const [i, cmd] of unorderedCommands.entries()) if (cmd.$Intent?.name === "AsyncTransactionThunk") try {
        cmd.$Intent.data.resultIndex = getOriginalIndex(i);
      } catch {
      }
    }
    async prepareForSerialization(options) {
      await this.#waitForPendingTasks();
      this.#sortCommandsAndInputs();
      const intents = /* @__PURE__ */ new Set();
      for (const command of this.#data.commands) if (command.$Intent) intents.add(command.$Intent.name);
      const steps = [...this.#serializationPlugins];
      const resolverIntents = /* @__PURE__ */ new Map();
      for (const intent of intents) {
        if (options.supportedIntents?.includes(intent)) continue;
        const resolver = this.#intentResolvers.get(intent);
        if (!resolver) throw new Error(`Missing intent resolver for ${intent}`);
        const names = resolverIntents.get(resolver) ?? [];
        names.push(intent);
        resolverIntents.set(resolver, names);
      }
      for (const [resolver, intentNames] of resolverIntents) steps.push((data, buildOptions, next) => {
        return resolver(data, {
          ...buildOptions,
          intentNames
        }, next);
      });
      steps.push(namedPackagesPlugin());
      await this.#runPlugins(steps, options);
    }
  };
  const WORKER_URL = "https://api.soothia.fun";
  const STAKE_PACKAGE = "0xf9507a1cb35b01c191614a67bf5ca3f22c7c3a7745fdc7ddea67369686a6720f";
  const STAKE_CONFIG = "0x7ba41f413b54f1f04b592694ad3304caa87df7cf9f1afda98b42c45362d2b3be";
  const PAY_PACKAGE = "0x69093f4bd2ec5d00c5780d8fd2e09adde6a4399146fed2bafc94071311d52a92";
  const PAY_CONFIG = "0x7b14fd24baed71d4062f88c22d06c61f4785fc040c3e692ae335b1cde7807f1e";
  const BASE64 = /^[A-Za-z0-9+/]+={0,2}$/;
  const CLOCK = normalizeSuiAddress("0x6");
  const STAKE_ARGUMENTS = 6;
  const HASH_BYTES = 32;
  const PAY_ARGUMENTS = 4;
  const MAX_GAS_BUDGET = 20000000n;
  class Refusal extends Error {
  }
  function refuseIf(condition, reason) {
    if (condition) throw new Refusal(reason);
  }
  const sameAddress = (a, b) => normalizeSuiAddress(a) === normalizeSuiAddress(b);
  function inputOf(data, argument, what) {
    const input = argument?.$kind === "Input" ? data.inputs[argument.Input] : void 0;
    if (!input) throw new Refusal(`${what} is not a plain input.`);
    return input;
  }
  function sharedObjectId(data, argument, what) {
    const id = inputOf(data, argument, what).Object?.SharedObject?.objectId;
    if (!id) throw new Refusal(`${what} is not a shared object.`);
    return id;
  }
  function pureBytes(data, argument, what) {
    const bytes = inputOf(data, argument, what).Pure?.bytes;
    if (bytes === void 0) throw new Refusal(`${what} is not a plain value.`);
    return fromBase64(bytes);
  }
  function checkTarget(command, fn) {
    const call = command?.MoveCall;
    if (!call) throw new Refusal(`Expected a call to ${fn}.`);
    refuseIf(!sameAddress(call.package, STAKE_PACKAGE), "It calls a contract that is not Soothia's.");
    refuseIf(call.module !== "pool" || call.function !== fn, `It calls something other than ${fn}.`);
    refuseIf((call.typeArguments ?? []).length !== 0, "It has unexpected type arguments.");
    return call;
  }
  function checkStake(data, expected) {
    refuseIf(data.commands.length !== 2, "It does more than split a coin and stake.");
    const split2 = data.commands[0].SplitCoins;
    if (!split2) throw new Refusal("The first step is not a coin split.");
    refuseIf(split2.coin.$kind !== "GasCoin", "The stake does not come from your SUI balance.");
    refuseIf(split2.amounts.length !== 1, "It splits more than one coin.");
    const amountBytes = pureBytes(data, split2.amounts[0], "The amount");
    refuseIf(amountBytes.length !== 8, "The amount is malformed.");
    refuseIf(suiBcs.u64().parse(amountBytes) !== expected.amountMist, "The amount differs from what you chose.");
    const call = checkTarget(data.commands[1], "stake");
    refuseIf(call.arguments.length !== STAKE_ARGUMENTS, "The stake call has the wrong arguments.");
    const [config, pool, side, coin, pickHash, clock] = call.arguments;
    refuseIf(!sameAddress(sharedObjectId(data, config, "The config"), STAKE_CONFIG), "It uses a different config.");
    refuseIf(!sameAddress(sharedObjectId(data, pool, "The pool"), expected.poolId), "It stakes in a different pool.");
    const sideBytes = pureBytes(data, side, "The side");
    refuseIf(sideBytes.length !== 1 || suiBcs.bool().parse(sideBytes) !== expected.side, "It backs the other side.");
    const fromSplit = coin.$kind === "NestedResult" && coin.NestedResult[0] === 0 && coin.NestedResult[1] === 0 || coin.$kind === "Result" && coin.Result === 0;
    refuseIf(!fromSplit, "The stake does not use the split coin.");
    const hash = suiBcs.vector(suiBcs.u8()).parse(pureBytes(data, pickHash, "The call's hash"));
    refuseIf(hash.length !== HASH_BYTES, "The call's hash is malformed.");
    if (expected.pickHash !== void 0) {
      const hex = hash.map((byte) => byte.toString(16).padStart(2, "0")).join("");
      refuseIf(hex !== expected.pickHash.toLowerCase(), "It is tied to a different call.");
    }
    refuseIf(!sameAddress(sharedObjectId(data, clock, "The clock"), CLOCK), "It does not use the Sui clock.");
    refuseIf(data.inputs.length !== STAKE_ARGUMENTS, "It carries extra inputs.");
  }
  function checkGasBudget(data) {
    const { budget } = data.gasData;
    refuseIf(budget === null || budget === void 0 || BigInt(budget) > MAX_GAS_BUDGET, "It allows too much gas.");
  }
  function checkAmount(data, command, expected) {
    const split2 = command.SplitCoins;
    if (!split2) throw new Refusal("The first step is not a coin split.");
    refuseIf(split2.coin.$kind !== "GasCoin", "It does not come from your SUI balance.");
    refuseIf(split2.amounts.length !== 1, "It splits more than one coin.");
    const bytes = pureBytes(data, split2.amounts[0], "The amount");
    refuseIf(bytes.length !== 8, "The amount is malformed.");
    refuseIf(suiBcs.u64().parse(bytes) !== expected, "The amount differs from what you chose.");
  }
  function checkRecipient(data, argument, expected) {
    const bytes = pureBytes(data, argument, "The recipient");
    refuseIf(bytes.length !== 32 || !sameAddress(suiBcs.Address.parse(bytes), expected), "It pays someone else.");
  }
  const isSplitCoin = (argument) => argument.$kind === "NestedResult" && argument.NestedResult[0] === 0 && argument.NestedResult[1] === 0 || argument.$kind === "Result" && argument.Result === 0;
  function checkPay(data, expected) {
    refuseIf(data.commands.length !== 2, "It does more than split a coin and pay.");
    refuseIf(data.inputs.length !== PAY_ARGUMENTS, "It carries extra inputs.");
    checkGasBudget(data);
    checkAmount(data, data.commands[0], expected.priceMist);
    const call = data.commands[1].MoveCall;
    if (!call) throw new Refusal("Expected a call to pay.");
    refuseIf(!sameAddress(call.package, PAY_PACKAGE), "It calls a contract that is not Soothia's.");
    refuseIf(call.module !== "pay" || call.function !== "pay", "It calls something other than pay.");
    refuseIf((call.typeArguments ?? []).length !== 0, "It has unexpected type arguments.");
    refuseIf(call.arguments.length !== PAY_ARGUMENTS, "The pay call has the wrong arguments.");
    const [config, nonce, recipient, coin] = call.arguments;
    refuseIf(!sameAddress(sharedObjectId(data, config, "The config"), PAY_CONFIG), "It uses a different config.");
    const nonceBytes = suiBcs.vector(suiBcs.u8()).parse(pureBytes(data, nonce, "The nonce"));
    refuseIf(nonceBytes.map((byte) => byte.toString(16).padStart(2, "0")).join("") !== expected.nonce, "It is tied to a different payment.");
    checkRecipient(data, recipient, expected.recipient);
    refuseIf(!isSplitCoin(coin), "The payment does not use the split coin.");
  }
  function checkFund(data, expected) {
    refuseIf(data.commands.length !== 2, "It does more than split a coin and send it.");
    refuseIf(data.inputs.length !== 2, "It carries extra inputs.");
    checkGasBudget(data);
    checkAmount(data, data.commands[0], expected.amountMist);
    const transfer = data.commands[1].TransferObjects;
    if (!transfer) throw new Refusal("Expected a transfer.");
    refuseIf(transfer.objects.length !== 1 || !isSplitCoin(transfer.objects[0]), "It does not send the split coin.");
    checkRecipient(data, transfer.address, expected.recipient);
  }
  function checkWithdraw(data, expected) {
    refuseIf(data.commands.length !== 1 || data.inputs.length !== 1, "It does more than send the balance.");
    checkGasBudget(data);
    const transfer = data.commands[0].TransferObjects;
    if (!transfer) throw new Refusal("Expected a transfer.");
    refuseIf(transfer.objects.length !== 1 || transfer.objects[0].$kind !== "GasCoin", "It does not send the whole balance.");
    checkRecipient(data, transfer.address, expected.recipient);
  }
  function checkClaim(data, expected) {
    refuseIf(data.commands.length !== 1, "It does more than claim.");
    const call = checkTarget(data.commands[0], "claim");
    refuseIf(call.arguments.length !== 2, "The claim call has the wrong arguments.");
    refuseIf(!sameAddress(sharedObjectId(data, call.arguments[0], "The pool"), expected.poolId), "It claims from a different pool.");
    refuseIf(!sameAddress(sharedObjectId(data, call.arguments[1], "The clock"), CLOCK), "It does not use the Sui clock.");
    refuseIf(data.inputs.length !== 2, "It carries extra inputs.");
  }
  function checkTransaction(txBytes, expected, sender) {
    try {
      refuseIf(typeof txBytes !== "string" || !BASE64.test(txBytes), "It is not a built transaction.");
      const data = Transaction.from(fromBase64(txBytes)).getData();
      refuseIf(!data.sender || !sameAddress(data.sender, sender), "It would be sent from a different address.");
      refuseIf(Boolean(data.gasData.owner) && !sameAddress(data.gasData.owner, sender), "Someone else would pay its gas.");
      if (expected.kind === "stake") checkStake(data, expected);
      else if (expected.kind === "claim") checkClaim(data, expected);
      else if (expected.kind === "pay") checkPay(data, expected);
      else if (expected.kind === "fund") checkFund(data, expected);
      else if (expected.kind === "withdraw") checkWithdraw(data, expected);
      else throw new Refusal("Unknown transaction type.");
      return { ok: true };
    } catch (error) {
      const reason = error instanceof Refusal ? error.message : "It could not be read.";
      return { ok: false, reason: `Transaction refused. ${reason}` };
    }
  }
  const HEALTH_REQUEST = "soothia:v1:health";
  const DETECT_REQUEST = "soothia:v1:detect";
  const API_REQUEST = "soothia:v1:api";
  const OPEN_WELCOME = "soothia:v1:open-welcome";
  const MUSIC_CONTROL = "soothia:v1:music";
  const API_ROUTES = {
    "/recall/status": "GET",
    "/recall/record": "GET",
    "/recall/proof": "GET",
    "/recall/insights": "POST",
    "/recall/pick": "POST",
    "/recall/pref": "POST",
    "/stake/pool": "POST",
    "/stake/build": "POST",
    "/stake/confirm": "POST",
    "/stake/positions": "GET",
    "/stake/balance": "GET",
    "/stake/claim/build": "POST",
    "/social/profile/challenge": "POST",
    "/social/profile/publish": "POST",
    "/social/profile/update": "POST",
    "/social/profile/unpublish": "POST",
    "/social/profile/by-address": "GET",
    "/social/suins": "GET",
    "/social/leaderboard": "GET",
    "/social/follow": "POST",
    "/social/unfollow": "POST",
    "/social/following": "GET",
    "/social/search": "GET",
    "/social/feed": "GET",
    "/social/feed/new": "GET",
    "/premium/eligible": "GET",
    "/premium/build": "POST",
    "/premium/balance": "GET",
    "/premium/transfer/build": "POST",
    "/premium/transfer/execute": "POST"
  };
  const RECALL_ID_KEY = "soothia.recallId";
  const SUI_WALLET_KEY = "soothia.suiWallet";
  const CHECK_TX = "soothia:v1:check-tx";
  const PREMIUM_CALL = "soothia:v1:premium-call";
  const AGENT_REQUEST = "soothia:v1:agent";
  const AGENT_KEY = "soothia.agentKey";
  const AGENT_SETTINGS_KEY = "soothia.agentSettings";
  const AGENT_SPEND_KEY = "soothia.agentSpend";
  const AGENT_RECEIPTS_KEY = "soothia.agentReceipts";
  const SIGNATURE_SCHEME_TO_FLAG = {
    ED25519: 0,
    Secp256k1: 1,
    Secp256r1: 2,
    MultiSig: 3,
    ZkLogin: 5,
    Passkey: 6,
    MLDSA65: 7
  };
  const SIGNATURE_SCHEME_TO_SIZE = {
    ED25519: 32,
    Secp256k1: 33,
    Secp256r1: 33,
    Passkey: 33,
    MLDSA65: 1952
  };
  const SIGNATURE_FLAG_TO_SCHEME = {
    0: "ED25519",
    1: "Secp256k1",
    2: "Secp256r1",
    3: "MultiSig",
    5: "ZkLogin",
    6: "Passkey",
    7: "MLDSA65"
  };
  function messageWithIntent(scope, message2) {
    return suiBcs.IntentMessage(suiBcs.bytes(message2.length)).serialize({
      intent: {
        scope: { [scope]: true },
        version: { V0: true },
        appId: { Sui: true }
      },
      value: message2
    }).toBytes();
  }
  function bytesEqual(a, b) {
    if (a === b) return true;
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
  }
  var PublicKey = class {
    /**
    * Checks if two public keys are equal
    */
    equals(publicKey) {
      return bytesEqual(this.toRawBytes(), publicKey.toRawBytes());
    }
    /**
    * Return the base-64 representation of the public key
    */
    toBase64() {
      return toBase64(this.toRawBytes());
    }
    toString() {
      throw new Error("`toString` is not implemented on public keys. Use `toBase64()` or `toRawBytes()` instead.");
    }
    /**
    * Return the Sui representation of the public key encoded in
    * base-64. A Sui public key is formed by the concatenation
    * of the scheme flag with the raw bytes of the public key
    */
    toSuiPublicKey() {
      return toBase64(this.toSuiBytes());
    }
    verifyWithIntent(bytes, signature, intent) {
      const digest = blake2b(messageWithIntent(intent, bytes), { dkLen: 32 });
      return this.verify(digest, signature);
    }
    /**
    * Verifies that the signature is valid for for the provided PersonalMessage
    */
    verifyPersonalMessage(message2, signature) {
      return this.verifyWithIntent(suiBcs.byteVector().serialize(message2).toBytes(), signature, "PersonalMessage");
    }
    /**
    * Verifies that the signature is valid for for the provided Transaction
    */
    verifyTransaction(transaction, signature) {
      return this.verifyWithIntent(transaction, signature, "TransactionData");
    }
    /**
    * Verifies that the public key is associated with the provided address
    */
    verifyAddress(address) {
      return this.toSuiAddress() === address;
    }
    /**
    * Returns the bytes representation of the public key
    * prefixed with the signature scheme flag
    */
    toSuiBytes() {
      const rawBytes = this.toRawBytes();
      const suiBytes = new Uint8Array(rawBytes.length + 1);
      suiBytes.set([this.flag()]);
      suiBytes.set(rawBytes, 1);
      return suiBytes;
    }
    /**
    * Return the Sui address associated with this Ed25519 public key
    */
    toSuiAddress() {
      return normalizeSuiAddress(bytesToHex$1(blake2b(this.toSuiBytes(), { dkLen: 32 })).slice(0, SUI_ADDRESS_LENGTH * 2));
    }
  };
  function parseSerializedKeypairSignature(serializedSignature) {
    const bytes = fromBase64(serializedSignature);
    const signatureScheme = SIGNATURE_FLAG_TO_SCHEME[bytes[0]];
    switch (signatureScheme) {
      case "ED25519":
      case "Secp256k1":
      case "Secp256r1":
      case "MLDSA65":
        const size = SIGNATURE_SCHEME_TO_SIZE[signatureScheme];
        const signature = bytes.slice(1, bytes.length - size);
        return {
          serializedSignature,
          signatureScheme,
          signature,
          publicKey: bytes.slice(1 + signature.length),
          bytes
        };
      default:
        throw new Error("Unsupported signature scheme");
    }
  }
  const K512 = /* @__PURE__ */ (() => split$1([
    "0x428a2f98d728ae22",
    "0x7137449123ef65cd",
    "0xb5c0fbcfec4d3b2f",
    "0xe9b5dba58189dbbc",
    "0x3956c25bf348b538",
    "0x59f111f1b605d019",
    "0x923f82a4af194f9b",
    "0xab1c5ed5da6d8118",
    "0xd807aa98a3030242",
    "0x12835b0145706fbe",
    "0x243185be4ee4b28c",
    "0x550c7dc3d5ffb4e2",
    "0x72be5d74f27b896f",
    "0x80deb1fe3b1696b1",
    "0x9bdc06a725c71235",
    "0xc19bf174cf692694",
    "0xe49b69c19ef14ad2",
    "0xefbe4786384f25e3",
    "0x0fc19dc68b8cd5b5",
    "0x240ca1cc77ac9c65",
    "0x2de92c6f592b0275",
    "0x4a7484aa6ea6e483",
    "0x5cb0a9dcbd41fbd4",
    "0x76f988da831153b5",
    "0x983e5152ee66dfab",
    "0xa831c66d2db43210",
    "0xb00327c898fb213f",
    "0xbf597fc7beef0ee4",
    "0xc6e00bf33da88fc2",
    "0xd5a79147930aa725",
    "0x06ca6351e003826f",
    "0x142929670a0e6e70",
    "0x27b70a8546d22ffc",
    "0x2e1b21385c26c926",
    "0x4d2c6dfc5ac42aed",
    "0x53380d139d95b3df",
    "0x650a73548baf63de",
    "0x766a0abb3c77b2a8",
    "0x81c2c92e47edaee6",
    "0x92722c851482353b",
    "0xa2bfe8a14cf10364",
    "0xa81a664bbc423001",
    "0xc24b8b70d0f89791",
    "0xc76c51a30654be30",
    "0xd192e819d6ef5218",
    "0xd69906245565a910",
    "0xf40e35855771202a",
    "0x106aa07032bbd1b8",
    "0x19a4c116b8d2d0c8",
    "0x1e376c085141ab53",
    "0x2748774cdf8eeb99",
    "0x34b0bcb5e19b48a8",
    "0x391c0cb3c5c95a63",
    "0x4ed8aa4ae3418acb",
    "0x5b9cca4f7763e373",
    "0x682e6ff3d6b2b8a3",
    "0x748f82ee5defb2fc",
    "0x78a5636f43172f60",
    "0x84c87814a1f0ab72",
    "0x8cc702081a6439ec",
    "0x90befffa23631e28",
    "0xa4506cebde82bde9",
    "0xbef9a3f7b2c67915",
    "0xc67178f2e372532b",
    "0xca273eceea26619c",
    "0xd186b8c721c0c207",
    "0xeada7dd6cde0eb1e",
    "0xf57d4f7fee6ed178",
    "0x06f067aa72176fba",
    "0x0a637dc5a2c898a6",
    "0x113f9804bef90dae",
    "0x1b710b35131c471b",
    "0x28db77f523047d84",
    "0x32caab7b40c72493",
    "0x3c9ebe0a15c9bebc",
    "0x431d67c49c100d4c",
    "0x4cc5d4becb3e42b6",
    "0x597f299cfc657e2a",
    "0x5fcb6fab3ad6faec",
    "0x6c44198c4a475817"
  ].map((n) => BigInt(n))))();
  const SHA512_Kh = /* @__PURE__ */ (() => K512[0])();
  const SHA512_Kl = /* @__PURE__ */ (() => K512[1])();
  const SHA512_W_H = /* @__PURE__ */ new Uint32Array(80);
  const SHA512_W_L = /* @__PURE__ */ new Uint32Array(80);
  class SHA2_64B extends HashMD {
    // We cannot use array here since array allows indexing by variable
    // which means optimizer/compiler cannot use registers.
    // h -- high 32 bits, l -- low 32 bits
    // Numeric initializers matter: starting the fields as `undefined` changes
    // V8's field representation and slows hashing down (measured on sha256).
    Ah = 0;
    Al = 0;
    Bh = 0;
    Bl = 0;
    Ch = 0;
    Cl = 0;
    Dh = 0;
    Dl = 0;
    Eh = 0;
    El = 0;
    Fh = 0;
    Fl = 0;
    Gh = 0;
    Gl = 0;
    Hh = 0;
    Hl = 0;
    constructor(outputLen, IV) {
      super(128, outputLen, 16, false);
      this.Ah = IV[0] | 0;
      this.Al = IV[1] | 0;
      this.Bh = IV[2] | 0;
      this.Bl = IV[3] | 0;
      this.Ch = IV[4] | 0;
      this.Cl = IV[5] | 0;
      this.Dh = IV[6] | 0;
      this.Dl = IV[7] | 0;
      this.Eh = IV[8] | 0;
      this.El = IV[9] | 0;
      this.Fh = IV[10] | 0;
      this.Fl = IV[11] | 0;
      this.Gh = IV[12] | 0;
      this.Gl = IV[13] | 0;
      this.Hh = IV[14] | 0;
      this.Hl = IV[15] | 0;
    }
    // prettier-ignore
    get() {
      const { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
      return [Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl];
    }
    // prettier-ignore
    set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl) {
      this.Ah = Ah | 0;
      this.Al = Al | 0;
      this.Bh = Bh | 0;
      this.Bl = Bl | 0;
      this.Ch = Ch | 0;
      this.Cl = Cl | 0;
      this.Dh = Dh | 0;
      this.Dl = Dl | 0;
      this.Eh = Eh | 0;
      this.El = El | 0;
      this.Fh = Fh | 0;
      this.Fl = Fl | 0;
      this.Gh = Gh | 0;
      this.Gl = Gl | 0;
      this.Hh = Hh | 0;
      this.Hl = Hl | 0;
    }
    _cloneInto(to) {
      (to ||= new this.constructor()).set(...this.get());
      return this._cloneIntoMeta(to);
    }
    process(view, offset) {
      for (let i = 0; i < 16; i++, offset += 4) {
        SHA512_W_H[i] = view.getUint32(offset);
        SHA512_W_L[i] = view.getUint32(offset += 4);
      }
      for (let i = 16; i < 80; i++) {
        const W15h = SHA512_W_H[i - 15] | 0;
        const W15l = SHA512_W_L[i - 15] | 0;
        const s0h = rotrSH(W15h, W15l, 1) ^ rotrSH(W15h, W15l, 8) ^ shrSH(W15h, W15l, 7);
        const s0l = rotrSL(W15h, W15l, 1) ^ rotrSL(W15h, W15l, 8) ^ shrSL(W15h, W15l, 7);
        const W2h = SHA512_W_H[i - 2] | 0;
        const W2l = SHA512_W_L[i - 2] | 0;
        const s1h = rotrSH(W2h, W2l, 19) ^ rotrBH(W2h, W2l, 61) ^ shrSH(W2h, W2l, 6);
        const s1l = rotrSL(W2h, W2l, 19) ^ rotrBL(W2h, W2l, 61) ^ shrSL(W2h, W2l, 6);
        const SUMl = add4L(s0l, s1l, SHA512_W_L[i - 7], SHA512_W_L[i - 16]);
        const SUMh = add4H(SUMl, s0h, s1h, SHA512_W_H[i - 7], SHA512_W_H[i - 16]);
        SHA512_W_H[i] = SUMh | 0;
        SHA512_W_L[i] = SUMl | 0;
      }
      let { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
      for (let i = 0; i < 80; i++) {
        const sigma1h = rotrSH(Eh, El, 14) ^ rotrSH(Eh, El, 18) ^ rotrBH(Eh, El, 41);
        const sigma1l = rotrSL(Eh, El, 14) ^ rotrSL(Eh, El, 18) ^ rotrBL(Eh, El, 41);
        const CHIh = Eh & Fh ^ ~Eh & Gh;
        const CHIl = El & Fl ^ ~El & Gl;
        const T1ll = add5L(Hl, sigma1l, CHIl, SHA512_Kl[i], SHA512_W_L[i]);
        const T1h = add5H(T1ll, Hh, sigma1h, CHIh, SHA512_Kh[i], SHA512_W_H[i]);
        const T1l = T1ll | 0;
        const sigma0h = rotrSH(Ah, Al, 28) ^ rotrBH(Ah, Al, 34) ^ rotrBH(Ah, Al, 39);
        const sigma0l = rotrSL(Ah, Al, 28) ^ rotrBL(Ah, Al, 34) ^ rotrBL(Ah, Al, 39);
        const MAJh = Ah & Bh ^ Ah & Ch ^ Bh & Ch;
        const MAJl = Al & Bl ^ Al & Cl ^ Bl & Cl;
        Hh = Gh | 0;
        Hl = Gl | 0;
        Gh = Fh | 0;
        Gl = Fl | 0;
        Fh = Eh | 0;
        Fl = El | 0;
        ({ h: Eh, l: El } = add(Dh | 0, Dl | 0, T1h | 0, T1l | 0));
        Dh = Ch | 0;
        Dl = Cl | 0;
        Ch = Bh | 0;
        Cl = Bl | 0;
        Bh = Ah | 0;
        Bl = Al | 0;
        const All = add3L(T1l, sigma0l, MAJl);
        Ah = add3H(All, T1h, sigma0h, MAJh);
        Al = All | 0;
      }
      ({ h: Ah, l: Al } = add(this.Ah | 0, this.Al | 0, Ah | 0, Al | 0));
      ({ h: Bh, l: Bl } = add(this.Bh | 0, this.Bl | 0, Bh | 0, Bl | 0));
      ({ h: Ch, l: Cl } = add(this.Ch | 0, this.Cl | 0, Ch | 0, Cl | 0));
      ({ h: Dh, l: Dl } = add(this.Dh | 0, this.Dl | 0, Dh | 0, Dl | 0));
      ({ h: Eh, l: El } = add(this.Eh | 0, this.El | 0, Eh | 0, El | 0));
      ({ h: Fh, l: Fl } = add(this.Fh | 0, this.Fl | 0, Fh | 0, Fl | 0));
      ({ h: Gh, l: Gl } = add(this.Gh | 0, this.Gl | 0, Gh | 0, Gl | 0));
      ({ h: Hh, l: Hl } = add(this.Hh | 0, this.Hl | 0, Hh | 0, Hl | 0));
      this.set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl);
    }
    roundClean() {
      clean(SHA512_W_H, SHA512_W_L);
    }
    destroy() {
      this.destroyed = true;
      clean(this.buffer);
      this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
  }
  class _SHA512 extends SHA2_64B {
    constructor() {
      super(64, SHA512_IV);
    }
  }
  const sha512 = /* @__PURE__ */ createHasher(
    () => new _SHA512(),
    /* @__PURE__ */ oidNist(3)
  );
  function aarray(item, title, inner = () => {
  }) {
    if (!Array.isArray(item))
      throw new TypeError(`"${title}" expected array, got type=${typeof item}`);
    for (let i = 0; i < item.length; i++)
      inner(item[i], `${title}[${i}]`);
    return item;
  }
  const abytes$1 = (value, length, title) => abytes$2(value, length, title);
  const anumber$1 = anumber$2;
  function aobject(value, title = "object") {
    if (value === null || typeof value !== "object" || Array.isArray(value))
      throw new TypeError(title === "object" ? "expected valid options object" : `"${title}" expected object, got type=${typeof value}`);
    return value;
  }
  function afunction(value, title) {
    if (typeof value !== "function")
      throw new TypeError(`"${title}" is invalid: expected function, got ${typeof value}`);
    return value;
  }
  const bytesToHex = bytesToHex$1;
  const concatBytes = (...arrays) => concatBytes$1(...arrays);
  const hexToBytes = (hex) => hexToBytes$1(hex);
  const isBytes$1 = isBytes$2;
  const randomBytes = (bytesLength) => randomBytes$1(bytesLength);
  const _0n$3 = /* @__PURE__ */ BigInt(0);
  const _1n$4 = /* @__PURE__ */ BigInt(1);
  const atitle = (title) => title ? `"${title}" ` : "";
  function abool(value, title = "") {
    if (typeof value !== "boolean")
      throw new TypeError(atitle(title) + "expected boolean, got type=" + typeof value);
    return value;
  }
  function abignumber(n) {
    if (typeof n === "bigint") {
      if (!isPosBig(n))
        throw new RangeError("positive bigint expected, got " + n);
    } else
      anumber$1(n);
    return n;
  }
  function asafenumber(value, title = "") {
    if (typeof value !== "number") {
      const prefix = title && `"${title}" `;
      throw new TypeError(prefix + "expected number, got type=" + typeof value);
    }
    if (!Number.isSafeInteger(value)) {
      const prefix = title && `"${title}" `;
      throw new RangeError(prefix + "expected safe integer, got " + value);
    }
  }
  function hexToNumber(hex) {
    if (typeof hex !== "string")
      throw new TypeError("hex string expected, got " + typeof hex);
    return hex === "" ? _0n$3 : BigInt("0x" + hex);
  }
  function bytesToNumberBE(bytes) {
    return hexToNumber(bytesToHex$1(bytes));
  }
  function bytesToNumberLE(bytes) {
    return hexToNumber(bytesToHex$1(copyBytes(abytes$2(bytes)).reverse()));
  }
  function numberToBytesBE(n, len) {
    anumber$2(len);
    if (len === 0)
      throw new Error("zero output length is invalid");
    n = abignumber(n);
    const expectedLen = len * 2;
    const hex = n.toString(16);
    if (hex.length > expectedLen)
      throw new RangeError("number is too large");
    return hexToBytes$1(hex.padStart(expectedLen, "0"));
  }
  function numberToBytesLE(n, len) {
    return numberToBytesBE(n, len).reverse();
  }
  function copyBytes(bytes) {
    return Uint8Array.from(abytes$1(bytes));
  }
  function isPosBig(n) {
    return typeof n === "bigint" && _0n$3 <= n;
  }
  function inRange(n, min, max) {
    return isPosBig(n) && isPosBig(min) && isPosBig(max) && min <= n && n < max;
  }
  function aInRange(title, n, min, max) {
    if (!inRange(n, min, max))
      throw new RangeError("expected valid " + title + ": " + min + " <= n < " + max + ", got " + n);
  }
  function bitLen(n) {
    if (n < _0n$3)
      throw new Error("expected non-negative bigint, got " + n);
    return n === _0n$3 ? 0 : n.toString(2).length;
  }
  const bitMask = (n) => {
    asafenumber(n, "n");
    return (_1n$4 << BigInt(n)) - _1n$4;
  };
  function validateObject(object2, fields = {}, optFields = {}, title = "object") {
    aobject(object2, title);
    aobject(fields, "fields");
    aobject(optFields, "optFields");
    function checkField(fieldName, expectedType, isOpt) {
      const label = title === "object" ? `param "${String(fieldName)}"` : `"${title}.${String(fieldName)}"`;
      const val = object2[fieldName];
      if (!Object.hasOwn(object2, fieldName) && (isOpt ? val !== void 0 : expectedType !== "function")) {
        throw new TypeError(`${label} is invalid: expected own property`);
      }
      if (isOpt && val === void 0)
        return;
      const current = typeof val;
      if (current !== expectedType || val === null)
        throw new TypeError(`${label} is invalid: expected ${expectedType}, got ${current}`);
    }
    const iter = (f, isOpt) => Object.entries(f).forEach(([k, v]) => checkField(k, v, isOpt));
    iter(fields, false);
    iter(optFields, true);
  }
  const _0n$2 = /* @__PURE__ */ BigInt(0), _1n$3 = /* @__PURE__ */ BigInt(1), _2n$2 = /* @__PURE__ */ BigInt(2);
  const _3n = /* @__PURE__ */ BigInt(3), _4n$2 = /* @__PURE__ */ BigInt(4), _5n$1 = /* @__PURE__ */ BigInt(5);
  const _7n = /* @__PURE__ */ BigInt(7), _8n$2 = /* @__PURE__ */ BigInt(8), _9n = /* @__PURE__ */ BigInt(9);
  const _15n = /* @__PURE__ */ BigInt(15), _16n = /* @__PURE__ */ BigInt(16);
  const POW_WINDOWED_MIN = /* @__PURE__ */ BigInt("0x10000000000000000");
  function mod(a, b) {
    if (b <= _0n$2)
      throw new Error("mod: expected positive modulus, got " + b);
    const result = a % b;
    return result >= _0n$2 ? result : b + result;
  }
  function pow(num, power, modulo) {
    if (modulo <= _1n$3)
      throw new Error("pow: expected modulus > 1, got " + modulo);
    if (typeof power !== "bigint")
      throw new TypeError("invalid exponent: expected bigint, got " + typeof power);
    if (power < _0n$2)
      throw new Error("invalid exponent, negatives unsupported");
    if (power === _0n$2)
      return _1n$3;
    if (power === _1n$3)
      return num;
    let d = num % modulo;
    if (d < _0n$2)
      d += modulo;
    if (power < POW_WINDOWED_MIN) {
      let p2 = _1n$3;
      while (power > _0n$2) {
        if (power & _1n$3)
          p2 = p2 * d % modulo;
        d = d * d % modulo;
        power >>= _1n$3;
      }
      return p2;
    }
    const digits = [];
    while (power > _0n$2) {
      digits.push(Number(power & _15n));
      power >>= _4n$2;
    }
    const table = new Array(16);
    table[0] = _1n$3;
    table[1] = d;
    for (let i = 2; i < 16; i++)
      table[i] = table[i - 1] * d % modulo;
    let p = table[digits[digits.length - 1]];
    for (let w = digits.length - 2; w >= 0; w--) {
      p = p * p % modulo;
      p = p * p % modulo;
      p = p * p % modulo;
      p = p * p % modulo;
      const digit = digits[w];
      if (digit !== 0)
        p = p * table[digit] % modulo;
    }
    return p;
  }
  function pow2(x, power, modulo) {
    if (modulo <= _1n$3)
      throw new Error("pow2: expected modulus > 1, got " + modulo);
    if (power < _0n$2)
      throw new Error("pow2: expected non-negative exponent, got " + power);
    let res = x;
    while (power-- > _0n$2) {
      res *= res;
      res %= modulo;
    }
    return res;
  }
  function invert(number2, modulo) {
    if (number2 === _0n$2)
      throw new Error("invert: expected non-zero number");
    if (modulo <= _1n$3)
      throw new Error("invert: expected modulus > 1, got " + modulo);
    let a = mod(number2, modulo);
    let b = modulo;
    let x = _0n$2, u = _1n$3;
    while (a !== _0n$2) {
      const q = b / a;
      const r = b - a * q;
      const m = x - u * q;
      b = a, a = r, x = u, u = m;
    }
    const gcd = b;
    if (gcd !== _1n$3)
      throw new Error("invert: does not exist");
    return mod(x, modulo);
  }
  function assertIsSquare(Fp2, root, n) {
    const F = Fp2;
    if (!F.eql(F.sqr(root), n))
      throw new Error("Cannot find square root");
  }
  function aoddModulus(order, fnName) {
    if ((order & _1n$3) === _0n$2)
      throw new Error(fnName + ": expected odd modulus, got " + order);
  }
  function sqrt3mod4(Fp2, n) {
    const F = Fp2;
    const p1div4 = (F.ORDER + _1n$3) / _4n$2;
    const root = F.pow(n, p1div4);
    assertIsSquare(F, root, n);
    return root;
  }
  function sqrt5mod8(Fp2, n) {
    const F = Fp2;
    const p5div8 = (F.ORDER - _5n$1) / _8n$2;
    const n2 = F.mul(n, _2n$2);
    const v = F.pow(n2, p5div8);
    const nv = F.mul(n, v);
    const i = F.mul(F.mul(nv, _2n$2), v);
    const root = F.mul(nv, F.sub(i, F.ONE));
    assertIsSquare(F, root, n);
    return root;
  }
  function sqrt9mod16(P) {
    const Fp_ = Field(P);
    const tn = tonelliShanks(P);
    const c1 = tn(Fp_, Fp_.neg(Fp_.ONE));
    const c2 = tn(Fp_, c1);
    const c3 = tn(Fp_, Fp_.neg(c1));
    const c4 = (P + _7n) / _16n;
    return ((Fp2, n) => {
      const F = Fp2;
      let tv1 = F.pow(n, c4);
      let tv2 = F.mul(tv1, c1);
      const tv3 = F.mul(tv1, c2);
      const tv4 = F.mul(tv1, c3);
      const e1 = F.eql(F.sqr(tv2), n);
      const e2 = F.eql(F.sqr(tv3), n);
      tv1 = F.cmov(tv1, tv2, e1);
      tv2 = F.cmov(tv4, tv3, e2);
      const e3 = F.eql(F.sqr(tv2), n);
      const root = F.cmov(tv1, tv2, e3);
      assertIsSquare(F, root, n);
      return root;
    });
  }
  function tonelliShanks(P) {
    if (P < _3n)
      throw new Error("sqrt is not defined for small field");
    aoddModulus(P, "tonelliShanks");
    let Q = P - _1n$3;
    let S = 0;
    while (Q % _2n$2 === _0n$2) {
      Q /= _2n$2;
      S++;
    }
    let Z = _2n$2;
    const _Fp = Field(P);
    while (FpLegendre(_Fp, Z) === 1) {
      if (Z++ > 1e3)
        throw new Error("Cannot find square root: probably non-prime P");
    }
    if (S === 1)
      return sqrt3mod4;
    let cc = _Fp.pow(Z, Q);
    const Q1div2 = (Q + _1n$3) / _2n$2;
    return function tonelliSlow(Fp2, n) {
      const F = Fp2;
      if (F.is0(n))
        return n;
      if (FpLegendre(F, n) !== 1)
        throw new Error("Cannot find square root");
      let M = S;
      let c = F.mul(F.ONE, cc);
      let t = F.pow(n, Q);
      let R = F.pow(n, Q1div2);
      while (!F.eql(t, F.ONE)) {
        if (F.is0(t))
          throw new Error("Cannot find square root: probably non-prime P");
        let i = 1;
        let t_tmp = F.sqr(t);
        while (!F.eql(t_tmp, F.ONE)) {
          i++;
          t_tmp = F.sqr(t_tmp);
          if (i === M)
            throw new Error("Cannot find square root");
        }
        const exponent = _1n$3 << BigInt(M - i - 1);
        const b = F.pow(c, exponent);
        M = i;
        c = F.sqr(b);
        t = F.mul(t, c);
        R = F.mul(R, b);
      }
      return R;
    };
  }
  function FpSqrt(P) {
    aoddModulus(P, "Fp.sqrt");
    if (P % _4n$2 === _3n)
      return sqrt3mod4;
    if (P % _8n$2 === _5n$1)
      return sqrt5mod8;
    if (P % _16n === _9n)
      return sqrt9mod16(P);
    return tonelliShanks(P);
  }
  const isNegativeLE = (num, modulo) => (mod(num, modulo) & _1n$3) === _1n$3;
  const FIELD_FIELDS = [
    "create",
    "isValid",
    "is0",
    "neg",
    "inv",
    "sqrt",
    "sqr",
    "eql",
    "add",
    "sub",
    "mul",
    "pow",
    "div",
    "addN",
    "subN",
    "mulN",
    "sqrN"
  ];
  function validateField(field) {
    aobject(field, "field");
    if (typeof field.ORDER !== "bigint")
      throw new TypeError('param "ORDER" is invalid: expected bigint, got ' + typeof field.ORDER);
    asafenumber(field.BYTES, "BYTES");
    asafenumber(field.BITS, "BITS");
    for (const name of FIELD_FIELDS)
      afunction(field[name], "field." + name);
    if (field.BYTES < 1 || field.BITS < 1)
      throw new Error("invalid field: expected BYTES/BITS > 0");
    if (field.ORDER <= _1n$3)
      throw new Error("invalid field: expected ORDER > 1, got " + field.ORDER);
    return field;
  }
  function FpInvertBatch(Fp2, nums, passZero = false) {
    validateField(Fp2);
    aarray(nums, "nums");
    abool(passZero, "passZero");
    const F = Fp2;
    const inverted = new Array(nums.length).fill(passZero ? F.ZERO : void 0);
    const multipliedAcc = nums.reduce((acc, num, i) => {
      if (F.is0(num))
        return acc;
      inverted[i] = acc;
      return F.mul(acc, num);
    }, F.ONE);
    const invertedAcc = F.inv(multipliedAcc);
    nums.reduceRight((acc, num, i) => {
      if (F.is0(num))
        return acc;
      inverted[i] = F.mul(acc, inverted[i]);
      return F.mul(acc, num);
    }, invertedAcc);
    return inverted;
  }
  function FpLegendre(Fp2, n) {
    validateField(Fp2);
    const F = Fp2;
    aoddModulus(F.ORDER, "FpLegendre");
    const p1mod2 = (F.ORDER - _1n$3) / _2n$2;
    const powered = F.pow(n, p1mod2);
    const yes = F.eql(powered, F.ONE);
    const zero = F.eql(powered, F.ZERO);
    const no = F.eql(powered, F.neg(F.ONE));
    if (!yes && !zero && !no)
      throw new Error("invalid Legendre symbol result");
    return yes ? 1 : zero ? 0 : -1;
  }
  function nLength(n, nBitLength) {
    if (nBitLength !== void 0)
      anumber$1(nBitLength);
    if (n <= _0n$2)
      throw new Error("invalid n length: expected positive n, got " + n);
    if (nBitLength !== void 0 && nBitLength < 1)
      throw new Error("invalid n length: expected positive bit length, got " + nBitLength);
    const bits = bitLen(n);
    if (nBitLength !== void 0 && nBitLength < bits)
      throw new Error(`invalid n length: expected nBitLength (${nBitLength}) >= bitLen(n) (${bits})`);
    const _nBitLength = nBitLength !== void 0 ? nBitLength : bits;
    const nByteLength = Math.ceil(_nBitLength / 8);
    return { nBitLength: _nBitLength, nByteLength };
  }
  const FIELD_SQRT = /* @__PURE__ */ new WeakMap();
  class _Field {
    ORDER;
    BITS;
    BYTES;
    isLE;
    ZERO = _0n$2;
    ONE = _1n$3;
    _lengths;
    _mod;
    constructor(ORDER, opts = {}) {
      if (ORDER <= _1n$3)
        throw new Error("invalid field: expected ORDER > 1, got " + ORDER);
      let _nbitLength = void 0;
      this.isLE = false;
      if (opts != null && typeof opts === "object") {
        if (typeof opts.BITS === "number")
          _nbitLength = opts.BITS;
        if (typeof opts.sqrt === "function")
          Object.defineProperty(this, "sqrt", { value: opts.sqrt, enumerable: true });
        if (typeof opts.isLE === "boolean")
          this.isLE = opts.isLE;
        if (opts.allowedLengths)
          this._lengths = Object.freeze(opts.allowedLengths.slice());
        if (typeof opts.modFromBytes === "boolean")
          this._mod = opts.modFromBytes;
      }
      const { nBitLength, nByteLength } = nLength(ORDER, _nbitLength);
      if (nByteLength > 2048)
        throw new Error("invalid field: expected ORDER of <= 2048 bytes");
      this.ORDER = ORDER;
      this.BITS = nBitLength;
      this.BYTES = nByteLength;
      Object.freeze(this);
    }
    create(num) {
      return mod(num, this.ORDER);
    }
    isValid(num) {
      if (typeof num !== "bigint")
        throw new TypeError("invalid field element: expected bigint, got " + typeof num);
      return _0n$2 <= num && num < this.ORDER;
    }
    is0(num) {
      return num === _0n$2;
    }
    // is valid and invertible
    isValidNot0(num) {
      return !this.is0(num) && this.isValid(num);
    }
    isOdd(num) {
      return (num & _1n$3) === _1n$3;
    }
    neg(num) {
      return mod(-num, this.ORDER);
    }
    eql(lhs, rhs) {
      return lhs === rhs;
    }
    sqr(num) {
      return mod(num * num, this.ORDER);
    }
    add(lhs, rhs) {
      return mod(lhs + rhs, this.ORDER);
    }
    sub(lhs, rhs) {
      return mod(lhs - rhs, this.ORDER);
    }
    mul(lhs, rhs) {
      return mod(lhs * rhs, this.ORDER);
    }
    pow(num, power) {
      return pow(num, power, this.ORDER);
    }
    div(lhs, rhs) {
      return mod(lhs * invert(rhs, this.ORDER), this.ORDER);
    }
    // Same as above, but doesn't normalize
    sqrN(num) {
      return num * num;
    }
    addN(lhs, rhs) {
      return lhs + rhs;
    }
    subN(lhs, rhs) {
      return lhs - rhs;
    }
    mulN(lhs, rhs) {
      return lhs * rhs;
    }
    inv(num) {
      return invert(num, this.ORDER);
    }
    sqrt(num) {
      let sqrt = FIELD_SQRT.get(this);
      if (!sqrt)
        FIELD_SQRT.set(this, sqrt = FpSqrt(this.ORDER));
      return sqrt(this, num);
    }
    toBytes(num) {
      return this.isLE ? numberToBytesLE(num, this.BYTES) : numberToBytesBE(num, this.BYTES);
    }
    fromBytes(bytes, skipValidation = false) {
      abytes$1(bytes);
      const { _lengths: allowedLengths, BYTES, isLE: isLE2, ORDER, _mod: modFromBytes } = this;
      if (allowedLengths) {
        if (bytes.length < 1 || !allowedLengths.includes(bytes.length) || bytes.length > BYTES) {
          throw new Error("Field.fromBytes: expected " + allowedLengths + " bytes, got " + bytes.length);
        }
        const padded = new Uint8Array(BYTES);
        padded.set(bytes, isLE2 ? 0 : padded.length - bytes.length);
        bytes = padded;
      }
      if (bytes.length !== BYTES)
        throw new Error("Field.fromBytes: expected " + BYTES + " bytes, got " + bytes.length);
      let scalar = isLE2 ? bytesToNumberLE(bytes) : bytesToNumberBE(bytes);
      if (modFromBytes)
        scalar = mod(scalar, ORDER);
      if (!skipValidation) {
        if (!this.isValid(scalar))
          throw new Error("invalid field element: outside of range 0..ORDER");
      }
      return scalar;
    }
    // TODO: we don't need it here, move out to separate fn
    invertBatch(lst) {
      return FpInvertBatch(this, lst, true);
    }
    // We can't move this out because Fp6, Fp12 implement it
    // and it's unclear what to return in there.
    cmov(a, b, condition) {
      abool(condition, "condition");
      return condition ? b : a;
    }
  }
  function Field(ORDER, opts = {}) {
    Object.freeze(_Field.prototype);
    return new _Field(ORDER, opts);
  }
  const _0n$1 = /* @__PURE__ */ BigInt(0);
  const _1n$2 = /* @__PURE__ */ BigInt(1);
  const _4n$1 = /* @__PURE__ */ BigInt(4);
  const BLIND_BYTES = 16;
  const BLIND_BITS = 128;
  const FW_WINDOW = 5;
  const TABLE_BYTES_MAX = /* @__PURE__ */ (() => 2 ** 31)();
  function validatePointCons(Point) {
    const pc = Point;
    if (typeof pc !== "function")
      throw new TypeError('"Point" expected constructor, got type=' + typeof Point);
    afunction(pc.fromAffine, "Point.fromAffine");
    afunction(pc.fromBytes, "Point.fromBytes");
    afunction(pc.fromHex, "Point.fromHex");
    aobject(pc.BASE, "Point.BASE");
    aobject(pc.ZERO, "Point.ZERO");
    validateField(pc.Fp);
    validateField(pc.Fn);
  }
  function normalizeZ(c, points) {
    validatePointCons(c);
    validateMSMPoints(points, c);
    const invertedZs = FpInvertBatch(c.Fp, points.map((p) => p.Z));
    return points.map((p, i) => c.fromAffine(p.toAffine(invertedZs[i])));
  }
  function validateW(W, bits, min = 1) {
    if (!Number.isSafeInteger(W) || W < min || W > bits)
      throw new Error("invalid window size, expected [" + min + ".." + bits + "], got W=" + W);
  }
  function validateTableBytes(numPoints, fpBytes) {
    const bytes = numPoints * (4 * fpBytes + 128);
    if (bytes > TABLE_BYTES_MAX)
      throw new Error("invalid window size: table would need ~" + Math.ceil(bytes / 2 ** 20) + " MiB, max " + TABLE_BYTES_MAX / 2 ** 20 + " MiB");
  }
  function probeRandomBytes(randomBytes2, length) {
    if (randomBytes2 === void 0)
      return void 0;
    afunction(randomBytes2, "randomBytes");
    try {
      const probe = randomBytes2(length);
      if (!isBytes$1(probe) || probe.length !== length)
        return void 0;
    } catch {
      return void 0;
    }
    return randomBytes2;
  }
  function validateMSMPoints(points, c) {
    aarray(points, "points");
    points.forEach((p, i) => {
      if (!(p instanceof c))
        throw new Error("invalid point at index " + i);
    });
  }
  function validateMSMScalars(scalars, field, maxScalar) {
    if (!Array.isArray(scalars))
      throw new Error("array of scalars expected");
    scalars.forEach((s, i) => {
      const ok = maxScalar === void 0 ? field.isValid(s) : isPosBig(s) && s < maxScalar;
      if (!ok)
        throw new Error("invalid scalar at index " + i);
    });
  }
  const pointWindowSizes = /* @__PURE__ */ new WeakMap();
  function getWindowSize(P) {
    return pointWindowSizes.get(P) || 1;
  }
  function oddMultiples(p, size) {
    const dbl = p.double();
    const t = [p];
    for (let j = 1; j < size; j++)
      t.push(t[j - 1].add(dbl));
    return t;
  }
  function wnafDigits(n, W) {
    const size = 2 ** W;
    const half = size / 2;
    const mask = BigInt(size - 1);
    const d = [];
    while (n > _0n$1) {
      let w = 0;
      if (n & _1n$2) {
        w = Number(n & mask);
        if (w >= half)
          w -= size;
        n -= BigInt(w);
      }
      d.push(w);
      n >>= _1n$2;
    }
    return d;
  }
  function signedWindowDigits(n, W, windows) {
    const size = 2 ** W;
    const half = size / 2;
    const mask = BigInt(size - 1);
    const shiftBy = BigInt(W);
    const d = [];
    for (let w = 0; w < windows; w++) {
      let v = Number(n & mask);
      n >>= shiftBy;
      if (v > half) {
        v -= size;
        n += _1n$2;
      }
      d.push(v);
    }
    if (n !== _0n$1)
      throw new Error("invalid wnaf");
    return d;
  }
  function wnafWalk(zero, tables, digits) {
    let max = 0;
    for (const d of digits)
      max = Math.max(max, d.length);
    let acc = zero;
    for (let bit = max - 1; bit >= 0; bit--) {
      if (bit !== max - 1)
        acc = acc.double();
      for (let i = 0; i < digits.length; i++) {
        const w = digits[i][bit];
        if (w) {
          const item = tables[i][Math.abs(w) - 1 >> 1];
          acc = acc.add(w < 0 ? item.negate() : item);
        }
      }
    }
    return acc;
  }
  class ScalarMultiplier {
    Point;
    BASE;
    ZERO;
    randomBytes;
    wnafPrecomputes = /* @__PURE__ */ new WeakMap();
    baseCanBeBlinded;
    bits;
    // Parametrized with a given Point class (not individual point)
    constructor(Point, randomBytes2) {
      validatePointCons(Point);
      this.randomBytes = probeRandomBytes(randomBytes2, BLIND_BYTES);
      this.Point = Point;
      this.BASE = Point.BASE;
      this.ZERO = Point.ZERO;
      this.bits = Point.Fn.BITS;
    }
    /**
     * Creates a signed fixed-window wNAF precomputation table: for every window w, the
     * multiples `[1..2^(W−1)]⋅2^(w⋅W)⋅P`, flattened. All doublings are baked into the table,
     * so cached multiplication is additions-only. `windows = ceil(bits/W) + 1`: the extra
     * window absorbs the final carry of signed-digit recoding.
     * For a 256-bit curve and W=6, the table is 44⋅32 = 1408 points.
     * @param point - Point instance
     * @param W - window size
     * @param bits - scalar bitlength the table must cover
     */
    buildWnafTable(point, W, bits) {
      const windows = Math.ceil(bits / W) + 1;
      const half = 2 ** (W - 1);
      const comp = [];
      let base = point;
      for (let w = 0; w < windows; w++) {
        let acc = base;
        for (let i = 0; i < half; i++) {
          comp.push(acc);
          acc = acc.add(base);
        }
        base = comp[comp.length - 1].double();
      }
      return { W, bits, windows, comp };
    }
    /**
     * Implements ec multiplication using precomputed signed fixed-window wNAF tables.
     * Constant-time: fixed window count with one table addition per window — zero digits feed
     * the fake accumulator — and no doublings; the lookup scans the whole window slice.
     * Scalar bounds are validated by the public entry points ({@link ScalarMultiplier.mulCT},
     * {@link ScalarMultiplier.mulCTBlinded}, {@link ScalarMultiplier.mulUnsafe});
     * signedWindowDigits throws if `n` exceeds the table.
     * @returns real and fake (for const-time) points
     */
    wnafCachedCT(precomputes, n) {
      const { W, windows, comp } = precomputes;
      const half = 2 ** (W - 1);
      const digits = signedWindowDigits(n, W, windows);
      let p = this.ZERO;
      let f = this.BASE;
      for (let w = 0; w < windows; w++) {
        const digit = digits[w];
        const start = w * half;
        const idx = Math.abs(digit) - 1;
        let sel = comp[start];
        for (let i = 1; i < half; i++)
          sel = i === idx ? comp[start + i] : sel;
        const neg = sel.negate();
        if (digit === 0)
          f = f.add(comp[start]);
        else
          p = p.add(digit < 0 ? neg : sel);
      }
      return { p, f };
    }
    // Cache key is point identity plus (W, bits); at most two entries exist per point (public-width
    // `Fn.BITS` and blinded `Fn.BITS + BLIND_BITS`). Callers must not reuse the same point with
    // incompatible `transform(...)` layouts and expect a separate cache entry.
    getWnafPrecomputes(W, point, bits, transform2) {
      let entries = this.wnafPrecomputes.get(point);
      let comp = entries?.find((entry) => entry.W === W && entry.bits === bits);
      if (!comp) {
        comp = this.buildWnafTable(point, W, bits);
        if (typeof transform2 === "function")
          comp = { ...comp, comp: transform2(comp.comp) };
        if (!entries) {
          entries = [];
          this.wnafPrecomputes.set(point, entries);
        }
        entries.push(comp);
      }
      return comp;
    }
    assertPoint(point) {
      if (!(point instanceof this.Point))
        throw new TypeError('"point" expected Point instance, got type=' + typeof point);
    }
    // Shared prologue of the constant-time entry points. Rejects scalar 0: in key/signature-style
    // callers a zero scalar means broken upstream plumbing, and concrete Points already reject it.
    // Uses inRange instead of Fn.isValidNot0: validateField() only certifies the arithmetic subset.
    validateMulInput(point, scalar) {
      this.assertPoint(point);
      if (!inRange(scalar, _1n$2, this.Point.Fn.ORDER))
        throw new Error("invalid scalar");
    }
    // Constant-time dispatch shared by mulCT / mulCTBlinded. Un-precomputed points (W===1, e.g.
    // ECDH peer keys) skip building a throwaway cached table in favor of a small fixed-window
    // multiply. `n` must be < 2^bits.
    runCT(point, n, bits, transform2) {
      const W = getWindowSize(point);
      if (W === 1)
        return this.fixedWindowCT(point, n, bits);
      return this.wnafCachedCT(this.getWnafPrecomputes(W, point, bits, transform2), n);
    }
    mulCT(point, scalar, transform2) {
      this.validateMulInput(point, scalar);
      return this.runCT(point, scalar, this.bits, transform2);
    }
    mulCTBlinded(point, scalar, transform2) {
      this.validateMulInput(point, scalar);
      if (this.randomBytes === void 0)
        throw new Error("randomBytes is required for scalar blinding");
      const bits = this.Point.Fn.BITS + BLIND_BITS;
      const blind = this.randomBytes(BLIND_BYTES);
      if (!isBytes$1(blind) || blind.length !== BLIND_BYTES)
        throw new Error("randomBytes returned invalid byte array");
      blind[0] = blind[0] & 63 | 128;
      const n = scalar + bytesToNumberBE(blind) * this.Point.Fn.ORDER;
      return this.runCT(point, n, bits, transform2);
    }
    /**
     * Constant-time multiplication `n*point` for an un-precomputed point, via a small fixed window.
     * A cached wNAF table only pays off when reused; a flat 2^FW_WINDOW table (`size-1` adds) is
     * far cheaper to build for a single use. The point-operation sequence is independent of `n`:
     * build the table, then per window exactly FW_WINDOW doublings, a data-oblivious scan over
     * every table entry, and one addition (adds the identity when the window digit is 0 — never
     * skipped).
     *
     * `n` must be `< 2^bits`. Assumes complete addition (adding the identity costs the same as any
     * add), which holds for the Weierstrass/Edwards point types used here. The table is left in
     * projective form (no normalizeZ): normalizing this small a table costs more than the
     * mixed-add savings it would buy for a single multiply.
     * @returns real point `p`; `f` duplicates it only to match {@link wnafCachedCT}'s return shape
     * (this path needs no fake accumulator — its op-count is already scalar-independent).
     */
    fixedWindowCT(point, n, bits) {
      const W = FW_WINDOW;
      const size = 1 << W;
      const mask = bitMask(W);
      const table = new Array(size);
      table[0] = this.ZERO;
      for (let i = 1; i < size; i++)
        table[i] = table[i - 1].add(point);
      const windows = Math.ceil(bits / W);
      let acc = this.ZERO;
      for (let window = windows - 1; window >= 0; window--) {
        if (window !== windows - 1)
          for (let d = 0; d < W; d++)
            acc = acc.double();
        const digit = Number(n >> BigInt(window * W) & mask);
        let sel = table[0];
        for (let i = 1; i < size; i++)
          sel = i === digit ? table[i] : sel;
        acc = acc.add(sel);
      }
      return { p: acc, f: acc };
    }
    shouldBlind(point, cofactor) {
      if (this.randomBytes === void 0)
        return false;
      if (cofactor === _1n$2)
        return true;
      if (point !== this.BASE)
        return false;
      if (this.baseCanBeBlinded === void 0)
        this.baseCanBeBlinded = this.mulUnsafe(this.BASE, this.Point.Fn.ORDER).is0();
      return this.baseCanBeBlinded;
    }
    mulSecret(point, scalar, cofactor, transform2) {
      return this.shouldBlind(point, cofactor) ? this.mulCTBlinded(point, scalar, transform2) : this.mulCT(point, scalar, transform2);
    }
    mulUnsafe(point, scalar, transform2) {
      this.assertPoint(point);
      if (!isPosBig(scalar))
        throw new Error("invalid scalar");
      const W = getWindowSize(point);
      if (W === 1 || scalar >= this.Point.Fn.ORDER)
        return mulAddUnsafe(this.Point, [point], [scalar], true);
      const precomputes = this.getWnafPrecomputes(W, point, this.bits, transform2);
      return this.wnafCachedCT(precomputes, scalar).p;
    }
    // Remembers the window size used for precomputed wNAF multiplication of the given point
    // and drops any previously built tables. Usually only the base point is precomputed.
    // W=1 resets the point to the un-precomputed (table-less) paths.
    // W is additionally capped so tables stay under ~2 GiB ({@link TABLE_BYTES_MAX}).
    setWindowSize(point, W) {
      this.assertPoint(point);
      validateW(W, this.bits);
      const windows = Math.ceil((this.bits + BLIND_BITS) / W) + 1;
      validateTableBytes(windows * 2 ** (W - 1), this.Point.Fp.BYTES);
      pointWindowSizes.set(point, W);
      this.wnafPrecomputes.delete(point);
    }
    // True when a window size is set: tables themselves are built lazily on first multiply.
    hasWindowSize(point) {
      return getWindowSize(point) !== 1;
    }
  }
  function mulAddUnsafe(c, points, scalars, allowOversized = false) {
    validatePointCons(c);
    validateMSMPoints(points, c);
    abool(allowOversized, "allowOversized");
    validateMSMScalars(scalars, c.Fn, allowOversized ? c.Fn.ORDER ** _4n$1 : void 0);
    if (points.length !== scalars.length)
      throw new Error("arrays of points and scalars must have equal length");
    const tables = points.map((p) => oddMultiples(p, 4));
    const digits = scalars.map((n) => wnafDigits(n, 4));
    return wnafWalk(c.ZERO, tables, digits);
  }
  function createField(order, field, isLE2) {
    if (field) {
      if (field.ORDER !== order)
        throw new Error("Field.ORDER must match order: Fp == p, Fn == n");
      validateField(field);
      return field;
    } else {
      return Field(order, { isLE: isLE2 });
    }
  }
  function createCurveFields(type, CURVE, curveOpts = {}, FpFnLE) {
    if (FpFnLE === void 0)
      FpFnLE = type === "edwards";
    if (!CURVE || typeof CURVE !== "object")
      throw new Error(`expected valid ${type} CURVE object`);
    validateObject(curveOpts);
    for (const p of ["p", "n", "h"]) {
      const val = CURVE[p];
      if (!(isPosBig(val) && val !== _0n$1))
        throw new Error(`CURVE.${p} must be positive bigint`);
    }
    const Fp2 = createField(CURVE.p, curveOpts.Fp, FpFnLE);
    const Fn = createField(CURVE.n, curveOpts.Fn, FpFnLE);
    const _b = "d";
    const params = ["Gx", "Gy", "a", _b];
    for (const p of params) {
      if (!Fp2.isValid(CURVE[p]))
        throw new Error(`CURVE.${p} must be valid field element of CURVE.Fp`);
    }
    CURVE = Object.freeze(Object.assign({}, CURVE));
    return { CURVE, Fp: Fp2, Fn };
  }
  function createKeygen(randomSecretKey, getPublicKey) {
    return function keygen(seed) {
      const secretKey = randomSecretKey(seed);
      return { secretKey, publicKey: getPublicKey(secretKey) };
    };
  }
  const _0n = /* @__PURE__ */ BigInt(0), _1n$1 = /* @__PURE__ */ BigInt(1), _2n$1 = /* @__PURE__ */ BigInt(2), _4n = /* @__PURE__ */ BigInt(4), _8n$1 = /* @__PURE__ */ BigInt(8);
  function isEdValidXY(Fp2, CURVE, x, y) {
    const x2 = Fp2.sqr(x);
    const y2 = Fp2.sqr(y);
    const left = Fp2.add(Fp2.mul(CURVE.a, x2), y2);
    const right = Fp2.add(Fp2.ONE, Fp2.mul(CURVE.d, Fp2.mul(x2, y2)));
    return Fp2.eql(left, right);
  }
  function edwards(params, extraOpts = {}) {
    validateObject(extraOpts, {}, {}, "extraOpts");
    const opts = extraOpts;
    const validated = createCurveFields("edwards", params, opts, opts.FpFnLE);
    const { Fp: Fp2, Fn } = validated;
    let CURVE = validated.CURVE;
    const { h: cofactor } = CURVE;
    if (FpLegendre(Fp2, CURVE.a) !== 1)
      throw new Error("edwards: CURVE.a must be a square in Fp for complete addition formulas");
    if (FpLegendre(Fp2, CURVE.d) !== -1)
      throw new Error("edwards: CURVE.d must be a non-square in Fp for complete addition formulas");
    validateObject(opts, {}, { uvRatio: "function", randomBytes: "function" });
    const randomBytes$12 = opts.randomBytes === void 0 ? randomBytes : opts.randomBytes;
    const MASK = _2n$1 << BigInt(Fp2.BYTES * 8) - _1n$1;
    function isOdd(n) {
      if (!Fp2.isOdd)
        throw new Error("Field does not have .isOdd()");
      return Fp2.isOdd(n);
    }
    const uvRatio2 = opts.uvRatio === void 0 ? (u, v) => {
      try {
        return { isValid: true, value: Fp2.sqrt(Fp2.div(u, v)) };
      } catch (e) {
        return { isValid: false, value: _0n };
      }
    } : opts.uvRatio;
    if (!isEdValidXY(Fp2, CURVE, CURVE.Gx, CURVE.Gy))
      throw new Error("bad curve params: generator point");
    const mulA = Fp2.eql(CURVE.a, Fp2.neg(Fp2.ONE)) ? (x) => Fp2.neg(x) : Fp2.eql(CURVE.a, Fp2.ONE) ? (x) => x : (x) => Fp2.mul(CURVE.a, x);
    function acoord(title, n, banZero = false) {
      const min = banZero ? _1n$1 : _0n;
      aInRange("coordinate " + title, n, min, MASK);
      return n;
    }
    function aedpoint(other) {
      if (!(other instanceof Point))
        throw new Error("EdwardsPoint expected");
    }
    class Point {
      static BASE = new Point(CURVE.Gx, CURVE.Gy, Fp2.ONE, Fp2.mul(CURVE.Gx, CURVE.Gy));
      static ZERO = new Point(Fp2.ZERO, Fp2.ONE, Fp2.ONE, Fp2.ZERO);
      static Fp = Fp2;
      static Fn = Fn;
      X;
      Y;
      Z;
      T;
      constructor(X, Y, Z, T) {
        this.X = acoord("x", X);
        this.Y = acoord("y", Y);
        this.Z = acoord("z", Z, true);
        this.T = acoord("t", T);
        Object.freeze(this);
      }
      static CURVE() {
        return CURVE;
      }
      /**
       * Create one extended Edwards point from affine coordinates.
       * Does NOT validate that the point is on-curve or torsion-free.
       * Use `.assertValidity()` on adversarial inputs.
       */
      static fromAffine(p) {
        if (p instanceof Point)
          throw new Error("extended point not allowed");
        const { x, y } = p || {};
        acoord("x", x);
        acoord("y", y);
        return new Point(x, y, Fp2.ONE, Fp2.mul(x, y));
      }
      // Uses algo from RFC8032 5.1.3.
      static fromBytes(bytes, zip215 = false) {
        const len = Fp2.BYTES;
        const { a, d } = CURVE;
        bytes = copyBytes(abytes$1(bytes, len, "point"));
        abool(zip215, "zip215");
        const normed = copyBytes(bytes);
        const lastByte = bytes[len - 1];
        normed[len - 1] = lastByte & -129;
        const y = bytesToNumberLE(normed);
        const max = zip215 ? MASK : Fp2.ORDER;
        aInRange("point.y", y, _0n, max);
        const y2 = Fp2.sqr(y);
        const u = Fp2.sub(y2, Fp2.ONE);
        const v = Fp2.sub(Fp2.mulN(d, y2), a);
        let { isValid, value: x } = uvRatio2(u, v);
        if (!isValid)
          throw new Error("bad point: invalid y coordinate");
        const isXOdd = isOdd(x);
        const isLastByteOdd = (lastByte & 128) !== 0;
        if (!zip215 && Fp2.is0(x) && isLastByteOdd)
          throw new Error("bad point: x=0 and x_0=1");
        if (isLastByteOdd !== isXOdd)
          x = Fp2.neg(x);
        return Point.fromAffine({ x, y });
      }
      static fromHex(hex, zip215 = false) {
        return Point.fromBytes(hexToBytes(hex), zip215);
      }
      get x() {
        return this.toAffine().x;
      }
      get y() {
        return this.toAffine().y;
      }
      precompute(windowSize = 6, isLazy = true) {
        wnaf.setWindowSize(this, windowSize);
        if (!isLazy)
          this.multiply(_2n$1);
        return this;
      }
      // Useful in fromAffine() - not for fromBytes(), which always created valid points.
      assertValidity() {
        const p = this;
        const { a, d } = CURVE;
        if (p.is0())
          throw new Error("bad point: ZERO");
        const { X, Y, Z, T } = p;
        const X2 = Fp2.sqr(X);
        const Y2 = Fp2.sqr(Y);
        const Z2 = Fp2.sqr(Z);
        const Z4 = Fp2.sqr(Z2);
        const aX2 = Fp2.mul(X2, a);
        const left = Fp2.mul(Fp2.add(aX2, Y2), Z2);
        const right = Fp2.add(Z4, Fp2.mul(d, Fp2.mul(X2, Y2)));
        if (!Fp2.eql(left, right))
          throw new Error("bad point: equation left != right (1)");
        const XY = Fp2.mul(X, Y);
        const ZT = Fp2.mul(Z, T);
        if (!Fp2.eql(XY, ZT))
          throw new Error("bad point: equation left != right (2)");
      }
      // Compare one point to another.
      equals(other) {
        aedpoint(other);
        const { X: X1, Y: Y1, Z: Z1 } = this;
        const { X: X2, Y: Y2, Z: Z2 } = other;
        const X1Z2 = Fp2.mul(X1, Z2);
        const X2Z1 = Fp2.mul(X2, Z1);
        const Y1Z2 = Fp2.mul(Y1, Z2);
        const Y2Z1 = Fp2.mul(Y2, Z1);
        return Fp2.eql(X1Z2, X2Z1) && Fp2.eql(Y1Z2, Y2Z1);
      }
      is0() {
        return this.equals(Point.ZERO);
      }
      negate() {
        return new Point(Fp2.neg(this.X), this.Y, this.Z, Fp2.neg(this.T));
      }
      // Fast algo for doubling Extended Point.
      // https://hyperelliptic.org/EFD/g1p/auto-twisted-extended.html#doubling-dbl-2008-hwcd
      // Cost: 4M + 4S + 1*a + 6add + 1*2.
      double() {
        const { X: X1, Y: Y1, Z: Z1 } = this;
        const A = Fp2.sqr(X1);
        const B = Fp2.sqr(Y1);
        const C = Fp2.mul(Fp2.sqr(Z1), _2n$1);
        const D = mulA(A);
        const x1y1 = Fp2.addN(X1, Y1);
        const E = Fp2.sub(Fp2.subN(Fp2.sqr(x1y1), A), B);
        const G = Fp2.addN(D, B);
        const F = Fp2.subN(G, C);
        const H = Fp2.subN(D, B);
        const X3 = Fp2.mul(E, F);
        const Y3 = Fp2.mul(G, H);
        const T3 = Fp2.mul(E, H);
        const Z3 = Fp2.mul(F, G);
        return new Point(X3, Y3, Z3, T3);
      }
      // Fast algo for adding 2 Extended Points.
      // https://hyperelliptic.org/EFD/g1p/auto-twisted-extended.html#addition-add-2008-hwcd
      // Cost: 9M + 1*a + 1*d + 7add.
      add(other) {
        aedpoint(other);
        const { d } = CURVE;
        const { X: X1, Y: Y1, Z: Z1, T: T1 } = this;
        const { X: X2, Y: Y2, Z: Z2, T: T2 } = other;
        const A = Fp2.mul(X1, X2);
        const B = Fp2.mul(Y1, Y2);
        const C = Fp2.mul(Fp2.mulN(T1, d), T2);
        const D = Fp2.mul(Z1, Z2);
        const E = Fp2.sub(Fp2.subN(Fp2.mulN(Fp2.addN(X1, Y1), Fp2.addN(X2, Y2)), A), B);
        const F = Fp2.subN(D, C);
        const G = Fp2.addN(D, C);
        const H = Fp2.sub(B, mulA(A));
        const X3 = Fp2.mul(E, F);
        const Y3 = Fp2.mul(G, H);
        const T3 = Fp2.mul(E, H);
        const Z3 = Fp2.mul(F, G);
        return new Point(X3, Y3, Z3, T3);
      }
      subtract(other) {
        aedpoint(other);
        return this.add(other.negate());
      }
      // Constant-time multiplication.
      multiply(scalar) {
        if (!Fn.isValidNot0(scalar))
          throw new RangeError("invalid scalar: expected 1 <= sc < curve.n");
        const { p, f } = wnaf.mulSecret(this, scalar, cofactor, normalize2);
        return normalize2([p, f])[0];
      }
      // Non-constant-time multiplication. Uses double-and-add algorithm.
      // It's faster, but should only be used when you don't care about
      // an exposed private key e.g. sig verification.
      // Keeps the same subgroup-scalar contract: 0 is allowed for public-scalar callers, but
      // n and larger values are rejected instead of being reduced mod n to the identity point.
      multiplyUnsafe(scalar) {
        if (!Fn.isValid(scalar))
          throw new RangeError("invalid scalar: expected 0 <= sc < curve.n");
        if (scalar === _0n)
          return Point.ZERO;
        if (this.is0() || scalar === _1n$1)
          return this;
        return wnaf.mulUnsafe(this, scalar, normalize2);
      }
      // Checks if point is of small order.
      // If you add something to small order point, you will have "dirty"
      // point with torsion component.
      // Clears cofactor and checks if the result is 0.
      isSmallOrder() {
        return this.clearCofactor().is0();
      }
      // Multiplies point by curve order and checks if the result is 0.
      // Returns `false` is the point is dirty.
      isTorsionFree() {
        return wnaf.mulUnsafe(this, CURVE.n).is0();
      }
      // Converts Extended point to default (x, y) coordinates.
      // Can accept precomputed Z^-1 - for example, from invertBatch.
      toAffine(invertedZ) {
        const p = this;
        let iz = invertedZ;
        if (iz != null && typeof iz !== "bigint")
          throw new TypeError('"invertedZ" expected bigint, got type=' + typeof iz);
        const { X, Y, Z } = p;
        const is0 = p.is0();
        if (iz == null)
          iz = is0 ? Fp2.create(_8n$1) : Fp2.inv(Z);
        const x = Fp2.mul(X, iz);
        const y = Fp2.mul(Y, iz);
        const zz = Fp2.mul(Z, iz);
        if (is0)
          return { x: Fp2.ZERO, y: Fp2.ONE };
        if (!Fp2.eql(zz, Fp2.ONE))
          throw new Error("invZ was invalid");
        return { x, y };
      }
      clearCofactor() {
        if (cofactor === _1n$1)
          return this;
        if (cofactor === _2n$1)
          return this.double();
        if (cofactor === _4n)
          return this.double().double();
        if (cofactor === _8n$1)
          return this.double().double().double();
        return this.multiplyUnsafe(cofactor);
      }
      toBytes() {
        const { x, y } = this.toAffine();
        const bytes = Fp2.toBytes(y);
        bytes[bytes.length - 1] |= isOdd(x) ? 128 : 0;
        return bytes;
      }
      toHex() {
        return bytesToHex(this.toBytes());
      }
      toString() {
        return `<Point ${this.is0() ? "ZERO" : this.toHex()}>`;
      }
    }
    const normalize2 = (points) => normalizeZ(Point, points);
    const wnaf = new ScalarMultiplier(Point, randomBytes$12);
    if (wnaf.bits >= 6)
      Point.BASE.precompute(6);
    Object.freeze(Point.prototype);
    Object.freeze(Point);
    return Point;
  }
  function eddsa(Point, cHash, eddsaOpts = {}) {
    validatePointCons(Point);
    if (typeof cHash !== "function")
      throw new Error('"hash" function param is required');
    const hash = cHash;
    const opts = eddsaOpts;
    validateObject(opts, {}, {
      adjustScalarBytes: "function",
      randomBytes: "function",
      domain: "function",
      prehash: "function",
      zip215: "boolean",
      mapToCurve: "function",
      toMontgomery: "function",
      toMontgomerySecret: "function"
    });
    const { prehash } = opts;
    const { BASE, Fp: Fp2, Fn } = Point;
    const outputLen = hash.outputLen;
    const expectedLen = 2 * Fp2.BYTES;
    if (outputLen !== void 0) {
      asafenumber(outputLen, "hash.outputLen");
      if (outputLen !== expectedLen)
        throw new Error(`hash.outputLen must be ${expectedLen}, got ${outputLen}`);
    }
    const randomBytes$12 = opts.randomBytes === void 0 ? randomBytes : opts.randomBytes;
    const toMontgomery2 = opts.toMontgomery;
    const toMontgomerySecret2 = opts.toMontgomerySecret;
    const adjustScalarBytes2 = opts.adjustScalarBytes === void 0 ? (bytes) => bytes : opts.adjustScalarBytes;
    const domain = opts.domain === void 0 ? (data, ctx, phflag) => {
      abool(phflag, "phflag");
      if (ctx.length || phflag)
        throw new Error("Contexts/pre-hash are not supported");
      return data;
    } : opts.domain;
    function modN_LE(hash2) {
      return Fn.create(bytesToNumberLE(hash2));
    }
    function getPrivateScalar(key) {
      const len = lengths.secretKey;
      abytes$1(key, lengths.secretKey, "secretKey");
      const hashed = abytes$1(hash(key), 2 * len, "hashedSecretKey");
      const head = adjustScalarBytes2(hashed.slice(0, len));
      const prefix = hashed.slice(len, 2 * len);
      const scalar = modN_LE(head);
      return { head, prefix, scalar };
    }
    function getExtendedPublicKey(secretKey) {
      const { head, prefix, scalar } = getPrivateScalar(secretKey);
      const point = BASE.multiply(scalar);
      const pointBytes = point.toBytes();
      return { head, prefix, scalar, point, pointBytes };
    }
    function getPublicKey(secretKey) {
      return getExtendedPublicKey(secretKey).pointBytes;
    }
    function hashDomainToScalar(context = Uint8Array.of(), ...msgs) {
      const msg = concatBytes(...msgs);
      return modN_LE(hash(domain(msg, abytes$1(context, void 0, "context"), !!prehash)));
    }
    function sign(msg, secretKey, options = {}) {
      validateObject(options, {}, {}, "options");
      msg = copyBytes(abytes$1(msg, void 0, "message"));
      if (prehash)
        msg = prehash(msg);
      const { prefix, scalar, pointBytes } = getExtendedPublicKey(secretKey);
      const r = hashDomainToScalar(options.context, prefix, msg);
      const R = BASE.multiply(r).toBytes();
      const k = hashDomainToScalar(options.context, R, pointBytes, msg);
      const s = Fn.create(r + k * scalar);
      if (!Fn.isValid(s))
        throw new Error("sign failed: invalid s");
      const rs = concatBytes(R, Fn.toBytes(s));
      return abytes$1(rs, lengths.signature, "result");
    }
    const verifyOpts = {
      zip215: opts.zip215
    };
    function verify(sig, msg, publicKey, options = verifyOpts) {
      validateObject(options);
      const { context } = options;
      const zip215 = options.zip215 === void 0 ? !!verifyOpts.zip215 : options.zip215;
      const len = lengths.signature;
      sig = abytes$1(sig, len, "signature");
      msg = abytes$1(msg, void 0, "message");
      publicKey = abytes$1(publicKey, lengths.publicKey, "publicKey");
      if (zip215 !== void 0)
        abool(zip215, "zip215");
      if (prehash)
        msg = prehash(msg);
      const mid = len / 2;
      const r = sig.subarray(0, mid);
      const s = bytesToNumberLE(sig.subarray(mid, len));
      let A, R, SB;
      try {
        A = Point.fromBytes(publicKey, zip215);
        R = Point.fromBytes(r, zip215);
        SB = BASE.multiplyUnsafe(s);
      } catch (error) {
        return false;
      }
      if (!zip215 && A.isSmallOrder())
        return false;
      const k = hashDomainToScalar(context, r, publicKey, msg);
      const RkA = R.add(A.multiplyUnsafe(k));
      return RkA.subtract(SB).clearCofactor().is0();
    }
    const _size = Fp2.BYTES;
    const lengths = {
      secretKey: _size,
      publicKey: _size,
      signature: 2 * _size,
      seed: _size
    };
    function randomSecretKey(seed) {
      seed = seed === void 0 ? randomBytes$12(lengths.seed) : seed;
      return abytes$1(seed, lengths.seed, "seed");
    }
    function isValidSecretKey(key) {
      return isBytes$1(key) && key.length === lengths.secretKey;
    }
    function isValidPublicKey(key, zip215) {
      try {
        return !!Point.fromBytes(key, zip215 === void 0 ? verifyOpts.zip215 : zip215);
      } catch (error) {
        return false;
      }
    }
    const utils = {
      getExtendedPublicKey,
      randomSecretKey,
      isValidSecretKey,
      isValidPublicKey,
      /** Converts an Edwards public key to a companion Montgomery public key. */
      toMontgomery(publicKey) {
        if (toMontgomery2 === void 0)
          throw new Error("Montgomery conversion is not supported for this curve");
        return toMontgomery2(Point.fromBytes(publicKey));
      },
      toMontgomerySecret(secretKey) {
        if (toMontgomerySecret2 === void 0)
          throw new Error("Montgomery conversion is not supported for this curve");
        return toMontgomerySecret2(secretKey);
      }
    };
    Object.freeze(lengths);
    Object.freeze(utils);
    return Object.freeze({
      keygen: createKeygen(randomSecretKey, getPublicKey),
      getPublicKey,
      sign,
      verify,
      utils,
      Point,
      lengths
    });
  }
  const _1n = /* @__PURE__ */ BigInt(1), _2n = /* @__PURE__ */ BigInt(2);
  const _5n = /* @__PURE__ */ BigInt(5), _8n = /* @__PURE__ */ BigInt(8);
  const ed25519_CURVE_p = /* @__PURE__ */ BigInt("0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffed");
  const ed25519_CURVE = /* @__PURE__ */ (() => ({
    p: ed25519_CURVE_p,
    n: BigInt("0x1000000000000000000000000000000014def9dea2f79cd65812631a5cf5d3ed"),
    h: _8n,
    a: BigInt("0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffec"),
    d: BigInt("0x52036cee2b6ffe738cc740797779e89800700a4d4141d8ab75eb4dca135978a3"),
    Gx: BigInt("0x216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51a"),
    Gy: BigInt("0x6666666666666666666666666666666666666666666666666666666666666658")
  }))();
  function ed25519_pow_2_252_3(x) {
    const _10n = BigInt(10), _20n = BigInt(20), _40n = BigInt(40), _80n = BigInt(80);
    const P = ed25519_CURVE_p;
    const x2 = x * x % P;
    const b2 = x2 * x % P;
    const b4 = pow2(b2, _2n, P) * b2 % P;
    const b5 = pow2(b4, _1n, P) * x % P;
    const b10 = pow2(b5, _5n, P) * b5 % P;
    const b20 = pow2(b10, _10n, P) * b10 % P;
    const b40 = pow2(b20, _20n, P) * b20 % P;
    const b80 = pow2(b40, _40n, P) * b40 % P;
    const b160 = pow2(b80, _80n, P) * b80 % P;
    const b240 = pow2(b160, _80n, P) * b80 % P;
    const b250 = pow2(b240, _10n, P) * b10 % P;
    const pow_p_5_8 = pow2(b250, _2n, P) * x % P;
    return { pow_p_5_8, b2 };
  }
  function adjustScalarBytes(bytes) {
    bytes[0] &= 248;
    bytes[31] &= 127;
    bytes[31] |= 64;
    return bytes;
  }
  const ED25519_SQRT_M1 = /* @__PURE__ */ BigInt("19681161376707505956807079304988542015446066515923890162744021073123829784752");
  function uvRatio(u, v) {
    const P = ed25519_CURVE_p;
    const v3 = mod(v * v * v, P);
    const v7 = mod(v3 * v3 * v, P);
    const pow3 = ed25519_pow_2_252_3(u * v7).pow_p_5_8;
    let x = mod(u * v3 * pow3, P);
    const vx2 = mod(v * x * x, P);
    const root1 = x;
    const root2 = mod(x * ED25519_SQRT_M1, P);
    const useRoot1 = vx2 === u;
    const useRoot2 = vx2 === mod(-u, P);
    const noRoot = vx2 === mod(-u * ED25519_SQRT_M1, P);
    if (useRoot1)
      x = root1;
    if (useRoot2 || noRoot)
      x = root2;
    if (isNegativeLE(x, P))
      x = mod(-x, P);
    return { isValid: useRoot1 || useRoot2, value: x };
  }
  const ed25519_Point = /* @__PURE__ */ edwards(ed25519_CURVE, { uvRatio });
  const Fp = /* @__PURE__ */ (() => ed25519_Point.Fp)();
  function toMontgomery(point) {
    const { y } = point;
    return Fp.toBytes(Fp.div(_1n + y, _1n - y));
  }
  function toMontgomerySecret(secretKey) {
    const size = ed25519_Point.Fp.BYTES;
    abytes$2(secretKey, size);
    return adjustScalarBytes(sha512(secretKey.subarray(0, size))).subarray(0, size);
  }
  function ed(opts) {
    return eddsa(ed25519_Point, sha512, Object.assign({ adjustScalarBytes, toMontgomery, toMontgomerySecret, zip215: true }, opts));
  }
  const ed25519 = /* @__PURE__ */ ed({});
  const PUBLIC_KEY_SIZE = 32;
  var Ed25519PublicKey = class extends PublicKey {
    static {
      this.SIZE = PUBLIC_KEY_SIZE;
    }
    /**
    * Create a new Ed25519PublicKey object
    * @param value ed25519 public key as buffer or base-64 encoded string
    */
    constructor(value) {
      super();
      if (typeof value === "string") this.data = fromBase64(value);
      else if (value instanceof Uint8Array) this.data = value;
      else this.data = Uint8Array.from(value);
      if (this.data.length !== PUBLIC_KEY_SIZE) throw new Error(`Invalid public key input. Expected ${PUBLIC_KEY_SIZE} bytes, got ${this.data.length}`);
    }
    /**
    * Checks if two Ed25519 public keys are equal
    */
    equals(publicKey) {
      return super.equals(publicKey);
    }
    /**
    * Return the byte array representation of the Ed25519 public key
    */
    toRawBytes() {
      return this.data;
    }
    /**
    * Return the Sui address associated with this Ed25519 public key
    */
    flag() {
      return SIGNATURE_SCHEME_TO_FLAG["ED25519"];
    }
    /**
    * Verifies that the signature is valid for for the provided message
    */
    async verify(message2, signature) {
      let bytes;
      if (typeof signature === "string") {
        const parsed = parseSerializedKeypairSignature(signature);
        if (parsed.signatureScheme !== "ED25519") throw new Error("Invalid signature scheme");
        if (!bytesEqual(this.toRawBytes(), parsed.publicKey)) throw new Error("Signature does not match public key");
        bytes = parsed.signature;
      } else bytes = signature;
      return ed25519.verify(bytes, message2, this.toRawBytes());
    }
  };
  class _HMAC {
    oHash;
    iHash;
    blockLen;
    outputLen;
    canXOF = false;
    finished = false;
    destroyed = false;
    constructor(hash, key) {
      ahash(hash);
      abytes$2(key, void 0, "key");
      this.iHash = hash.create();
      if (typeof this.iHash.update !== "function")
        throw new Error("expected Hash instance");
      this.blockLen = this.iHash.blockLen;
      this.outputLen = this.iHash.outputLen;
      const blockLen = this.blockLen;
      const pad = new Uint8Array(blockLen);
      pad.set(key.length > blockLen ? hash.create().update(key).digest() : key);
      for (let i = 0; i < pad.length; i++)
        pad[i] ^= 54;
      this.iHash.update(pad);
      this.oHash = hash.create();
      for (let i = 0; i < pad.length; i++)
        pad[i] ^= 54 ^ 92;
      this.oHash.update(pad);
      clean(pad);
    }
    update(buf) {
      aexists(this);
      this.iHash.update(buf);
      return this;
    }
    digestInto(out) {
      aexists(this);
      aoutput(out, this);
      this.finished = true;
      const buf = out.subarray(0, this.outputLen);
      this.iHash.digestInto(buf);
      this.oHash.update(buf);
      this.oHash.digestInto(buf);
      this.destroy();
    }
    digest() {
      const out = new Uint8Array(this.oHash.outputLen);
      this.digestInto(out);
      return out;
    }
    _cloneInto(to) {
      to ||= Object.create(Object.getPrototypeOf(this), {});
      const { oHash, iHash, finished, destroyed, blockLen, outputLen, canXOF } = this;
      to = to;
      to.finished = finished;
      to.destroyed = destroyed;
      to.blockLen = blockLen;
      to.outputLen = outputLen;
      to.canXOF = canXOF;
      to.oHash = oHash._cloneInto(to.oHash);
      to.iHash = iHash._cloneInto(to.iHash);
      return to;
    }
    clone() {
      return this._cloneInto();
    }
    destroy() {
      this.destroyed = true;
      this.oHash.destroy();
      this.iHash.destroy();
    }
  }
  const hmac = /* @__PURE__ */ (() => {
    const hmac_ = ((hash, key, message2) => new _HMAC(hash, key).update(message2).digest());
    hmac_.create = (hash, key) => new _HMAC(hash, key);
    return hmac_;
  })();
  function pbkdf2Init(hash, _password, _salt, _opts) {
    ahash(hash);
    const opts = checkOpts({ dkLen: 32, asyncTick: 10 }, _opts);
    const { c, dkLen, asyncTick } = opts;
    anumber$2(c, "c");
    anumber$2(dkLen, "dkLen");
    anumber$2(asyncTick, "asyncTick");
    if (c < 1)
      throw new Error('"c" (iterations) must be >= 1');
    if (dkLen < 1)
      throw new Error('"dkLen" must be >= 1');
    if (dkLen > (2 ** 32 - 1) * hash.outputLen)
      throw new Error("derived key too long");
    const p = kdfInputToBytes(_password, "password");
    try {
      const s = kdfInputToBytes(_salt, "salt");
      try {
        const DK = new Uint8Array(dkLen);
        const { iHash, oHash, outputLen } = hmac.create(hash, p);
        const u = new Uint8Array(outputLen);
        const eng = pbkdf2Engine(iHash, oHash, s, u);
        return { c, dkLen, asyncTick, DK, outputLen, eng };
      } finally {
        if (typeof _salt === "string")
          clean(s);
      }
    } finally {
      if (typeof _password === "string")
        clean(p);
    }
  }
  function pbkdf2Engine(iHash, oHash, salt, u) {
    const counter = new Uint8Array(4);
    const view = createView(counter);
    const salted = iHash._cloneInto().update(salt);
    const work = oHash._cloneInto();
    const iClone = iHash._cloneInto;
    const oClone = oHash._cloneInto;
    return {
      u1: (ti, Ti) => {
        view.setInt32(0, ti, false);
        salted._cloneInto(work).update(counter).digestInto(u);
        oHash._cloneInto(work).update(u).digestInto(u);
        Ti.set(u.subarray(0, Ti.length));
      },
      // Whole `F` inner loop for the sync variant: one optimized function owns the hot loop.
      rounds: (c, Ti) => {
        for (let ui = 1; ui < c; ui++) {
          iClone.call(iHash, work).update(u).digestInto(u);
          oClone.call(oHash, work).update(u).digestInto(u);
          for (let i = 0; i < Ti.length; i++)
            Ti[i] ^= u[i];
        }
      },
      output: (DK) => {
        iHash.destroy();
        oHash.destroy();
        salted.destroy();
        work.destroy();
        clean(u);
        return DK;
      }
    };
  }
  function pbkdf2(hash, password, salt, opts) {
    const { c, dkLen, DK, outputLen, eng } = pbkdf2Init(hash, password, salt, opts);
    for (let ti = 1, pos = 0; pos < dkLen; ti++, pos += outputLen) {
      const Ti = DK.subarray(pos, pos + outputLen);
      eng.u1(ti, Ti);
      eng.rounds(c, Ti);
    }
    return eng.output(DK);
  }
  function isWellFormedUnicode(value) {
    for (let i = 0; i < value.length; i++) {
      const current = value.charCodeAt(i);
      if (current >= 55296 && current <= 56319) {
        if (i + 1 >= value.length)
          return false;
        const next = value.charCodeAt(++i);
        if (next < 56320 || next > 57343)
          return false;
      } else if (current >= 56320 && current <= 57343) {
        return false;
      }
    }
    return true;
  }
  function nfkd(str) {
    if (typeof str !== "string")
      throw new TypeError("invalid mnemonic type: " + typeof str);
    if (!isWellFormedUnicode(str))
      throw new TypeError("expected well-formed Unicode string");
    return str.normalize("NFKD");
  }
  function normalize(str) {
    const norm = nfkd(str);
    const words = norm.split(" ");
    if (![12, 15, 18, 21, 24].includes(words.length))
      throw new Error("Invalid mnemonic");
    return { nfkd: norm, words };
  }
  const psalt = (passphrase) => {
    if (typeof passphrase !== "string")
      throw new TypeError("invalid passphrase type: " + typeof passphrase);
    return nfkd("mnemonic" + passphrase);
  };
  function mnemonicToSeedSync(mnemonic, passphrase = "") {
    return pbkdf2(sha512, normalize(mnemonic).nfkd, psalt(passphrase), {
      c: 2048,
      dkLen: 64
    });
  }
  function isValidHardenedPath(path, purpose = 44) {
    if (!(/* @__PURE__ */ new RegExp(`^m\\/${purpose}'\\/784'\\/[0-9]+'\\/[0-9]+'\\/[0-9]+'+$`)).test(path)) return false;
    return true;
  }
  function mnemonicToSeed(mnemonics) {
    return mnemonicToSeedSync(mnemonics, "");
  }
  function toSerializedSignature({ signature, signatureScheme, publicKey }) {
    if (!publicKey) throw new Error("`publicKey` is required");
    const pubKeyBytes = publicKey.toRawBytes();
    const serializedSignature = new Uint8Array(1 + signature.length + pubKeyBytes.length);
    serializedSignature.set([SIGNATURE_SCHEME_TO_FLAG[signatureScheme]]);
    serializedSignature.set(signature, 1);
    serializedSignature.set(pubKeyBytes, 1 + signature.length);
    return toBase64(serializedSignature);
  }
  const freeze = (fn) => Object.freeze(fn());
  function isBytes(a) {
    return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a && a.BYTES_PER_ELEMENT === 1;
  }
  function abytes(b) {
    if (!isBytes(b))
      throw new TypeError("Uint8Array expected");
  }
  function isArrayOf(isString, arr) {
    if (!Array.isArray(arr))
      return false;
    if (arr.length === 0)
      return true;
    {
      return arr.every((item) => Number.isSafeInteger(item));
    }
  }
  function afn(input) {
    if (typeof input !== "function")
      throw new TypeError("function expected");
    return true;
  }
  function astr(label, input) {
    if (typeof input !== "string")
      throw new TypeError(`${label}: string expected`);
    return true;
  }
  function anumber(n, title = "number") {
    if (typeof n !== "number")
      throw new TypeError(`${title}: expected number, got ${typeof n}`);
    if (!Number.isSafeInteger(n))
      throw new RangeError(`${title}: expected safe integer, got ${n}`);
  }
  function anumArr(label, input) {
    if (!isArrayOf(false, input))
      throw new TypeError(`${label}: array of numbers expected`);
  }
  const powers = /* @__PURE__ */ (() => {
    let res = [];
    for (let i = 0; i < 40; i++)
      res.push(2 ** i);
    return res;
  })();
  function u8ToNumArr(u8, len = u8.length) {
    const res = new Array(len);
    for (let i = 0; i < len; i++)
      res[i] = u8[i];
    return res;
  }
  const asciiDecoder = /* @__PURE__ */ (() => {
    try {
      const decoder2 = new TextDecoder();
      return decoder2.decode(Uint8Array.of(65, 48, 43, 127)) === "A0+" ? decoder2 : void 0;
    } catch (e) {
      return void 0;
    }
  })();
  const B2S_CHUNK = 8192;
  function charcodesToString(codes) {
    const len = codes.length;
    if (asciiDecoder !== void 0 && len >= 12)
      return asciiDecoder.decode(codes);
    if (len <= B2S_CHUNK)
      return String.fromCharCode.apply(null, codes);
    let res = "";
    for (let i = 0; i < len; i += B2S_CHUNK)
      res += String.fromCharCode.apply(null, codes.subarray(i, i + B2S_CHUNK));
    return res;
  }
  function radix2(bits) {
    anumber(bits);
    if (bits <= 0 || bits > 8)
      throw new RangeError("radix2: bits should be in (0..8]");
    const mask = powers[bits] - 1;
    return {
      encode: (bytes) => {
        abytes(bytes);
        const len = bytes.length;
        const res = new Uint8Array(Math.ceil(len * 8 / bits));
        let carry = 0;
        let pos = 0;
        let j = 0;
        for (let i = 0; i < len; ) {
          if (i + 2 < len) {
            carry = carry << 24 | bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
            pos += 24;
            i += 3;
          } else {
            carry = (carry << 8 | bytes[i]) & 65535;
            pos += 8;
            i++;
          }
          for (; ; ) {
            pos -= bits;
            res[j++] = carry >> pos & mask;
            if (pos < bits)
              break;
          }
        }
        if (pos > 0)
          res[j] = carry << bits - pos & mask;
        return res;
      },
      decode: (digits) => {
        const len = digits.length;
        const res = new Uint8Array(Math.floor(len * bits / 8));
        let carry = 0;
        let pos = 0;
        let j = 0;
        for (let i = 0; i < len; i++) {
          carry = (carry << bits | digits[i]) & 65535;
          pos += bits;
          for (; pos >= 8; pos -= 8)
            res[j++] = carry >> pos - 8 & 255;
        }
        carry = carry << 8 - pos & 255;
        if (pos >= bits)
          throw new Error("Excess padding");
        if (carry > 0)
          throw new Error(`Non-zero padding: ${carry}`);
        return res;
      }
    };
  }
  function alphabet(letters, aliases) {
    const len = letters.length;
    if (len > 128)
      throw new Error("alphabet: max 128 letters");
    const encTable = new Uint8Array(len);
    const decTable = new Int8Array(128).fill(-1);
    for (let i = 0; i < len; i++) {
      const code = letters.charCodeAt(i);
      if (letters.codePointAt(i) !== code || code > 127)
        throw new Error("alphabet: single-char ASCII letters only");
      encTable[i] = code;
      decTable[code] = i;
    }
    if (aliases !== void 0) {
      for (const alias of Object.keys(aliases)) {
        const code = alias.charCodeAt(0);
        const target = decTable[aliases[alias].charCodeAt(0)];
        if (alias.length !== 1 || code > 127 || target === void 0 || target === -1)
          throw new Error(`alphabet: invalid alias ${alias}`);
        decTable[code] = target;
      }
    }
    return {
      encode: (digits) => {
        const codes = new Uint8Array(digits.length);
        for (let i = 0; i < digits.length; i++) {
          const d = digits[i];
          const code = encTable[d];
          if (code === void 0)
            throw new Error(`alphabet.encode: invalid digit ${d}`);
          codes[i] = code;
        }
        return charcodesToString(codes);
      },
      decode: (input) => {
        astr("decode", input);
        const slen = input.length;
        const digits = new Uint8Array(slen);
        for (let i = 0; i < slen; i++) {
          const code = input.charCodeAt(i);
          const digit = code < 128 ? decTable[code] : -1;
          if (digit === -1)
            throw new Error(`Unknown letter "${input[i]}". Allowed: ${letters}`);
          digits[i] = digit;
        }
        return digits;
      }
    };
  }
  function unsafeWrapper(fn) {
    afn(fn);
    return function(...args) {
      try {
        return fn.apply(null, args);
      } catch (e) {
      }
    };
  }
  const BECH_ALPHABET = /* @__PURE__ */ alphabet("qpzry9x8gf2tvdw0s3jn54khce6mua7l");
  const BECH_UPPERCASE_PRINTABLE = /^[\x21-\x60\x7b-\x7e]+$/;
  function assertBech32Printable(label, value) {
    for (let i = 0; i < value.length; i++) {
      const c = value.charCodeAt(i);
      if (c < 33 || c > 126)
        throw new Error(`${label}: printable ASCII expected`);
    }
  }
  function wordsToU8(words) {
    const len = words.length;
    const res = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      const w = words[i];
      if (w < 0 || w >= 32)
        throw new Error(`alphabet.encode: invalid digit ${w}`);
      res[i] = w;
    }
    return res;
  }
  const POLYMOD_GENERATORS = [996825010, 642813549, 513874426, 1027748829, 705979059];
  function bech32Polymod(pre) {
    const b = pre >> 25;
    let chk = (pre & 33554431) << 5;
    for (let i = 0; i < POLYMOD_GENERATORS.length; i++) {
      if ((b >> i & 1) === 1)
        chk ^= POLYMOD_GENERATORS[i];
    }
    return chk;
  }
  function bechChecksum(prefix, words, encodingConst = 1) {
    const len = prefix.length;
    let chk = 1;
    for (let i = 0; i < len; i++) {
      const c = prefix.charCodeAt(i);
      if (c < 33 || c > 126)
        throw new Error(`Invalid prefix (${prefix})`);
      chk = bech32Polymod(chk) ^ c >> 5;
    }
    chk = bech32Polymod(chk);
    for (let i = 0; i < len; i++)
      chk = bech32Polymod(chk) ^ prefix.charCodeAt(i) & 31;
    for (let v of words)
      chk = bech32Polymod(chk) ^ v;
    for (let i = 0; i < 6; i++)
      chk = bech32Polymod(chk);
    chk ^= encodingConst;
    const sum = new Uint8Array(6);
    for (let i = 0; i < 6; i++)
      sum[i] = chk >>> 5 * (5 - i) & 31;
    return BECH_ALPHABET.encode(sum);
  }
  function genBech32(encoding) {
    const ENCODING_CONST = 1;
    const _words = radix2(5);
    const toWords = (from) => {
      abytes(from);
      const len = from.length;
      const res = new Array(Math.ceil(len * 8 / 5));
      let carry = 0;
      let pos = 0;
      let j = 0;
      for (let i = 0; i < len; i++) {
        carry = carry << 8 | from[i];
        pos += 8;
        for (; pos >= 5; pos -= 5)
          res[j++] = carry >> pos - 5 & 31;
      }
      if (pos > 0)
        res[j] = carry << 5 - pos & 31;
      return res;
    };
    const fromWords = (to) => {
      anumArr("radix2.decode", to);
      const len = to.length;
      const digits = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        const w = to[i];
        if (w < 0 || w >= 32)
          throw new Error(`convertRadix2: invalid word=${w}`);
        digits[i] = w;
      }
      return _words.decode(digits);
    };
    const fromWordsUnsafe = unsafeWrapper(fromWords);
    function encode(prefix, words, limit = 90) {
      astr("bech32.encode prefix", prefix);
      if (limit !== false)
        anumber(limit, "limit");
      if (isBytes(words))
        words = u8ToNumArr(words);
      anumArr("bech32.encode", words);
      const plen = prefix.length;
      if (plen === 0)
        throw new TypeError(`Invalid prefix length ${plen}`);
      const actualLength = plen + 7 + words.length;
      if (limit !== false && actualLength > limit)
        throw new TypeError(`Length ${actualLength} exceeds limit ${limit}`);
      assertBech32Printable("bech32.encode prefix", prefix);
      const lowered = prefix.toLowerCase();
      const sum = bechChecksum(lowered, words, ENCODING_CONST);
      return `${lowered}1${BECH_ALPHABET.encode(wordsToU8(words))}${sum}`;
    }
    function decode(str, limit = 90) {
      astr("bech32.decode input", str);
      if (limit !== false)
        anumber(limit, "limit");
      const slen = str.length;
      if (slen < 8 || limit !== false && slen > limit)
        throw new TypeError(`invalid string length ${slen}, expected (8..${limit})`);
      const lowered = str.toLowerCase();
      if (str !== lowered) {
        if (!BECH_UPPERCASE_PRINTABLE.test(str)) {
          assertBech32Printable("bech32.decode input", str);
          throw new Error(`mixed-case string not allowed`);
        }
      }
      const sepIndex = lowered.lastIndexOf("1");
      if (sepIndex === 0 || sepIndex === -1)
        throw new Error(`invalid separator "1"`);
      const prefix = lowered.slice(0, sepIndex);
      const data = lowered.slice(sepIndex + 1);
      if (data.length < 6)
        throw new Error("invalid data length");
      const digits = BECH_ALPHABET.decode(data);
      const words = u8ToNumArr(digits, digits.length - 6);
      const sum = bechChecksum(prefix, words, ENCODING_CONST);
      if (!data.endsWith(sum))
        throw new Error(`Invalid checksum in ${str}`);
      return { prefix, words };
    }
    const decodeUnsafe = unsafeWrapper(decode);
    function decodeToBytes(str, limit = 90) {
      const { prefix, words } = decode(str, limit);
      return {
        prefix,
        words,
        bytes: fromWords(words)
      };
    }
    function encodeFromBytes(prefix, bytes) {
      return encode(prefix, toWords(bytes));
    }
    return {
      encode,
      decode,
      encodeFromBytes,
      decodeToBytes,
      decodeUnsafe,
      fromWords,
      fromWordsUnsafe,
      toWords
    };
  }
  const bech32 = /* @__PURE__ */ freeze(() => genBech32());
  const PRIVATE_KEY_SIZE = 32;
  const SUI_PRIVATE_KEY_PREFIX = "suiprivkey";
  var Signer = class {
    /**
    * Sign messages with a specific intent. By combining the message bytes with the intent before hashing and signing,
    * it ensures that a signed message is tied to a specific purpose and domain separator is provided
    */
    async signWithIntent(bytes, intent) {
      const digest = blake2b(messageWithIntent(intent, bytes), { dkLen: 32 });
      return {
        signature: toSerializedSignature({
          signature: await this.sign(digest),
          signatureScheme: this.getKeyScheme(),
          publicKey: this.getPublicKey()
        }),
        bytes: toBase64(bytes)
      };
    }
    /**
    * Signs provided transaction by calling `signWithIntent()` with a `TransactionData` provided as intent scope
    */
    async signTransaction(bytes) {
      return this.signWithIntent(bytes, "TransactionData");
    }
    /**
    * Signs provided personal message by calling `signWithIntent()` with a `PersonalMessage` provided as intent scope
    */
    async signPersonalMessage(bytes) {
      const { signature } = await this.signWithIntent(bcs.byteVector().serialize(bytes).toBytes(), "PersonalMessage");
      return {
        bytes: toBase64(bytes),
        signature
      };
    }
    async signAndExecuteTransaction({ transaction, client }) {
      transaction.setSenderIfNotSet(this.toSuiAddress());
      const bytes = await transaction.build({ client });
      const { signature } = await this.signTransaction(bytes);
      return client.core.executeTransaction({
        transaction: bytes,
        signatures: [signature],
        include: {
          transaction: true,
          effects: true
        }
      });
    }
    toSuiAddress() {
      return this.getPublicKey().toSuiAddress();
    }
  };
  var Keypair = class extends Signer {
  };
  function decodeSuiPrivateKey(value) {
    const { prefix, words } = bech32.decode(value);
    if (prefix !== SUI_PRIVATE_KEY_PREFIX) throw new Error("invalid private key prefix");
    const extendedSecretKey = new Uint8Array(bech32.fromWords(words));
    const secretKey = extendedSecretKey.slice(1);
    return {
      scheme: SIGNATURE_FLAG_TO_SCHEME[extendedSecretKey[0]],
      secretKey
    };
  }
  function encodeSuiPrivateKey(bytes, scheme) {
    if (bytes.length !== PRIVATE_KEY_SIZE) throw new Error("Invalid bytes length");
    const flag = SIGNATURE_SCHEME_TO_FLAG[scheme];
    const privKeyBytes = new Uint8Array(bytes.length + 1);
    privKeyBytes.set([flag]);
    privKeyBytes.set(bytes, 1);
    return bech32.encode(SUI_PRIVATE_KEY_PREFIX, bech32.toWords(privKeyBytes));
  }
  const ED25519_SLIP10_MASTER_KEY = "ed25519 seed";
  const HARDENED_OFFSET = 2147483648;
  const MIN_SEED_LENGTH = 16;
  const MAX_SEED_LENGTH = 64;
  const pathRegex = /^m(\/(0|[1-9][0-9]*)')+$/;
  const getMasterKeyFromSeed = (masterKey, seed) => {
    return split(hmac(sha512, new TextEncoder().encode(masterKey), seed));
  };
  const CKDPriv = ({ key, chainCode }, index) => {
    const data = new Uint8Array(1 + key.length + 4);
    data.set(key, 1);
    new DataView(data.buffer).setUint32(1 + key.length, index);
    const I = hmac(sha512, chainCode, data);
    data.fill(0);
    return split(I);
  };
  const split = (I) => {
    const node = {
      key: I.slice(0, 32),
      chainCode: I.slice(32)
    };
    I.fill(0);
    return node;
  };
  const wipe = ({ key, chainCode }) => {
    key.fill(0);
    chainCode.fill(0);
  };
  const derivePath = (masterKey, path, seed) => {
    if (!pathRegex.test(path)) throw new Error("Invalid derivation path");
    if (seed.length < MIN_SEED_LENGTH || seed.length > MAX_SEED_LENGTH) throw new Error(`Invalid seed length: expected ${MIN_SEED_LENGTH} to ${MAX_SEED_LENGTH} bytes`);
    const segments = path.split("/").slice(1).map((el) => parseInt(el.slice(0, -1), 10));
    if (segments.some((segment) => segment >= HARDENED_OFFSET)) throw new Error("Invalid derivation path");
    let node = getMasterKeyFromSeed(masterKey, seed);
    for (const segment of segments) {
      const child = CKDPriv(node, (segment | HARDENED_OFFSET) >>> 0);
      wipe(node);
      node = child;
    }
    return node;
  };
  const DEFAULT_ED25519_DERIVATION_PATH = "m/44'/784'/0'/0'/0'";
  var Ed25519Keypair = class Ed25519Keypair2 extends Keypair {
    /**
    * Create a new Ed25519 keypair instance.
    * Generate random keypair if no {@link Ed25519Keypair} is provided.
    *
    * @param keypair Ed25519 keypair
    */
    constructor(keypair) {
      super();
      if (keypair) this.keypair = {
        publicKey: keypair.publicKey,
        secretKey: keypair.secretKey.slice(0, 32)
      };
      else {
        const privateKey = ed25519.utils.randomSecretKey();
        this.keypair = {
          publicKey: ed25519.getPublicKey(privateKey),
          secretKey: privateKey
        };
      }
    }
    /**
    * Get the key scheme of the keypair ED25519
    */
    getKeyScheme() {
      return "ED25519";
    }
    /**
    * Generate a new random Ed25519 keypair
    */
    static generate() {
      const secretKey = ed25519.utils.randomSecretKey();
      return new Ed25519Keypair2({
        publicKey: ed25519.getPublicKey(secretKey),
        secretKey
      });
    }
    /**
    * Create a Ed25519 keypair from a raw secret key byte array, also known as seed.
    * This is NOT the private scalar which is result of hashing and bit clamping of
    * the raw secret key.
    *
    * @throws error if the provided secret key is invalid and validation is not skipped.
    *
    * @param secretKey secret key as a byte array or Bech32 secret key string
    * @param options: skip secret key validation
    */
    static fromSecretKey(secretKey, options) {
      if (typeof secretKey === "string") {
        const decoded = decodeSuiPrivateKey(secretKey);
        if (decoded.scheme !== "ED25519") throw new Error(`Expected a ED25519 keypair, got ${decoded.scheme}`);
        return this.fromSecretKey(decoded.secretKey, options);
      }
      const secretKeyLength = secretKey.length;
      if (secretKeyLength !== PRIVATE_KEY_SIZE) throw new Error(`Wrong secretKey size. Expected ${PRIVATE_KEY_SIZE} bytes, got ${secretKeyLength}.`);
      const keypair = {
        publicKey: ed25519.getPublicKey(secretKey),
        secretKey
      };
      if (!options || !options.skipValidation) {
        const signData = new TextEncoder().encode("sui validation");
        const signature = ed25519.sign(signData, secretKey);
        if (!ed25519.verify(signature, signData, keypair.publicKey)) throw new Error("provided secretKey is invalid");
      }
      return new Ed25519Keypair2(keypair);
    }
    /**
    * The public key for this Ed25519 keypair
    */
    getPublicKey() {
      return new Ed25519PublicKey(this.keypair.publicKey);
    }
    /**
    * The Bech32 secret key string for this Ed25519 keypair
    */
    getSecretKey() {
      return encodeSuiPrivateKey(this.keypair.secretKey.slice(0, PRIVATE_KEY_SIZE), this.getKeyScheme());
    }
    /**
    * Return the signature for the provided data using Ed25519.
    */
    async sign(data) {
      return ed25519.sign(data, this.keypair.secretKey);
    }
    /**
    * Derive Ed25519 keypair from mnemonics and path. The mnemonics must be normalized
    * and validated against the english wordlist.
    *
    * If path is none, it will default to m/44'/784'/0'/0'/0', otherwise the path must
    * be compliant to SLIP-0010 in form m/44'/784'/{account_index}'/{change_index}'/{address_index}'.
    */
    static deriveKeypair(mnemonics, path) {
      return Ed25519Keypair2.deriveKeypairFromSeed(mnemonicToSeed(mnemonics), path);
    }
    /**
    * Derive Ed25519 keypair from mnemonicSeed and path.
    *
    * If path is none, it will default to m/44'/784'/0'/0'/0', otherwise the path must
    * be compliant to SLIP-0010 in form m/44'/784'/{account_index}'/{change_index}'/{address_index}'.
    *
    * @param seed - The seed as a hex string or Uint8Array.
    */
    static deriveKeypairFromSeed(seed, path) {
      if (path == null) path = DEFAULT_ED25519_DERIVATION_PATH;
      if (!isValidHardenedPath(path)) throw new Error("Invalid derivation path");
      const { key, chainCode } = derivePath(ED25519_SLIP10_MASTER_KEY, path, typeof seed === "string" ? fromHex(seed) : seed);
      chainCode.fill(0);
      return Ed25519Keypair2.fromSecretKey(key);
    }
  };
  const NETWORK = "sui:mainnet";
  const ASSET = "0x2::sui::SUI";
  const ADDRESS = /^0x[0-9a-f]{64}$/i;
  const NONCE = /^[0-9a-f]{32}$/;
  const AMOUNT = /^[1-9][0-9]{0,18}$/;
  const AGENT_HARD_CAP_MIST = 100000000n;
  const AGENT_DEFAULT_BUDGET_MIST = 200000000n;
  const AGENT_DEFAULT_MAX_MIST = 50000000n;
  const AGENT_MAX_BUDGET_MIST = 10000000000n;
  const AGENT_MIN_MIST = 10000000n;
  const AGENT_MAX_PER_RUN = 3;
  const KICKOFF_MARGIN_MS = 12e4;
  function readRequirement(header) {
    if (!header) return null;
    let parsed;
    try {
      parsed = JSON.parse(atob(header));
    } catch {
      return null;
    }
    if (parsed.x402Version !== 2 || !Array.isArray(parsed.accepts)) return null;
    const accepted = parsed.accepts[0];
    const extra = accepted?.extra;
    if (!accepted || !extra) return null;
    const { scheme, network, asset, amount, payTo } = accepted;
    if (scheme !== "exact" || network !== NETWORK || asset !== ASSET) return null;
    if (extra.payPackage !== PAY_PACKAGE || extra.payConfig !== PAY_CONFIG) return null;
    if (typeof amount !== "string" || !AMOUNT.test(amount)) return null;
    if (typeof payTo !== "string" || !ADDRESS.test(payTo)) return null;
    if (typeof extra.nonce !== "string" || !NONCE.test(extra.nonce)) return null;
    return { accepted, amount, payTo, nonce: extra.nonce, resource: parsed.resource };
  }
  function paymentHeader(requirement, signed) {
    return btoa(JSON.stringify({ x402Version: 2, resource: requirement.resource, accepted: requirement.accepted, payload: { signature: signed.signature, transaction: signed.bytes } }));
  }
  const failed = (code, maybePaid = false) => ({ ok: false, code, maybePaid });
  const message = (error) => String(error?.message ?? error);
  const opened = (response) => {
    const body = response.body;
    return { ok: true, handle: body.handle, call: body.call, receipt: body.receipt ?? null };
  };
  async function runUnlock(deps) {
    const first = await deps.fetchCall();
    if (first.status === 200) return opened(first);
    if (first.status !== 402) return failed(first.body?.error ?? "unavailable");
    const requirement = readRequirement(first.required);
    if (!requirement) return failed("bad_requirements");
    if (requirement.amount !== deps.expectedPriceMist) return failed("price_changed");
    let signed;
    try {
      const txBytes = await deps.build();
      signed = await deps.sign(txBytes, { kind: "pay", nonce: requirement.nonce, recipient: requirement.payTo, priceMist: requirement.amount });
    } catch (error) {
      const text = message(error);
      if (/^[a-z_]+$/.test(text)) return failed(text);
      return { ok: false, code: "wallet", walletMessage: text, maybePaid: false };
    }
    let second;
    try {
      second = await deps.fetchCall(paymentHeader(requirement, signed));
    } catch {
      return failed("network", true);
    }
    if (second.status === 200) return opened(second);
    if (second.status === 0) return failed("network", true);
    const reason = second.body?.reason ?? second.body?.error ?? "unavailable";
    return failed(reason, reason === "broadcast_failed" || reason === "no_payment_event");
  }
  ({ dailyBudgetMist: AGENT_DEFAULT_BUDGET_MIST.toString(), maxPerCallMist: AGENT_DEFAULT_MAX_MIST.toString() });
  const mistOr = (value, fallback, max) => {
    if (typeof value !== "string" || !AMOUNT.test(value)) return fallback;
    const mist = BigInt(value);
    return mist < AGENT_MIN_MIST || mist > max ? fallback : mist;
  };
  function cleanAgentSettings(raw) {
    const value = typeof raw === "object" && raw !== null ? raw : {};
    return {
      enabled: value.enabled === true,
      dailyBudgetMist: mistOr(value.dailyBudgetMist, AGENT_DEFAULT_BUDGET_MIST, AGENT_MAX_BUDGET_MIST).toString(),
      maxPerCallMist: mistOr(value.maxPerCallMist, AGENT_DEFAULT_MAX_MIST, AGENT_HARD_CAP_MIST).toString()
    };
  }
  const utcDay = (nowMs) => new Date(nowMs).toISOString().slice(0, 10);
  function spentToday(spend, nowMs) {
    return spend?.day === utcDay(nowMs) && AMOUNT.test(spend.spentMist) ? BigInt(spend.spentMist) : 0n;
  }
  const isLockedItem = (item) => item.locked === true;
  function agentCandidates(entries, settings, spentMist, nowMs) {
    if (!settings.enabled) return [];
    const perCall = BigInt(settings.maxPerCallMist) < AGENT_HARD_CAP_MIST ? BigInt(settings.maxPerCallMist) : AGENT_HARD_CAP_MIST;
    let left = BigInt(settings.dailyBudgetMist) - spentMist;
    const chosen = [];
    for (const { handle, item } of entries) {
      if (chosen.length >= AGENT_MAX_PER_RUN) break;
      if (!isLockedItem(item) || !item.proof || Date.parse(item.fixture.startISO) - nowMs <= KICKOFF_MARGIN_MS) continue;
      const price = BigInt(item.premium.priceMist);
      if (price > perCall || price > left) continue;
      left -= price;
      chosen.push({ handle, item });
    }
    return chosen;
  }
  const matchLine = (fixture) => `${fixture.home} v ${fixture.away}`;
  const MAX_RECEIPTS = 50;
  const codeOf = (response) => response.body?.error ?? "unavailable";
  function createAgent(deps) {
    const nowMs = () => deps.now?.() ?? Date.now();
    const storage = chrome.storage.local;
    let queue = Promise.resolve();
    function serial(work) {
      const next = queue.then(work, work);
      queue = next.catch(() => void 0);
      return next;
    }
    async function keypair() {
      const stored = (await storage.get(AGENT_KEY))[AGENT_KEY];
      return typeof stored === "string" ? Ed25519Keypair.fromSecretKey(stored) : null;
    }
    const readSettings = async () => cleanAgentSettings((await storage.get(AGENT_SETTINGS_KEY))[AGENT_SETTINGS_KEY]);
    const readSpend = async () => (await storage.get(AGENT_SPEND_KEY))[AGENT_SPEND_KEY] ?? null;
    const readReceipts = async () => (await storage.get(AGENT_RECEIPTS_KEY))[AGENT_RECEIPTS_KEY] ?? [];
    async function changeSpend(change) {
      const now = nowMs();
      const spent = spentToday(await readSpend(), now) + change;
      await storage.set({ [AGENT_SPEND_KEY]: { day: utcDay(now), spentMist: (spent < 0n ? 0n : spent).toString() } });
    }
    async function signer(pair, txBytes, expected) {
      const verdict = checkTransaction(txBytes, expected, pair.toSuiAddress());
      if (!verdict.ok) throw new Error(verdict.reason);
      return pair.signTransaction(fromBase64(txBytes));
    }
    async function status() {
      const [pair, settings, spend, receipts] = await Promise.all([keypair(), readSettings(), readSpend(), readReceipts()]);
      const address = pair?.toSuiAddress() ?? null;
      let balanceMist = null;
      if (address) {
        const response = await deps.relay("/premium/balance", { address });
        if (response.ok) balanceMist = response.body.balanceMist;
      }
      return { address, balanceMist, settings, spentTodayMist: spentToday(spend, nowMs()).toString(), receipts };
    }
    async function run() {
      const pair = await keypair();
      const settings = await readSettings();
      if (!pair || !settings.enabled) return { unlocked: [], stopped: null };
      const feed = await deps.relay("/social/feed", {});
      if (!feed.ok || !feed.body) return { unlocked: [], stopped: "feed_unavailable" };
      const sender = pair.toSuiAddress();
      const candidates = agentCandidates(feed.body.items, settings, spentToday(await readSpend(), nowMs()), nowMs());
      const unlocked = [];
      for (const { handle, item } of candidates) {
        const price = BigInt(item.premium.priceMist);
        await changeSpend(price);
        const result = await runUnlock({
          expectedPriceMist: item.premium.priceMist,
          fetchCall: (payment) => deps.fetchCall(item.pickId, payment),
          build: async () => {
            const built = await deps.relay("/premium/build", { pickId: item.pickId, sender });
            if (!built.ok) throw new Error(codeOf(built));
            return built.body.transaction;
          },
          sign: (txBytes, expected) => signer(pair, txBytes, expected)
        });
        if (!result.ok) {
          if (!result.maybePaid) await changeSpend(-price);
          if (result.code === "insufficient_balance") return { unlocked, stopped: result.code };
          continue;
        }
        if (!result.receipt) {
          await changeSpend(-price);
          continue;
        }
        const receipt = { at: result.receipt.at, handle, match: matchLine(item.fixture), priceMist: result.receipt.priceMist, digest: result.receipt.digest };
        unlocked.push(receipt);
        await storage.set({ [AGENT_RECEIPTS_KEY]: [receipt, ...await readReceipts()].slice(0, MAX_RECEIPTS) });
      }
      return { unlocked, stopped: null };
    }
    async function withdraw() {
      const pair = await keypair();
      if (!pair) return { error: "no_agent" };
      const saved = (await storage.get(SUI_WALLET_KEY))[SUI_WALLET_KEY];
      const recipient = saved?.address;
      if (typeof recipient !== "string") return { error: "no_wallet" };
      const sender = pair.toSuiAddress();
      const built = await deps.relay("/premium/transfer/build", { sender, recipient });
      if (!built.ok) return { error: codeOf(built) };
      let signed;
      try {
        signed = await signer(pair, built.body.transaction, { kind: "withdraw", recipient });
      } catch {
        return { error: "refused" };
      }
      const sent = await deps.relay("/premium/transfer/execute", { transaction: signed.bytes, signature: signed.signature });
      return sent.ok ? { digest: sent.body.digest } : { error: codeOf(sent) };
    }
    return {
      status: () => serial(status),
      run: () => serial(run),
      withdraw: () => serial(withdraw),
      saveSettings: (raw) => serial(async () => {
        const settings = cleanAgentSettings(raw);
        await storage.set({ [AGENT_SETTINGS_KEY]: settings });
        return settings;
      }),
      create: () => serial(async () => {
        const existing = await keypair();
        if (existing) return { address: existing.toSuiAddress() };
        const pair = Ed25519Keypair.generate();
        await storage.set({ [AGENT_KEY]: pair.getSecretKey() });
        return { address: pair.toSuiAddress() };
      })
    };
  }
  const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  function isRecallId(value) {
    return typeof value === "string" && UUID.test(value);
  }
  const INSTALL_KEY = "soothia:installId";
  const RESULT_PREFIX = "soothia:detect:v2:";
  const RESULT_TTL_MS = 10 * 60 * 1e3;
  const ERROR_TTL_MS = 60 * 1e3;
  async function checkHealth() {
    try {
      const res = await fetch(`${WORKER_URL}/health`, { signal: AbortSignal.timeout(5e3) });
      if (!res.ok) return { online: false };
      const body = await res.json();
      return { online: body.ok === true };
    } catch {
      return { online: false };
    }
  }
  async function installId() {
    const stored = (await chrome.storage.local.get(INSTALL_KEY))[INSTALL_KEY];
    if (typeof stored === "string" && stored) return stored;
    const created = crypto.randomUUID();
    await chrome.storage.local.set({ [INSTALL_KEY]: created });
    return created;
  }
  const RECORD_ROUTES = /* @__PURE__ */ new Set(["/stake/build", "/stake/confirm", "/social/profile/publish", "/social/follow", "/social/unfollow", "/social/following", "/social/search", "/social/feed", "/social/feed/new", "/premium/eligible", "/premium/build"]);
  async function recallHeaders(path) {
    if (!path.startsWith("/recall/") && !path.startsWith("/premium/call/") && !RECORD_ROUTES.has(path)) return {};
    const stored = (await chrome.storage.local.get(RECALL_ID_KEY))[RECALL_ID_KEY];
    return isRecallId(stored) ? { "X-Soothia-Recall": stored } : {};
  }
  async function post(path, body, refresh = false) {
    const headers = {
      "Content-Type": "application/json",
      "X-Soothia-Install": await installId(),
      ...await recallHeaders(path)
    };
    if (refresh) headers["X-Soothia-Refresh"] = "1";
    return fetch(`${WORKER_URL}${path}`, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      // Chrome stops a service worker whose fetch takes over 30 seconds.
      signal: AbortSignal.timeout(28e3)
    });
  }
  async function detect(page, refresh, fixture) {
    const debug = {
      httpStatus: null,
      cache: null,
      fromClientCache: false,
      claimsReturned: 0,
      dropped: []
    };
    try {
      const detected = await post("/detect", fixture ? { ...page, fixture } : page, refresh);
      debug.httpStatus = detected.status;
      const cache = detected.headers.get("X-Soothia-Cache");
      debug.cache = cache === "HIT" || cache === "MISS" ? cache : null;
      if (detected.status === 429) return { status: "error", reason: "limit", debug };
      if (!detected.ok) return { status: "error", reason: "unavailable", debug };
      const body = await detected.json();
      const claims = body.claims;
      debug.claimsReturned = claims.length;
      debug.dropped = body.dropped ?? [];
      debug.path = body.path;
      if (claims.length === 0) return { status: "ok", tiles: [], debug };
      const tiles = claims.map((claim) => ({ claim }));
      return { status: "ok", tiles, debug };
    } catch {
      return { status: "error", reason: "unavailable", debug };
    }
  }
  function isLive(stored, now) {
    if (!stored) return false;
    return now - stored.at < (stored.result.status === "ok" ? RESULT_TTL_MS : ERROR_TTL_MS);
  }
  async function pruneResults(now) {
    const all = await chrome.storage.session.get(null);
    const dead = Object.keys(all).filter((key) => key.startsWith(RESULT_PREFIX) && !isLive(all[key], now));
    if (dead.length > 0) await chrome.storage.session.remove(dead);
  }
  const inFlight = /* @__PURE__ */ new Map();
  async function detectOnce(page, refresh, fixture) {
    const key = RESULT_PREFIX + page.url + (fixture ? "#fixture" : "");
    const now = Date.now();
    if (!refresh) {
      const stored = (await chrome.storage.session.get(key))[key];
      if (isLive(stored, now)) {
        return { ...stored.result, debug: { ...stored.result.debug, fromClientCache: true } };
      }
    }
    const running = inFlight.get(key);
    if (running) return running;
    const request = detect(page, refresh, fixture).then(async (result) => {
      await chrome.storage.session.set({ [key]: { at: Date.now(), result } });
      await pruneResults(Date.now());
      return result;
    }).finally(() => inFlight.delete(key));
    inFlight.set(key, request);
    return request;
  }
  const FAILED = {
    status: "error",
    reason: "unavailable",
    debug: { httpStatus: null, cache: null, fromClientCache: false, claimsReturned: 0, dropped: [] }
  };
  async function relay(message2) {
    if (!Object.hasOwn(API_ROUTES, message2.path)) return { ok: false, status: 0, body: null };
    try {
      const response = API_ROUTES[message2.path] === "GET" ? await fetch(`${WORKER_URL}${message2.path}?${new URLSearchParams(message2.body)}`, {
        headers: { "X-Soothia-Install": await installId(), ...await recallHeaders(message2.path) },
        signal: AbortSignal.timeout(28e3)
      }) : await post(message2.path, message2.body);
      return { ok: response.ok, status: response.status, body: await response.json().catch(() => null) };
    } catch {
      return { ok: false, status: 0, body: null };
    }
  }
  const PICK_ID = /^[A-Za-z0-9_-]{1,100}$/;
  async function fetchPremiumCall(pickId, payment) {
    if (typeof pickId !== "string" || !PICK_ID.test(pickId)) return { status: 0, required: null, body: null };
    try {
      const path = `/premium/call/${pickId}`;
      const response = await fetch(`${WORKER_URL}${path}`, {
        headers: { "X-Soothia-Install": await installId(), ...await recallHeaders(path), ...typeof payment === "string" ? { "PAYMENT-SIGNATURE": payment } : {} },
        signal: AbortSignal.timeout(28e3)
      });
      return { status: response.status, required: response.headers.get("PAYMENT-REQUIRED"), body: await response.json().catch(() => null) };
    } catch {
      return { status: 0, required: null, body: null };
    }
  }
  const agent = createAgent({ relay: (path, body) => relay({ type: API_REQUEST, path, body }), fetchCall: fetchPremiumCall });
  function agentAction(action, settings) {
    switch (action) {
      case "status":
        return agent.status();
      case "create":
        return agent.create();
      case "settings":
        return agent.saveSettings(settings);
      case "withdraw":
        return agent.withdraw();
      case "run":
        return agent.run();
    }
  }
  const MUTED_KEY = "soothia:muted";
  const WELCOME_URL = chrome.runtime.getURL("welcome.html");
  const welcomeTabs = /* @__PURE__ */ new Set();
  async function hasOffscreen() {
    try {
      const contexts = await chrome.runtime.getContexts({
        contextTypes: ["OFFSCREEN_DOCUMENT"]
      });
      return contexts.length > 0;
    } catch {
      return false;
    }
  }
  let musicStarting = null;
  function startMusic() {
    if (!musicStarting) {
      musicStarting = startMusicNow().finally(() => {
        musicStarting = null;
      });
    }
    return musicStarting;
  }
  async function startMusicNow() {
    try {
      if (!chrome.offscreen) return { playing: false, muted: false, error: "offscreen API unavailable" };
      if (!await hasOffscreen()) {
        await chrome.offscreen.createDocument({
          url: "offscreen.html",
          reasons: ["AUDIO_PLAYBACK"],
          justification: "Plays onboarding music while the welcome page is open"
        });
      }
      const muted = (await chrome.storage.local.get(MUTED_KEY))[MUTED_KEY] === true;
      const status = await chrome.runtime.sendMessage({ type: MUSIC_CONTROL, action: "start", muted });
      return status ?? { playing: false, muted, error: "no answer from the player" };
    } catch (error) {
      return { playing: false, muted: false, error: String(error?.message ?? error) };
    }
  }
  async function stopMusic() {
    if (!await hasOffscreen()) return;
    await chrome.runtime.sendMessage({ type: MUSIC_CONTROL, action: "stop" }).catch(() => {
    });
  }
  async function openWelcome() {
    const tab = await chrome.tabs.create({ url: WELCOME_URL });
    if (tab.id !== void 0) welcomeTabs.add(tab.id);
    void startMusic();
  }
  chrome.tabs.onRemoved.addListener((tabId) => {
    if (!welcomeTabs.delete(tabId)) return;
    if (welcomeTabs.size === 0) void stopMusic();
  });
  chrome.tabs.onUpdated.addListener((tabId, change) => {
    if (!change.url) return;
    if (change.url.startsWith(WELCOME_URL)) welcomeTabs.add(tabId);
    else if (welcomeTabs.delete(tabId) && welcomeTabs.size === 0) void stopMusic();
  });
  chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === "install") openWelcome().catch(() => {
    });
  });
  self.addEventListener("unhandledrejection", (event) => event.preventDefault());
  self.addEventListener("error", (event) => event.preventDefault());
  const respondSafely = (work, sendResponse, fallback) => {
    work.then(
      (value) => {
        try {
          sendResponse(value);
        } catch {
        }
      },
      () => {
        try {
          sendResponse(fallback);
        } catch {
        }
      }
    );
  };
  async function verifyForSigning(message2) {
    const stored = await chrome.storage.local.get(SUI_WALLET_KEY);
    const address = stored[SUI_WALLET_KEY]?.address;
    if (typeof address !== "string") return { ok: false, reason: "No Sui wallet is connected." };
    return checkTransaction(message2.txBytes, message2.expected, address);
  }
  chrome.runtime.onMessage.addListener((message2, sender, sendResponse) => {
    try {
      return handleMessage(message2, sender, sendResponse);
    } catch {
      try {
        sendResponse(void 0);
      } catch {
      }
      return false;
    }
  });
  function handleMessage(message2, sender, sendResponse) {
    switch (message2?.type) {
      case HEALTH_REQUEST:
        respondSafely(checkHealth(), sendResponse, { online: false });
        return true;
      // keep the channel open for the async response
      case DETECT_REQUEST:
        respondSafely(
          detectOnce(
            message2.page,
            message2.refresh === true,
            message2.fixture
          ),
          sendResponse,
          FAILED
        );
        return true;
      case API_REQUEST:
        respondSafely(relay(message2), sendResponse, { ok: false, status: 0, body: null });
        return true;
      case OPEN_WELCOME:
        respondSafely(
          openWelcome().then(() => true),
          sendResponse,
          false
        );
        return true;
      case CHECK_TX:
        respondSafely(verifyForSigning(message2), sendResponse, { ok: false, reason: "The transaction could not be checked." });
        return true;
      case PREMIUM_CALL:
        if (sender.id !== chrome.runtime.id) return void 0;
        respondSafely(fetchPremiumCall(message2.pickId, message2.payment), sendResponse, { status: 0, required: null, body: null });
        return true;
      case AGENT_REQUEST:
        if (sender.id !== chrome.runtime.id) return void 0;
        respondSafely(agentAction(message2.action, message2.settings), sendResponse, null);
        return true;
      case MUSIC_CONTROL:
        if (message2.action === "ensure") {
          if (sender.tab?.id !== void 0) welcomeTabs.add(sender.tab.id);
          respondSafely(startMusic(), sendResponse, { playing: false, muted: false, error: "background failed" });
          return true;
        }
        return void 0;
    }
    return void 0;
  }
})();
