(function() {
  "use strict";
  const SITE_URL = "https://soothia.heylana.workers.dev";
  const betLink = (marketId) => `${SITE_URL}/m/${marketId}`;
  function el(tag, className, text) {
    const node = document.createElement(tag);
    node.className = className;
    if (text) node.textContent = text;
    return node;
  }
  function button(label, className, onClick) {
    const node = el("button", className, label);
    node.type = "button";
    if (onClick) node.addEventListener("click", onClick);
    return node;
  }
  function copyButton(label, text, className, onCopied) {
    const node = button(label, className, () => {
      void navigator.clipboard.writeText(text).then(() => {
        node.textContent = "Copied";
        node.classList.add("copied");
        onCopied?.();
        setTimeout(() => {
          node.textContent = label;
          node.classList.remove("copied");
        }, 1500);
      }).catch(() => {
        node.textContent = "Couldn't copy";
        setTimeout(() => node.textContent = label, 1500);
      });
    });
    return node;
  }
  function externalLink(label, href, className) {
    const node = el("a", className, label);
    node.href = href;
    node.target = "_blank";
    node.rel = "noopener noreferrer";
    return node;
  }
  const END_DATE = new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC"
  });
  function endDate(iso) {
    const date = new Date(iso);
    return Number.isNaN(date.getTime()) ? "" : END_DATE.format(date);
  }
  function domainName(url) {
    try {
      return new URL(url).hostname.replace(/^www\./, "");
    } catch {
      return url;
    }
  }
  function shortAddress(address) {
    return address.length > 10 ? `${address.slice(0, 4)}…${address.slice(-4)}` : address;
  }
  const SVG_NS = "http://www.w3.org/2000/svg";
  let starCount = 0;
  function starSvg(className = "star") {
    const id = `sth-chrome-${++starCount}`;
    const wrap = el("span", className);
    const svg = document.createElementNS(SVG_NS, "svg");
    svg.setAttribute("viewBox", "-50 -50 100 100");
    svg.setAttribute("aria-hidden", "true");
    svg.innerHTML = `<defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFFFFF"/><stop offset=".34" stop-color="#D3D1DE"/><stop offset=".5" stop-color="#6F6C82"/><stop offset=".64" stop-color="#F3F2F8"/><stop offset="1" stop-color="#8E8BA0"/></linearGradient></defs><path d="M0 -50 C3 -12 8 -4 32 0 C8 4 3 12 0 50 C-3 12 -8 4 -32 0 C-8 -4 -3 -12 0 -50Z" fill="url(#${id})"/><path d="M0 -50 C3 -12 8 -4 32 0 L0 0Z" fill="#FFFFFF" opacity=".38"/><path d="M0 0 L-32 0 C-8 4 -3 12 0 50Z" fill="#0E0D14" opacity=".28"/>`;
    wrap.append(svg);
    return wrap;
  }
  function icon(name) {
    const svg = document.createElementNS(SVG_NS, "svg");
    svg.setAttribute("aria-hidden", "true");
    const paths = {
      close: ["14", `<path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>`],
      refresh: ["12", `<path d="M10 6a4 4 0 1 1-1.2-2.85M10 1.5v2.5H7.5" stroke="currentColor" stroke-width="1.3" fill="none" stroke-linecap="round"/>`],
      sound: [
        "14",
        `<path d="M2 5.5v3h2.2L7.5 11V3L4.2 5.5H2z" fill="currentColor"/><path d="M9.5 4.8a2.6 2.6 0 0 1 0 4.4M11.2 3a5 5 0 0 1 0 8" stroke="currentColor" stroke-width="1.3" fill="none" stroke-linecap="round"/>`
      ],
      muted: [
        "14",
        `<path d="M2 5.5v3h2.2L7.5 11V3L4.2 5.5H2z" fill="currentColor"/><path d="M9.3 5.2l3.4 3.6M12.7 5.2l-3.4 3.6" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>`
      ],
      warn: [
        "16",
        `<path d="M8 1.8l6.6 11.6H1.4z" fill="none" stroke="#F2C069" stroke-width="1.4" stroke-linejoin="round"/><path d="M8 6.5v3.2M8 11.4v.2" stroke="#F2C069" stroke-width="1.5" stroke-linecap="round"/>`
      ]
    };
    const [size, body] = paths[name];
    svg.setAttribute("width", size);
    svg.setAttribute("height", size);
    svg.setAttribute("viewBox", `0 0 ${size} ${size}`);
    svg.innerHTML = body;
    return svg;
  }
  function withMono(text) {
    const out = [];
    const pattern = /\$?\d[\d,]*(?:\.\d+)?(?: ?(?:USDC|SOL|%|bytes))?/g;
    let last2 = 0;
    for (const match of text.matchAll(pattern)) {
      if (match.index > last2) out.push(text.slice(last2, match.index));
      out.push(el("span", "mono", match[0]));
      last2 = match.index + match[0].length;
    }
    if (last2 < text.length) out.push(text.slice(last2));
    return out;
  }
  const INSTALL_LINKS = [
    { name: "Phantom", url: "https://phantom.com" },
    { name: "Solflare", url: "https://solflare.com" },
    { name: "Backpack", url: "https://backpack.app" },
    { name: "Jupiter", url: "https://jup.ag/mobile" }
  ];
  function walletIcon(info, className = "wallet-icon") {
    if (info.icon) {
      const img = document.createElement("img");
      img.className = className;
      img.src = info.icon;
      img.alt = "";
      img.width = 20;
      img.height = 20;
      return img;
    }
    return el("span", `${className} wallet-initial`, info.name.slice(0, 1).toUpperCase());
  }
  function pickWallet(container, wallets) {
    return new Promise((resolve) => {
      const panel = el("div", "wallet-picker");
      panel.setAttribute("role", "dialog");
      panel.setAttribute("aria-label", "Choose a wallet");
      const finish = (name) => {
        panel.remove();
        resolve(name);
      };
      if (wallets.length === 0) {
        panel.append(el("p", "wallet-picker-title", "No Solana wallet found"));
        panel.append(el("p", "note", "Install one, then reload this page."));
        const links = el("div", "wallet-picker-links");
        for (const { name, url } of INSTALL_LINKS) {
          const link = el("a", "link ext", name);
          link.href = url;
          link.target = "_blank";
          link.rel = "noopener noreferrer";
          links.append(link);
        }
        panel.append(links);
      } else {
        panel.append(el("p", "wallet-picker-title", "Choose a wallet"));
        const list = el("div", "wallet-picker-list");
        for (const info of wallets) {
          const row = button("", "wallet-option", () => finish(info.name));
          row.append(walletIcon(info), el("span", "wallet-option-name", info.name));
          list.append(row);
        }
        panel.append(list);
      }
      panel.append(button("Cancel", "ghost centered", () => finish(null)));
      container.append(panel);
      panel.scrollIntoView({ block: "nearest" });
      panel.querySelector(".wallet-option, .ghost")?.focus({ preventScroll: true });
    });
  }
  const ORB_SIZE = 56;
  const ORB_MARGIN = 20;
  const CARD_WIDTH = 340;
  const CARD_GAP = 12;
  const EDGE_PADDING = 8;
  const FONT_SERIF = "Soothia Lora";
  const FONT_SANS = "Soothia Inter";
  const FONT_MONO = "Soothia JetBrains Mono";
  const HOST_STYLES = {
    all: "initial",
    position: "fixed",
    top: "0",
    left: "0",
    width: "0",
    height: "0",
    "z-index": "2147483647",
    display: "block",
    "pointer-events": "none"
  };
  const CHEVRON = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 10 10'%3E%3Cpath d='M2 4l3 3 3-3' stroke='%23A9A5BD' stroke-width='1.4' fill='none'/%3E%3C/svg%3E")`;
  const STYLES = `
:host {
  all: initial;

  --sth-orb-core: #F4F1FF;
  --sth-orb-mid:  #AFA9EC;
  --sth-orb-edge: #7F77DD;
  --sth-orb-deep: #534AB7;
  --sth-orb-fill: radial-gradient(circle at 38% 34%, #FFFFFF 0%, #F4F1FF 24%, #D6D1F6 52%, #AFA9EC 76%, #7F77DD 100%);
  --sth-orb-fill-bright: radial-gradient(circle at 38% 34%, #FFFFFF 0%, #F8F6FF 30%, #DFDAF9 56%, #B8B2F0 78%, #8A82E4 100%);
  --sth-orb-glow: 0 0 16px 2px rgba(127,119,221,.42), 0 0 40px 6px rgba(83,74,183,.26);
  --sth-orb-glow-bright: 0 0 22px 6px rgba(175,169,236,.7), 0 0 60px 14px rgba(127,119,221,.45);
  --sth-orb-edge-light: 0 2px 10px rgba(14,13,20,.35);
  --sth-chrome: linear-gradient(135deg, #FFFFFF 0%, #D3D1DE 34%, #6F6C82 50%, #F3F2F8 64%, #8E8BA0 100%);

  --sth-ink: #000000;
  /* Pure black surfaces; raised elements sit one level up so hierarchy survives. */
  --sth-surface: #000000;
  --sth-raised: #0B0B0F;
  --sth-raised-hover: #121218;
  --sth-surface-2: var(--sth-raised);
  --sth-surface-3: rgba(175,169,236,.10);
  --sth-hairline: rgba(175,169,236,.22);
  --sth-hairline-soft: rgba(175,169,236,.14);
  /* X dark mode is also pure black: the hairline and violet glow separate the card from the page. */
  --sth-shadow: 0 0 0 1px rgba(127,119,221,.12), 0 12px 40px rgba(83,74,183,.28), 0 24px 60px -12px rgba(0,0,0,.65);
  --sth-blur: blur(18px) saturate(140%);

  --sth-text: #F5F0E6;
  --sth-text-2: #A9A5BD;
  --sth-text-3: #8C88A0;
  --sth-text-on-orb: #16131F;
  --sth-link: #CFCAF6;

  --sth-yes: #5DCAA5;  --sth-yes-bg: rgba(93,202,165,.12);
  --sth-no:  #F0997B;  --sth-no-bg:  rgba(240,153,123,.12);
  --sth-warn: #F2C069; --sth-warn-bg: rgba(242,192,105,.10);
  --sth-focus: #F4F1FF;

  --sth-font-serif: "${FONT_SERIF}", "Lora", Georgia, serif;
  --sth-font-sans: "${FONT_SANS}", "Inter", system-ui, -apple-system, sans-serif;
  --sth-font-mono: "${FONT_MONO}", "JetBrains Mono", ui-monospace, Menlo, monospace;

  --sth-r-card: 20px; --sth-r-tile: 14px;
  --sth-r-field: 12px; --sth-r-pill: 999px;
  --sth-space-1: 4px; --sth-space-2: 8px; --sth-space-3: 12px;
  --sth-space-4: 16px; --sth-space-5: 24px;
  --sth-target: 32px;
  --sth-card-w: ${CARD_WIDTH}px; --sth-orb: ${ORB_SIZE}px;

  --sth-breathe: 4.8s; --sth-shimmer: 9s;
  --sth-think: 1.1s;   --sth-twinkle: .6s;
  --sth-pulse: .9s;    --sth-ease: cubic-bezier(.2,.7,.2,1);
}

*, *::before, *::after {
  box-sizing: border-box;
}

:host :focus-visible {
  outline: 2px solid var(--sth-focus);
  outline-offset: 2px;
}

@keyframes sthBreathe {
  0%, 100% { box-shadow: 0 0 16px 2px rgba(127,119,221,.42), 0 0 40px 6px rgba(83,74,183,.26); }
  50% { box-shadow: 0 0 24px 5px rgba(127,119,221,.6), 0 0 60px 12px rgba(83,74,183,.36); }
}
@keyframes sthBreatheBright {
  0%, 100% { box-shadow: 0 0 22px 6px rgba(175,169,236,.7), 0 0 60px 14px rgba(127,119,221,.45); }
  50% { box-shadow: 0 0 30px 9px rgba(175,169,236,.85), 0 0 80px 20px rgba(127,119,221,.55); }
}
@keyframes sthShimmer {
  0% { transform: translate(-14%, -10%) rotate(0deg); }
  50% { transform: translate(10%, 8%) rotate(180deg); }
  100% { transform: translate(-14%, -10%) rotate(360deg); }
}
@keyframes sthSpin { to { transform: rotate(360deg); } }
@keyframes sthTwinkle {
  0% { transform: scale(0) rotate(-45deg); opacity: 0; }
  60% { transform: scale(1.25) rotate(8deg); opacity: 1; }
  100% { transform: scale(1) rotate(0deg); opacity: 1; }
}
@keyframes sthPulse {
  0% { transform: scale(1); opacity: .7; }
  100% { transform: scale(2.4); opacity: 0; }
}
@keyframes sthCardIn {
  from { opacity: 0; transform: translateY(4px); }
  to { opacity: 1; transform: translateY(0); }
}

/* ---------- Orb (orb.idle / orb.thinking / orb.found / orb.success) ---------- */

.orb {
  position: fixed;
  width: var(--sth-orb);
  height: var(--sth-orb);
  padding: 0;
  border: none;
  background: transparent;
  cursor: grab;
  pointer-events: auto;
  touch-action: none;
  user-select: none;
  -webkit-user-select: none;
  transition: transform 150ms var(--sth-ease);
}
.orb:hover { transform: scale(1.04); }
.orb.dragging { cursor: grabbing; transform: scale(.96); transition: none; }

.orb-body {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  overflow: hidden;
  background: var(--sth-orb-fill);
  box-shadow: var(--sth-orb-glow);
  animation: sthBreathe var(--sth-breathe) ease-in-out infinite;
}
.orb-shimmer {
  position: absolute;
  inset: -20%;
  background:
    radial-gradient(circle at 30% 30%, rgba(255,255,255,.75) 0%, rgba(255,255,255,0) 32%),
    radial-gradient(circle at 72% 70%, rgba(127,119,221,.35) 0%, rgba(127,119,221,0) 36%);
  animation: sthShimmer var(--sth-shimmer) ease-in-out infinite;
}
/* The chrome glint on the upper-right rim: part of the mark, always on. */
.orb-glint {
  position: absolute;
  right: -6px;
  top: -8px;
  width: 22px;
  height: 22px;
  pointer-events: none;
}
.orb-glint svg, .star svg { display: block; width: 100%; height: 100%; }

.orb-arc {
  position: absolute;
  inset: -7px;
  border-radius: 50%;
  border: 1.5px solid transparent;
  border-top-color: var(--sth-text);
  border-right-color: rgba(245,240,230,.35);
  opacity: 0;
  pointer-events: none;
}
.orb[data-state="thinking"] .orb-arc {
  opacity: 1;
  animation: sthSpin var(--sth-think) linear infinite;
}
/* Ivory vanishes on a white page: the arc goes deep violet there. */
:host([data-theme="light"]) .orb-arc {
  border-top-color: var(--sth-orb-deep);
  border-right-color: rgba(83,74,183,.35);
}

.orb[data-state="found"] .orb-body {
  background: var(--sth-orb-fill-bright);
  animation: sthBreatheBright 3.2s ease-in-out infinite;
}
.orb-stars { position: absolute; inset: 0; pointer-events: none; }
.orb-stars .star {
  position: absolute;
  transform-origin: 50% 50%;
  animation: sthTwinkle var(--sth-twinkle) var(--sth-ease) both;
}
.orb-stars .star:nth-child(1) { left: -22px; top: -10px; width: 16px; height: 16px; }
.orb-stars .star:nth-child(2) { left: -34px; top: 16px; width: 12px; height: 12px; animation-delay: .12s; }
.orb-stars .star:nth-child(3) { left: 4px; top: -30px; width: 13px; height: 13px; animation-delay: .24s; }

.orb-pulse {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(244,241,255,.9) 0%, rgba(175,169,236,.4) 60%, rgba(175,169,236,0) 72%);
  opacity: 0;
  pointer-events: none;
}
.orb.success .orb-pulse { animation: sthPulse var(--sth-pulse) var(--sth-ease) both; }
.orb.success .orb-body { animation: sthBreatheBright 1.2s ease-in-out; }

/* On light pages the orb's edge needs help, and the stars a drop shadow. */
:host([data-theme="light"]) .orb-body {
  box-shadow: var(--sth-orb-glow), var(--sth-orb-edge-light), inset 0 0 0 1px rgba(83,74,183,.35);
  animation: none;
}
:host([data-theme="light"]) .orb[data-state="found"] .orb-body {
  box-shadow: var(--sth-orb-glow-bright), var(--sth-orb-edge-light), inset 0 0 0 1px rgba(83,74,183,.35);
}
:host([data-theme="light"]) .orb-stars .star,
:host([data-theme="light"]) .orb-glint { filter: drop-shadow(0 1px 1px rgba(14,13,20,.5)); }

/* ---------- Card ---------- */

.card {
  position: fixed;
  width: var(--sth-card-w);
  max-width: calc(100vw - ${EDGE_PADDING * 2}px);
  max-height: calc(100vh - ${EDGE_PADDING * 2}px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--sth-hairline);
  border-radius: var(--sth-r-card);
  background: var(--sth-surface);
  -webkit-backdrop-filter: var(--sth-blur);
  backdrop-filter: var(--sth-blur);
  box-shadow: var(--sth-shadow);
  color: var(--sth-text);
  font: 400 14px/1.45 var(--sth-font-sans);
  text-align: left;
  overflow: hidden;
  pointer-events: auto;
  animation: sthCardIn 140ms var(--sth-ease);
}
.card[hidden] { display: none; }

/* Card stars: tiny chrome four-point stars in empty corners, under all content. */
.card-stars { position: absolute; inset: 0; z-index: -1; pointer-events: none; overflow: hidden; }
.card-star { position: absolute; width: 10px; height: 10px; opacity: var(--rest, .45); animation: sthCardTwinkle 4.5s ease-in-out infinite; }
.card-star svg { display: block; width: 100%; height: 100%; overflow: visible; }
.card-star:nth-child(1) { right: 16px; top: 12px; width: 11px; height: 11px; --rest: .5; animation-duration: 3.8s; animation-delay: .4s; }
.card-star:nth-child(2) { right: 36px; top: 30px; width: 8px; height: 8px; --rest: .35; animation-duration: 5.6s; animation-delay: 2.1s; }
.card-star:nth-child(3) { left: 12px; bottom: 14px; width: 10px; height: 10px; --rest: .45; animation-duration: 4.4s; animation-delay: 1.3s; }
.card-star:nth-child(4) { right: 14px; bottom: 12px; width: 12px; height: 12px; --rest: .6; animation-duration: 5.9s; animation-delay: 3.2s; }
.card-star:nth-child(5) { right: 40px; bottom: 30px; width: 8px; height: 8px; --rest: .3; animation-duration: 3.4s; animation-delay: .9s; }
.card-star:nth-child(6) { right: 8px; top: 48%; width: 9px; height: 9px; --rest: .4; animation-duration: 6s; animation-delay: 2.7s; }
/* Sheets are narrow and busy: keep three. */
.card:has(.has-sheet) .card-star:nth-child(n+4) { display: none; }
@keyframes sthCardTwinkle { 0%,70%,100% { opacity: var(--rest, .45); transform: scale(1); filter: none; } 85% { opacity: .8; transform: scale(1.25) rotate(8deg); filter: drop-shadow(0 0 4px rgba(244,241,255,.8)); } }

.card-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex: none;
  padding: 14px 12px 12px 16px;
}
.brand { display: flex; align-items: center; gap: 10px; }
.mark { position: relative; width: 20px; height: 20px; flex: none; }
.mark-body {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: var(--sth-orb-fill);
  box-shadow: 0 0 8px rgba(127,119,221,.6);
}
.mark .star { position: absolute; right: -4px; top: -5px; width: 11px; height: 11px; }
.wordmark { font: 500 18px/1 var(--sth-font-serif); color: var(--sth-text); }
.close {
  width: 32px;
  height: 32px;
  border: 0;
  border-radius: 10px;
  background: transparent;
  color: var(--sth-text-2);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}
.close:hover { background: var(--sth-surface-3); color: var(--sth-text); }
.close svg { display: block; }
.head-actions { display: flex; align-items: center; gap: 2px; }

/* First-run speech bubble, attached to the orb. */
.bubble {
  position: fixed;
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 12px 10px 12px 14px;
  border: 1px solid var(--sth-hairline);
  border-radius: 14px;
  background: var(--sth-raised);
  box-shadow: var(--sth-shadow);
  color: var(--sth-text);
  pointer-events: auto;
  animation: sthCardIn 400ms var(--sth-ease);
}
.bubble[hidden] { display: none; }
.bubble::after {
  content: "";
  position: absolute;
  width: 10px;
  height: 10px;
  background: var(--sth-raised);
  border-right: 1px solid var(--sth-hairline);
  border-bottom: 1px solid var(--sth-hairline);
}
.bubble[data-side="left"]::after { right: -6px; top: calc(50% - 5px); transform: rotate(-45deg); }
.bubble[data-side="above"]::after { bottom: -6px; right: 22px; transform: rotate(45deg); }
.bubble[data-side="below"]::after { top: -6px; right: 22px; transform: rotate(-135deg); }
.bubble-text { margin: 0; font: 400 14px/1.45 var(--sth-font-serif); }
.bubble-close {
  flex: none;
  width: 24px;
  height: 24px;
  margin: -4px -2px 0 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--sth-text-2);
  cursor: pointer;
}
.bubble-close:hover { background: var(--sth-surface-3); color: var(--sth-text); }
.bubble-close svg { display: block; margin: auto; width: 11px; height: 11px; }

.replay { display: flex; flex-wrap: wrap; gap: 4px 14px; margin: 4px 0 6px; }
.replay .link { min-height: 26px; }

.tabs {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4px;
  flex: none;
  margin: 0 16px 12px;
  padding: 3px;
  border: 1px solid var(--sth-hairline-soft);
  border-radius: var(--sth-r-pill);
  background: var(--sth-surface-2);
}
.tab {
  height: 32px;
  border: 0;
  border-radius: var(--sth-r-pill);
  background: transparent;
  color: var(--sth-text-2);
  font: 500 13px/1 var(--sth-font-sans);
  cursor: pointer;
}
.tab.selected { background: var(--sth-raised-hover); color: var(--sth-text); }

.body {
  flex: 1 1 auto;
  min-height: 0;
  overflow-y: auto;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.body[hidden] { display: none; }
/* While a sheet is open the body stops scrolling: the sheet's form scrolls
   under its own fixed footer instead (review-sheet: "button sticks to the bottom"). */
.body.has-sheet { padding: 0; overflow: hidden; gap: 0; }

/* ---------- Type ---------- */

.line {
  margin: 0;
  color: var(--sth-text-2);
  font: 400 13px/1.5 var(--sth-font-sans);
}
.note, .muted {
  margin: 0;
  color: var(--sth-text-2);
  font: 400 12px/1.5 var(--sth-font-sans);
}
.note:empty, .muted:empty, .status-line:empty, .warn:empty { display: none; }
.mono { font-family: var(--sth-font-mono); }
.status-line { margin: 10px 0 0; color: var(--sth-text); font: 400 13px/1.5 var(--sth-font-sans); }

/* ---------- Buttons (btn.primary / btn.secondary / link) ---------- */

.button {
  height: 36px;
  padding: 0 18px;
  border: 1px solid rgba(175,169,236,.3);
  border-radius: var(--sth-r-pill);
  background: rgba(175,169,236,.08);
  color: var(--sth-text);
  font: 600 13px/1 var(--sth-font-sans);
  cursor: pointer;
  white-space: nowrap;
}
.button { background: var(--sth-raised); }
.button:hover { background: var(--sth-raised-hover); }
.button.primary {
  padding: 0 14px;
  border: 0;
  background: linear-gradient(180deg, #F4F1FF, #C9C3F2);
  color: var(--sth-text-on-orb);
  box-shadow: 0 0 0 1px rgba(255,255,255,.4) inset, 0 4px 14px -4px rgba(127,119,221,.6);
}
.button.primary:hover {
  background: linear-gradient(180deg, #FFFFFF, #D6D1F6);
  box-shadow: 0 6px 20px -4px rgba(175,169,236,.7);
}
.button.wide {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  width: 100%;
  height: 44px;
  font-size: 14px;
}
.button.ext::after { content: " \\2197"; margin-left: 4px; }
.button.wide.primary { box-shadow: 0 0 0 1px rgba(255,255,255,.4) inset, 0 6px 20px -6px rgba(127,119,221,.7); }
.button.small { height: 32px; padding: 0 16px; }
.button.dry {
  border: 1px dashed rgba(175,169,236,.5);
  background: transparent;
  color: var(--sth-link);
  box-shadow: none;
}
.button.dry:hover { background: var(--sth-surface-3); }
.button:disabled, .button[aria-disabled="true"], .button.primary:disabled {
  border: 0;
  background: rgba(175,169,236,.12);
  color: var(--sth-text-3);
  box-shadow: none;
  cursor: not-allowed;
}
a.button { display: inline-flex; align-items: center; justify-content: center; text-decoration: none; }

.link {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-height: 32px;
  padding: 0;
  border: none;
  background: none;
  color: var(--sth-link);
  font: 500 13px/1 var(--sth-font-sans);
  text-decoration: none;
  cursor: pointer;
}
.link:hover { color: var(--sth-text); text-decoration: underline; }
.link.ext::after { content: " \\2197"; }
.link.block { display: flex; margin-top: 4px; }
.link.mono { font: 400 12px/1 var(--sth-font-mono); color: var(--sth-text-2); }
.live-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--sth-yes);
  box-shadow: 0 0 6px var(--sth-yes);
}
.ghost {
  height: 32px;
  padding: 0 10px;
  border: 0;
  border-radius: 10px;
  background: transparent;
  color: var(--sth-text-2);
  font: 500 12px/1 var(--sth-font-sans);
  cursor: pointer;
}
.ghost:hover { color: var(--sth-text); background: var(--sth-surface-3); }

/* ---------- Claim tiles (claim-tile.unmatched / .matched / .own-live) ---------- */

.tile {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 14px;
  border: 1px solid var(--sth-hairline-soft);
  border-radius: var(--sth-r-tile);
  background: var(--sth-raised);
}
.meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
.chip {
  padding: 5px 8px;
  border-radius: var(--sth-r-pill);
  background: var(--sth-raised-hover);
  color: var(--sth-link);
  font: 500 11px/1 var(--sth-font-sans);
  letter-spacing: .06em;
  text-transform: uppercase;
}
.ends { color: var(--sth-text-2); font: 400 11px/1 var(--sth-font-mono); }
.question {
  margin: 0;
  color: var(--sth-text);
  font: 400 17px/1.4 var(--sth-font-serif);
  text-wrap: pretty;
  overflow-wrap: anywhere;
}
.quote {
  margin: 0;
  color: var(--sth-text-2);
  font: italic 400 13px/1.5 var(--sth-font-serif);
  overflow-wrap: anywhere;
}
.actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}
.actions.end { justify-content: flex-end; }
.odds { color: var(--sth-yes); font: 500 15px/1 var(--sth-font-mono); }

/* ---------- Empty / skipped / error (this-page.empty, .skipped, .error) ---------- */

.state {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 14px;
  padding: 36px 12px 40px;
  text-align: center;
}
.state.error { padding: 32px 12px; gap: 16px; }
.state-orb {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: radial-gradient(circle at 38% 34%, #F4F1FF 0%, #AFA9EC 60%, #534AB7 100%);
  opacity: .55;
}
.state.skipped .state-orb { opacity: .35; }
.state.error .state-orb { opacity: .35; box-shadow: 0 0 0 1.5px rgba(240,153,123,.6); }
.state-text { margin: 0; color: var(--sth-text); font: 400 19px/1.4 var(--sth-font-serif); }

/* ---------- Sheets (review-sheet, bet-sheet) ---------- */

.sheet { display: flex; flex-direction: column; flex: 1 1 auto; min-height: 0; }
.sheet-head {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: none;
  padding: 10px 12px;
  border-top: 1px solid var(--sth-hairline-soft);
  border-bottom: 1px solid var(--sth-hairline-soft);
}
.back {
  height: 32px;
  padding: 0 8px;
  border: 0;
  border-radius: 10px;
  background: transparent;
  color: var(--sth-text-2);
  font: 500 13px/1 var(--sth-font-sans);
  cursor: pointer;
}
.back:hover { color: var(--sth-text); background: var(--sth-surface-3); }
.sheet-title { margin: 0 0 0 4px; color: var(--sth-text); font: 500 16px/1 var(--sth-font-serif); }
.form, .outcome {
  display: flex;
  flex-direction: column;
  flex: 1 1 auto;
  min-height: 0;
  gap: 18px;
  padding: 16px;
  overflow-y: auto;
}
.outcome.success ~ .steps { display: none; }
/* Once an outcome shows, the footer button has done its job. */
.outcome:not([hidden]) ~ .sheet-foot { display: none; }
.form[hidden], .outcome[hidden], .steps[hidden] { display: none; }
.sheet-foot {
  flex: none;
  padding: 12px 16px 16px;
  border-top: 1px solid var(--sth-hairline-soft);
}
.sheet-foot:empty { display: none; }
.sheet-foot .status-line { margin: 0 0 10px; }

.field { display: flex; flex-direction: column; gap: 8px; }
.field-label {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  color: var(--sth-text-2);
  font: 500 12px/1.2 var(--sth-font-sans);
}
.counter { color: var(--sth-text-3); font: 400 11px/1 var(--sth-font-mono); }
.counter.over { color: var(--sth-no); font-weight: 500; }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }

.input {
  display: block;
  width: 100%;
  min-height: 40px;
  padding: 0 12px;
  border: 1px solid var(--sth-hairline);
  border-radius: var(--sth-r-field);
  background: var(--sth-surface-2);
  color: var(--sth-text);
  color-scheme: dark;
  font: 500 13px/1.3 var(--sth-font-sans);
}
.input:focus-visible {
  outline: none;
  border-color: rgba(175,169,236,.45);
  box-shadow: 0 0 0 3px rgba(175,169,236,.12);
}
textarea.input {
  padding: 12px;
  font: 400 16px/1.45 var(--sth-font-serif);
  resize: vertical;
}
select.input {
  padding-right: 30px;
  appearance: none;
  -webkit-appearance: none;
  background-image: ${CHEVRON};
  background-repeat: no-repeat;
  background-position: right 10px center;
  cursor: pointer;
}
input[type="date"].input { font-family: var(--sth-font-mono); }
input[type="number"].input { font-family: var(--sth-font-mono); }

/* Market type cards */
.types { display: flex; flex-direction: column; gap: 8px; }
.type {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 12px;
  border: 1px solid rgba(175,169,236,.14);
  border-radius: var(--sth-r-field);
  background: var(--sth-raised);
  cursor: pointer;
}
.type:hover { background: var(--sth-raised-hover); }
.type:has(.type-box:checked) { border-color: var(--sth-orb-mid); background: var(--sth-raised-hover); }
.type-box {
  flex: none;
  width: 16px;
  height: 16px;
  margin: 0;
  appearance: none;
  -webkit-appearance: none;
  border: 1.5px solid var(--sth-text-3);
  border-radius: 50%;
  background: transparent;
  cursor: pointer;
}
.type-box:checked { border-color: var(--sth-focus); background: radial-gradient(circle, #F4F1FF 0 4px, transparent 4.5px); }
.type-text { display: flex; flex-direction: column; gap: 6px; min-width: 0; flex: 1; }
.type-name { display: flex; align-items: center; color: var(--sth-text); font: 600 14px/1 var(--sth-font-sans); }
.type-fee { margin-left: auto; color: var(--sth-text-2); font: 500 13px/1 var(--sth-font-mono); }
.type:has(.type-box:checked) .type-fee { color: var(--sth-text); }
.type-blurb { color: var(--sth-text-2); font: 400 12.5px/1.5 var(--sth-font-sans); }
.type:not(:has(.type-box:checked)) .type-blurb { display: none; }

/* How it resolves */
.rule { border: 1px solid rgba(175,169,236,.14); border-radius: var(--sth-r-field); background: var(--sth-raised); }
.rule-summary {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 40px;
  padding: 0 12px;
  color: var(--sth-text);
  font: 500 13px/1 var(--sth-font-sans);
  list-style: none;
  cursor: pointer;
  user-select: none;
  -webkit-user-select: none;
}
.rule-summary::-webkit-details-marker { display: none; }
.rule-summary::after {
  content: "";
  width: 10px;
  height: 10px;
  background: ${CHEVRON} center / contain no-repeat;
}
.rule[open] .rule-summary::after { transform: rotate(180deg); }
.rule-body { display: flex; flex-direction: column; gap: 10px; padding: 0 12px 12px; }
.sources { display: flex; flex-wrap: wrap; gap: 6px; margin: 0; padding: 0; list-style: none; }
.source a, .source {
  display: inline-block;
  padding: 7px 10px;
  border: 1px solid rgba(175,169,236,.2);
  background: var(--sth-raised-hover);
  border-radius: var(--sth-r-pill);
  color: var(--sth-text);
  font: 400 12px/1 var(--sth-font-mono);
  text-decoration: none;
}
.source a:hover { border-color: rgba(175,169,236,.5); }
.rule-text { margin: 0; color: var(--sth-text-3); font: 400 11.5px/1.5 var(--sth-font-sans); overflow-wrap: anywhere; }

/* Wallet row (wallet-row.connected / .disconnected) */
.wallet {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  border-radius: var(--sth-r-field);
  background: var(--sth-surface-2);
}
.wallet.disconnected { padding: 0; background: transparent; flex-wrap: wrap; }
.wallet .wallet-picker { flex: 1 1 100%; width: 100%; margin-top: 8px; }
.wallet-dot { flex: none; width: 8px; height: 8px; border-radius: 50%; background: var(--sth-yes); }
.wallet-text { display: flex; flex-direction: column; gap: 5px; min-width: 0; }
.wallet-line { display: flex; align-items: center; gap: 2px; min-width: 0; }
.wallet-address { color: var(--sth-text); font: 500 13px/1 var(--sth-font-mono); }
.wallet-holdings { color: var(--sth-text-2); font: 400 11px/1 var(--sth-font-mono); }
.wallet .ghost { margin-left: auto; }
.wallet-icon { flex: none; width: 20px; height: 20px; border-radius: 6px; object-fit: cover; }
.wallet-initial { display: inline-flex; align-items: center; justify-content: center; background: var(--sth-raised-hover); color: var(--sth-text); font: 700 11px/1 var(--sth-font-sans); }
.wallet-name { color: var(--sth-text-2); font: 500 12px/1 var(--sth-font-sans); }

/* Wallet picker */
.wallet-picker { margin-top: 10px; padding: 12px; border: 1px solid var(--sth-hairline); border-radius: 12px; background: var(--sth-raised); display: grid; gap: 8px; }
.wallet-picker-title { margin: 0; color: var(--sth-text); font: 600 13px/1.3 var(--sth-font-sans); }
.wallet-picker-list { display: grid; gap: 6px; }
.wallet-option { display: flex; align-items: center; gap: 10px; width: 100%; padding: 9px 10px; border: 1px solid var(--sth-hairline-soft); border-radius: 10px; background: transparent; color: var(--sth-text); font: 500 13px/1 var(--sth-font-sans); text-align: left; cursor: pointer; }
.wallet-option:hover, .wallet-option:focus-visible { background: var(--sth-raised-hover); border-color: var(--sth-orb-mid); }
.wallet-picker-links { display: flex; flex-wrap: wrap; gap: 6px 14px; }
.button.connect {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
  height: 44px;
  border-radius: var(--sth-r-field);
  font-size: 14px;
}
.phantom-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  border-radius: 6px;
  background: #AB9FF2;
  color: var(--sth-text-on-orb);
  font: 700 10px/1 var(--sth-font-sans);
}

/* Fee box */
.fee {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 12px;
  border: 1px solid rgba(175,169,236,.14);
  border-radius: var(--sth-r-field);
  background: var(--sth-raised);
  color: var(--sth-text-2);
  font: 400 13px/1.5 var(--sth-font-sans);
}
.fee:empty { display: none; }
.fee-row { display: flex; justify-content: space-between; gap: 12px; font: 400 12px/1 var(--sth-font-sans); }
.fee-row.total { color: var(--sth-text); font: 500 13px/1 var(--sth-font-sans); }
.fee-row .mono { font-family: var(--sth-font-mono); }

/* Amber warning */
.warn {
  display: flex;
  gap: 10px;
  margin: 0;
  padding: 10px 12px;
  border: 1px solid rgba(242,192,105,.3);
  border-radius: var(--sth-r-field);
  background: var(--sth-warn-bg);
  color: var(--sth-warn);
  font: 400 12.5px/1.5 var(--sth-font-sans);
}
.warn svg { flex: none; margin-top: 1px; }
.warn .mono { font-family: var(--sth-font-mono); }

/* Progress steps (progress-steps) */
.steps {
  display: flex;
  flex: none;
  flex-direction: column;
  gap: 14px;
  margin: 0 16px 16px;
  padding: 16px;
  border: 1px solid var(--sth-hairline);
  border-radius: 16px;
  background: var(--sth-raised);
  list-style: none;
}
.step { display: flex; align-items: center; gap: 12px; color: var(--sth-text-3); font: 500 13px/1 var(--sth-font-sans); }
.step-icon { position: relative; flex: none; width: 20px; height: 20px; }
.step-icon::before {
  content: "";
  position: absolute;
  inset: 1.5px;
  border-radius: 50%;
  border: 1.5px solid rgba(175,169,236,.25);
}
.step[data-state="active"] { color: var(--sth-text); font-weight: 600; }
.step[data-state="active"] .step-icon::before { inset: 0; border-color: rgba(175,169,236,.2); }
.step[data-state="active"] .step-icon::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: 50%;
  border: 1.5px solid transparent;
  border-top-color: var(--sth-text);
  animation: sthSpin var(--sth-think) linear infinite;
}
.step[data-state="done"] { color: var(--sth-text-2); }
.step[data-state="done"] .step-icon::before { inset: 0; border: 0; background: rgba(93,202,165,.16); }
.step[data-state="done"] .step-icon::after {
  content: "";
  position: absolute;
  inset: 0;
  background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 10 10'%3E%3Cpath d='M2 5.2l2 2 4-4.4' stroke='%235DCAA5' stroke-width='1.6' fill='none' stroke-linecap='round'/%3E%3C/svg%3E") center no-repeat;
}
.step[data-state="error"] { color: var(--sth-no); }
.step[data-state="error"] .step-icon::before { inset: 0; border-color: rgba(240,153,123,.6); }

/* ---------- Bet sheet ---------- */

.sides { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.side {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: 68px;
  border: 1px solid var(--sth-hairline);
  border-radius: var(--sth-r-tile);
  background: var(--sth-raised);
  cursor: pointer;
}
.side:hover { background: var(--sth-raised-hover); }
.side-label { color: var(--sth-text-2); font: 600 13px/1 var(--sth-font-sans); letter-spacing: .06em; }
.side-pct { color: var(--sth-text-2); font: 500 22px/1 var(--sth-font-mono); }
.side-yes.selected { border: 1.5px solid var(--sth-yes); background: var(--sth-yes-bg); }
.side-yes.selected .side-label, .side-yes.selected .side-pct { color: var(--sth-yes); }
.side-no.selected { border: 1.5px solid var(--sth-no); background: var(--sth-no-bg); }
.side-no.selected .side-label, .side-no.selected .side-pct { color: var(--sth-no); }

.chips { display: grid; grid-template-columns: 1fr 1fr 1fr 1.6fr; gap: 6px; }
.chip-button {
  height: 40px;
  border: 1px solid var(--sth-hairline);
  border-radius: var(--sth-r-field);
  background: var(--sth-raised);
  color: var(--sth-text);
  font: 500 14px/1 var(--sth-font-mono);
  cursor: pointer;
}
.chip-button:hover { background: var(--sth-raised-hover); }
.chip-button.selected { border-color: var(--sth-orb-mid); background: var(--sth-raised-hover); }
.custom {
  display: flex;
  align-items: center;
  gap: 4px;
  height: 40px;
  padding: 0 10px;
  border: 1px solid var(--sth-hairline);
  border-radius: var(--sth-r-field);
  background: var(--sth-surface-2);
}
.custom:focus-within { border-color: rgba(175,169,236,.45); box-shadow: 0 0 0 3px rgba(175,169,236,.12); }
.custom-sign { color: var(--sth-text-3); font: 500 14px/1 var(--sth-font-mono); }
.custom .input.amount {
  min-height: 0;
  height: 100%;
  padding: 0;
  border: 0;
  background: transparent;
  font: 500 14px/1 var(--sth-font-mono);
  -moz-appearance: textfield;
}
.custom .input.amount::-webkit-outer-spin-button, .custom .input.amount::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
.custom .input.amount::placeholder { color: var(--sth-text-3); font: 400 13px/1 var(--sth-font-sans); }
.custom .input.amount:focus-visible { box-shadow: none; }

.quote-box {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 12px;
  border-radius: var(--sth-r-field);
  background: var(--sth-surface-2);
  color: var(--sth-text);
  font: 400 13px/1.55 var(--sth-font-sans);
}
.quote-box:empty { display: none; }
.quote-box .mono { font-family: var(--sth-font-mono); }
.quote-box .yes { color: var(--sth-yes); }
.quote-box .no { color: var(--sth-no); }
.quote-box .note { color: var(--sth-text-2); }

.button.buy { border: 0; color: var(--sth-ink); }
.button.buy[data-side="yes"] { background: var(--sth-yes); box-shadow: 0 6px 20px -8px rgba(93,202,165,.8); }
.button.buy[data-side="no"] { background: var(--sth-no); box-shadow: 0 6px 20px -8px rgba(240,153,123,.8); }
.button.buy:disabled { background: rgba(175,169,236,.12); color: var(--sth-text-3); box-shadow: none; }

/* ---------- Success (success.market-live / success.bet-placed) ---------- */

.success { padding: 28px 20px 20px; gap: 18px; align-items: stretch; }
.flourish { position: relative; height: 64px; }
.flourish .star {
  position: absolute;
  left: 50%;
  animation: sthTwinkle var(--sth-twinkle) var(--sth-ease) both;
}
.flourish .star:nth-child(1) { top: 0; width: 30px; height: 46px; margin-left: -15px; }
.flourish .star:nth-child(2) { top: 28px; width: 16px; height: 16px; margin-left: -46px; animation-delay: .12s; }
.flourish .star:nth-child(3) { top: 22px; width: 18px; height: 18px; margin-left: 28px; animation-delay: .24s; }
.success-title { margin: 0; color: var(--sth-text); font: 400 26px/1.25 var(--sth-font-serif); text-align: center; }
.success-sub { margin: 0; color: var(--sth-text-2); font: 400 15px/1.45 var(--sth-font-serif); text-align: center; text-wrap: pretty; }
.button-stack { display: flex; flex-direction: column; gap: 8px; }
.button-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.button-grid .button { height: 40px; }
.button-grid .button.tall { height: 44px; font-size: 14px; }
.summary-box {
  padding: 12px;
  border: 1px solid rgba(93,202,165,.25);
  border-radius: var(--sth-r-field);
  background: rgba(93,202,165,.08);
  color: var(--sth-text);
  font: 400 13px/1.55 var(--sth-font-sans);
  text-align: center;
}
.summary-box .mono { font-family: var(--sth-font-mono); }
.summary-box .yes { color: var(--sth-yes); }
.summary-box .no { color: var(--sth-no); }
.summary-box .muted-inline { color: var(--sth-text-2); }
.centered { align-self: center; }

/* ---------- My bets ---------- */

.refresh-row { display: flex; justify-content: flex-end; }
.refresh-row .link { padding: 0 4px; font-size: 12px; }
.positions { display: flex; flex-direction: column; gap: 8px; }
.position { display: flex; align-items: center; gap: 10px; }
.side-chip {
  flex: none;
  width: 28px;
  background: var(--sth-raised-hover);
  padding: 5px 0;
  border-radius: 6px;
  text-align: center;
  font: 600 11px/1 var(--sth-font-sans);
  letter-spacing: .06em;
}
.side-chip-yes { color: var(--sth-yes); background: var(--sth-yes-bg); }
.side-chip-no { color: var(--sth-no); background: var(--sth-no-bg); }
.position-text { color: var(--sth-text); font: 400 13px/1 var(--sth-font-mono); }
.tile.market .question { font-size: 16px; }
.tile.market .actions { margin-top: 8px; gap: 14px; }
.tile.market .actions .link { margin-right: auto; }
.tile.market .actions .link + .link { margin-right: 0; }
.button.copied, .link.copied { color: var(--sth-yes); }
.earnings { margin-top: 10px; padding: 10px 12px; border-radius: 10px; background: var(--sth-raised-hover); display: grid; gap: 4px; }
.earnings-label { margin: 0; color: var(--sth-text-2); font: 600 11px/1 var(--sth-font-sans); letter-spacing: .06em; text-transform: uppercase; }
.earnings-text { margin: 0; }
.earnings .button { justify-self: start; margin-top: 4px; }
.earnings .status-line { margin: 4px 0 0; }

/* Tooltip for the disabled Claim button */
.tip { position: relative; }
.tip::after {
  content: attr(data-tip);
  position: absolute;
  right: 0;
  bottom: calc(100% + 8px);
  padding: 8px 10px;
  border-radius: 8px;
  background: var(--sth-orb-core);
  color: var(--sth-text-on-orb);
  font: 500 12px/1 var(--sth-font-sans);
  white-space: nowrap;
  box-shadow: 0 8px 20px rgba(0,0,0,.4);
  opacity: 0;
  pointer-events: none;
  transition: opacity 120ms var(--sth-ease);
}
.tip::before {
  content: "";
  position: absolute;
  right: 18px;
  bottom: calc(100% + 3px);
  border: 5px solid transparent;
  border-top-color: var(--sth-orb-core);
  opacity: 0;
  pointer-events: none;
}
.tip:hover::after, .tip:focus-within::after, .tip:hover::before, .tip:focus-within::before { opacity: 1; }

/* ---------- Debug footer ---------- */

.debug {
  flex: none;
  padding: 8px 16px 12px;
  border-top: 1px solid rgba(175,169,236,.10);
  color: var(--sth-text-3);
  font: 400 11px/1.7 var(--sth-font-mono);
}
.debug-summary {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 32px;
  list-style: none;
  cursor: pointer;
  user-select: none;
  -webkit-user-select: none;
}
.debug-summary::-webkit-details-marker { display: none; }
.debug-summary::before {
  content: "";
  width: 8px;
  height: 8px;
  background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8' viewBox='0 0 8 8'%3E%3Cpath d='M2 1l4 3-4 3z' fill='%238C88A0'/%3E%3C/svg%3E") center no-repeat;
  transition: transform 120ms var(--sth-ease);
}
.debug[open] .debug-summary::before { transform: rotate(90deg); }
.scan {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 2px 10px;
  margin: 0 0 8px;
}
.scan-name { color: var(--sth-text-3); }
.scan-value { margin: 0; color: var(--sth-text-2); overflow-wrap: anywhere; }
.debug .button.small { margin: 2px 0 8px; font-size: 12px; }
.toggle { display: flex; align-items: center; gap: 8px; padding: 3px 0; color: var(--sth-text-2); cursor: pointer; }
.toggle-box { margin: 0; accent-color: var(--sth-orb-edge); }
.status { display: flex; align-items: center; gap: 10px; padding: 6px 0; }
.dot { flex: none; width: 8px; height: 8px; border-radius: 50%; background: var(--sth-text-3); }
.status[data-state="good"] .dot { background: var(--sth-yes); box-shadow: 0 0 6px rgba(93,202,165,.6); }
.status[data-state="bad"] .dot { background: var(--sth-no); }

@media (prefers-reduced-motion: reduce) {
  :host * { animation: none !important; transition: none !important; }
  /* The thinking arc stays visible and static; found stars render at rest;
     the success pulse is replaced by the found glow for 1.2s. */
  .orb[data-state="thinking"] .orb-arc { opacity: 1; }
  .orb-stars .star, .flourish .star { opacity: 1; transform: none; }
  .orb.success .orb-body { background: var(--sth-orb-fill-bright); box-shadow: var(--sth-orb-glow-bright); }
  .card-star { opacity: .4; transform: none; }
}
`;
  const FACES = [
    { family: FONT_SERIF, file: "fonts/soothia-lora.woff2", style: "normal" },
    { family: FONT_SERIF, file: "fonts/soothia-lora-italic.woff2", style: "italic" },
    { family: FONT_SANS, file: "fonts/soothia-inter.woff2", style: "normal" },
    { family: FONT_MONO, file: "fonts/soothia-jetbrains-mono.woff2", style: "normal" }
  ];
  function loadFonts() {
    if (typeof FontFace === "undefined" || !document.fonts) return;
    for (const face of FACES) {
      try {
        const font = new FontFace(face.family, `url(${chrome.runtime.getURL(face.file)}) format("woff2")`, {
          style: face.style,
          weight: "100 900",
          display: "swap"
        });
        document.fonts.add(font);
        font.load().catch(() => {
        });
      } catch {
      }
    }
  }
  const SYNTH_STYLES = ["musicbox", "celesta", "chimes"];
  const DEFAULT_STYLE = "celesta";
  const MASTER_VOLUME = 0.25;
  const FLOOR = 1e-4;
  const PENDING_MAX_AGE_MS = 1500;
  const REVERB_SECONDS = 1.6;
  let context = null;
  let master = null;
  let reverbSend = null;
  let muted = false;
  let style = DEFAULT_STYLE;
  let last = "–";
  let pending = null;
  const armedRoots = /* @__PURE__ */ new WeakSet();
  const listeners = /* @__PURE__ */ new Set();
  let onPlay = null;
  function notify() {
    const state = getAudioState();
    for (const listener of listeners) listener(state);
  }
  function getAudioState() {
    return { context: context ? context.state : "not created", muted, style, last };
  }
  function onAudioState(listener) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  }
  function impulse(ctx) {
    const length = Math.floor(ctx.sampleRate * REVERB_SECONDS);
    const buffer = ctx.createBuffer(2, length, ctx.sampleRate);
    for (let channel = 0; channel < 2; channel++) {
      const data = buffer.getChannelData(channel);
      let smooth = 0;
      for (let i = 0; i < length; i++) {
        const decay = Math.pow(1 - i / length, 2.6);
        smooth += (Math.random() * 2 - 1 - smooth) * 0.35;
        data[i] = smooth * decay;
      }
    }
    return buffer;
  }
  function ensureContext() {
    if (context) return context;
    try {
      context = new AudioContext();
      master = context.createGain();
      master.gain.value = MASTER_VOLUME;
      master.connect(context.destination);
      const reverb = context.createConvolver();
      reverb.buffer = impulse(context);
      reverbSend = context.createGain();
      reverbSend.gain.value = 0.3;
      reverbSend.connect(reverb).connect(master);
    } catch {
      context = null;
    }
    notify();
    return context;
  }
  function wake() {
    const ctx = ensureContext();
    if (!ctx || ctx.state === "running") return;
    ctx.resume().then(
      () => {
        notify();
        if (pending && Date.now() - pending.at <= PENDING_MAX_AGE_MS) playSound(pending.name);
        pending = null;
      },
      () => {
      }
    );
  }
  function armSounds(root = window) {
    if (armedRoots.has(root)) return;
    armedRoots.add(root);
    for (const type of ["pointerdown", "keydown", "touchstart"]) {
      root.addEventListener(type, wake, { capture: true, passive: true });
    }
  }
  function setMuted(value) {
    muted = value;
    notify();
  }
  function isMuted() {
    return muted;
  }
  function setStyle(value) {
    style = value;
    notify();
  }
  const PENTATONIC = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21];
  const C6 = 1046.5;
  function pitch(degree) {
    return C6 * Math.pow(2, PENTATONIC[Math.max(0, Math.min(PENTATONIC.length - 1, degree))] / 12);
  }
  const humanSeconds = () => (Math.random() * 2 - 1) * 0.012;
  const cents = () => (Math.random() * 2 - 1) * 8;
  const TIMBRES = {
    // Plucked, delicate, short, a touch of tine brightness.
    musicbox: { ratios: [1, 2.76, 5.4, 8.93], gains: [1, 0.42, 0.18, 0.06], partialDecay: [1, 0.55, 0.3, 0.18], attack: 4e-3, decay: 0.42, reverb: 0.25, dust: false },
    // Brighter, clear bells.
    celesta: { ratios: [1, 2.76, 5.4, 8.93], gains: [1, 0.55, 0.3, 0.12], partialDecay: [1, 0.6, 0.35, 0.2], attack: 8e-3, decay: 0.7, reverb: 0.32, dust: true },
    // Airy, dreamy, lots of shimmer.
    chimes: { ratios: [1, 2.76, 5.4, 8.93], gains: [1, 0.5, 0.35, 0.16], partialDecay: [1, 0.7, 0.5, 0.35], attack: 0.012, decay: 1.4, reverb: 0.45, dust: true }
  };
  function bell(ctx, out, timbre, freq, at, gain, length, bright) {
    const detune = cents();
    const start = Math.max(ctx.currentTime, at + humanSeconds());
    for (const [index, ratio] of timbre.ratios.entries()) {
      const partialGain = gain * timbre.gains[index] * (index === 0 ? 1 : bright);
      if (partialGain < 4e-3) continue;
      const decay = timbre.decay * length * timbre.partialDecay[index];
      const env = ctx.createGain();
      env.gain.setValueAtTime(FLOOR, start);
      env.gain.linearRampToValueAtTime(partialGain, start + timbre.attack);
      env.gain.exponentialRampToValueAtTime(FLOOR, start + timbre.attack + decay);
      env.connect(out);
      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.value = freq * ratio;
      osc.detune.value = detune;
      osc.connect(env);
      osc.start(start);
      osc.stop(start + timbre.attack + decay + 0.05);
    }
  }
  function dust(ctx, out, timbre, at) {
    const count = 3 + Math.floor(Math.random() * 4);
    for (let i = 0; i < count; i++) {
      const degree = 6 + Math.floor(Math.random() * 4);
      bell(ctx, out, timbre, pitch(degree), at + Math.random() * 0.25, 0.05, 0.35, 0.5);
    }
  }
  const PHRASES = {
    // Three notes rising, like a star appearing: G6 C7 E7.
    found: [{ degree: 3, at: 0 }, { degree: 5, at: 0.09 }, { degree: 7, at: 0.18, gain: 0.8 }],
    // One tiny bell: A6.
    open: [{ degree: 4, at: 0, gain: 0.7, length: 0.7 }],
    // C6 D6 E6 G6 A6 C7, then a bright E7 with sparkle.
    marketLive: [
      { degree: 0, at: 0 },
      { degree: 1, at: 0.11 },
      { degree: 2, at: 0.22 },
      { degree: 3, at: 0.33 },
      { degree: 4, at: 0.44 },
      { degree: 5, at: 0.55, gain: 0.9 },
      { degree: 7, at: 0.7, gain: 0.8, length: 1.3 }
    ],
    // Root, major third, fifth: C6 E6 G6, warm.
    betPlaced: [{ degree: 0, at: 0, bright: 0.5, length: 1.2 }, { degree: 2, at: 0.18, bright: 0.5, length: 1.2 }, { degree: 3, at: 0.36, bright: 0.55, length: 1.5 }],
    // Two soft bells stepping down, an octave below the main register.
    softError: [{ degree: 1, at: 0, gain: 0.55, bright: 0.35, length: 1.1 }, { degree: 0, at: 0.28, gain: 0.5, bright: 0.3, length: 1.4 }]
  };
  const OCTAVE = { softError: 0.5 };
  function synth(ctx, name, timbre, into, send) {
    const dry = ctx.createGain();
    dry.gain.value = 1;
    dry.connect(into);
    const wet = ctx.createGain();
    wet.gain.value = timbre.reverb;
    wet.connect(send);
    const out = ctx.createGain();
    out.connect(dry);
    out.connect(wet);
    const now = ctx.currentTime + 0.02;
    const octave = OCTAVE[name] ?? 1;
    let end = 0;
    for (const note of PHRASES[name]) {
      bell(ctx, out, timbre, pitch(note.degree) * octave, now + note.at, (note.gain ?? 0.6) * 0.5, note.length ?? 1, note.bright ?? 1);
      end = Math.max(end, note.at);
    }
    if (timbre.dust && (name === "found" || name === "marketLive")) dust(ctx, out, timbre, now + end);
  }
  const fileBuffers = /* @__PURE__ */ new Map();
  function fileUrl(name, ext) {
    return typeof chrome !== "undefined" && chrome.runtime?.getURL ? chrome.runtime.getURL(`sfx/${name}.${ext}`) : `sfx/${name}.${ext}`;
  }
  async function playFile(ctx, name) {
    if (!master) return false;
    if (!fileBuffers.has(name)) {
      fileBuffers.set(name, null);
      for (const ext of ["mp3", "wav"]) {
        try {
          const response = await fetch(fileUrl(name, ext));
          if (!response.ok) continue;
          fileBuffers.set(name, await ctx.decodeAudioData(await response.arrayBuffer()));
          break;
        } catch {
        }
      }
    }
    const buffer = fileBuffers.get(name);
    if (!buffer) return false;
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(master);
    source.start();
    return true;
  }
  function playSound(name, override) {
    const chosen = style;
    try {
      if (muted) {
        last = `${name} skipped: muted`;
        notify();
        return;
      }
      const ctx = ensureContext();
      if (!ctx || !master || !reverbSend) {
        last = `${name} skipped: no audio`;
        notify();
        return;
      }
      if (ctx.state !== "running") {
        pending = { name, at: Date.now() };
        last = `${name} queued: ${ctx.state}`;
        notify();
        return;
      }
      onPlay?.();
      if (chosen === "files") {
        const into = master;
        const send = reverbSend;
        void playFile(ctx, name).then((played) => {
          if (!played) synth(ctx, name, TIMBRES[DEFAULT_STYLE], into, send);
        });
      } else {
        synth(ctx, name, TIMBRES[chosen], master, reverbSend);
      }
      last = `${name} (${chosen})`;
      notify();
    } catch {
      last = `${name} failed`;
      notify();
    }
  }
  const WALLET_STATUS = "soothia:v1:wallet-status";
  const WALLET_REQUEST = "soothia:v1:wallet-request";
  const HEALTH_REQUEST = "soothia:v1:health";
  const NAV_CHANGED = "soothia:v1:nav-changed";
  const DETECT_REQUEST = "soothia:v1:detect";
  const WALLET_RPC_REQUEST = "soothia:v1:wallet-rpc";
  const WALLET_RPC_RESPONSE = "soothia:v1:wallet-rpc-result";
  const API_REQUEST = "soothia:v1:api";
  const INJECT_SIGNER = "soothia:v1:inject-signer";
  const IMAGE_REQUEST = "soothia:v1:image";
  const OPEN_WELCOME = "soothia:v1:open-welcome";
  const TWEET = 'article[data-testid="tweet"]';
  const TEXT = [
    '[data-testid="tweetText"]',
    '[data-testid="twitterArticleRichTextView"]',
    '[data-testid="longformRichTextComponent"]'
  ].join(",");
  function statusIdFromPath(pathname) {
    return /\/status(?:es)?\/(\d+)/.exec(pathname)?.[1] ?? null;
  }
  function permalinkId(href) {
    return /\/status\/(\d+)(?:[/?#]|$)/.exec(href ?? "")?.[1] ?? null;
  }
  function permalinkTime(article, statusId) {
    for (const link of article.querySelectorAll("a[href]")) {
      const time = link.querySelector("time");
      if (!time) continue;
      if (!statusId || permalinkId(link.getAttribute("href")) === statusId) return time;
    }
    return null;
  }
  function findFocalTweet(root, statusId) {
    for (const article of root.querySelectorAll(TWEET)) {
      if (permalinkTime(article, statusId)) return article;
    }
    return root.querySelector(`[data-testid="primaryColumn"] ${TWEET}`);
  }
  function renderedText(node) {
    let out = "";
    for (const child of node.childNodes) {
      if (child.nodeType === 3) out += child.nodeValue ?? "";
      else if (child.nodeType !== 1) continue;
      else if (child.tagName === "IMG") out += child.getAttribute("alt") ?? "";
      else if (child.tagName === "BR") out += "\n";
      else out += renderedText(child);
    }
    return out;
  }
  function readTweetArticle(article, statusId) {
    const body = article.querySelector(TEXT);
    if (!body) return null;
    const text = renderedText(body).replace(/[ \t]+/g, " ").replace(/\s*\n\s*/g, "\n").trim();
    if (!text) return null;
    const handle = /@\w{1,15}/.exec(article.querySelector('[data-testid="User-Name"]')?.textContent ?? "")?.[0] ?? null;
    const time = statusId && permalinkTime(article, statusId) || permalinkTime(article) || article.querySelector("time");
    return { handle, postedAt: time?.getAttribute("datetime") ?? null, text };
  }
  const TEXT_MAX_CHARS = 4e3;
  const MIN_ARTICLE_CHARS = 200;
  const MIN_TWEET_CHARS = 30;
  const MIN_PARAGRAPH_CHARS = 60;
  function isSkippedLocation() {
    if (location.protocol !== "http:" && location.protocol !== "https:") return true;
    const host = location.hostname;
    return host === "localhost" || host.endsWith(".localhost") || host === "0.0.0.0" || host === "[::1]" || /^127\./.test(host);
  }
  function clean(text) {
    return (text ?? "").replace(/\s+/g, " ").trim();
  }
  function isVisible(element) {
    return element.getClientRects().length > 0;
  }
  function isX() {
    return /(^|\.)(x|twitter)\.com$/.test(location.hostname);
  }
  function mainTweet() {
    const statusId = statusIdFromPath(location.pathname);
    if (statusId) {
      const article = findFocalTweet(document, statusId);
      return article && { article, statusId };
    }
    const articles = [...document.querySelectorAll('article[data-testid="tweet"]')].filter(isVisible);
    if (articles.length === 0) return null;
    const middle = window.innerHeight / 2;
    const distance = (article) => {
      const rect = article.getBoundingClientRect();
      return Math.abs(rect.top + rect.height / 2 - middle);
    };
    return { article: articles.reduce((best, article) => distance(article) < distance(best) ? article : best) };
  }
  function readTweet() {
    const main = mainTweet();
    if (!main) return "no tweet on the page yet";
    const tweet = readTweetArticle(main.article, main.statusId);
    if (!tweet) return "tweet has no text";
    if (tweet.text.length < MIN_TWEET_CHARS) return `tweet text is ${tweet.text.length} chars, need ${MIN_TWEET_CHARS}`;
    const who = tweet.handle ?? "unknown author";
    const posted = tweet.postedAt ? ` (posted ${tweet.postedAt.slice(0, 10)})` : "";
    return {
      title: tweet.handle ? `Post by ${tweet.handle} on X` : "Post on X",
      text: `${who}${posted}: ${tweet.text}`
    };
  }
  const CHROME_SELECTOR = [
    "nav",
    "footer",
    "aside",
    "form",
    "dialog",
    "figure",
    '[role="navigation"]',
    '[role="banner"]',
    '[role="contentinfo"]',
    '[role="complementary"]',
    '[role="dialog"]',
    '[role="alertdialog"]',
    '[aria-hidden="true"]'
  ].join(",");
  const NOISE_NAME = /cookie|consent|gdpr|advert|sponsor|promo|newsletter|subscribe|paywall|sidebar|comment|related|share|social|breadcrumb|(^|[\s_-])ads?($|[\s_-])/i;
  function isNoise(paragraph) {
    if (paragraph.closest(CHROME_SELECTOR)) return true;
    let node = paragraph;
    for (let depth = 0; node && depth < 5; depth++, node = node.parentElement) {
      if (NOISE_NAME.test(`${node.id} ${node.getAttribute("class") ?? ""}`)) return true;
    }
    return false;
  }
  function paragraphsIn(root) {
    const out = [];
    for (const element of root.querySelectorAll("p")) {
      const text = clean(element.textContent);
      if (text.length < MIN_PARAGRAPH_CHARS || !isVisible(element) || isNoise(element)) continue;
      out.push({ element, text });
    }
    return out;
  }
  function totalLength(paragraphs) {
    return paragraphs.reduce((sum, paragraph) => sum + paragraph.text.length, 0);
  }
  function articleParagraphs() {
    let best = [];
    for (const article of document.querySelectorAll("article")) {
      const found = paragraphsIn(article);
      if (totalLength(found) > totalLength(best)) best = found;
    }
    if (totalLength(best) >= MIN_ARTICLE_CHARS) return best.map((paragraph) => paragraph.text);
    const all = paragraphsIn(document.querySelector('main, [role="main"]') ?? document.body);
    const byParent = /* @__PURE__ */ new Map();
    for (const paragraph of all) {
      const parent = paragraph.element.parentElement;
      byParent.set(parent, [...byParent.get(parent) ?? [], paragraph]);
    }
    let largest = [];
    for (const group of byParent.values()) {
      if (totalLength(group) > totalLength(largest)) largest = group;
    }
    const chosen = totalLength(largest) >= MIN_ARTICLE_CHARS ? largest : all;
    return chosen.map((paragraph) => paragraph.text);
  }
  function headline() {
    for (const h1 of document.querySelectorAll("h1")) {
      const text = clean(h1.textContent);
      if (text && isVisible(h1)) return text;
    }
    const og = document.querySelector('meta[property="og:title"]')?.content;
    return clean(og) || clean(document.title);
  }
  function readArticle() {
    const body = articleParagraphs().join("\n");
    if (body.length < MIN_ARTICLE_CHARS) return `article text is ${body.length} chars, need ${MIN_ARTICLE_CHARS}`;
    const title = headline();
    return { title, text: title ? `${title}

${body}` : body };
  }
  function readPage() {
    const site = location.hostname.replace(/^www\./, "");
    if (isSkippedLocation()) {
      return { kind: "skip", reason: "local or non-web page", info: { site, chars: 0, preview: "" } };
    }
    const found = isX() ? readTweet() : readArticle();
    if (typeof found === "string") return { kind: "thin", reason: found, info: { site, chars: 0, preview: "" } };
    const text = found.text.slice(0, TEXT_MAX_CHARS);
    return {
      kind: "page",
      info: { site, chars: text.length, preview: text.slice(0, 80) },
      page: { url: location.href.split("#")[0], site, title: found.title.slice(0, 300), text }
    };
  }
  const CATEGORIES = [
    "sports",
    "crypto",
    "politics",
    "entertainment",
    "finance",
    "science",
    "world",
    "other"
  ];
  const QUESTION_MAX_LENGTH = 200;
  const MIN_END_LEAD_MS = 2 * 3600 * 1e3;
  const MAX_END_HORIZON_MS = 365 * 24 * 3600 * 1e3;
  const MIN_SOL_FOR_CREATE = 0.02;
  const DEFAULT_MARKET_TYPE = "breaking";
  const DEFAULT_BUY_WINDOW_HOURS = 48;
  const BREAKING_MAX_BUY_WINDOW_HOURS = 72;
  const BUY_WINDOW_CHOICES = [
    { hours: 1, label: "In 1 hour" },
    { hours: 6, label: "In 6 hours" },
    { hours: 12, label: "In 12 hours" },
    { hours: 24, label: "In 24 hours" },
    { hours: 48, label: "In 2 days" },
    { hours: 72, label: "In 3 days" },
    { hours: 24 * 7, label: "In 1 week" },
    { hours: 24 * 14, label: "In 2 weeks" },
    { hours: 24 * 30, label: "In 30 days" }
  ];
  const LIVE_NOW = "live";
  const MIN_BET_USDC = 1;
  const MAX_BET_USDC = 100;
  const MIN_SOL_FOR_BET = 5e-3;
  const BET_CHIPS = [1, 2, 5];
  const SOLANA_MAX_TRANSACTION_BYTES = 1232;
  const COMPUTE_BUDGET_PROGRAM = "ComputeBudget111111111111111111111111111111";
  const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  function base58(bytes) {
    let value = 0n;
    for (const byte of bytes) value = value << 8n | BigInt(byte);
    let out = "";
    for (; value > 0n; value /= 58n) out = ALPHABET[Number(value % 58n)] + out;
    for (const byte of bytes) {
      if (byte !== 0) break;
      out = "1" + out;
    }
    return out;
  }
  function hex(bytes) {
    return [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  function fromBase64(text) {
    return Uint8Array.from(atob(text), (char) => char.charCodeAt(0));
  }
  function parse(bytes) {
    let at = 0;
    const take = (count) => {
      if (at + count > bytes.length) throw new Error("truncated");
      at += count;
      return bytes.subarray(at - count, at);
    };
    const length = () => {
      let value = 0;
      for (let shift = 0; ; shift += 7) {
        const byte = take(1)[0];
        value |= (byte & 127) << shift;
        if (!(byte & 128)) return value;
        if (shift > 14) throw new Error("bad length");
      }
    };
    const signatures = Array.from({ length: length() }, () => take(64));
    if (take(1)[0] !== 128) throw new Error("not a v0 transaction");
    const [signers, readonlySigned, readonlyUnsigned] = take(3);
    const keys = Array.from({ length: length() }, () => base58(take(32)));
    const blockhash = hex(take(32));
    const describe = (index) => {
      if (index >= keys.length) return `lookup#${index - keys.length}`;
      const signer = index < signers;
      const writable = signer ? index < signers - readonlySigned : index < keys.length - readonlyUnsigned;
      return `${keys[index]}:${signer ? "s" : "-"}:${writable ? "w" : "-"}`;
    };
    const instructions = Array.from({ length: length() }, () => {
      const program = keys[take(1)[0]] ?? "unknown";
      const accounts = [...take(length())].map(describe);
      return { program, accounts, data: hex(take(length())) };
    });
    const lookups = hex(bytes.subarray(at));
    if (keys.length === 0) throw new Error("no accounts");
    return { signatures, feePayer: keys[0], blockhash, instructions, lookups };
  }
  const same = (a, b) => a.program === b.program && a.data === b.data && a.accounts.join() === b.accounts.join();
  function checkSignedTransaction(unsignedBase64, signedBase64) {
    let signedBytes;
    let built;
    try {
      signedBytes = fromBase64(signedBase64);
      built = parse(fromBase64(unsignedBase64));
    } catch (error) {
      return { ok: false, problem: "unreadable", bytes: 0, detail: String(error.message) };
    }
    const bytes = signedBytes.length;
    const fail = (problem2, detail) => ({
      ok: false,
      problem: problem2,
      bytes,
      detail
    });
    if (bytes > SOLANA_MAX_TRANSACTION_BYTES) {
      return fail("too_large", `${bytes} bytes, limit ${SOLANA_MAX_TRANSACTION_BYTES}`);
    }
    let signed;
    try {
      signed = parse(signedBytes);
    } catch (error) {
      return fail("unreadable", String(error.message));
    }
    if (signed.signatures.length === 0 || signed.signatures[0].every((byte) => byte === 0)) {
      return fail("not_signed", "first signature is empty");
    }
    if (signed.signatures.length !== built.signatures.length) return fail("changed", "signer count differs");
    if (signed.feePayer !== built.feePayer) return fail("changed", "fee payer differs");
    if (signed.blockhash !== built.blockhash) return fail("changed", "blockhash differs");
    if (signed.lookups !== built.lookups) return fail("changed", "address lookup tables differ");
    const core = (parsed) => parsed.instructions.filter((instruction) => instruction.program !== COMPUTE_BUDGET_PROGRAM);
    const builtCore = core(built);
    const signedCore = core(signed);
    if (signedCore.length !== builtCore.length) {
      const extra = signedCore.find((instruction) => !builtCore.some((original) => same(original, instruction)));
      return fail("changed", extra ? `unexpected instruction for program ${extra.program}` : "an instruction was removed");
    }
    for (let index = 0; index < builtCore.length; index++) {
      if (!same(builtCore[index], signedCore[index])) {
        return fail("changed", `instruction ${index + 1} (${builtCore[index].program}) was altered`);
      }
    }
    const computeBudget = (parsed) => parsed.instructions.length - core(parsed).length;
    return { ok: true, bytes, addedComputeBudget: computeBudget(signed) - computeBudget(built) };
  }
  const LAST_WALLET_KEY = "soothia:wallet";
  const TIMEOUT_MS = {
    listWallets: 2e3,
    getPublicKey: 4e3,
    signerPing: 1500,
    disconnect: 5e3,
    connect: 12e4,
    signTransaction: 18e4
  };
  function call(method, extra = {}) {
    return new Promise((resolve) => {
      const id = crypto.randomUUID();
      function done(outcome) {
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        resolve(outcome);
      }
      function onMessage(event) {
        if (event.source !== window || event.origin !== window.location.origin) return;
        const data = event.data;
        if (data?.type !== WALLET_RPC_RESPONSE || data.id !== id || typeof data.ok !== "boolean") return;
        const { type: _type, id: _id, ...outcome } = data;
        done(outcome);
      }
      const timer = setTimeout(() => done({ ok: false, reason: "timeout" }), TIMEOUT_MS[method]);
      window.addEventListener("message", onMessage);
      const request = { type: WALLET_RPC_REQUEST, id, method, ...extra };
      window.postMessage(request, window.location.origin);
    });
  }
  async function ensureSigner() {
    if ((await call("signerPing")).ok) return true;
    try {
      await chrome.runtime.sendMessage({ type: INJECT_SIGNER });
    } catch {
      return false;
    }
    for (let attempt = 0; attempt < 4; attempt++) {
      if ((await call("signerPing")).ok) return true;
    }
    return false;
  }
  let current = null;
  async function lastUsed() {
    try {
      const stored = await chrome.storage.local.get(LAST_WALLET_KEY);
      return typeof stored[LAST_WALLET_KEY] === "string" ? stored[LAST_WALLET_KEY] : null;
    } catch {
      return null;
    }
  }
  function remember(outcome) {
    if (!outcome.ok) return;
    current = outcome.wallet ?? null;
    if (outcome.wallet) chrome.storage.local.set({ [LAST_WALLET_KEY]: outcome.wallet.name }).catch(() => {
    });
  }
  const wallet = {
    /** Detected wallets, the last used one first. */
    async list() {
      const outcome = await call("listWallets");
      const wallets = outcome.ok ? outcome.wallets ?? [] : [];
      const preferred = await lastUsed();
      return wallets.slice().sort((a, b) => Number(b.name === preferred) - Number(a.name === preferred));
    },
    async connect(name) {
      const outcome = await call("connect", { wallet: name });
      remember(outcome);
      return outcome;
    },
    async disconnect() {
      current = null;
      return call("disconnect");
    },
    /** The connected address, or null. Never opens a prompt. */
    async publicKey() {
      const outcome = await call("getPublicKey", { wallet: await lastUsed() ?? void 0 });
      if (outcome.ok && outcome.wallet) current = outcome.wallet;
      return outcome.ok ? outcome.publicKey ?? null : null;
    },
    /** The connected wallet's name and icon, once known. */
    current: () => current,
    async signTransaction(txBase64) {
      const first = await call("signTransaction", { txBase64 });
      if (first.ok || first.reason !== "legacy_needs_signer") return first;
      if (!await ensureSigner()) return { ok: false, reason: "failed", message: "signer did not load" };
      return call("signTransaction", { txBase64 });
    }
  };
  const QUOTE_DEBOUNCE_MS$1 = 700;
  const QUOTE_REFRESH_BEFORE_MS$1 = 15e3;
  const QUOTE_MIN_TO_START_MS$1 = 25e3;
  const MAX_AUTO_REFRESHES$1 = 5;
  const CONFIRM_WAIT_MS$1 = 9e4;
  const STEPS$1 = ["Signing", "Sending", "Confirming", "Recording"];
  const sleep$1 = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const usd = (value) => `$${value.toFixed(2)}`;
  const pct = (price) => price === null ? "–" : `${(price * 100).toFixed(1)}%`;
  function problem(response) {
    const error = response.body ?? {};
    if (response.status === 0) return "I couldn't reach Soothia's server. Check your connection.";
    if (response.status === 429) return "Too many requests just now. Try again in a minute.";
    switch (error.error) {
      case "market_not_in_primary":
        return "This market's buying window has closed.";
      case "amount_too_small":
        return "That amount is below Panta's minimum.";
      case "bad_amount":
        return error.message ?? `Bets are between ${usd(MIN_BET_USDC)} and ${usd(MAX_BET_USDC)}.`;
      case "quote_stale":
        return "The price moved. Getting a fresh quote.";
      default:
        return error.message || "I couldn't get a price just now.";
    }
  }
  function openBetSheet(host) {
    let target = host.target;
    let side = "yes";
    let amount2 = "1.00";
    let address = null;
    let balances = null;
    let quote = null;
    let quoteError = "";
    let quoting = false;
    let quoteSeq = 0;
    let autoRefreshes = 0;
    let busy = false;
    let disposed = false;
    let quoteTimer;
    let expiryTimer;
    const form = el("div", "form");
    const outcome = el("div", "outcome");
    outcome.hidden = true;
    const title = el("p", "question", target.title);
    const sides = el("div", "sides");
    sides.setAttribute("role", "radiogroup");
    const sideButtons = /* @__PURE__ */ new Map();
    for (const kind of ["yes", "no"]) {
      const node2 = button("", `side side-${kind}`, () => {
        side = kind;
        renderSides();
        requestQuote(0);
      });
      node2.setAttribute("role", "radio");
      node2.append(el("span", "side-label", kind.toUpperCase()), el("span", "side-pct", ""));
      sideButtons.set(kind, node2);
      sides.append(node2);
    }
    const chips = el("div", "chips");
    const customInput = el("input", "input amount");
    customInput.type = "number";
    customInput.min = String(MIN_BET_USDC);
    customInput.max = String(MAX_BET_USDC);
    customInput.step = "0.01";
    customInput.placeholder = "Custom";
    for (const value of BET_CHIPS) {
      chips.append(
        button(`$${value}`, "chip-button", () => {
          amount2 = value.toFixed(2);
          customInput.value = "";
          renderChips();
          requestQuote(0);
        })
      );
    }
    const custom = el("label", "custom");
    custom.append(el("span", "custom-sign", "$"), customInput);
    chips.append(custom);
    const quoteBox = el("div", "quote-box");
    const payout = el("p", "note");
    const walletRow = el("div", "wallet");
    const missing = el("p", "warn");
    const buyButton = button("Buy", "button buy wide", () => void buy());
    buyButton.dataset.side = side;
    const status = el("p", "line status-line");
    status.setAttribute("aria-live", "polite");
    const steps = el("ol", "steps");
    steps.hidden = true;
    const amountField = el("div", "field");
    amountField.append(el("span", "field-label", "Amount"), chips);
    quoteBox.append(payout);
    form.append(title, sides, amountField, quoteBox, walletRow, missing);
    const header = el("div", "sheet-head");
    header.append(button("‹ Back", "back", () => host.back()), el("h3", "sheet-title", "Place a bet"));
    const foot = el("div", "sheet-foot");
    foot.append(status, buyButton);
    const node = el("div", "sheet");
    node.append(header, form, outcome, steps, foot);
    function setStatus(text) {
      status.textContent = text;
      host.layout();
    }
    function showSteps(active, failed = false) {
      steps.hidden = active === null;
      const index = active === "done" ? STEPS$1.length : active === null ? -1 : STEPS$1.indexOf(active);
      steps.replaceChildren(
        ...STEPS$1.map((name, position) => {
          const state = position < index ? "done" : position === index ? failed ? "error" : "active" : "todo";
          const item = el("li", "step");
          item.dataset.state = state;
          item.append(el("span", "step-icon"), el("span", "step-label", state === "active" ? `${name}…` : name));
          return item;
        })
      );
      host.layout();
    }
    function renderSides() {
      for (const [kind, node2] of sideButtons) {
        const price = kind === "yes" ? target.yesPrice : target.noPrice;
        node2.querySelector(".side-pct").textContent = pct(price);
        node2.title = price === null ? "No price yet" : `${usd(price)} per share`;
        node2.classList.toggle("selected", kind === side);
        node2.setAttribute("aria-checked", String(kind === side));
      }
      buyButton.dataset.side = side;
    }
    function renderChips() {
      for (const chip of chips.querySelectorAll(".chip-button")) {
        const picked = Number(chip.textContent.slice(1)).toFixed(2) === amount2 && !customInput.value;
        chip.classList.toggle("selected", picked);
        chip.setAttribute("aria-pressed", String(picked));
      }
    }
    function renderWallet() {
      walletRow.classList.toggle("disconnected", !address);
      if (!address) {
        walletRow.replaceChildren(button("Connect wallet", "button connect", () => void connect()));
        return;
      }
      const holdings = balances ? `${balances.sol.toFixed(4)} SOL · ${balances.usdc.toFixed(2)} USDC` : "checking balances…";
      const current2 = wallet.current();
      const who = el("span", "wallet-address", shortAddress(address));
      who.title = address;
      const text = el("span", "wallet-text");
      const line = el("span", "wallet-line");
      if (current2) line.append(el("span", "wallet-name", `${current2.name} · `));
      line.append(who);
      text.append(line, el("span", "wallet-holdings", holdings));
      walletRow.replaceChildren(current2 ? walletIcon(current2) : el("span", "wallet-dot"), text, button("Disconnect", "ghost", () => void disconnect()));
    }
    function renderQuote() {
      const mono = (text, extra = "") => el("span", `mono ${extra}`, text);
      if (!address) quoteBox.replaceChildren("Connect a wallet to see the price.");
      else if (quote) {
        const line = el("div", "");
        line.append(
          "You get ",
          mono(`~${quote.shares.toFixed(2)} ${quote.side.toUpperCase()}`, quote.side),
          " shares at ",
          mono(`~${usd(quote.avgPrice)}`),
          " each. Fee ",
          mono(usd(quote.feeUsdc)),
          ". Total ",
          mono(usd(quote.totalUsdc)),
          "."
        );
        const win = quote.shares * quote.payoutPerShareUsdc;
        payout.textContent = `If ${quote.side.toUpperCase()} wins, each share pays ~${usd(quote.payoutPerShareUsdc)}: about ${usd(win)} back on ${usd(quote.totalUsdc)} spent.`;
        quoteBox.replaceChildren(line, payout);
      } else if (quoting) quoteBox.replaceChildren("Getting the price…");
      else if (quoteError) quoteBox.replaceChildren(quoteError, " ", button("Try again", "link", () => requestQuote(0)));
      else quoteBox.replaceChildren();
      if (!quote) payout.textContent = "";
    }
    function shortfall() {
      if (!balances || !quote) return "";
      const usdc = Math.max(0, quote.totalUsdc - balances.usdc);
      const sol = Math.max(0, MIN_SOL_FOR_BET - balances.sol);
      const parts = [];
      if (usdc > 0) parts.push(`${(Math.ceil(usdc * 100) / 100).toFixed(2)} USDC`);
      if (sol > 0) parts.push(`${(Math.ceil(sol * 1e4) / 1e4).toFixed(4)} SOL`);
      return parts.join(" and ");
    }
    function renderGate() {
      const { dryRun } = host.settings();
      const short = shortfall();
      if (!short) missing.replaceChildren();
      else {
        const text = el("span", "");
        text.append(...withMono(`This wallet is missing ${short}. Add it, then come back.`));
        missing.replaceChildren(icon("warn"), text);
      }
      buyButton.classList.toggle("dry", dryRun);
      buyButton.classList.toggle("buy", !dryRun);
      buyButton.replaceChildren(
        ...dryRun ? [`Buy ${side.toUpperCase()} (dry run, nothing is sent)`] : quote ? [`Buy ${side.toUpperCase()} · `, el("span", "mono", usd(quote.totalUsdc))] : [`Buy ${side.toUpperCase()}`]
      );
      buyButton.disabled = busy || !address || !quote || !balances || short !== "";
    }
    function render() {
      renderSides();
      renderChips();
      renderWallet();
      renderQuote();
      renderGate();
      host.layout();
    }
    async function fetchQuote() {
      if (!address) return null;
      clearTimeout(quoteTimer);
      clearTimeout(expiryTimer);
      const seq = ++quoteSeq;
      quoting = true;
      render();
      const response = await host.api("/buy/quote", {
        wallet: address,
        marketId: target.marketId,
        side,
        amountUsdc: amount2
      });
      if (disposed || seq !== quoteSeq) return null;
      quoting = false;
      if (response.ok && response.body) {
        quote = response.body;
        quoteError = "";
        host.debug({
          quote: `${quote.side} ${usd(quote.totalUsdc)} -> ${quote.shares.toFixed(4)} shares at ${quote.avgPrice.toFixed(4)}, fee ${usd(quote.feeUsdc)}, expires ${quote.expiresAt.slice(11, 19)} UTC`
        });
        expiryTimer = setTimeout(onQuoteExpiring, Math.max(1e3, Date.parse(quote.expiresAt) - Date.now() - QUOTE_REFRESH_BEFORE_MS$1));
      } else {
        quote = null;
        quoteError = problem(response);
        host.debug({ quote: `failed (${response.status}): ${response.body?.error ?? "no response"}` });
      }
      render();
      return quote;
    }
    function onQuoteExpiring() {
      if (disposed || busy) return;
      if (host.isVisible() && autoRefreshes < MAX_AUTO_REFRESHES$1) {
        autoRefreshes++;
        void fetchQuote();
      } else {
        quote = null;
        quoteError = "The price quote expired.";
        render();
      }
    }
    function requestQuote(delayMs = QUOTE_DEBOUNCE_MS$1) {
      clearTimeout(quoteTimer);
      if (!address) return;
      autoRefreshes = 0;
      quote = null;
      quoteError = "";
      quoteSeq++;
      quoting = true;
      render();
      quoteTimer = setTimeout(() => void fetchQuote(), delayMs);
    }
    async function loadBalances() {
      if (!address) return;
      const owner = address;
      const response = await host.api("/wallet/balances", { wallet: owner });
      if (disposed || owner !== address) return;
      balances = response.ok ? response.body : null;
      host.debug({ wallet: balances ? `${owner} (${balances.sol} SOL, ${balances.usdc} USDC)` : `${owner} (balances unavailable)` });
      render();
    }
    function setAddress(next) {
      address = next;
      balances = null;
      quote = null;
      quoteError = "";
      host.debug({ wallet: next ?? "not connected" });
      render();
      if (next) {
        void loadBalances();
        requestQuote(0);
      }
    }
    async function connect() {
      const wallets = await wallet.list();
      if (disposed) return;
      setStatus(wallets.length ? "Choose a wallet." : "");
      const choice = pickWallet(walletRow, wallets);
      host.layout();
      const name = await choice;
      if (disposed) return;
      if (!name) return setStatus("");
      setStatus(`Approve the connection in ${name}.`);
      const result = await wallet.connect(name);
      if (disposed) return;
      if (result.ok && result.publicKey) {
        setStatus("");
        setAddress(result.publicKey);
      } else if (!result.ok && result.reason === "rejected") setStatus("Connection cancelled.");
      else if (!result.ok && result.reason === "no_wallet") setStatus("No Solana wallet found in this browser.");
      else setStatus(`${name} didn't answer. Open it and try again.`);
    }
    async function disconnect() {
      await wallet.disconnect();
      if (!disposed) setAddress(null);
    }
    async function buy() {
      if (busy || !address) return;
      busy = true;
      render();
      try {
        await run(address);
      } finally {
        busy = false;
        if (!disposed) render();
      }
    }
    async function run(owner) {
      const { dryRun } = host.settings();
      for (let round = 1; round <= 2; round++) {
        showSteps(null);
        let current2 = quote;
        if (!current2 || Date.parse(current2.expiresAt) - Date.now() < QUOTE_MIN_TO_START_MS$1) {
          setStatus("Getting a fresh price…");
          current2 = await fetchQuote();
          if (disposed) return;
          if (!current2) return setStatus(quoteError);
        }
        setStatus("Preparing your transaction…");
        const built = await host.api("/buy/build", { wallet: owner, quoteId: current2.quoteId });
        if (disposed) return;
        if (!built.ok || !built.body) {
          const code = built.body?.error;
          if ((code === "quote_stale" || code === "quote_expired") && round === 1) {
            quote = null;
            continue;
          }
          return setStatus(problem(built));
        }
        const { txBase64, orderId, bytes } = built.body;
        const simulated = await host.api("/tx/simulate", { txBase64 });
        if (disposed) return;
        const simulation = simulated.ok ? simulated.body : null;
        host.debug({
          simulate: !simulation ? `could not simulate (${simulated.status})` : simulation.ok ? `built ${bytes} bytes; ok, ${simulation.unitsConsumed ?? "?"} compute units` : `built ${bytes} bytes; failed: ${simulation.logLine ?? JSON.stringify(simulation.err)}`
        });
        if (!simulation?.ok) {
          host.sound?.("softError");
          return setStatus(simulation?.reason ?? "I couldn't test this transaction, so nothing was sent. Try again in a moment.");
        }
        showSteps("Signing");
        setStatus("Approve the purchase in your wallet.");
        const signed = await wallet.signTransaction(txBase64);
        if (disposed) return;
        if (!signed.ok || !signed.signedTxBase64 || !signed.signature) {
          showSteps(null);
          host.sound?.("softError");
          return setStatus(
            !signed.ok && signed.reason === "rejected" ? "Cancelled in your wallet. Nothing was sent." : "Your wallet couldn't sign this. Nothing was sent."
          );
        }
        const checked = checkSignedTransaction(txBase64, signed.signedTxBase64);
        if (!checked.ok) {
          host.debug({ signature: `refused, not sent: ${checked.problem} (${checked.detail})` });
          showSteps(null);
          return setStatus("The transaction your wallet signed is not the one Soothia built. Nothing was sent.");
        }
        if (dryRun) {
          host.debug({ signature: `${signed.signature} (dry run, not sent; ${checked.bytes} bytes)`, register: "not attempted (dry run)" });
          showSteps(null);
          host.sound?.("open");
          return setStatus("Dry run complete: your wallet signed it, nothing was sent.");
        }
        showSteps("Sending");
        setStatus("Sending to Solana…");
        host.debug({ signature: signed.signature, register: "sending" });
        const sent = await host.api("/buy/send", { signedTxBase64: signed.signedTxBase64, orderId });
        if (disposed) return;
        if (!sent.ok && sent.status !== 0) {
          const error = sent.body ?? {};
          if (error.error === "blockhash_expired" && round === 1) {
            quote = null;
            setStatus("That took a while and the transaction expired before it was sent. Nothing was charged. One more time.");
            continue;
          }
          showSteps("Sending", true);
          return setStatus(error.reason ?? "Solana didn't accept the transaction. Nothing was charged.");
        }
        await follow(orderId, signed.signature, sent.ok ? sent.body : null);
        return;
      }
      showSteps(null);
      setStatus("That didn't go through. Nothing was charged. Try again when you're ready.");
    }
    async function follow(orderId, signature, first) {
      form.hidden = true;
      showSteps("Confirming");
      setStatus("Waiting for Solana to confirm…");
      let result = first;
      const deadline = Date.now() + CONFIRM_WAIT_MS$1;
      while ((!result || result.status === "pending") && Date.now() < deadline) {
        const response = await host.api("/buy/status", { signature, orderId });
        if (disposed) return;
        if (response.ok && response.body) result = response.body;
        else await sleep$1(3e3);
      }
      if (disposed) return;
      const solscan = externalLink("Transaction on Solscan", `https://solscan.io/tx/${signature}`, "link mono ext centered");
      outcome.classList.remove("success");
      if (!result || result.status === "pending") {
        host.debug({ register: "still unconfirmed" });
        setStatus("");
        outcome.replaceChildren(
          el("p", "line", "Solana hasn't confirmed it yet. Don't buy again: your transaction is still on its way."),
          button("Check again", "button", () => {
            busy = true;
            void follow(orderId, signature, null).finally(() => busy = false);
          }),
          solscan
        );
      } else if (result.status === "failed") {
        host.debug({ register: "transaction failed on-chain" });
        host.sound?.("softError");
        showSteps("Confirming", true);
        setStatus("");
        outcome.replaceChildren(el("p", "line", "The transaction failed on Solana. No USDC was taken."), solscan, button("Back", "link", () => host.back()));
      } else {
        const recorded = result.submitted || result.attributed;
        const issues = Object.entries(result.errors).map(([step, code]) => `${step}: ${code}`).join(", ");
        host.debug({ register: recorded ? `recorded (${result.verified ?? "verified"}, attributed ${result.attributed})${issues ? `; ${issues}` : ""}` : `on-chain, not recorded (${issues})` });
        showSteps(recorded ? "done" : "Recording", !recorded);
        setStatus("");
        host.celebrate?.();
        host.sound?.("betPlaced");
        const flourish = el("div", "flourish");
        flourish.append(starSvg(), starSvg(), starSvg());
        const summary = el("div", "summary-box");
        summary.append(el("span", `mono ${side}`, `${quote ? `~${quote.shares.toFixed(2)} ` : ""}${side.toUpperCase()}`), " shares are yours");
        if (quote) {
          summary.append(" for ", el("span", "mono", usd(quote.totalUsdc)), " ", el("span", "muted-inline", `(${usd(quote.amountUsdc)} stake + ${usd(quote.feeUsdc)} fee)`));
        }
        if (!recorded) summary.append(" Panta's records are catching up; the shares are on-chain.");
        const actions = el("div", "button-grid");
        actions.append(
          externalLink("View on Panta", result.marketUrl, "button primary tall ext"),
          button("Done", "button tall", () => host.back())
        );
        outcome.classList.add("success");
        outcome.replaceChildren(flourish, el("h3", "success-title", "Bet placed"), el("p", "success-sub", target.title), summary, actions, solscan);
      }
      outcome.hidden = false;
      host.layout();
    }
    customInput.addEventListener("input", () => {
      const value = Number(customInput.value);
      if (!Number.isFinite(value) || value < MIN_BET_USDC || value > MAX_BET_USDC) {
        renderChips();
        return;
      }
      amount2 = value.toFixed(2);
      renderChips();
      requestQuote();
    });
    host.debug({ wallet: "not connected", quote: "–", simulate: "–", signature: "–", register: "–" });
    render();
    void host.api("/market", { id: target.marketId }).then((response) => {
      if (disposed || !response.ok || !response.body) return;
      const fresh = response.body;
      target = { ...target, title: fresh.title || target.title, yesPrice: fresh.yesPrice, noPrice: fresh.noPrice };
      title.textContent = target.title;
      renderSides();
    });
    void wallet.publicKey().then((found) => {
      if (!disposed && found && !address) setAddress(found);
    });
    return {
      node,
      refresh() {
        if (disposed) return;
        if (address && !quote && !quoting && !busy && quoteError === "The price quote expired.") requestQuote(0);
        else render();
      },
      dispose() {
        disposed = true;
        clearTimeout(quoteTimer);
        clearTimeout(expiryTimer);
      },
      trigger: () => void buy()
    };
  }
  const QUOTE_DEBOUNCE_MS = 900;
  const QUOTE_REFRESH_BEFORE_MS = 3e4;
  const QUOTE_MIN_TO_START_MS = 12e4;
  const QUOTE_MIN_TO_SEND_MS = 45e3;
  const MAX_AUTO_REFRESHES = 5;
  const CONFIRM_WAIT_MS = 9e4;
  const MAX_SIGN_ROUNDS = 3;
  const STEPS = ["Signing", "Sending", "Confirming", "Registering"];
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  function amount(value) {
    return Number.isInteger(value) ? String(value) : value.toFixed(2);
  }
  function msLeft(quote) {
    return Date.parse(quote.expiresAt) - Date.now();
  }
  function utcDay(ms) {
    return new Date(ms).toISOString().slice(0, 10);
  }
  function quoteProblem(response) {
    const error = response.body ?? {};
    if (response.status === 0) return "I couldn't reach Soothia's server. Check your connection.";
    if (response.status === 429) return "Too many requests just now. Try again in a minute.";
    switch (error.error) {
      case "invalid_draft":
        return error.message ?? "Something in the market details needs fixing.";
      case "duplicate_market":
        return "This wallet has already made a market with this exact question. Change the wording to make a new one.";
      case "create_not_permitted":
        return "Market creation is switched off for Soothia right now.";
      case "invalid_market_params":
        return error.message && !error.message.includes("unexpected") ? error.message : "Panta is busy. Try again in a few seconds.";
      default:
        return "I couldn't get the fee just now.";
    }
  }
  function openSheet(host) {
    const { claim } = host.tile;
    let question = claim.question;
    let category = claim.category;
    let endTime = claim.endTime;
    let marketType = DEFAULT_MARKET_TYPE;
    let buyWindow = claim.eventLive ? LIVE_NOW : DEFAULT_BUY_WINDOW_HOURS;
    let address = null;
    let balances = null;
    let quote = null;
    let quoteError = "";
    let quoting = false;
    let quoteSeq = 0;
    let autoRefreshes = 0;
    let shownImage = "";
    let busy = false;
    let disposed = false;
    let quoteTimer;
    let expiryTimer;
    const form = el("div", "form");
    const outcome = el("div", "outcome");
    outcome.hidden = true;
    const questionInput = el("textarea", "input");
    questionInput.rows = 3;
    questionInput.maxLength = QUESTION_MAX_LENGTH;
    questionInput.value = question;
    const counter = el("span", "counter");
    const categorySelect = el("select", "input");
    for (const name of CATEGORIES) {
      const option = el("option", "", name);
      option.value = name;
      categorySelect.append(option);
    }
    categorySelect.value = category;
    const dateInput = el("input", "input");
    dateInput.type = "date";
    dateInput.min = utcDay(Date.now() + MIN_END_LEAD_MS);
    dateInput.max = utcDay(Date.now() + MAX_END_HORIZON_MS);
    dateInput.value = endTime.slice(0, 10);
    const typeGroup = el("div", "types");
    const typeInputs = /* @__PURE__ */ new Map();
    const typeFees = /* @__PURE__ */ new Map();
    const TYPE_COPY = {
      breaking: {
        name: "Breaking",
        fee: "20 USDC",
        blurb: "People can buy YES/NO until the buying window closes, then shares trade between people until it resolves."
      },
      standard: {
        name: "Standard",
        fee: "50 USDC",
        blurb: "For events more than 3 days away that need a longer buying window."
      }
    };
    for (const kind of ["breaking", "standard"]) {
      const card = el("label", "type");
      const input = el("input", "type-box");
      input.type = "radio";
      input.name = "soothia-market-type";
      input.value = kind;
      input.checked = kind === marketType;
      const feeLabel = el("span", "type-fee", TYPE_COPY[kind].fee);
      const head = el("span", "type-name", TYPE_COPY[kind].name);
      head.append(feeLabel);
      const text = el("span", "type-text");
      text.append(head, el("span", "type-blurb", TYPE_COPY[kind].blurb));
      card.append(input, text);
      typeGroup.append(card);
      typeInputs.set(kind, input);
      typeFees.set(kind, feeLabel);
    }
    const windowSelect = el("select", "input");
    function fillWindowChoices() {
      const current2 = String(buyWindow);
      windowSelect.replaceChildren();
      if (claim.eventLive && marketType === "breaking") {
        const live = el("option", "", "Live now (closes at once)");
        live.value = LIVE_NOW;
        windowSelect.append(live);
      }
      for (const choice of BUY_WINDOW_CHOICES) {
        if (marketType === "breaking" && choice.hours > BREAKING_MAX_BUY_WINDOW_HOURS) continue;
        const option = el("option", "", choice.label);
        option.value = String(choice.hours);
        windowSelect.append(option);
      }
      windowSelect.value = current2;
      if (windowSelect.value !== current2) {
        buyWindow = DEFAULT_BUY_WINDOW_HOURS;
        windowSelect.value = String(buyWindow);
      }
    }
    fillWindowChoices();
    const rule = el("details", "rule");
    const ruleText = el("p", "rule-text", "Connect a wallet to see the exact rule Panta will receive.");
    const sources = el("ul", "sources");
    const resolver = el("p", "note", "Panta's AI resolver settles it from these sources, with a 1-hour dispute window.");
    const ruleBody = el("div", "rule-body");
    ruleBody.append(sources, resolver, ruleText);
    rule.append(el("summary", "rule-summary", "How it resolves"), ruleBody);
    rule.addEventListener("toggle", () => host.layout());
    const image = el("img", "thumb");
    image.alt = "";
    image.hidden = true;
    const walletRow = el("div", "wallet");
    const fitNote = el("p", "note fit-note");
    const missing = el("p", "warn");
    const fee = el("div", "fee");
    const createButton = button("Create market", "button primary wide", () => void create());
    const status = el("p", "line status-line");
    status.setAttribute("aria-live", "polite");
    const steps = el("ol", "steps");
    steps.hidden = true;
    function field(label, control, extra) {
      const wrap = el("label", "field");
      const head = el("span", "field-label", label);
      if (extra) head.append(extra);
      wrap.append(head, control);
      return wrap;
    }
    const row = el("div", "field-row");
    row.append(field("Buying window closes", windowSelect), field("Ends (UTC date)", dateInput));
    const typeField = el("div", "field");
    typeField.append(el("span", "field-label", "Market type"), typeGroup);
    form.append(
      field("Question", questionInput, counter),
      typeField,
      row,
      field("Category", categorySelect),
      rule,
      walletRow,
      fee,
      fitNote,
      missing,
      image
    );
    const header = el("div", "sheet-head");
    header.append(button("‹ Back", "back", () => host.back()), el("h3", "sheet-title", "Make it a market"));
    const foot = el("div", "sheet-foot");
    foot.append(status, createButton);
    const node = el("div", "sheet");
    node.append(header, form, outcome, steps, foot);
    function setStatus(text) {
      status.textContent = text;
      host.layout();
    }
    function showSteps(active, failed = false) {
      steps.hidden = active === null;
      const index = active === "done" ? STEPS.length : active === null ? -1 : STEPS.indexOf(active);
      steps.replaceChildren(
        ...STEPS.map((name, position) => {
          const state = position < index ? "done" : position === index ? failed ? "error" : "active" : "todo";
          const item = el("li", "step");
          item.dataset.state = state;
          item.append(el("span", "step-icon"), el("span", "step-label", state === "active" ? `${name}…` : name));
          return item;
        })
      );
      host.layout();
    }
    function renderWallet() {
      walletRow.classList.toggle("disconnected", !address);
      if (!address) {
        walletRow.replaceChildren(button("Connect wallet", "button connect", () => void connect()));
        return;
      }
      const holdings = balances ? `${balances.sol.toFixed(4)} SOL · ${balances.usdc.toFixed(2)} USDC` : "checking balances…";
      const current2 = wallet.current();
      const who = el("span", "wallet-address", shortAddress(address));
      who.title = address;
      const text = el("span", "wallet-text");
      const line = el("span", "wallet-line");
      if (current2) line.append(el("span", "wallet-name", `${current2.name} · `));
      line.append(who);
      text.append(line, el("span", "wallet-holdings", holdings));
      walletRow.replaceChildren(current2 ? walletIcon(current2) : el("span", "wallet-dot"), text, button("Disconnect", "ghost", () => void disconnect()));
    }
    function renderFee() {
      if (!address) fee.replaceChildren("Connect a wallet to see the live fee.");
      else if (quote) {
        const { paymentUsdc, breakdown } = quote;
        const row2 = (label, value, total = false) => {
          const line = el("div", total ? "fee-row total" : "fee-row", label);
          line.append(el("span", "mono", value));
          return line;
        };
        fee.replaceChildren(
          row2("Total", `${amount(paymentUsdc)} USDC`, true),
          row2("Seeds your market's liquidity", amount(breakdown.liquidityUsdc)),
          row2("Panta's fee", amount(breakdown.platformFeeUsdc))
        );
      } else if (quoting) fee.replaceChildren("Getting the live fee…");
      else if (quoteError) fee.replaceChildren(quoteError, " ", button("Try again", "link", () => requestQuote(0)));
      else fee.replaceChildren("");
    }
    function shortfall() {
      if (!balances || !quote) return "";
      const usdc = Math.max(0, quote.paymentUsdc - balances.usdc);
      const sol = Math.max(0, MIN_SOL_FOR_CREATE - balances.sol);
      const parts = [];
      if (usdc > 0) parts.push(`${(Math.ceil(usdc * 100) / 100).toFixed(2)} USDC`);
      if (sol > 0) parts.push(`${(Math.ceil(sol * 1e4) / 1e4).toFixed(4)} SOL`);
      return parts.join(" and ");
    }
    function renderGate() {
      const { dryRun, skipChecks } = host.settings();
      const short = shortfall();
      const overridden = short !== "" && dryRun && skipChecks;
      if (!short) missing.replaceChildren();
      else {
        const text = el("span", "");
        text.append(
          ...withMono(
            overridden ? `This wallet is missing ${short}. Dry run: balance check skipped.` : `This wallet is missing ${short}. Add it, then come back.`
          )
        );
        missing.replaceChildren(icon("warn"), text);
      }
      createButton.classList.toggle("dry", dryRun);
      createButton.classList.toggle("primary", !dryRun);
      createButton.replaceChildren(
        ...dryRun ? ["Create (dry run, nothing is sent)"] : quote ? ["Create market · ", el("span", "mono", `${amount(quote.paymentUsdc)} USDC`)] : ["Create market"]
      );
      const blocked = busy || !address || !quote || !balances || short !== "" && !overridden;
      createButton.disabled = blocked;
    }
    function render() {
      counter.textContent = `${questionInput.value.length}/${QUESTION_MAX_LENGTH}`;
      counter.classList.toggle("over", questionInput.value.length >= QUESTION_MAX_LENGTH);
      renderWallet();
      renderFee();
      renderGate();
      host.layout();
    }
    function showQuoteDetails(next) {
      if (next.question !== question) {
        question = next.question;
        questionInput.value = next.question;
      }
      const link = /(^|\.)(x|twitter)\.com$/.test(domainName(host.pageUrl)) ? "post" : "page";
      typeFees.get(next.marketType)?.replaceChildren(`${amount(next.paymentUsdc)} USDC`);
      const changes = [
        next.adjustments.includes("page_link_dropped") ? `kept ${next.authority.name} as the source and left out the ${link} link` : "",
        next.adjustments.includes("minimal_rule") ? "shortened the rule" : "",
        next.adjustments.includes("question_trimmed") ? "trimmed the question" : ""
      ].filter(Boolean);
      const listed = changes.length > 1 ? `${changes.slice(0, -1).join(", ")} and ${changes[changes.length - 1]}` : changes[0];
      fitNote.textContent = changes.length ? `To fit in one Solana transaction, I ${listed}.` : "";
      ruleText.textContent = next.resolutionRule;
      sources.replaceChildren(
        ...next.sourcesOfTruth.map((url) => {
          const item = el("li", /^https?:\/\//i.test(url) ? "source-item" : "source");
          if (/^https?:\/\//i.test(url)) {
            const link2 = externalLink(domainName(url), url, "");
            link2.title = url;
            item.append(link2);
          } else item.append(url);
          return item;
        })
      );
      if (shownImage !== category) {
        const wanted = category;
        shownImage = wanted;
        void host.image(wanted).then((dataUrl) => {
          if (disposed || wanted !== category || !dataUrl) return;
          image.src = dataUrl;
          image.hidden = false;
          host.layout();
        });
      }
    }
    function draft() {
      return {
        question,
        category,
        endTime,
        pageUrl: host.pageUrl,
        resolutionType: claim.resolution.type,
        marketType,
        buyWindowHours: buyWindow === LIVE_NOW ? 0 : buyWindow,
        eventInProgress: buyWindow === LIVE_NOW
      };
    }
    async function fetchQuote() {
      if (!address) return null;
      clearTimeout(quoteTimer);
      clearTimeout(expiryTimer);
      const seq = ++quoteSeq;
      quoting = true;
      render();
      const response = await host.api("/create/quote", { wallet: address, draft: draft() });
      if (disposed || seq !== quoteSeq) return null;
      quoting = false;
      if (response.ok && response.body) {
        const next = response.body;
        quote = next;
        quoteError = "";
        showQuoteDetails(next);
        host.debug({
          quote: `${amount(next.paymentUsdc)} USDC, expires ${next.expiresAt.slice(11, 19)} UTC, about ${next.predictedBytes} bytes${next.adjustments.length ? ` (${next.adjustments.join(", ")})` : ""}`
        });
        expiryTimer = setTimeout(onQuoteExpiring, Math.max(1e3, msLeft(next) - QUOTE_REFRESH_BEFORE_MS));
      } else {
        quote = null;
        quoteError = quoteProblem(response);
        host.debug({ quote: `failed (${response.status}): ${response.body?.error ?? "no response"}` });
      }
      render();
      return quote;
    }
    function onQuoteExpiring() {
      if (disposed || busy) return;
      if (host.isVisible() && autoRefreshes < MAX_AUTO_REFRESHES) {
        autoRefreshes++;
        void fetchQuote();
      } else {
        quote = null;
        quoteError = "The quote expired.";
        render();
      }
    }
    function requestQuote(delayMs = QUOTE_DEBOUNCE_MS) {
      clearTimeout(quoteTimer);
      if (!address) return;
      autoRefreshes = 0;
      quote = null;
      quoteError = "";
      quoteSeq++;
      quoting = true;
      render();
      quoteTimer = setTimeout(() => void fetchQuote(), delayMs);
    }
    async function loadBalances() {
      if (!address) return;
      const owner = address;
      const response = await host.api("/wallet/balances", { wallet: owner });
      if (disposed || owner !== address) return;
      balances = response.ok ? response.body : null;
      host.debug({
        wallet: balances ? `${owner} (${balances.sol} SOL, ${balances.usdc} USDC)` : `${owner} (balances unavailable)`
      });
      if (!balances) setStatus("I couldn't read this wallet's balances. Try again in a moment.");
      render();
    }
    function setAddress(next) {
      address = next;
      balances = null;
      quote = null;
      quoteError = "";
      host.debug({ wallet: next ?? "not connected" });
      render();
      if (next) {
        void loadBalances();
        requestQuote(0);
      }
    }
    async function connect() {
      const wallets = await wallet.list();
      if (disposed) return;
      setStatus(wallets.length ? "Choose a wallet." : "");
      const choice = pickWallet(walletRow, wallets);
      host.layout();
      const name = await choice;
      if (disposed) return;
      if (!name) return setStatus("");
      setStatus(`Approve the connection in ${name}.`);
      const outcome2 = await wallet.connect(name);
      if (disposed) return;
      if (outcome2.ok && outcome2.publicKey) {
        setStatus("");
        setAddress(outcome2.publicKey);
      } else if (!outcome2.ok && outcome2.reason === "rejected") setStatus("Connection cancelled.");
      else if (!outcome2.ok && outcome2.reason === "no_wallet") setStatus("No Solana wallet found in this browser.");
      else setStatus(`${name} didn't answer. Open it and try again.`);
    }
    async function disconnect() {
      await wallet.disconnect();
      if (!disposed) setAddress(null);
    }
    async function create() {
      if (busy || !address) return;
      busy = true;
      render();
      try {
        await run(address);
      } finally {
        busy = false;
        if (!disposed) render();
      }
    }
    async function run(owner) {
      const { dryRun, skipChecks } = host.settings();
      const lax = dryRun && skipChecks;
      let notice = "";
      for (let round = 1; round <= MAX_SIGN_ROUNDS; round++) {
        showSteps(null);
        let current2 = quote;
        if (!current2 || msLeft(current2) < QUOTE_MIN_TO_START_MS) {
          setStatus(`${notice}Getting a fresh quote…`);
          current2 = await fetchQuote();
          if (disposed) return;
          if (!current2) {
            setStatus(quoteError);
            return;
          }
        }
        setStatus(`${notice}Preparing your transaction…`);
        const built = await host.api("/create/build", { wallet: owner, quoteId: current2.quoteId });
        if (disposed) return;
        if (!built.ok || !built.body) {
          if (built.body?.error === "create_expired") {
            quote = null;
            continue;
          }
          setStatus("I couldn't prepare the transaction. Nothing was sent. Try again in a moment.");
          return;
        }
        const { txBase64, bytes: builtBytes, quote: requoted } = built.body;
        if (requoted) {
          clearTimeout(expiryTimer);
          quote = requoted;
          showQuoteDetails(requoted);
          render();
          setStatus("I had to shorten this to fit in one Solana transaction. Check it, then press Create again.");
          return;
        }
        const simulated = await host.api("/create/simulate", { txBase64 });
        if (disposed) return;
        const simulation = simulated.ok ? simulated.body : null;
        host.debug({
          simulate: !simulation ? `could not simulate (${simulated.status})` : simulation.ok ? `built ${builtBytes} bytes; ok, ${simulation.unitsConsumed ?? "?"} compute units` : `built ${builtBytes} bytes; failed: ${simulation.logLine ?? JSON.stringify(simulation.err)}`
        });
        if (!simulation?.ok && !lax) {
          host.sound?.("softError");
          setStatus(simulation?.reason ?? "I couldn't test this transaction, so nothing was sent. Try again in a moment.");
          return;
        }
        showSteps("Signing");
        setStatus(`${notice}Approve the transaction in your wallet.`);
        const signed = await wallet.signTransaction(txBase64);
        if (disposed) return;
        if (!signed.ok || !signed.signedTxBase64 || !signed.signature) {
          showSteps(null);
          host.sound?.("softError");
          setStatus(
            !signed.ok && signed.reason === "rejected" ? "Cancelled in your wallet. Nothing was sent." : !signed.ok && signed.reason === "timeout" ? "Your wallet didn't answer in time. Nothing was sent." : "Your wallet couldn't sign this. Nothing was sent."
          );
          return;
        }
        const checked = checkSignedTransaction(txBase64, signed.signedTxBase64);
        if (!checked.ok) {
          host.debug({ signature: `refused, not sent: ${checked.problem} (${checked.detail})` });
          showSteps(null);
          setStatus(
            checked.problem === "too_large" ? `The signed transaction is ${checked.bytes} bytes, over Solana's 1,232-byte limit. Nothing was sent.` : checked.problem === "not_signed" ? "Your wallet returned the transaction without a signature. Nothing was sent." : "The transaction your wallet signed is not the one Soothia built. Nothing was sent."
          );
          return;
        }
        if (dryRun) {
          host.debug({
            signature: `${signed.signature} (dry run, not sent; ${checked.bytes} bytes signed, ${checked.addedComputeBudget} compute-budget added)`,
            register: "not attempted (dry run)"
          });
          showSteps(null);
          host.sound?.("open");
          setStatus("Dry run complete: your wallet signed it, nothing was sent.");
          return;
        }
        if (msLeft(current2) < QUOTE_MIN_TO_SEND_MS) {
          quote = null;
          notice = "That took a while and the quote ran out, so nothing was sent or charged. One more time: ";
          continue;
        }
        showSteps("Sending");
        setStatus("Sending to Solana…");
        host.debug({ signature: `${signed.signature} (${checked.bytes} bytes)`, register: "sending" });
        host.savePending({ quoteId: current2.quoteId, signature: signed.signature, question });
        const sent = await host.api("/create/send", {
          signedTxBase64: signed.signedTxBase64,
          quoteId: current2.quoteId,
          confirm: false
        });
        if (disposed) return;
        if (!sent.ok && sent.status !== 0) {
          const error = sent.body ?? {};
          host.savePending(null);
          if (error.error === "blockhash_expired") {
            host.debug({ register: "not sent (transaction expired)" });
            notice = "The transaction expired before it reached Solana, so nothing was charged. One more time: ";
            continue;
          }
          host.debug({ simulate: `send refused: ${error.logLine ?? error.error ?? sent.status}`, register: "not sent" });
          showSteps("Sending", true);
          setStatus(error.reason ?? "Solana didn't accept the transaction. Nothing was charged.");
          return;
        }
        await confirmAndRegister(current2.quoteId, signed.signature, sent.ok ? sent.body : null);
        return;
      }
      showSteps(null);
      setStatus("That didn't go through after a few tries. Nothing was charged. Try again when you're ready.");
    }
    async function confirmAndRegister(quoteId, signature, first) {
      form.hidden = true;
      outcome.hidden = true;
      showSteps("Confirming");
      setStatus("Waiting for Solana to confirm…");
      host.debug({ register: "waiting for confirmation" });
      let result = first;
      const deadline = Date.now() + CONFIRM_WAIT_MS;
      while ((!result || result.status === "pending") && Date.now() < deadline) {
        const response = await host.api("/create/register-retry", { signature, quoteId });
        if (disposed) return;
        if (response.ok && response.body) result = response.body;
        else await sleep(3e3);
      }
      if (disposed) return;
      const again = () => {
        busy = true;
        void confirmAndRegister(quoteId, signature, null).finally(() => {
          busy = false;
        });
      };
      if (!result || result.status === "pending") {
        host.debug({ register: "still unconfirmed" });
        setStatus("");
        outcome.replaceChildren(
          el("p", "line", "Solana hasn't confirmed it yet. Don't create it again: your transaction is still on its way."),
          button("Check again", "button", again)
        );
      } else if (result.status === "failed") {
        host.savePending(null);
        host.debug({ register: "transaction failed on-chain" });
        host.sound?.("softError");
        showSteps("Confirming", true);
        setStatus("");
        outcome.replaceChildren(
          el("p", "line", "The transaction failed on Solana. Nothing was created and your USDC was not taken."),
          button("Back to review", "button", () => {
            outcome.hidden = true;
            form.hidden = false;
            showSteps(null);
            render();
          })
        );
      } else if (!result.registered) {
        host.debug({ register: `on-chain, not registered yet (${result.registerError ?? "unknown"})` });
        showSteps("Registering");
        setStatus("");
        outcome.classList.remove("success");
        outcome.replaceChildren(
          el("p", "line", "Your market is on-chain, finishing registration..."),
          el("p", "note", "You have paid once and will not be charged again."),
          button("Retry", "button", again),
          externalLink("Transaction on Solscan", `https://solscan.io/tx/${signature}`, "link mono ext")
        );
      } else {
        host.savePending(null);
        host.debug({ register: "registered" });
        host.sound?.("marketLive");
        host.created({ marketId: result.marketId, marketUrl: result.marketUrl });
        showSteps("done");
        setStatus("");
        const link = betLink(result.marketId);
        const share = "https://x.com/intent/post?text=" + encodeURIComponent(`I turned this into a prediction market with Soothia. Bet YES or NO: ${question}`) + `&url=${encodeURIComponent(link)}`;
        const actions = el("div", "actions");
        const marketId = result.marketId;
        const flourish = el("div", "flourish");
        flourish.append(starSvg(), starSvg(), starSvg());
        const grid = el("div", "button-grid");
        grid.append(
          externalLink("Share on X", share, "button"),
          button("Bet on it", "button", () => host.bet({ marketId, title: question }))
        );
        actions.className = "button-stack";
        actions.append(
          externalLink("View on Panta", result.marketUrl, "button primary wide ext"),
          grid,
          copyButton("Copy bet link", link, "button wide", () => host.sound?.("open"))
        );
        outcome.classList.add("success");
        outcome.replaceChildren(
          flourish,
          el("h3", "success-title", "Your market is live"),
          el("p", "success-sub", question),
          actions,
          externalLink("Transaction on Solscan", `https://solscan.io/tx/${signature}`, "link mono ext centered"),
          button("Done", "ghost centered", () => host.back())
        );
      }
      outcome.hidden = false;
      host.layout();
    }
    questionInput.addEventListener("input", () => {
      question = questionInput.value.trim().replace(/\s+/g, " ");
      requestQuote();
    });
    categorySelect.addEventListener("change", () => {
      category = categorySelect.value;
      requestQuote(0);
    });
    for (const [kind, input] of typeInputs) {
      input.addEventListener("change", () => {
        if (!input.checked) return;
        marketType = kind;
        fillWindowChoices();
        requestQuote(0);
      });
    }
    windowSelect.addEventListener("change", () => {
      buyWindow = windowSelect.value === LIVE_NOW ? LIVE_NOW : Number(windowSelect.value);
      requestQuote(0);
    });
    dateInput.addEventListener("change", () => {
      if (!dateInput.value) return;
      endTime = `${dateInput.value}${claim.endTime.slice(10)}`;
      requestQuote(0);
    });
    host.debug({ wallet: "not connected", quote: "–", simulate: "–", signature: "–", register: "–" });
    render();
    void wallet.publicKey().then((found) => {
      if (!disposed && found && !address) setAddress(found);
    });
    return {
      node,
      refresh() {
        if (disposed) return;
        if (address && !quote && !quoting && !busy && quoteError === "The quote expired.") requestQuote(0);
        else render();
      },
      dispose() {
        disposed = true;
        clearTimeout(quoteTimer);
        clearTimeout(expiryTimer);
      },
      trigger: () => void create()
    };
  }
  const LOCAL_DATE = new Intl.DateTimeFormat(void 0, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
  function money(value) {
    return `$${value.toFixed(2)}`;
  }
  function estimateUsdc(liquidity) {
    if (!liquidity) return null;
    return Math.round(liquidity.totalVolumeUsdc * (liquidity.royaltyBps / 1e4) * 100) / 100;
  }
  function earningsView(primaryPhaseEnd, liquidity, nowMs) {
    const closes = primaryPhaseEnd ? Date.parse(primaryPhaseEnd) : NaN;
    const closed = Number.isFinite(closes) && closes <= nowMs;
    const when = Number.isFinite(closes) ? LOCAL_DATE.format(new Date(closes)) : "the buying window closes";
    const estimate = estimateUsdc(liquidity);
    if (closed) {
      return {
        phase: "claimable",
        estimateUsdc: estimate,
        text: estimate === null ? "The buying window has closed." : `Estimated ~${money(estimate)}. The buying window has closed.`
      };
    }
    if (estimate === null) {
      return { phase: "open", estimateUsdc: null, text: `Up to 20% of the pool. Claimable after ${when}.` };
    }
    const share = liquidity ? `${Math.round(liquidity.royaltyBps / 100)}%` : "20%";
    return {
      phase: "open",
      estimateUsdc: estimate,
      text: `Estimated ~${money(estimate)} so far (${share === "20%" ? "up to 20%" : `${share}, down from 20%`} of the pool, lower if the market is very one-sided). Claimable after the buying window closes on ${when}.`
    };
  }
  const HOST_ID = "soothia-host";
  const POSITION_KEY = "soothia:orbPosition";
  const DRAG_THRESHOLD = 4;
  const DRY_RUN_KEY = "soothia:dryRun";
  const SKIP_CHECKS_KEY = "soothia:skipChecks";
  const PENDING_KEY = "soothia:pendingCreate";
  const MUTED_KEY = "soothia:muted";
  const STYLE_KEY = "soothia:sfxStyle";
  const BUBBLE_KEY = "soothia:bubbleShown";
  const BUBBLE_DELAY_MS = 1500;
  const SETTLE_MS = 2e3;
  const THIN_RETRY_MS = 800;
  const THIN_RETRIES = 5;
  const MIN_THINKING_MS = 600;
  function currentUrl() {
    return location.href.split("#")[0];
  }
  function viewport() {
    return {
      width: document.documentElement.clientWidth || window.innerWidth,
      height: window.innerHeight
    };
  }
  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), Math.max(min, max));
  }
  async function loadPosition() {
    const fallback = { right: ORB_MARGIN, bottom: ORB_MARGIN };
    try {
      const stored = (await chrome.storage.local.get(POSITION_KEY))[POSITION_KEY];
      if (typeof stored?.right === "number" && typeof stored?.bottom === "number") {
        return { right: stored.right, bottom: stored.bottom };
      }
    } catch {
    }
    return fallback;
  }
  function savePosition(position) {
    chrome.storage.local.set({ [POSITION_KEY]: position }).catch(() => {
    });
  }
  function comingNext(label, className, tip = "Coming next") {
    const node = button(label, className);
    node.setAttribute("aria-disabled", "true");
    const wrap = el("span", "tip");
    wrap.dataset.tip = tip;
    wrap.append(node);
    return wrap;
  }
  const STOPWORDS = new Set("will the and for with from that this than then have has had are was were been being its their there what when where which who into over under above below after before between against during not yes any all more most less out off per via about around by on at to of in is it as or an a be".split(" "));
  function words(text) {
    return new Set(
      text.toLowerCase().match(/[\p{L}\p{N}]+/gu)?.filter((word) => word.length > 2 && !STOPWORDS.has(word)) ?? []
    );
  }
  function overlap(a, b) {
    const other = words(b);
    return [...words(a)].filter((word) => other.has(word)).length;
  }
  function tileNode({ claim, market }, live, onMake, onBet) {
    const tile = el("div", "tile");
    const meta = el("div", "meta");
    const ends = endDate(claim.endTime);
    meta.append(el("span", "chip", claim.category), el("span", "ends", ends ? `Ends ${ends}` : ""));
    const actions = el("div", "actions");
    if (live) {
      const target = { marketId: live.marketId, title: live.title, yesPrice: null, noPrice: null };
      const link = externalLink("Live on Panta", live.marketUrl, "link ext");
      link.prepend(el("span", "live-dot"));
      actions.append(link, button("Bet", "button", () => onBet(target)));
    } else if (market) {
      const odds = market.yesPrice === null ? "YES –" : `YES ${(market.yesPrice * 100).toFixed(1)}%`;
      const oddsNode = el("span", "odds", odds);
      oddsNode.title = market.title;
      const target = { marketId: market.id, title: market.title, yesPrice: market.yesPrice, noPrice: market.noPrice };
      actions.append(oddsNode, button("Bet", "button", () => onBet(target)));
    } else {
      actions.classList.add("end");
      actions.append(button("Make it a market", "button primary", onMake));
    }
    tile.append(
      el("p", "question", claim.question),
      meta,
      el("p", "quote", `“${claim.sourceQuote}”`),
      actions
    );
    return tile;
  }
  function statusRow() {
    const row = el("div", "status");
    const label = el("span", "label");
    row.append(el("span", "dot"), label);
    return {
      row,
      set(text, state) {
        label.textContent = text;
        row.dataset.state = state;
      }
    };
  }
  async function mount() {
    if (document.getElementById(HOST_ID)) return;
    const host = document.createElement("div");
    host.id = HOST_ID;
    for (const [property, value] of Object.entries(HOST_STYLES)) {
      host.style.setProperty(property, value, "important");
    }
    const shadow = host.attachShadow({ mode: "closed" });
    const style2 = document.createElement("style");
    style2.textContent = STYLES;
    const orb = el("button", "orb");
    orb.type = "button";
    orb.setAttribute("aria-label", "Soothia");
    orb.setAttribute("aria-expanded", "false");
    orb.dataset.state = "idle";
    const orbBody = el("span", "orb-body");
    orbBody.append(el("span", "orb-shimmer"));
    const orbStars = el("span", "orb-stars");
    orb.append(orbBody, starSvg("orb-glint"), el("span", "orb-arc"), orbStars, el("span", "orb-pulse"));
    function pageIsLight() {
      for (const node of [document.body, document.documentElement]) {
        const match = /rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([\d.]+))?/.exec(getComputedStyle(node).backgroundColor);
        if (!match || match[4] !== void 0 && Number(match[4]) === 0) continue;
        const [r, g, b] = [Number(match[1]), Number(match[2]), Number(match[3])];
        return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 > 0.6;
      }
      return true;
    }
    function applyTheme() {
      host.dataset.theme = pageIsLight() ? "light" : "dark";
    }
    const card = el("div", "card");
    card.hidden = true;
    card.setAttribute("role", "dialog");
    card.setAttribute("aria-label", "Soothia");
    const cardStars = el("div", "card-stars");
    cardStars.setAttribute("aria-hidden", "true");
    for (let i = 0; i < 6; i++) cardStars.append(starSvg("card-star"));
    card.append(cardStars);
    const walletRow = statusRow();
    const proxyRow = statusRow();
    const body = el("div", "body");
    const betsPane = el("div", "body");
    betsPane.hidden = true;
    const tabs = el("div", "tabs");
    tabs.setAttribute("role", "tablist");
    const claimsTab = button("This page", "tab selected", () => showTab("claims"));
    const betsTab = button("My bets", "tab", () => showTab("bets"));
    for (const tab of [claimsTab, betsTab]) tab.setAttribute("role", "tab");
    tabs.append(claimsTab, betsTab);
    function showTab(which) {
      body.hidden = which !== "claims";
      betsPane.hidden = which !== "bets";
      claimsTab.classList.toggle("selected", which === "claims");
      betsTab.classList.toggle("selected", which === "bets");
      claimsTab.setAttribute("aria-selected", String(which === "claims"));
      betsTab.setAttribute("aria-selected", String(which === "bets"));
      if (which === "bets") void renderBets();
      layout();
    }
    const debug = el("details", "debug");
    const scanInfo = el("dl", "scan");
    const scanAgain = el("button", "button small", "Scan again");
    scanAgain.type = "button";
    function toggle(label) {
      const row = el("label", "toggle");
      const box = el("input", "toggle-box");
      box.type = "checkbox";
      row.append(box, el("span", "toggle-label", label));
      return { row, box };
    }
    const dryRunToggle = toggle("Dry run (sign only, never send)");
    const skipChecksToggle = toggle("In dry run, skip balance and simulation checks");
    const createInfo = el("dl", "scan");
    const replayRow = el("div", "replay");
    replayRow.append(
      button("Show welcome again", "link mono", () => {
        chrome.runtime.sendMessage({ type: OPEN_WELCOME }).catch(() => {
        });
      }),
      button("Reset first-run bubble", "link mono", () => {
        chrome.storage.local.remove(BUBBLE_KEY).catch(() => {
        });
      })
    );
    debug.append(
      el("summary", "debug-summary", "debug"),
      scanInfo,
      scanAgain,
      dryRunToggle.row,
      skipChecksToggle.row,
      createInfo,
      replayRow,
      walletRow.row,
      proxyRow.row
    );
    const head = el("div", "card-head");
    const brand = el("div", "brand");
    const mark = el("span", "mark");
    mark.append(el("span", "mark-body"), starSvg("star"));
    brand.append(mark, el("h2", "wordmark", "Soothia"));
    const close = button("", "close", () => setOpen(false));
    close.setAttribute("aria-label", "Close");
    close.append(icon("close"));
    const muteButton = button("", "close mute", () => void toggleMute());
    function renderMute() {
      const label = isMuted() ? "Unmute sounds" : "Mute sounds";
      muteButton.setAttribute("aria-label", label);
      muteButton.title = label;
      muteButton.replaceChildren(icon(isMuted() ? "muted" : "sound"));
    }
    async function toggleMute() {
      setMuted(!isMuted());
      renderMute();
      chrome.storage.local.set({ [MUTED_KEY]: isMuted() }).catch(() => {
      });
    }
    const headActions = el("div", "head-actions");
    headActions.append(muteButton, close);
    head.append(brand, headActions);
    function sound(name) {
      playSound(name);
    }
    armSounds(shadow);
    armSounds(window);
    card.append(head, tabs, body, betsPane, debug);
    for (const type of ["keydown", "keypress", "keyup"]) {
      card.addEventListener(type, (event) => event.stopPropagation());
    }
    const bubble = el("div", "bubble");
    bubble.setAttribute("role", "status");
    bubble.hidden = true;
    const bubbleClose = button("", "bubble-close", () => dismissBubble());
    bubbleClose.setAttribute("aria-label", "Dismiss");
    bubbleClose.append(icon("close"));
    bubble.append(el("p", "bubble-text", "I'll glow when I spot something you can bet on. Click me anytime."), bubbleClose);
    let bubbleTimer;
    function dismissBubble() {
      clearTimeout(bubbleTimer);
      if (bubble.hidden) return;
      bubble.hidden = true;
      chrome.storage.local.set({ [BUBBLE_KEY]: true }).catch(() => {
      });
    }
    async function maybeShowBubble() {
      try {
        if ((await chrome.storage.local.get(BUBBLE_KEY))[BUBBLE_KEY] === true) return;
      } catch {
        return;
      }
      bubbleTimer = setTimeout(() => {
        if (!card.hidden) return;
        bubble.hidden = false;
        layout();
      }, BUBBLE_DELAY_MS);
    }
    shadow.append(style2, orb, card, bubble);
    let position = await loadPosition();
    function layout() {
      const { width, height } = viewport();
      position = {
        right: clamp(position.right, 0, width - ORB_SIZE),
        bottom: clamp(position.bottom, 0, height - ORB_SIZE)
      };
      const orbLeft = width - position.right - ORB_SIZE;
      const orbTop = height - position.bottom - ORB_SIZE;
      orb.style.left = `${orbLeft}px`;
      orb.style.top = `${orbTop}px`;
      if (!bubble.hidden) {
        const bubbleWidth = Math.min(240, width - EDGE_PADDING * 2);
        bubble.style.width = `${bubbleWidth}px`;
        const bubbleHeight = bubble.offsetHeight;
        let bubbleLeft = orbLeft - CARD_GAP - bubbleWidth;
        let bubbleTop = orbTop + ORB_SIZE / 2 - bubbleHeight / 2;
        bubble.dataset.side = "left";
        if (bubbleLeft < EDGE_PADDING) {
          bubbleLeft = clamp(orbLeft + ORB_SIZE - bubbleWidth, EDGE_PADDING, width - bubbleWidth - EDGE_PADDING);
          bubbleTop = orbTop - CARD_GAP - bubbleHeight;
          bubble.dataset.side = "above";
          if (bubbleTop < EDGE_PADDING) {
            bubbleTop = orbTop + ORB_SIZE + CARD_GAP;
            bubble.dataset.side = "below";
          }
        }
        bubble.style.left = `${bubbleLeft}px`;
        bubble.style.top = `${clamp(bubbleTop, EDGE_PADDING, height - bubbleHeight - EDGE_PADDING)}px`;
      }
      if (card.hidden) return;
      const cardWidth = Math.min(CARD_WIDTH, width - EDGE_PADDING * 2);
      const cardHeight = card.offsetHeight;
      let left = orbLeft - CARD_GAP - cardWidth;
      if (left < EDGE_PADDING) left = orbLeft + ORB_SIZE + CARD_GAP;
      left = clamp(left, EDGE_PADDING, width - cardWidth - EDGE_PADDING);
      let top = orbTop + ORB_SIZE - cardHeight;
      if (top < EDGE_PADDING) top = orbTop;
      top = clamp(top, EDGE_PADDING, height - cardHeight - EDGE_PADDING);
      card.style.left = `${left}px`;
      card.style.top = `${top}px`;
    }
    let detectedWallets = [];
    function renderWalletRow() {
      walletRow.set(
        detectedWallets.length ? `Wallet: ${detectedWallets.map((info) => info.name).join(", ")} detected` : "Wallet: none found",
        detectedWallets.length ? "good" : "bad"
      );
    }
    window.addEventListener("message", (event) => {
      if (event.source !== window || event.origin !== window.location.origin) return;
      const data = event.data;
      if (typeof data !== "object" || data === null) return;
      const { type, wallets } = data;
      if (type !== WALLET_STATUS || !Array.isArray(wallets)) return;
      detectedWallets = wallets;
      renderWalletRow();
    });
    async function chooseAndConnect(container) {
      const choice = pickWallet(container, await wallet.list());
      layout();
      const name = await choice;
      layout();
      if (!name) return null;
      return wallet.connect(name);
    }
    async function refreshProxy() {
      proxyRow.set("Proxy: checking…", "idle");
      let online = false;
      try {
        const response = await chrome.runtime.sendMessage({ type: HEALTH_REQUEST });
        online = response?.online === true;
      } catch {
        online = false;
      }
      proxyRow.set(online ? "Proxy: online" : "Proxy: offline", online ? "good" : "bad");
    }
    let foundSoundUrl = "";
    function setOrb(state, count = 0) {
      const was = orb.dataset.state;
      orb.dataset.state = state;
      if (state === "found" && was !== "found" && foundSoundUrl !== watchedUrl) {
        foundSoundUrl = watchedUrl;
        sound("found");
      }
      if (state !== "found") orbStars.replaceChildren();
      else if (was !== "found" || orbStars.childElementCount !== Math.min(count, 3)) {
        orbStars.replaceChildren(...Array.from({ length: Math.min(Math.max(count, 1), 3) }, () => starSvg("star")));
      }
      orb.setAttribute("aria-label", state === "found" ? `Soothia, ${count} found` : "Soothia");
    }
    function pulseOrb() {
      orb.classList.remove("success");
      void orb.offsetWidth;
      orb.classList.add("success");
      setTimeout(() => orb.classList.remove("success"), 1300);
    }
    function stateBlock(kind, text, ...extra) {
      const block = el("div", `state ${kind}`);
      block.append(el("span", "state-orb"), el("p", "state-text", text), ...extra);
      return block;
    }
    function rescanButton() {
      return button("Scan again", "button", rescan);
    }
    let tiles = [];
    let sheet = null;
    const liveMarkets = /* @__PURE__ */ new Map();
    function closeSheet() {
      sheet?.dispose();
      sheet = null;
      body.classList.remove("has-sheet");
    }
    function showTiles() {
      closeSheet();
      setOrb("found", tiles.length);
      body.replaceChildren(
        ...tiles.map((tile) => tileNode(tile, liveMarkets.get(tile.claim.id), () => review(tile), openBet))
      );
      layout();
    }
    function openBet(target) {
      closeSheet();
      showTab("claims");
      sheet = openBetSheet({
        target,
        api,
        settings: () => ({ dryRun: dryRunToggle.box.checked }),
        debug: setCreateDebug,
        layout,
        isVisible: () => !card.hidden && document.visibilityState === "visible",
        back: showTiles,
        celebrate: pulseOrb,
        sound
      });
      body.classList.add("has-sheet");
      body.replaceChildren(sheet.node);
      layout();
    }
    let creatorMarkets = [];
    async function loadCreatorMarkets() {
      const owner = await wallet.publicKey();
      if (!owner) return;
      const response = await api("/creator/markets", { wallet: owner });
      if (!response.ok || !response.body) return;
      creatorMarkets = response.body.markets;
      attachCreatorMarkets();
    }
    function attachCreatorMarkets() {
      const here = creatorMarkets.filter((market) => market.registered && market.pageUrl?.split("#")[0] === watchedUrl);
      let changed = false;
      for (const market of here) {
        if ([...liveMarkets.values()].some((live) => live.marketId === market.marketId)) continue;
        const best = tiles.filter((tile) => !liveMarkets.has(tile.claim.id)).map((tile) => ({ tile, score: overlap(tile.claim.question, market.question) })).sort((a, b) => b.score - a.score)[0];
        if (!best || best.score === 0) continue;
        liveMarkets.set(best.tile.claim.id, { marketId: market.marketId, marketUrl: market.marketUrl, title: market.question });
        changed = true;
      }
      if (changed && !sheet && tiles.length > 0) showTiles();
    }
    async function renderBets() {
      const owner = await wallet.publicKey();
      if (!owner) {
        const connect = button("Connect wallet", "button connect", async () => {
          const result = await chooseAndConnect(betsPane);
          if (result?.ok) void renderBets();
        });
        betsPane.replaceChildren(stateBlock("empty", "Connect a wallet to see your bets."), connect);
        layout();
        return;
      }
      betsPane.replaceChildren(stateBlock("watching", "Loading your bets…"));
      layout();
      const response = await api("/positions", { wallet: owner });
      if (!response.ok || !response.body) {
        betsPane.replaceChildren(stateBlock("error", "Couldn't load your bets.", button("Try again", "button", () => void renderBets())));
        layout();
        return;
      }
      const positions = response.body.positions;
      if (creatorMarkets.length === 0) await loadCreatorMarkets();
      if (positions.length === 0) {
        betsPane.replaceChildren(refreshRow(), stateBlock("empty", "No bets yet."));
        layout();
        return;
      }
      const byMarket = /* @__PURE__ */ new Map();
      for (const position2 of positions) byMarket.set(position2.marketId, [...byMarket.get(position2.marketId) ?? [], position2]);
      betsPane.replaceChildren(
        refreshRow(),
        ...[...byMarket.values()].map((held) => {
          const first = held[0];
          const block = el("div", "tile market");
          block.append(el("p", "question", first.title || shortAddressLike(first.marketId)));
          const rows = el("div", "positions");
          for (const position2 of held) {
            const row = el("div", "position");
            row.append(
              el("span", `side-chip side-chip-${position2.side}`, position2.side.toUpperCase()),
              el(
                "span",
                "position-text",
                `${position2.shares.toFixed(2)} shares · ${position2.phase}${position2.outcome ? ` · ${position2.outcome.toUpperCase()} won` : ""}`
              )
            );
            rows.append(row);
          }
          block.append(rows);
          if (first.creatorSeedShares) {
            const seed = first.creatorSeedShares.toFixed(first.creatorSeedShares % 1 ? 2 : 0);
            block.append(el("p", "note", `Includes ${seed} YES + ${seed} NO from your creation seed.`));
          }
          if (creatorMarkets.some((market) => market.registered && market.marketId === first.marketId)) {
            block.append(earningsRow(first.marketId, block));
          }
          const claimable = held.find((position2) => position2.claimable && !position2.claimed);
          const claimed = held.some((position2) => position2.claimed);
          const actions = el("div", "actions");
          actions.append(
            externalLink("View on Panta", first.marketUrl, "link ext"),
            copyButton("Copy bet link", betLink(first.marketId), "link", () => sound("open"))
          );
          if (claimed && !claimable) actions.append(el("span", "note", "Claimed"));
          else if (claimable) actions.append(button("Claim", "button primary small", () => void claim(claimable, block)));
          else actions.append(comingNext("Claim", "button small", "Available after the market resolves"));
          block.append(actions);
          return block;
        })
      );
      layout();
    }
    function refreshRow() {
      const row = el("div", "refresh-row");
      const link = button("Refresh", "link", () => void renderBets());
      link.prepend(icon("refresh"));
      row.append(link);
      return row;
    }
    function earningsRow(marketId, block) {
      const row = el("div", "earnings");
      const text = el("p", "note earnings-text", "Checking the pool…");
      row.append(el("p", "earnings-label", "Creator earnings"), text);
      void (async () => {
        const response = await api("/market", { id: marketId });
        if (!response.ok || !response.body) {
          text.textContent = "Up to 20% of the pool, claimable after the buying window closes.";
          layout();
          return;
        }
        const info = response.body;
        const view = earningsView(info.primaryPhaseEnd, info.liquidity, Date.now());
        text.textContent = view.text;
        if (view.phase === "claimable") {
          row.append(button("Claim creator fees", "button primary small", () => void claimCreatorFees(marketId, block)));
        }
        layout();
      })();
      return row;
    }
    async function claimCreatorFees(marketId, row) {
      const owner = await wallet.publicKey();
      if (!owner) return;
      const note = el("p", "line status-line", "Preparing your claim…");
      row.append(note);
      layout();
      const built = await api("/claim/creator-fees/build", { wallet: owner, marketId });
      if (!built.ok || !built.body) {
        const error = built.body?.error ?? "";
        note.textContent = error === "market_not_graduated" || error === "no_creator_fees" ? "Nothing to claim yet." : built.body?.message ?? "I couldn't prepare the claim just now.";
        layout();
        return;
      }
      const { txBase64, claimableFeesUsdc } = built.body;
      const amount2 = money(claimableFeesUsdc);
      note.textContent = `Signing: approve the claim in your wallet (${amount2}).`;
      layout();
      const signed = await wallet.signTransaction(txBase64);
      if (!signed.ok || !signed.signedTxBase64 || !signed.signature) {
        note.textContent = !signed.ok && signed.reason === "rejected" ? "Cancelled in your wallet. Nothing was sent." : "Your wallet couldn't sign this.";
        return;
      }
      if (!checkSignedTransaction(txBase64, signed.signedTxBase64).ok) {
        note.textContent = "The transaction your wallet signed is not the one Soothia built. Nothing was sent.";
        return;
      }
      if (dryRunToggle.box.checked) {
        setCreateDebug({ signature: `${signed.signature} (dry run creator-fee claim, not sent)` });
        note.textContent = `Dry run complete: your wallet signed the claim for ${amount2}, nothing was sent.`;
        return;
      }
      note.textContent = "Sending your claim…";
      const sent = await api("/claim/send", { signedTxBase64: signed.signedTxBase64, wallet: owner, marketId });
      if (!sent.ok) {
        note.textContent = sent.body?.reason ?? "Solana didn't accept the claim. Nothing was taken.";
        return;
      }
      setCreateDebug({ signature: signed.signature, register: "creator-fee claim sent" });
      note.textContent = "Confirming on Solana…";
      for (let attempt = 0; attempt < 5; attempt++) {
        const status = await api("/tx/status", { signature: signed.signature });
        const state = status.ok ? status.body.status : "pending";
        if (state === "confirmed") {
          note.replaceChildren(
            el("strong", "", `Creator fees claimed: ${amount2}.`),
            el("span", "", " Panta does not record creator-fee claims, so nothing to report. "),
            externalLink("Transaction on Solscan", `https://solscan.io/tx/${signed.signature}`, "link mono ext")
          );
          setCreateDebug({ register: "creator-fee claim confirmed" });
          sound("betPlaced");
          pulseOrb();
          layout();
          return;
        }
        if (state === "failed") {
          note.textContent = "The claim failed on Solana. Nothing was taken.";
          return;
        }
      }
      note.textContent = "Still waiting for Solana. Refresh in a minute; do not claim again.";
    }
    function shortAddressLike(id) {
      return `Market ${id.slice(0, 4)}…${id.slice(-4)}`;
    }
    async function claim(position2, row) {
      const owner = await wallet.publicKey();
      if (!owner) return;
      const note = el("p", "line status-line", "Preparing your claim…");
      row.append(note);
      layout();
      const built = await api("/claim/build", {
        wallet: owner,
        marketId: position2.marketId
      });
      if (!built.ok || !built.body) {
        note.textContent = built.body?.message ?? "I couldn't prepare the claim just now.";
        return;
      }
      const { txBase64, winningShares } = built.body;
      note.textContent = `Approve the claim in your wallet (${winningShares.toFixed(2)} winning shares).`;
      layout();
      const signed = await wallet.signTransaction(txBase64);
      if (!signed.ok || !signed.signedTxBase64 || !signed.signature) {
        note.textContent = !signed.ok && signed.reason === "rejected" ? "Cancelled in your wallet. Nothing was sent." : "Your wallet couldn't sign this.";
        return;
      }
      const checked = checkSignedTransaction(txBase64, signed.signedTxBase64);
      if (!checked.ok) {
        note.textContent = "The transaction your wallet signed is not the one Soothia built. Nothing was sent.";
        return;
      }
      if (dryRunToggle.box.checked) {
        setCreateDebug({ signature: `${signed.signature} (dry run claim, not sent)` });
        note.textContent = "Dry run complete: your wallet signed the claim, nothing was sent.";
        return;
      }
      note.textContent = "Sending your claim…";
      const sent = await api("/claim/send", {
        signedTxBase64: signed.signedTxBase64,
        wallet: owner,
        marketId: position2.marketId
      });
      if (!sent.ok) {
        note.textContent = sent.body?.reason ?? "Solana didn't accept the claim. Nothing was taken.";
        return;
      }
      setCreateDebug({ signature: signed.signature, register: "claim sent" });
      note.textContent = "Waiting for Solana to confirm…";
      for (let attempt = 0; attempt < 5; attempt++) {
        const status = await api("/tx/status", { signature: signed.signature });
        const state = status.ok ? status.body.status : "pending";
        if (state === "confirmed") {
          note.textContent = "Claimed. Your winnings are in your wallet.";
          setCreateDebug({ register: "claim confirmed" });
          return;
        }
        if (state === "failed") {
          note.textContent = "The claim failed on Solana. Nothing was taken.";
          return;
        }
      }
      note.textContent = "Still waiting for Solana. Refresh in a minute; do not claim again.";
    }
    let mockApi = null;
    async function api(path, payload) {
      if (mockApi && path in mockApi) {
        await new Promise((resolve) => setTimeout(resolve, 60));
        return { ok: true, status: 200, body: mockApi[path] };
      }
      try {
        const message = { type: API_REQUEST, path, body: payload };
        const response = await chrome.runtime.sendMessage(message);
        return response ?? { ok: false, status: 0, body: null };
      } catch {
        return { ok: false, status: 0, body: null };
      }
    }
    function review(tile) {
      closeSheet();
      sheet = openSheet({
        tile,
        pageUrl: watchedUrl,
        api,
        image: async (category) => {
          try {
            return await chrome.runtime.sendMessage({ type: IMAGE_REQUEST, category }) ?? null;
          } catch {
            return null;
          }
        },
        settings: () => ({ dryRun: dryRunToggle.box.checked, skipChecks: skipChecksToggle.box.checked }),
        debug: setCreateDebug,
        layout,
        isVisible: () => !card.hidden && document.visibilityState === "visible",
        back: showTiles,
        created: (market) => {
          liveMarkets.set(tile.claim.id, { marketId: market.marketId, marketUrl: market.marketUrl, title: tile.claim.question });
          pulseOrb();
        },
        sound,
        bet: (target) => openBet({ ...target, yesPrice: null, noPrice: null }),
        savePending
      });
      body.classList.add("has-sheet");
      body.replaceChildren(sheet.node);
      layout();
    }
    function render(view) {
      closeSheet();
      switch (view.kind) {
        case "watching":
          setOrb("idle");
          body.replaceChildren(stateBlock("watching", "I'm watching this page."));
          break;
        case "thinking":
          setOrb("thinking");
          body.replaceChildren(stateBlock("watching", "Reading this page…"));
          break;
        case "tiles":
          tiles = view.tiles;
          showTiles();
          attachCreatorMarkets();
          break;
        case "empty":
          setOrb("idle");
          body.replaceChildren(stateBlock("empty", "Nothing to call here."));
          break;
        case "skipped":
          setOrb("idle");
          body.replaceChildren(stateBlock("skipped", "Not enough to read on this page."));
          break;
        case "error":
          setOrb("idle");
          sound("softError");
          if (view.reason === "limit") {
            body.replaceChildren(stateBlock("error", "That's all my calls for today. I'll be back tomorrow."));
          } else {
            body.replaceChildren(stateBlock("error", "I couldn't read this one just now.", rescanButton()));
          }
          break;
      }
      layout();
    }
    let scan = { read: null, state: "waiting for the page to settle", detect: null };
    function renderDebug() {
      const rows = [
        ["site", scan.read?.site ?? location.hostname.replace(/^www\./, "")],
        ["extracted", scan.read ? `${scan.read.chars} chars` : "–"],
        ["text", scan.read?.preview || "–"],
        ["detect", scan.state]
      ];
      const audio = getAudioState();
      rows.push(["audio", `${audio.muted ? "muted" : audio.context} · ${audio.last}`]);
      const detect = scan.detect;
      if (detect) {
        const worker = detect.cache ?? "–";
        rows.push(
          ["http", detect.httpStatus === null ? "no response" : String(detect.httpStatus)],
          ["cache", detect.fromClientCache ? `client 10-min rule (worker said ${worker})` : worker],
          ["claims", `${detect.claimsReturned} returned, ${detect.dropped.length} dropped`]
        );
        for (const dropped of detect.dropped) {
          rows.push(["dropped", `${dropped.reason}: ${dropped.question || "(no question)"}`]);
        }
      }
      scanInfo.replaceChildren(
        ...rows.flatMap(([name, value]) => [el("dt", "scan-name", name), el("dd", "scan-value", value)])
      );
      if (!card.hidden) layout();
    }
    function setScan(update) {
      scan = { ...scan, ...update };
      renderDebug();
    }
    onAudioState(() => renderDebug());
    let createDebug = { wallet: "–", quote: "–", simulate: "–", signature: "–", register: "–" };
    function setCreateDebug(update) {
      createDebug = { ...createDebug, ...update };
      const rows = [
        ["wallet", createDebug.wallet],
        ["quote", createDebug.quote],
        ["simulate", createDebug.simulate],
        ["signature", createDebug.signature],
        ["register", createDebug.register]
      ];
      createInfo.replaceChildren(
        ...rows.flatMap(([name, value]) => [el("dt", "scan-name", name), el("dd", "scan-value", value)])
      );
      if (!card.hidden) layout();
    }
    function savePending(pending2) {
      const done = pending2 ? chrome.storage.local.set({ [PENDING_KEY]: pending2 }) : chrome.storage.local.remove(PENDING_KEY);
      done.catch(() => {
      });
    }
    async function resumePending() {
      let pending2;
      try {
        pending2 = (await chrome.storage.local.get(PENDING_KEY))[PENDING_KEY];
      } catch {
        return;
      }
      if (!pending2?.signature || !pending2.quoteId) return;
      setCreateDebug({ signature: pending2.signature, register: "resuming an unfinished market…" });
      const response = await api("/create/register-retry", {
        signature: pending2.signature,
        quoteId: pending2.quoteId
      });
      const result = response.ok ? response.body : null;
      if (result?.registered) {
        savePending(null);
        setCreateDebug({ register: `registered (resumed): ${result.marketUrl}` });
      } else if (result?.status === "failed") {
        savePending(null);
        setCreateDebug({ register: "transaction failed on-chain (resumed)" });
      } else {
        setCreateDebug({ register: `unfinished: ${result?.registerError ?? result?.status ?? "no answer"}` });
      }
    }
    async function loadSettings() {
      dryRunToggle.box.checked = true;
      try {
        const stored = await chrome.storage.local.get([DRY_RUN_KEY, SKIP_CHECKS_KEY, MUTED_KEY, STYLE_KEY]);
        dryRunToggle.box.checked = stored[DRY_RUN_KEY] !== false;
        skipChecksToggle.box.checked = stored[SKIP_CHECKS_KEY] === true;
        setMuted(stored[MUTED_KEY] === true);
        const saved = stored[STYLE_KEY];
        if (typeof saved === "string" && [...SYNTH_STYLES, "files"].includes(saved)) setStyle(saved);
      } catch {
      }
      skipChecksToggle.box.disabled = !dryRunToggle.box.checked;
      renderMute();
    }
    dryRunToggle.box.addEventListener("change", () => {
      skipChecksToggle.box.disabled = !dryRunToggle.box.checked;
      chrome.storage.local.set({ [DRY_RUN_KEY]: dryRunToggle.box.checked }).catch(() => {
      });
      sheet?.refresh();
    });
    skipChecksToggle.box.addEventListener("change", () => {
      chrome.storage.local.set({ [SKIP_CHECKS_KEY]: skipChecksToggle.box.checked }).catch(() => {
      });
      sheet?.refresh();
    });
    let watchedUrl = currentUrl();
    let detectTimer;
    async function runDetect(url, retriesLeft, refresh) {
      if (url !== watchedUrl) return;
      const read = readPage();
      if (read.kind === "thin" && retriesLeft > 0) {
        const attempt = THIN_RETRIES - retriesLeft + 1;
        setScan({ read: read.info, state: `waiting for text, try ${attempt} of ${THIN_RETRIES} (${read.reason})` });
        detectTimer = setTimeout(() => void runDetect(url, retriesLeft - 1, refresh), THIN_RETRY_MS);
        return;
      }
      if (read.kind !== "page") {
        setScan({ read: read.info, state: `skipped (${read.reason})`, detect: null });
        render({ kind: "skipped" });
        return;
      }
      setScan({ read: read.info, state: refresh ? "running (scan again)" : "running", detect: null });
      render({ kind: "thinking" });
      const started = Date.now();
      let result;
      let relayError = "";
      try {
        const message = { type: DETECT_REQUEST, page: read.page, refresh };
        result = await chrome.runtime.sendMessage(message);
        if (!result) relayError = "background gave no answer";
      } catch {
        relayError = "background unreachable; reload this tab";
      }
      const remaining = MIN_THINKING_MS - (Date.now() - started);
      if (remaining > 0) await new Promise((resolve) => setTimeout(resolve, remaining));
      if (url !== watchedUrl) return;
      if (!result) {
        setScan({ state: `error (${relayError})`, detect: null });
        render({ kind: "error", reason: "unavailable" });
      } else if (result.status === "error") {
        setScan({ state: `error (${result.reason})`, detect: result.debug });
        render({ kind: "error", reason: result.reason });
      } else {
        setScan({ state: "done", detect: result.debug });
        if (result.tiles.length === 0) render({ kind: "empty" });
        else render({ kind: "tiles", tiles: result.tiles.slice(0, 3) });
      }
    }
    function rescan() {
      clearTimeout(detectTimer);
      void runDetect(watchedUrl, THIN_RETRIES, true);
    }
    scanAgain.addEventListener("click", rescan);
    function scheduleDetect() {
      clearTimeout(detectTimer);
      const url = watchedUrl;
      detectTimer = setTimeout(() => void runDetect(url, THIN_RETRIES, false), SETTLE_MS);
    }
    function onUrlMaybeChanged() {
      const url = currentUrl();
      if (url === watchedUrl) return;
      watchedUrl = url;
      setScan({ read: null, state: "waiting for the page to settle", detect: null });
      render({ kind: "watching" });
      scheduleDetect();
    }
    window.addEventListener("popstate", onUrlMaybeChanged);
    window.addEventListener("message", (event) => {
      if (event.source !== window || event.origin !== window.location.origin) return;
      if (event.data?.type === NAV_CHANGED) onUrlMaybeChanged();
    });
    debug.addEventListener("toggle", layout);
    function setOpen(open) {
      card.hidden = !open;
      orb.setAttribute("aria-expanded", String(open));
      if (!open) return;
      sound("open");
      dismissBubble();
      renderWalletRow();
      window.postMessage({ type: WALLET_REQUEST }, window.location.origin);
      void refreshProxy();
      sheet?.refresh();
      layout();
    }
    document.addEventListener(
      "keydown",
      (event) => {
        if (event.key === "Escape" && !card.hidden) setOpen(false);
      },
      true
    );
    document.addEventListener(
      "pointerdown",
      (event) => {
        if (!card.hidden && event.target !== host) setOpen(false);
      },
      true
    );
    let drag = null;
    let suppressClick = false;
    orb.addEventListener("pointerdown", (event) => {
      if (event.button !== 0) return;
      drag = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        origin: position,
        moved: false
      };
      orb.setPointerCapture(event.pointerId);
    });
    orb.addEventListener("pointermove", (event) => {
      if (!drag || event.pointerId !== drag.pointerId) return;
      const dx = event.clientX - drag.startX;
      const dy = event.clientY - drag.startY;
      if (!drag.moved && Math.hypot(dx, dy) < DRAG_THRESHOLD) return;
      drag.moved = true;
      orb.classList.add("dragging");
      position = { right: drag.origin.right - dx, bottom: drag.origin.bottom - dy };
      layout();
    });
    function endDrag(event) {
      if (!drag || event.pointerId !== drag.pointerId) return;
      if (drag.moved) {
        suppressClick = true;
        setTimeout(() => suppressClick = false, 0);
        savePosition(position);
      }
      orb.classList.remove("dragging");
      drag = null;
    }
    orb.addEventListener("pointerup", endDrag);
    orb.addEventListener("pointercancel", endDrag);
    orb.addEventListener("click", () => {
      if (suppressClick) {
        suppressClick = false;
        return;
      }
      setOpen(card.hidden);
    });
    window.addEventListener("resize", layout);
    renderWalletRow();
    proxyRow.set("Proxy: checking…", "idle");
    if (/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) {
      window.addEventListener("message", (event) => {
        if (event.source !== window) return;
        const data = event.data;
        if (data?.type !== "soothia:v1:dev-scene" || !data.scene) return;
        if (data.scene === "press" && data.selector) {
          card.querySelector(data.selector)?.click();
          return;
        }
        if (data.scene === "dump") {
          const node = data.selector ? card.querySelector(data.selector) : null;
          window.postMessage({ type: "soothia:v1:dev-dump", text: card.innerText, node: node ? node.outerHTML.slice(0, 300) : null }, "*");
          return;
        }
        if (data.mocks) mockApi = data.mocks;
        if (typeof data.dryRun === "boolean") dryRunToggle.box.checked = data.dryRun;
        clearTimeout(detectTimer);
        const mockTiles = data.tiles ?? [];
        const show = () => {
          tiles = mockTiles;
          if (mockTiles[2]) {
            liveMarkets.set(mockTiles[2].claim.id, {
              marketId: "CLQqZ7r6WYC5xNumWrmC7UAkQ1Z6pdCbjJSy7wQu1DgL",
              marketUrl: "https://www.panta.market/market/CLQqZ7r6WYC5xNumWrmC7UAkQ1Z6pdCbjJSy7wQu1DgL",
              title: mockTiles[2].claim.question
            });
          }
          showTiles();
        };
        switch (data.scene) {
          case "orb-idle":
            render({ kind: "watching" });
            break;
          case "orb-thinking":
            render({ kind: "thinking" });
            break;
          case "orb-found":
            show();
            break;
          case "orb-success":
            show();
            pulseOrb();
            break;
          case "tiles":
            show();
            setOpen(true);
            break;
          case "empty":
            render({ kind: "empty" });
            setOpen(true);
            break;
          case "skipped":
            render({ kind: "skipped" });
            setOpen(true);
            break;
          case "error":
            render({ kind: "error", reason: "unavailable" });
            setOpen(true);
            break;
          case "review":
            show();
            setOpen(true);
            review(mockTiles[0]);
            break;
          case "bet":
            show();
            setOpen(true);
            openBet({ marketId: "CLQqZ7r6WYC5xNumWrmC7UAkQ1Z6pdCbjJSy7wQu1DgL", title: mockTiles[1].claim.question, yesPrice: 0.5, noPrice: 0.5 });
            break;
          case "success-create":
            show();
            setOpen(true);
            review(mockTiles[0]);
            setTimeout(() => sheet?.trigger?.(), 1200);
            break;
          case "success-bet":
            show();
            setOpen(true);
            openBet({ marketId: "CLQqZ7r6WYC5xNumWrmC7UAkQ1Z6pdCbjJSy7wQu1DgL", title: mockTiles[1].claim.question, yesPrice: 0.5, noPrice: 0.5 });
            setTimeout(() => sheet?.trigger?.(), 1200);
            break;
          case "mybets":
            show();
            setOpen(true);
            showTab("bets");
            break;
          case "debug":
            show();
            setOpen(true);
            debug.open = true;
            break;
        }
      });
    }
    loadFonts();
    applyTheme();
    setTimeout(applyTheme, 1500);
    renderDebug();
    setCreateDebug({});
    await loadSettings();
    void resumePending();
    void loadCreatorMarkets();
    void maybeShowBubble();
    render({ kind: "watching" });
    document.documentElement.append(host);
    if (document.readyState === "complete") scheduleDetect();
    else window.addEventListener("load", scheduleDetect, { once: true });
  }
  if (window.top === window) void mount();
})();
