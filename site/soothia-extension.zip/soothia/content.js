(function() {
  "use strict";
  function el(tag, className, text) {
    const node = document.createElement(tag);
    node.className = className;
    if (text) node.textContent = text;
    return node;
  }
  function button(label, className, onClick) {
    const node = el("button", className, label);
    node.type = "button";
    if (onClick) node.addEventListener("click", onClick);
    return node;
  }
  function externalLink(label, href, className) {
    const node = el("a", className, label);
    node.href = href;
    node.target = "_blank";
    node.rel = "noopener noreferrer";
    return node;
  }
  const END_DATE = new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC"
  });
  function endDate(iso) {
    const date = new Date(iso);
    return Number.isNaN(date.getTime()) ? "" : END_DATE.format(date);
  }
  const SVG_NS = "http://www.w3.org/2000/svg";
  let starCount = 0;
  function starSvg(className = "star") {
    const id = `sth-chrome-${++starCount}`;
    const wrap = el("span", className);
    const svg = document.createElementNS(SVG_NS, "svg");
    svg.setAttribute("viewBox", "-50 -50 100 100");
    svg.setAttribute("aria-hidden", "true");
    svg.innerHTML = `<defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFFFFF"/><stop offset=".34" stop-color="#D3D1DE"/><stop offset=".5" stop-color="#6F6C82"/><stop offset=".64" stop-color="#F3F2F8"/><stop offset="1" stop-color="#8E8BA0"/></linearGradient></defs><path d="M0 -50 C3 -12 8 -4 32 0 C8 4 3 12 0 50 C-3 12 -8 4 -32 0 C-8 -4 -3 -12 0 -50Z" fill="url(#${id})"/><path d="M0 -50 C3 -12 8 -4 32 0 L0 0Z" fill="#FFFFFF" opacity=".38"/><path d="M0 0 L-32 0 C-8 4 -3 12 0 50Z" fill="#0E0D14" opacity=".28"/>`;
    wrap.append(svg);
    return wrap;
  }
  function icon(name) {
    const svg = document.createElementNS(SVG_NS, "svg");
    svg.setAttribute("aria-hidden", "true");
    const paths = {
      close: ["14", `<path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>`],
      refresh: [
        "12",
        `<path d="M10 6a4 4 0 1 1-1.2-2.85M10 1.5v2.5H7.5" stroke="currentColor" stroke-width="1.3" fill="none" stroke-linecap="round"/>`
      ],
      sound: [
        "14",
        `<path d="M2 5.5v3h2.2L7.5 11V3L4.2 5.5H2z" fill="currentColor"/><path d="M9.5 4.8a2.6 2.6 0 0 1 0 4.4M11.2 3a5 5 0 0 1 0 8" stroke="currentColor" stroke-width="1.3" fill="none" stroke-linecap="round"/>`
      ],
      muted: [
        "14",
        `<path d="M2 5.5v3h2.2L7.5 11V3L4.2 5.5H2z" fill="currentColor"/><path d="M9.3 5.2l3.4 3.6M12.7 5.2l-3.4 3.6" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>`
      ],
      quiet: [
        "14",
        `<path d="M11.8 8.9A5.2 5.2 0 0 1 5.1 2.2a5.2 5.2 0 1 0 6.7 6.7z" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>`
      ],
      warn: [
        "16",
        `<path d="M8 1.8l6.6 11.6H1.4z" fill="none" stroke="#F2C069" stroke-width="1.4" stroke-linejoin="round"/><path d="M8 6.5v3.2M8 11.4v.2" stroke="#F2C069" stroke-width="1.5" stroke-linecap="round"/>`
      ]
    };
    const [size, body] = paths[name];
    svg.setAttribute("width", size);
    svg.setAttribute("height", size);
    svg.setAttribute("viewBox", `0 0 ${size} ${size}`);
    svg.innerHTML = body;
    return svg;
  }
  const ORB_SIZE = 56;
  const ORB_MARGIN = 20;
  const CARD_WIDTH = 340;
  const CARD_GAP = 12;
  const EDGE_PADDING = 8;
  const FONT_SERIF = "Soothia Lora";
  const FONT_SANS = "Soothia Inter";
  const FONT_MONO = "Soothia JetBrains Mono";
  const HOST_STYLES = {
    all: "initial",
    position: "fixed",
    top: "0",
    left: "0",
    width: "0",
    height: "0",
    "z-index": "2147483647",
    display: "block",
    "pointer-events": "none"
  };
  const CHEVRON = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 10 10'%3E%3Cpath d='M2 4l3 3 3-3' stroke='%23A9A5BD' stroke-width='1.4' fill='none'/%3E%3C/svg%3E")`;
  const STYLES = `
:host {
  all: initial;

  --sth-orb-core: #F4F1FF;
  --sth-orb-mid:  #AFA9EC;
  --sth-orb-edge: #7F77DD;
  --sth-orb-deep: #534AB7;
  --sth-orb-fill: radial-gradient(circle at 38% 34%, #FFFFFF 0%, #F4F1FF 24%, #D6D1F6 52%, #AFA9EC 76%, #7F77DD 100%);
  --sth-orb-fill-bright: radial-gradient(circle at 38% 34%, #FFFFFF 0%, #F8F6FF 30%, #DFDAF9 56%, #B8B2F0 78%, #8A82E4 100%);
  --sth-orb-glow: 0 0 16px 2px rgba(127,119,221,.42), 0 0 40px 6px rgba(83,74,183,.26);
  --sth-orb-glow-bright: 0 0 22px 6px rgba(175,169,236,.7), 0 0 60px 14px rgba(127,119,221,.45);
  --sth-orb-edge-light: 0 2px 10px rgba(14,13,20,.35);
  --sth-chrome: linear-gradient(135deg, #FFFFFF 0%, #D3D1DE 34%, #6F6C82 50%, #F3F2F8 64%, #8E8BA0 100%);

  --sth-ink: #000000;
  /* Pure black surfaces; raised elements sit one level up so hierarchy survives. */
  --sth-surface: #000000;
  --sth-raised: #0B0B0F;
  --sth-raised-hover: #121218;
  --sth-surface-2: var(--sth-raised);
  --sth-surface-3: rgba(175,169,236,.10);
  --sth-hairline: rgba(175,169,236,.22);
  --sth-hairline-soft: rgba(175,169,236,.14);
  /* X dark mode is also pure black: the hairline and violet glow separate the card from the page. */
  --sth-shadow: 0 0 0 1px rgba(127,119,221,.12), 0 12px 40px rgba(83,74,183,.28), 0 24px 60px -12px rgba(0,0,0,.65);
  --sth-blur: blur(18px) saturate(140%);

  --sth-text: #F5F0E6;
  --sth-text-2: #A9A5BD;
  --sth-text-3: #8C88A0;
  --sth-text-on-orb: #16131F;
  --sth-link: #CFCAF6;

  --sth-yes: #5DCAA5;  --sth-yes-bg: rgba(93,202,165,.12);
  --sth-no:  #F0997B;  --sth-no-bg:  rgba(240,153,123,.12);
  --sth-warn: #F2C069; --sth-warn-bg: rgba(242,192,105,.10);
  --sth-focus: #F4F1FF;

  --sth-font-serif: "${FONT_SERIF}", "Lora", Georgia, serif;
  --sth-font-sans: "${FONT_SANS}", "Inter", system-ui, -apple-system, sans-serif;
  --sth-font-mono: "${FONT_MONO}", "JetBrains Mono", ui-monospace, Menlo, monospace;

  --sth-r-card: 20px; --sth-r-tile: 14px;
  --sth-r-field: 12px; --sth-r-pill: 999px;
  --sth-space-1: 4px; --sth-space-2: 8px; --sth-space-3: 12px;
  --sth-space-4: 16px; --sth-space-5: 24px;
  --sth-target: 32px;
  --sth-card-w: ${CARD_WIDTH}px; --sth-orb: ${ORB_SIZE}px;

  --sth-breathe: 4.8s; --sth-shimmer: 9s;
  --sth-think: 1.1s;   --sth-twinkle: .6s;
  --sth-pulse: .9s;    --sth-ease: cubic-bezier(.2,.7,.2,1);
}

*, *::before, *::after {
  box-sizing: border-box;
}

:host :focus-visible {
  outline: 2px solid var(--sth-focus);
  outline-offset: 2px;
}

@keyframes sthBreathe {
  0%, 100% { box-shadow: 0 0 16px 2px rgba(127,119,221,.42), 0 0 40px 6px rgba(83,74,183,.26); }
  50% { box-shadow: 0 0 24px 5px rgba(127,119,221,.6), 0 0 60px 12px rgba(83,74,183,.36); }
}
@keyframes sthBreatheBright {
  0%, 100% { box-shadow: 0 0 22px 6px rgba(175,169,236,.7), 0 0 60px 14px rgba(127,119,221,.45); }
  50% { box-shadow: 0 0 30px 9px rgba(175,169,236,.85), 0 0 80px 20px rgba(127,119,221,.55); }
}
@keyframes sthShimmer {
  0% { transform: translate(-14%, -10%) rotate(0deg); }
  50% { transform: translate(10%, 8%) rotate(180deg); }
  100% { transform: translate(-14%, -10%) rotate(360deg); }
}
@keyframes sthSpin { to { transform: rotate(360deg); } }
@keyframes sthTwinkle {
  0% { transform: scale(0) rotate(-45deg); opacity: 0; }
  60% { transform: scale(1.25) rotate(8deg); opacity: 1; }
  100% { transform: scale(1) rotate(0deg); opacity: 1; }
}
@keyframes sthPulse {
  0% { transform: scale(1); opacity: .7; }
  100% { transform: scale(2.4); opacity: 0; }
}
@keyframes sthCardIn {
  from { opacity: 0; transform: translateY(4px); }
  to { opacity: 1; transform: translateY(0); }
}

/* ---------- Orb (orb.idle / orb.thinking / orb.found / orb.success) ---------- */

.orb {
  position: fixed;
  width: var(--sth-orb);
  height: var(--sth-orb);
  padding: 0;
  border: none;
  background: transparent;
  cursor: grab;
  pointer-events: auto;
  touch-action: none;
  user-select: none;
  -webkit-user-select: none;
  transition: transform 150ms var(--sth-ease);
}
.orb:hover { transform: scale(1.04); }
.orb.dragging { cursor: grabbing; transform: scale(.96); transition: none; }

.orb-body {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  overflow: hidden;
  background: var(--sth-orb-fill);
  box-shadow: var(--sth-orb-glow);
  animation: sthBreathe var(--sth-breathe) ease-in-out infinite;
}
.orb-shimmer {
  position: absolute;
  inset: -20%;
  background:
    radial-gradient(circle at 30% 30%, rgba(255,255,255,.75) 0%, rgba(255,255,255,0) 32%),
    radial-gradient(circle at 72% 70%, rgba(127,119,221,.35) 0%, rgba(127,119,221,0) 36%);
  animation: sthShimmer var(--sth-shimmer) ease-in-out infinite;
}
/* The chrome glint on the upper-right rim: part of the mark, always on. */
.orb-glint {
  position: absolute;
  right: -6px;
  top: -8px;
  width: 22px;
  height: 22px;
  pointer-events: none;
}
.orb-glint svg, .star svg { display: block; width: 100%; height: 100%; }

.orb-arc {
  position: absolute;
  inset: -7px;
  border-radius: 50%;
  border: 1.5px solid transparent;
  border-top-color: var(--sth-text);
  border-right-color: rgba(245,240,230,.35);
  opacity: 0;
  pointer-events: none;
}
.orb[data-state="thinking"] .orb-arc {
  opacity: 1;
  animation: sthSpin var(--sth-think) linear infinite;
}
/* Ivory vanishes on a white page: the arc goes deep violet there. */
:host([data-theme="light"]) .orb-arc {
  border-top-color: var(--sth-orb-deep);
  border-right-color: rgba(83,74,183,.35);
}

.orb[data-state="found"] .orb-body {
  background: var(--sth-orb-fill-bright);
  animation: sthBreatheBright 3.2s ease-in-out infinite;
}
.orb-stars { position: absolute; inset: 0; pointer-events: none; }
.orb-stars .star {
  position: absolute;
  transform-origin: 50% 50%;
  animation: sthTwinkle var(--sth-twinkle) var(--sth-ease) both;
}
.orb-stars .star:nth-child(1) { left: -22px; top: -10px; width: 16px; height: 16px; }
.orb-stars .star:nth-child(2) { left: -34px; top: 16px; width: 12px; height: 12px; animation-delay: .12s; }
.orb-stars .star:nth-child(3) { left: 4px; top: -30px; width: 13px; height: 13px; animation-delay: .24s; }

.orb-pulse {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(244,241,255,.9) 0%, rgba(175,169,236,.4) 60%, rgba(175,169,236,0) 72%);
  opacity: 0;
  pointer-events: none;
}
.orb.success .orb-pulse { animation: sthPulse var(--sth-pulse) var(--sth-ease) both; }
.orb.success .orb-body { animation: sthBreatheBright 1.2s ease-in-out; }

/* On light pages the orb's edge needs help, and the stars a drop shadow. */
:host([data-theme="light"]) .orb-body {
  box-shadow: var(--sth-orb-glow), var(--sth-orb-edge-light), inset 0 0 0 1px rgba(83,74,183,.35);
  animation: none;
}
:host([data-theme="light"]) .orb[data-state="found"] .orb-body {
  box-shadow: var(--sth-orb-glow-bright), var(--sth-orb-edge-light), inset 0 0 0 1px rgba(83,74,183,.35);
}
:host([data-theme="light"]) .orb-stars .star,
:host([data-theme="light"]) .orb-glint { filter: drop-shadow(0 1px 1px rgba(14,13,20,.5)); }

/* ---------- Card ---------- */

.card {
  position: fixed;
  width: var(--sth-card-w);
  max-width: calc(100vw - ${EDGE_PADDING * 2}px);
  max-height: calc(100vh - ${EDGE_PADDING * 2}px);
  display: flex;
  flex-direction: column;
  border: 1px solid var(--sth-hairline);
  border-radius: var(--sth-r-card);
  background: var(--sth-surface);
  -webkit-backdrop-filter: var(--sth-blur);
  backdrop-filter: var(--sth-blur);
  box-shadow: var(--sth-shadow);
  color: var(--sth-text);
  font: 400 14px/1.45 var(--sth-font-sans);
  text-align: left;
  overflow: hidden;
  pointer-events: auto;
  animation: sthCardIn 140ms var(--sth-ease);
}
.card[hidden] { display: none; }

/* Card stars: tiny chrome four-point stars in empty corners, under all content. */
.card-stars { position: absolute; inset: 0; z-index: -1; pointer-events: none; overflow: hidden; }
.card-star { position: absolute; width: 10px; height: 10px; opacity: var(--rest, .45); animation: sthCardTwinkle 4.5s ease-in-out infinite; }
.card-star svg { display: block; width: 100%; height: 100%; overflow: visible; }
.card-star:nth-child(1) { right: 16px; top: 12px; width: 11px; height: 11px; --rest: .5; animation-duration: 3.8s; animation-delay: .4s; }
.card-star:nth-child(2) { right: 36px; top: 30px; width: 8px; height: 8px; --rest: .35; animation-duration: 5.6s; animation-delay: 2.1s; }
.card-star:nth-child(3) { left: 12px; bottom: 14px; width: 10px; height: 10px; --rest: .45; animation-duration: 4.4s; animation-delay: 1.3s; }
.card-star:nth-child(4) { right: 14px; bottom: 12px; width: 12px; height: 12px; --rest: .6; animation-duration: 5.9s; animation-delay: 3.2s; }
.card-star:nth-child(5) { right: 40px; bottom: 30px; width: 8px; height: 8px; --rest: .3; animation-duration: 3.4s; animation-delay: .9s; }
.card-star:nth-child(6) { right: 8px; top: 48%; width: 9px; height: 9px; --rest: .4; animation-duration: 6s; animation-delay: 2.7s; }
/* Sheets are narrow and busy: keep three. */
.card:has(.has-sheet) .card-star:nth-child(n+4) { display: none; }
@keyframes sthCardTwinkle { 0%,70%,100% { opacity: var(--rest, .45); transform: scale(1); filter: none; } 85% { opacity: .8; transform: scale(1.25) rotate(8deg); filter: drop-shadow(0 0 4px rgba(244,241,255,.8)); } }

.card-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex: none;
  padding: 14px 12px 12px 16px;
}
.brand { display: flex; align-items: center; gap: 10px; }
.mark { position: relative; width: 20px; height: 20px; flex: none; }
.mark-body {
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: var(--sth-orb-fill);
  box-shadow: 0 0 8px rgba(127,119,221,.6);
}
.mark .star { position: absolute; right: -4px; top: -5px; width: 11px; height: 11px; }
.wordmark { font: 500 18px/1 var(--sth-font-serif); color: var(--sth-text); }
.close {
  width: 32px;
  height: 32px;
  border: 0;
  border-radius: 10px;
  background: transparent;
  color: var(--sth-text-2);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}
.close:hover { background: var(--sth-surface-3); color: var(--sth-text); }
.close svg { display: block; }
.head-actions { display: flex; align-items: center; gap: 2px; }
.close.quiet[hidden] { display: none; }

/* First-run speech bubble, attached to the orb. */
.bubble {
  position: fixed;
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 12px 10px 12px 14px;
  border: 1px solid var(--sth-hairline);
  border-radius: 14px;
  background: var(--sth-raised);
  box-shadow: var(--sth-shadow);
  color: var(--sth-text);
  pointer-events: auto;
  animation: sthCardIn 400ms var(--sth-ease);
}
.bubble[hidden] { display: none; }
.bubble::after {
  content: "";
  position: absolute;
  width: 10px;
  height: 10px;
  background: var(--sth-raised);
  border-right: 1px solid var(--sth-hairline);
  border-bottom: 1px solid var(--sth-hairline);
}
.bubble[data-side="left"]::after { right: -6px; top: calc(50% - 5px); transform: rotate(-45deg); }
.bubble[data-side="above"]::after { bottom: -6px; right: 22px; transform: rotate(45deg); }
.bubble[data-side="below"]::after { top: -6px; right: 22px; transform: rotate(-135deg); }
.bubble-text { margin: 0; font: 400 14px/1.45 var(--sth-font-serif); }
.bubble-close {
  flex: none;
  width: 24px;
  height: 24px;
  margin: -4px -2px 0 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--sth-text-2);
  cursor: pointer;
}
.bubble-close:hover { background: var(--sth-surface-3); color: var(--sth-text); }
.bubble-close svg { display: block; margin: auto; width: 11px; height: 11px; }

.replay { display: flex; flex-wrap: wrap; gap: 4px 14px; margin: 4px 0 6px; }
.replay .link { min-height: 26px; }

.tabs {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 4px;
  flex: none;
  margin: 0 16px 12px;
  padding: 3px;
  border: 1px solid var(--sth-hairline-soft);
  border-radius: var(--sth-r-pill);
  background: var(--sth-surface-2);
}
.tab {
  height: 32px;
  border: 0;
  border-radius: var(--sth-r-pill);
  background: transparent;
  color: var(--sth-text-2);
  font: 500 13px/1 var(--sth-font-sans);
  cursor: pointer;
}
.tab.selected { background: var(--sth-raised-hover); color: var(--sth-text); }

.body {
  flex: 1 1 auto;
  min-height: 0;
  overflow-y: auto;
  padding: 0 12px 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.body[hidden] { display: none; }
/* While a sheet is open the body stops scrolling: the sheet's form scrolls
   under its own fixed footer instead ("button sticks to the bottom"). */
.body.has-sheet { padding: 0; overflow: hidden; gap: 0; }

/* ---------- Type ---------- */

.line {
  margin: 0;
  color: var(--sth-text-2);
  font: 400 13px/1.5 var(--sth-font-sans);
}
.note, .muted {
  margin: 0;
  color: var(--sth-text-2);
  font: 400 12px/1.5 var(--sth-font-sans);
}
.note:empty, .muted:empty, .status-line:empty, .warn:empty { display: none; }
.mono { font-family: var(--sth-font-mono); }
.status-line { margin: 10px 0 0; color: var(--sth-text); font: 400 13px/1.5 var(--sth-font-sans); }

/* ---------- Buttons (btn.primary / btn.secondary / link) ---------- */

.button {
  height: 36px;
  padding: 0 18px;
  border: 1px solid rgba(175,169,236,.3);
  border-radius: var(--sth-r-pill);
  background: rgba(175,169,236,.08);
  color: var(--sth-text);
  font: 600 13px/1 var(--sth-font-sans);
  cursor: pointer;
  white-space: nowrap;
}
.button { background: var(--sth-raised); }
.button:hover { background: var(--sth-raised-hover); }
.button.primary {
  padding: 0 14px;
  border: 0;
  background: linear-gradient(180deg, #F4F1FF, #C9C3F2);
  color: var(--sth-text-on-orb);
  box-shadow: 0 0 0 1px rgba(255,255,255,.4) inset, 0 4px 14px -4px rgba(127,119,221,.6);
}
.button.primary:hover {
  background: linear-gradient(180deg, #FFFFFF, #D6D1F6);
  box-shadow: 0 6px 20px -4px rgba(175,169,236,.7);
}
.button.wide {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  width: 100%;
  height: 44px;
  font-size: 14px;
}
.button.ext::after { content: " \\2197"; margin-left: 4px; }
.button.wide.primary { box-shadow: 0 0 0 1px rgba(255,255,255,.4) inset, 0 6px 20px -6px rgba(127,119,221,.7); }
.button.small { height: 32px; padding: 0 16px; }
.button:disabled, .button[aria-disabled="true"], .button.primary:disabled {
  border: 0;
  background: rgba(175,169,236,.12);
  color: var(--sth-text-3);
  box-shadow: none;
  cursor: not-allowed;
}
a.button { display: inline-flex; align-items: center; justify-content: center; text-decoration: none; }

.link {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-height: 32px;
  padding: 0;
  border: none;
  background: none;
  color: var(--sth-link);
  font: 500 13px/1 var(--sth-font-sans);
  text-decoration: none;
  cursor: pointer;
}
.link:hover { color: var(--sth-text); text-decoration: underline; }
.link.ext::after { content: " \\2197"; }
.link.block { display: flex; margin-top: 4px; }
.link.mono { font: 400 12px/1 var(--sth-font-mono); color: var(--sth-text-2); }
.ghost {
  height: 32px;
  padding: 0 10px;
  border: 0;
  border-radius: 10px;
  background: transparent;
  color: var(--sth-text-2);
  font: 500 12px/1 var(--sth-font-sans);
  cursor: pointer;
}
.ghost:hover { color: var(--sth-text); background: var(--sth-surface-3); }

/* ---------- Claim tiles ---------- */

.tile {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 14px;
  border: 1px solid var(--sth-hairline-soft);
  border-radius: var(--sth-r-tile);
  background: var(--sth-raised);
}
.meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
.chip {
  padding: 5px 8px;
  border-radius: var(--sth-r-pill);
  background: var(--sth-raised-hover);
  color: var(--sth-link);
  font: 500 11px/1 var(--sth-font-sans);
  letter-spacing: .06em;
  text-transform: uppercase;
}
.ends { color: var(--sth-text-2); font: 400 11px/1 var(--sth-font-mono); }
.question {
  margin: 0;
  color: var(--sth-text);
  font: 400 17px/1.4 var(--sth-font-serif);
  text-wrap: pretty;
  overflow-wrap: anywhere;
}
.quote.from-match { font-style: normal; color: var(--sth-text-2); }
.from-match-label { display: inline-block; padding: 2px 7px; margin-right: 2px; border-radius: 999px; background: var(--sth-raised-hover); color: var(--sth-link); font: 600 10px/1.4 var(--sth-font-sans); letter-spacing: .06em; text-transform: uppercase; }
.quote {
  margin: 0;
  color: var(--sth-text-2);
  font: italic 400 13px/1.5 var(--sth-font-serif);
  overflow-wrap: anywhere;
}
.actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}
.actions.end { justify-content: flex-end; }

/* ---------- Empty / skipped / error (this-page.empty, .skipped, .error) ---------- */

.state {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 14px;
  padding: 36px 12px 40px;
  text-align: center;
}
.state.error { padding: 32px 12px; gap: 16px; }
.state-orb {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: radial-gradient(circle at 38% 34%, #F4F1FF 0%, #AFA9EC 60%, #534AB7 100%);
  opacity: .55;
}
.state.skipped .state-orb { opacity: .35; }
.state.error .state-orb { opacity: .35; box-shadow: 0 0 0 1.5px rgba(240,153,123,.6); }
.state-text { margin: 0; color: var(--sth-text); font: 400 19px/1.4 var(--sth-font-serif); }

/* ---------- Sheets ---------- */

.sheet { display: flex; flex-direction: column; flex: 1 1 auto; min-height: 0; }
.sheet-head {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: none;
  padding: 10px 12px;
  border-top: 1px solid var(--sth-hairline-soft);
  border-bottom: 1px solid var(--sth-hairline-soft);
}
.back {
  height: 32px;
  padding: 0 8px;
  border: 0;
  border-radius: 10px;
  background: transparent;
  color: var(--sth-text-2);
  font: 500 13px/1 var(--sth-font-sans);
  cursor: pointer;
}
.back:hover { color: var(--sth-text); background: var(--sth-surface-3); }
.sheet-title { margin: 0 0 0 4px; color: var(--sth-text); font: 500 16px/1 var(--sth-font-serif); }
.form, .outcome {
  display: flex;
  flex-direction: column;
  flex: 1 1 auto;
  min-height: 0;
  gap: 18px;
  padding: 16px;
  overflow-y: auto;
}
/* Once an outcome shows, the footer button has done its job. */
.outcome:not([hidden]) ~ .sheet-foot { display: none; }
.form[hidden], .outcome[hidden] { display: none; }
.sheet-foot {
  flex: none;
  padding: 12px 16px 16px;
  border-top: 1px solid var(--sth-hairline-soft);
}
.sheet-foot:empty { display: none; }
.sheet-foot .status-line { margin: 0 0 10px; }

.field { display: flex; flex-direction: column; gap: 8px; }
.field-label {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  color: var(--sth-text-2);
  font: 500 12px/1.2 var(--sth-font-sans);
}
.counter { color: var(--sth-text-3); font: 400 11px/1 var(--sth-font-mono); }
.counter.over { color: var(--sth-no); font-weight: 500; }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }

.input {
  display: block;
  width: 100%;
  min-height: 40px;
  padding: 0 12px;
  border: 1px solid var(--sth-hairline);
  border-radius: var(--sth-r-field);
  background: var(--sth-surface-2);
  color: var(--sth-text);
  color-scheme: dark;
  font: 500 13px/1.3 var(--sth-font-sans);
}
.input:focus-visible {
  outline: none;
  border-color: rgba(175,169,236,.45);
  box-shadow: 0 0 0 3px rgba(175,169,236,.12);
}
textarea.input {
  padding: 12px;
  font: 400 16px/1.45 var(--sth-font-serif);
  resize: vertical;
}
select.input {
  padding-right: 30px;
  appearance: none;
  -webkit-appearance: none;
  background-image: ${CHEVRON};
  background-repeat: no-repeat;
  background-position: right 10px center;
  cursor: pointer;
}
input[type="date"].input { font-family: var(--sth-font-mono); }
input[type="number"].input { font-family: var(--sth-font-mono); }

/* Amber warning */
.warn {
  display: flex;
  gap: 10px;
  margin: 0;
  padding: 10px 12px;
  border: 1px solid rgba(242,192,105,.3);
  border-radius: var(--sth-r-field);
  background: var(--sth-warn-bg);
  color: var(--sth-warn);
  font: 400 12.5px/1.5 var(--sth-font-sans);
}
.warn svg { flex: none; margin-top: 1px; }
.warn .mono { font-family: var(--sth-font-mono); }

/* ---------- Call sheet ---------- */

.sides { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.side {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: 68px;
  border: 1px solid var(--sth-hairline);
  border-radius: var(--sth-r-tile);
  background: var(--sth-raised);
  cursor: pointer;
}
.side:hover { background: var(--sth-raised-hover); }
.side-label { color: var(--sth-text-2); font: 600 13px/1 var(--sth-font-sans); letter-spacing: .06em; }
.side-pct { color: var(--sth-text-2); font: 500 22px/1 var(--sth-font-mono); }
.side-yes.selected { border: 1.5px solid var(--sth-yes); background: var(--sth-yes-bg); }
.side-yes.selected .side-label, .side-yes.selected .side-pct { color: var(--sth-yes); }
.side-no.selected { border: 1.5px solid var(--sth-no); background: var(--sth-no-bg); }
.side-no.selected .side-label, .side-no.selected .side-pct { color: var(--sth-no); }

.button.buy { border: 0; color: var(--sth-ink); }
.button.buy[data-side="yes"] { background: var(--sth-yes); box-shadow: 0 6px 20px -8px rgba(93,202,165,.8); }
.button.buy[data-side="no"] { background: var(--sth-no); box-shadow: 0 6px 20px -8px rgba(240,153,123,.8); }
.button.buy:disabled { background: rgba(175,169,236,.12); color: var(--sth-text-3); box-shadow: none; }

/* ---------- Success ---------- */

.success { padding: 28px 20px 20px; gap: 18px; align-items: stretch; }

/* ---------- Record rows ---------- */

.refresh-row { display: flex; justify-content: flex-end; }
.refresh-row .link { padding: 0 4px; font-size: 12px; }
.positions { display: flex; flex-direction: column; gap: 8px; }
.position { display: flex; align-items: center; gap: 10px; }
.side-chip {
  flex: none;
  width: 28px;
  background: var(--sth-raised-hover);
  padding: 5px 0;
  border-radius: 6px;
  text-align: center;
  font: 600 11px/1 var(--sth-font-sans);
  letter-spacing: .06em;
}
.side-chip-yes { color: var(--sth-yes); background: var(--sth-yes-bg); }
.side-chip-no { color: var(--sth-no); background: var(--sth-no-bg); }
.position-text { color: var(--sth-text); font: 400 13px/1 var(--sth-font-mono); }

/* ---------- Total Recall on tiles ---------- */
.tile-recall { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.called-row { display: flex; flex-wrap: wrap; align-items: center; gap: 6px 12px; }
.called-badge {
  padding: 5px 8px;
  border-radius: var(--sth-r-pill);
  background: var(--sth-raised-hover);
  color: var(--sth-link);
  font: 500 11px/1.3 var(--sth-font-mono);
  overflow-wrap: anywhere;
}
.call-it { margin-left: auto; }
.call-slider-head { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; }
.call-value { color: var(--sth-text); font: 500 15px/1 var(--sth-font-mono); }
.call-slider { width: 100%; margin: 0; accent-color: var(--sth-orb-edge); cursor: pointer; }
.call-nudge { display: flex; flex-direction: column; align-items: flex-start; gap: 6px; }
.call-nudge[hidden], .call-nudge .link[hidden] { display: none; }
.tile-notes { display: flex; flex-direction: column; gap: 4px; }
.tile-note { margin: 0; color: var(--sth-text-3); font: 400 12px/1.45 var(--sth-font-sans); overflow-wrap: anywhere; }

/* ---------- My record ---------- */
.record-headline { margin: 0; color: var(--sth-text); font: 400 17px/1.4 var(--sth-font-serif); }
.record-section { display: flex; flex-direction: column; gap: 8px; margin-top: 6px; }
.record-section h3 { margin: 0; }
.cal-list { display: flex; flex-direction: column; gap: 12px; }
.cal-bucket { display: flex; flex-direction: column; gap: 5px; }
.cal-label { margin: 0; color: var(--sth-text-2); font: 400 12px/1 var(--sth-font-mono); }
.cal-bar { display: grid; grid-template-columns: 56px 1fr 36px; align-items: center; gap: 8px; }
.cal-name { color: var(--sth-text-3); font: 400 11px/1 var(--sth-font-sans); }
.cal-track { display: block; height: 6px; border-radius: var(--sth-r-pill); background: var(--sth-raised-hover); overflow: hidden; }
.cal-fill { display: block; height: 100%; border-radius: var(--sth-r-pill); }
.cal-fill.claimed { background: var(--sth-orb-mid); }
.cal-fill.landed { background: var(--sth-yes); }
.cal-value { color: var(--sth-text-2); font: 400 11px/1 var(--sth-font-mono); text-align: right; }
.record-table { width: 100%; border-collapse: collapse; color: var(--sth-text); font: 400 13px/1.3 var(--sth-font-sans); }
.record-table th { padding: 4px 0; color: var(--sth-text-3); font: 500 11px/1 var(--sth-font-sans); text-align: right; }
.record-table td { padding: 5px 0; border-top: 1px solid var(--sth-hairline-soft); text-align: right; }
.record-table th:first-child, .record-table td:first-child { text-align: left; overflow-wrap: anywhere; }
.lesson-text { margin: 0; color: var(--sth-text); font: 400 14px/1.45 var(--sth-font-serif); }
.record-call { gap: 8px; }
.record-match { margin: 0; color: var(--sth-text); font: 400 15px/1.35 var(--sth-font-serif); overflow-wrap: anywhere; }
.record-proof { display: flex; flex-wrap: wrap; align-items: center; gap: 4px 12px; }
.proof-result { flex: 1 1 auto; }
.proof-result.good { color: var(--sth-yes); }
.record-footer { margin-top: 8px; overflow-wrap: anywhere; }
.quiet-list { display: flex; flex-direction: column; gap: 4px; }
.quiet-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.quiet-site { color: var(--sth-text); font: 400 13px/1 var(--sth-font-mono); overflow-wrap: anywhere; }
/* ---------- Debug footer ---------- */

.debug {
  flex: none;
  padding: 8px 16px 12px;
  border-top: 1px solid rgba(175,169,236,.10);
  color: var(--sth-text-3);
  font: 400 11px/1.7 var(--sth-font-mono);
}
.debug-summary {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 32px;
  list-style: none;
  cursor: pointer;
  user-select: none;
  -webkit-user-select: none;
}
.debug-summary::-webkit-details-marker { display: none; }
.debug-summary::before {
  content: "";
  width: 8px;
  height: 8px;
  background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8' viewBox='0 0 8 8'%3E%3Cpath d='M2 1l4 3-4 3z' fill='%238C88A0'/%3E%3C/svg%3E") center no-repeat;
  transition: transform 120ms var(--sth-ease);
}
.debug[open] .debug-summary::before { transform: rotate(90deg); }
.scan {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 2px 10px;
  margin: 0 0 8px;
}
.scan[hidden] { display: none; }
.debug-version { margin-left: auto; color: var(--sth-text-3); }
.scan-name { color: var(--sth-text-3); }
.scan-value { margin: 0; color: var(--sth-text-2); overflow-wrap: anywhere; }
.debug .button.small { margin: 2px 0 8px; font-size: 12px; }
.toggle { display: flex; align-items: center; gap: 8px; padding: 3px 0; color: var(--sth-text-2); cursor: pointer; }
.toggle-box { margin: 0; accent-color: var(--sth-orb-edge); }
.recall-field { margin: 8px 0; }
.stake-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-top: 8px; }
.stake-line { margin: 0; font-size: 12px; color: var(--sth-text-2); }
.stake-row .button.small { flex: none; margin: 0; }
.back-side { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.back-chips { display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; margin: 6px 0; }
.back-chips .button.small { margin: 0; padding: 0; }
.back-chip.selected { outline: 2px solid var(--sth-text-2); outline-offset: -2px; }
.back-custom { width: 100%; height: 32px; font-size: 12px; }
.back-estimate:empty { display: none; }
.back-estimate { margin: 8px 0 0; font-size: 13px; }
.status-line.bad, .stake-claim-note.bad { color: var(--sth-no); }
.button.primary.back-submit:disabled, .button.primary.back-submit:disabled:hover {
  background: linear-gradient(180deg, #F4F1FF, #C9C3F2);
  color: var(--sth-text-on-orb);
  box-shadow: 0 0 0 1px rgba(255,255,255,.4) inset;
  opacity: .55;
}
.stake-block { margin-top: 8px; display: flex; flex-wrap: wrap; align-items: center; gap: 6px; }
.stake-text { font-size: 12px; color: var(--sth-text-2); flex: 1 1 auto; min-width: 0; }
.stake-block .button.small { flex: none; margin: 0; }
.stake-claim-note { flex: 1 1 100%; margin: 0; font-size: 12px; color: var(--sth-text-2); overflow-wrap: anywhere; }
.stake-claim-note:empty { display: none; }
.wallet-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; }
.wallet-stat { display: flex; flex-direction: column; font-size: 12px; color: var(--sth-text-2); }
.wallet-stat b { font-size: 14px; font-weight: 500; color: var(--sth-text); }
.record-header { display: flex; flex-direction: column; align-items: flex-start; margin-bottom: 10px; }
.record-identity { display: flex; align-items: center; gap: 8px; width: 100%; font-size: 12px; color: var(--sth-text-2); }
.record-who { font-weight: 600; color: var(--sth-text); }
.record-identity .refresh-row { margin: 0 0 0 auto; }
.record-score { margin: 6px 0 0; font-size: 40px; font-weight: 600; line-height: 1; color: var(--sth-text); }
.record-score-label { margin: 2px 0 0; font-size: 11px; letter-spacing: .08em; color: var(--sth-text-2); }
.record-tally { margin: 6px 0 0; font-size: 13px; color: var(--sth-text); }
.record-attention { display: flex; flex-direction: column; gap: 6px; margin-bottom: 10px; }
.record-attention-item { padding: 8px 10px; border: 1px solid rgba(175,169,236,.3); border-radius: 8px; background: var(--sth-raised); color: var(--sth-text); font: 500 12px/1.3 var(--sth-font-sans); text-align: left; cursor: pointer; }
.record-attention-item:hover { background: var(--sth-raised-hover); }
.record-segments { display: grid; grid-template-columns: repeat(4, 1fr); gap: 2px; margin-bottom: 10px; padding: 2px; border-radius: 8px; background: var(--sth-raised); }
.record-segment { padding: 7px 0; border: 0; border-radius: 6px; background: transparent; color: var(--sth-text-2); font: 500 12px/1 var(--sth-font-sans); cursor: pointer; }
.record-segment.selected { background: var(--sth-raised-hover); color: var(--sth-text); }
.call-row { border-bottom: 1px solid rgba(175,169,236,.14); }
.call-row-head { display: flex; flex-direction: column; gap: 2px; width: 100%; padding: 8px 0; border: 0; background: transparent; color: var(--sth-text); font: 400 13px/1.35 var(--sth-font-sans); text-align: left; cursor: pointer; }
.call-row-top { display: flex; align-items: baseline; gap: 6px; }
.call-icon { flex: none; font-weight: 700; }
.call-icon.right { color: var(--sth-yes); }
.call-icon.wrong { color: var(--sth-no); }
.call-match { flex: 1 1 auto; min-width: 0; font-weight: 600; overflow-wrap: anywhere; }
.call-date { flex: none; font-size: 12px; color: var(--sth-text-2); }
.call-lean { font-size: 12px; color: var(--sth-text-2); }
.call-detail { display: flex; flex-direction: column; gap: 4px; padding: 0 0 10px; }
.call-detail-line { margin: 0; font-size: 12px; color: var(--sth-text-2); }
.record-show-more { align-self: flex-start; margin-top: 6px; }
.record-more { margin-top: 10px; font-size: 12px; color: var(--sth-text-2); }
.record-more-summary { cursor: pointer; }
.record-more .note { margin: 6px 0 0; }
.orb-badge { position: absolute; top: -2px; right: -2px; min-width: 16px; height: 16px; padding: 0 4px; border-radius: 999px; background: var(--sth-no); color: var(--sth-text-on-orb); font: 700 10px/16px var(--sth-font-sans); text-align: center; pointer-events: none; }
.social-slot { display: flex; flex-direction: column; gap: 6px; }
.feed-row { display: flex; flex-direction: column; gap: 2px; padding: 8px 0; border-bottom: 1px solid rgba(175,169,236,.14); }
.feed-top { display: flex; justify-content: space-between; gap: 8px; align-items: baseline; }
.feed-handle { min-width: 0; font-weight: 600; overflow-wrap: anywhere; }
.feed-time { flex: none; font-size: 11px; color: var(--sth-text-3); }
.feed-match { margin: 0; font-size: 13px; font-weight: 600; color: var(--sth-text); overflow-wrap: anywhere; }
.feed-call, .feed-mine { margin: 0; font-size: 12px; color: var(--sth-text-2); }
.feed-tail { align-self: flex-start; margin: 4px 0 0; }
.follow-search { width: 100%; height: 32px; font-size: 13px; }
.follow-results, .follow-list { display: flex; flex-direction: column; }
.follow-results:empty { display: none; }
.follow-row { display: flex; align-items: center; gap: 8px; padding: 6px 0; border-bottom: 1px solid rgba(175,169,236,.14); }
.follow-row .feed-handle { flex: 1 1 auto; }
.follow-row .button.small { flex: none; margin: 0; }
.followed { margin-top: 6px; }
.followed-head { display: flex; align-items: center; gap: 6px; width: 100%; padding: 0; border: 0; background: transparent; color: var(--sth-text-2); font: 400 12px/1.35 var(--sth-font-sans); text-align: left; cursor: pointer; }
.followed-avatars { display: inline-flex; flex: none; }
.followed-avatar { display: inline-block; width: 18px; height: 18px; margin-right: -4px; border-radius: 50%; background: var(--sth-orb-mid); color: var(--sth-text-on-orb); font: 700 9px/18px var(--sth-font-sans); text-align: center; }
.followed-text { min-width: 0; margin-left: 6px; }
.followed-list { display: flex; flex-direction: column; gap: 4px; margin-top: 6px; }
.followed-call { display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--sth-text-2); }
.followed-who { flex: none; font-weight: 600; color: var(--sth-text); }
.followed-lean { flex: 1 1 auto; min-width: 0; }
.followed-call .button.small { flex: none; margin: 0; }
.feed-premium { color: var(--sth-orb-mid); font-weight: 600; }
.premium-unlock { display: flex; flex-direction: column; align-items: flex-start; gap: 4px; }
.premium-unlock .button.small { margin: 4px 0 0; }
.premium-unlock .note { margin: 0; }
.premium-receipt { margin: 2px 0 0; display: flex; align-items: center; gap: 4px; flex-wrap: wrap; }
.followed-call .premium-unlock { flex: none; align-items: flex-end; }
.followed-call .premium-unlock .button.small { margin: 0; }
.premium-field { display: flex; flex-direction: column; gap: 6px; margin-top: 8px; }
.premium-choices { display: flex; flex-direction: column; gap: 6px; }
.premium-choices[hidden] { display: none; }
.premium-prices { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; }
.premium-price { margin: 0; }
.premium-price.selected { border-color: var(--sth-orb-mid); color: var(--sth-orb-mid); }
.premium-custom { flex: 1 1 96px; min-width: 96px; height: 30px; font-size: 12px; }
.agent-switch { display: inline-flex; align-items: center; gap: 6px; font-size: 13px; color: var(--sth-text); cursor: pointer; }
.agent-check { width: 16px; height: 16px; margin: 0; accent-color: var(--sth-orb-mid); }
.agent-body, .agent-info { display: flex; flex-direction: column; gap: 6px; }
.agent-info .note, .agent-info .warn { margin: 0; }
.agent-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.agent-row .button.small { margin: 0; }
.agent-input { flex: 0 1 96px; width: 96px; height: 30px; font-size: 12px; }
.agent-body > .button.small { align-self: flex-start; margin: 0; }
.agent-note { margin: 0; color: var(--sth-orb-mid); }
.agent-receipt { display: flex; flex-direction: column; gap: 2px; padding: 4px 0; font-size: 11px; color: var(--sth-text-2); overflow-wrap: anywhere; border-bottom: 1px solid rgba(175,169,236,.14); }
.tail-label { margin: 0 0 6px; font-size: 12px; font-weight: 600; color: var(--sth-orb-mid); }
.go-public { padding: 10px; border: 1px solid var(--sth-hairline-soft, rgba(175,169,236,.14)); border-radius: 10px; }
.go-public-handle { width: 100%; height: 32px; font-size: 13px; }
.go-public-title { margin: 0; font-size: 14px; font-weight: 600; color: var(--sth-text); }
.go-public .button.small { align-self: flex-start; margin: 0; }
.go-public-status:empty { display: none; }
.board-periods { display: flex; gap: 6px; margin-bottom: 8px; }
.board-periods .button.small { margin: 0; padding: 0 10px; }
.board-period.selected { outline: 2px solid var(--sth-text-2); outline-offset: -2px; }
.board-row { display: grid; grid-template-columns: 24px minmax(0, 1fr) auto; gap: 0 8px; align-items: baseline; padding: 8px 0; border-bottom: 1px solid rgba(175,169,236,.14); }
.board-rank { color: var(--sth-text-2); font-size: 12px; }
.board-handle { min-width: 0; overflow-wrap: anywhere; }
.board-score { font-weight: 600; color: var(--sth-text); }
.board-meta { grid-column: 2 / -1; }
.board-all { display: inline-block; margin-top: 10px; }
.wallet-field { margin: 8px 0; }
.wallet-row { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; }
.wallet-row .button.small { margin: 0; padding: 0 10px; }
.wallet-picker { margin-top: 6px; }
.wallet-note { margin: 6px 0 0; font-size: 12px; color: var(--sth-text-3); overflow-wrap: anywhere; }
.wallet-note:empty { display: none; }
.recall-row { display: flex; align-items: center; gap: 6px; }
.recall-row .input { flex: 1 1 auto; min-width: 0; height: 32px; font-size: 12px; }
.recall-row .button.small { margin: 0; padding: 0 10px; }
.status { display: flex; align-items: center; gap: 10px; padding: 6px 0; }
.status[hidden] { display: none; }
.dot { flex: none; width: 8px; height: 8px; border-radius: 50%; background: var(--sth-text-3); }
.status[data-state="good"] .dot { background: var(--sth-yes); box-shadow: 0 0 6px rgba(93,202,165,.6); }
.status[data-state="bad"] .dot { background: var(--sth-no); }

@media (prefers-reduced-motion: reduce) {
  :host * { animation: none !important; transition: none !important; }
  /* The thinking arc stays visible and static; found stars render at rest;
     the success pulse is replaced by the found glow for 1.2s. */
  .orb[data-state="thinking"] .orb-arc { opacity: 1; }
  .orb-stars .star, .flourish .star { opacity: 1; transform: none; }
  .orb.success .orb-body { background: var(--sth-orb-fill-bright); box-shadow: var(--sth-orb-glow-bright); }
  .card-star { opacity: .4; transform: none; }
}
`;
  const FACES = [
    { family: FONT_SERIF, file: "fonts/soothia-lora.woff2", style: "normal" },
    { family: FONT_SERIF, file: "fonts/soothia-lora-italic.woff2", style: "italic" },
    { family: FONT_SANS, file: "fonts/soothia-inter.woff2", style: "normal" },
    { family: FONT_MONO, file: "fonts/soothia-jetbrains-mono.woff2", style: "normal" }
  ];
  function loadFonts() {
    if (typeof FontFace === "undefined" || !document.fonts) return;
    for (const face of FACES) {
      try {
        const font = new FontFace(face.family, `url(${chrome.runtime.getURL(face.file)}) format("woff2")`, {
          style: face.style,
          weight: "100 900",
          display: "swap"
        });
        document.fonts.add(font);
        font.load().catch(() => {
        });
      } catch {
      }
    }
  }
  const SYNTH_STYLES = ["musicbox", "celesta", "chimes"];
  const DEFAULT_STYLE = "celesta";
  const MASTER_VOLUME = 0.25;
  const FLOOR = 1e-4;
  const PENDING_MAX_AGE_MS = 1500;
  const REVERB_SECONDS = 1.6;
  let context = null;
  let master = null;
  let reverbSend = null;
  let muted = false;
  let style = DEFAULT_STYLE;
  let last = "–";
  let pending = null;
  const armedRoots = /* @__PURE__ */ new WeakSet();
  const listeners = /* @__PURE__ */ new Set();
  let onPlay = null;
  function notify() {
    const state = getAudioState();
    for (const listener of listeners) listener(state);
  }
  function getAudioState() {
    return { context: context ? context.state : "not created", muted, style, last };
  }
  function onAudioState(listener) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  }
  function impulse(ctx) {
    const length = Math.floor(ctx.sampleRate * REVERB_SECONDS);
    const buffer = ctx.createBuffer(2, length, ctx.sampleRate);
    for (let channel = 0; channel < 2; channel++) {
      const data = buffer.getChannelData(channel);
      let smooth = 0;
      for (let i = 0; i < length; i++) {
        const decay = Math.pow(1 - i / length, 2.6);
        smooth += (Math.random() * 2 - 1 - smooth) * 0.35;
        data[i] = smooth * decay;
      }
    }
    return buffer;
  }
  function ensureContext() {
    if (context) return context;
    try {
      context = new AudioContext();
      master = context.createGain();
      master.gain.value = MASTER_VOLUME;
      master.connect(context.destination);
      const reverb = context.createConvolver();
      reverb.buffer = impulse(context);
      reverbSend = context.createGain();
      reverbSend.gain.value = 0.3;
      reverbSend.connect(reverb).connect(master);
    } catch {
      context = null;
    }
    notify();
    return context;
  }
  function wake() {
    const ctx = ensureContext();
    if (!ctx || ctx.state === "running") return;
    ctx.resume().then(
      () => {
        notify();
        if (pending && Date.now() - pending.at <= PENDING_MAX_AGE_MS) playSound(pending.name);
        pending = null;
      },
      () => {
      }
    );
  }
  function armSounds(root = window) {
    if (armedRoots.has(root)) return;
    armedRoots.add(root);
    for (const type of ["pointerdown", "keydown", "touchstart"]) {
      root.addEventListener(type, wake, { capture: true, passive: true });
    }
  }
  function setMuted(value) {
    muted = value;
    notify();
  }
  function isMuted() {
    return muted;
  }
  function setStyle(value) {
    style = value;
    notify();
  }
  const PENTATONIC = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21];
  const C6 = 1046.5;
  function pitch(degree) {
    return C6 * Math.pow(2, PENTATONIC[Math.max(0, Math.min(PENTATONIC.length - 1, degree))] / 12);
  }
  const humanSeconds = () => (Math.random() * 2 - 1) * 0.012;
  const cents = () => (Math.random() * 2 - 1) * 8;
  const TIMBRES = {
    // Plucked, delicate, short, a touch of tine brightness.
    musicbox: {
      ratios: [1, 2.76, 5.4, 8.93],
      gains: [1, 0.42, 0.18, 0.06],
      partialDecay: [1, 0.55, 0.3, 0.18],
      attack: 4e-3,
      decay: 0.42,
      reverb: 0.25,
      dust: false
    },
    // Brighter, clear bells.
    celesta: {
      ratios: [1, 2.76, 5.4, 8.93],
      gains: [1, 0.55, 0.3, 0.12],
      partialDecay: [1, 0.6, 0.35, 0.2],
      attack: 8e-3,
      decay: 0.7,
      reverb: 0.32,
      dust: true
    },
    // Airy, dreamy, lots of shimmer.
    chimes: {
      ratios: [1, 2.76, 5.4, 8.93],
      gains: [1, 0.5, 0.35, 0.16],
      partialDecay: [1, 0.7, 0.5, 0.35],
      attack: 0.012,
      decay: 1.4,
      reverb: 0.45,
      dust: true
    }
  };
  function bell(ctx, out, timbre, freq, at, gain, length, bright) {
    const detune = cents();
    const start = Math.max(ctx.currentTime, at + humanSeconds());
    for (const [index, ratio] of timbre.ratios.entries()) {
      const partialGain = gain * timbre.gains[index] * (index === 0 ? 1 : bright);
      if (partialGain < 4e-3) continue;
      const decay = timbre.decay * length * timbre.partialDecay[index];
      const env = ctx.createGain();
      env.gain.setValueAtTime(FLOOR, start);
      env.gain.linearRampToValueAtTime(partialGain, start + timbre.attack);
      env.gain.exponentialRampToValueAtTime(FLOOR, start + timbre.attack + decay);
      env.connect(out);
      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.value = freq * ratio;
      osc.detune.value = detune;
      osc.connect(env);
      osc.start(start);
      osc.stop(start + timbre.attack + decay + 0.05);
    }
  }
  function dust(ctx, out, timbre, at) {
    const count = 3 + Math.floor(Math.random() * 4);
    for (let i = 0; i < count; i++) {
      const degree = 6 + Math.floor(Math.random() * 4);
      bell(ctx, out, timbre, pitch(degree), at + Math.random() * 0.25, 0.05, 0.35, 0.5);
    }
  }
  const PHRASES = {
    // Three notes rising, like a star appearing: G6 C7 E7.
    found: [
      { degree: 3, at: 0 },
      { degree: 5, at: 0.09 },
      { degree: 7, at: 0.18, gain: 0.8 }
    ],
    // One tiny bell: A6.
    open: [{ degree: 4, at: 0, gain: 0.7, length: 0.7 }],
    // C6 D6 E6 G6 A6 C7, then a bright E7 with sparkle.
    marketLive: [
      { degree: 0, at: 0 },
      { degree: 1, at: 0.11 },
      { degree: 2, at: 0.22 },
      { degree: 3, at: 0.33 },
      { degree: 4, at: 0.44 },
      { degree: 5, at: 0.55, gain: 0.9 },
      { degree: 7, at: 0.7, gain: 0.8, length: 1.3 }
    ],
    // Root, major third, fifth: C6 E6 G6, warm.
    betPlaced: [
      { degree: 0, at: 0, bright: 0.5, length: 1.2 },
      { degree: 2, at: 0.18, bright: 0.5, length: 1.2 },
      { degree: 3, at: 0.36, bright: 0.55, length: 1.5 }
    ],
    // Two soft bells stepping down, an octave below the main register.
    softError: [
      { degree: 1, at: 0, gain: 0.55, bright: 0.35, length: 1.1 },
      { degree: 0, at: 0.28, gain: 0.5, bright: 0.3, length: 1.4 }
    ]
  };
  const OCTAVE = { softError: 0.5 };
  function synth(ctx, name, timbre, into, send) {
    const dry = ctx.createGain();
    dry.gain.value = 1;
    dry.connect(into);
    const wet = ctx.createGain();
    wet.gain.value = timbre.reverb;
    wet.connect(send);
    const out = ctx.createGain();
    out.connect(dry);
    out.connect(wet);
    const now = ctx.currentTime + 0.02;
    const octave = OCTAVE[name] ?? 1;
    let end = 0;
    for (const note of PHRASES[name]) {
      bell(
        ctx,
        out,
        timbre,
        pitch(note.degree) * octave,
        now + note.at,
        (note.gain ?? 0.6) * 0.5,
        note.length ?? 1,
        note.bright ?? 1
      );
      end = Math.max(end, note.at);
    }
    if (timbre.dust && (name === "found" || name === "marketLive")) dust(ctx, out, timbre, now + end);
  }
  const fileBuffers = /* @__PURE__ */ new Map();
  function fileUrl(name, ext) {
    return typeof chrome !== "undefined" && chrome.runtime?.getURL ? chrome.runtime.getURL(`sfx/${name}.${ext}`) : `sfx/${name}.${ext}`;
  }
  async function playFile(ctx, name) {
    if (!master) return false;
    if (!fileBuffers.has(name)) {
      fileBuffers.set(name, null);
      for (const ext of ["mp3", "wav"]) {
        try {
          const response = await fetch(fileUrl(name, ext));
          if (!response.ok) continue;
          fileBuffers.set(name, await ctx.decodeAudioData(await response.arrayBuffer()));
          break;
        } catch {
        }
      }
    }
    const buffer = fileBuffers.get(name);
    if (!buffer) return false;
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(master);
    source.start();
    return true;
  }
  function playSound(name, override) {
    const chosen = style;
    try {
      if (muted) {
        last = `${name} skipped: muted`;
        notify();
        return;
      }
      const ctx = ensureContext();
      if (!ctx || !master || !reverbSend) {
        last = `${name} skipped: no audio`;
        notify();
        return;
      }
      if (ctx.state !== "running") {
        pending = { name, at: Date.now() };
        last = `${name} queued: ${ctx.state}`;
        notify();
        return;
      }
      onPlay?.();
      if (chosen === "files") {
        const into = master;
        const send = reverbSend;
        void playFile(ctx, name).then((played) => {
          if (!played) synth(ctx, name, TIMBRES[DEFAULT_STYLE], into, send);
        });
      } else {
        synth(ctx, name, TIMBRES[chosen], master, reverbSend);
      }
      last = `${name} (${chosen})`;
      notify();
    } catch {
      last = `${name} failed`;
      notify();
    }
  }
  const HEALTH_REQUEST = "soothia:v1:health";
  const NAV_CHANGED = "soothia:v1:nav-changed";
  const DETECT_REQUEST = "soothia:v1:detect";
  const API_REQUEST = "soothia:v1:api";
  const OPEN_WELCOME = "soothia:v1:open-welcome";
  const RECALL_ID_KEY = "soothia.recallId";
  const SUI_WALLET_KEY = "soothia.suiWallet";
  const SOCIAL_SEEN_KEY = "soothia.socialSeen";
  const FEED_CHECK_KEY = "soothia.feedCheck";
  const RECORD_SECTION_KEY = "soothia.recordSection";
  const CHECK_TX = "soothia:v1:check-tx";
  const PREMIUM_CALL = "soothia:v1:premium-call";
  const AGENT_REQUEST = "soothia:v1:agent";
  const TWEET = 'article[data-testid="tweet"]';
  const TEXT = [
    '[data-testid="tweetText"]',
    '[data-testid="twitterArticleRichTextView"]',
    '[data-testid="longformRichTextComponent"]'
  ].join(",");
  function statusIdFromPath(pathname) {
    return /\/status(?:es)?\/(\d+)/.exec(pathname)?.[1] ?? null;
  }
  function permalinkId(href) {
    return /\/status\/(\d+)(?:[/?#]|$)/.exec(href ?? "")?.[1] ?? null;
  }
  function permalinkTime(article, statusId) {
    for (const link of article.querySelectorAll("a[href]")) {
      const time = link.querySelector("time");
      if (!time) continue;
      if (!statusId || permalinkId(link.getAttribute("href")) === statusId) return time;
    }
    return null;
  }
  function findFocalTweet(root, statusId) {
    for (const article of root.querySelectorAll(TWEET)) {
      if (permalinkTime(article, statusId)) return article;
    }
    return root.querySelector(`[data-testid="primaryColumn"] ${TWEET}`);
  }
  function renderedText(node) {
    let out = "";
    for (const child of node.childNodes) {
      if (child.nodeType === 3) out += child.nodeValue ?? "";
      else if (child.nodeType !== 1) continue;
      else if (child.tagName === "IMG") out += child.getAttribute("alt") ?? "";
      else if (child.tagName === "BR") out += "\n";
      else out += renderedText(child);
    }
    return out;
  }
  function readTweetArticle(article, statusId) {
    const body = article.querySelector(TEXT);
    if (!body) return null;
    const text = renderedText(body).replace(/[ \t]+/g, " ").replace(/\s*\n\s*/g, "\n").trim();
    if (!text) return null;
    const handle = /@\w{1,15}/.exec(article.querySelector('[data-testid="User-Name"]')?.textContent ?? "")?.[0] ?? null;
    const time = statusId && permalinkTime(article, statusId) || permalinkTime(article) || article.querySelector("time");
    return { handle, postedAt: time?.getAttribute("datetime") ?? null, text };
  }
  const TEXT_MAX_CHARS = 4e3;
  const MIN_ARTICLE_CHARS = 200;
  const MIN_TWEET_CHARS = 30;
  const MIN_PARAGRAPH_CHARS = 60;
  const SEARCH_HOSTS = /(^|\.)(google\.[a-z.]{2,8}|bing\.com|duckduckgo\.com|search\.yahoo\.com|yahoo\.com\/search|yandex\.(com|ru)|baidu\.com|ecosia\.org|search\.brave\.com|startpage\.com|qwant\.com|kagi\.com|ask\.com|perplexity\.ai)$/i;
  function skipReason(url, contentType = "text/html") {
    if (url.protocol !== "http:" && url.protocol !== "https:") return "local or non-web page";
    const host = url.hostname.toLowerCase();
    if (host === "localhost" || host.endsWith(".localhost") || host === "0.0.0.0" || host === "[::1]" || /^127\./.test(host)) {
      return "local or non-web page";
    }
    if (SEARCH_HOSTS.test(host) || host.endsWith("yahoo.com") && /^\/search/.test(url.pathname))
      return "search results";
    if (/\.pdf($|[?#])/i.test(url.pathname) || /pdf/i.test(contentType)) return "PDF";
    if (!/html|xhtml/i.test(contentType)) return `not a web page (${contentType})`;
    return null;
  }
  function isSkippedLocation() {
    return skipReason(location, document.contentType || "text/html");
  }
  function clean(text) {
    return (text ?? "").replace(/\s+/g, " ").trim();
  }
  function isVisible(element) {
    return element.getClientRects().length > 0;
  }
  function isX() {
    return /(^|\.)(x|twitter)\.com$/.test(location.hostname);
  }
  function mainTweet() {
    const statusId = statusIdFromPath(location.pathname);
    if (statusId) {
      const article = findFocalTweet(document, statusId);
      return article && { article, statusId };
    }
    const articles = [...document.querySelectorAll('article[data-testid="tweet"]')].filter(isVisible);
    if (articles.length === 0) return null;
    const middle = window.innerHeight / 2;
    const distance = (article) => {
      const rect = article.getBoundingClientRect();
      return Math.abs(rect.top + rect.height / 2 - middle);
    };
    return { article: articles.reduce((best, article) => distance(article) < distance(best) ? article : best) };
  }
  function readTweet() {
    const main = mainTweet();
    if (!main) return "no tweet on the page yet";
    const tweet = readTweetArticle(main.article, main.statusId);
    if (!tweet) return "tweet has no text";
    if (tweet.text.length < MIN_TWEET_CHARS) return `tweet text is ${tweet.text.length} chars, need ${MIN_TWEET_CHARS}`;
    const who = tweet.handle ?? "unknown author";
    const posted = tweet.postedAt ? ` (posted ${tweet.postedAt.slice(0, 10)})` : "";
    return {
      title: tweet.handle ? `Post by ${tweet.handle} on X` : "Post on X",
      text: `${who}${posted}: ${tweet.text}`
    };
  }
  const CHROME_SELECTOR = [
    "nav",
    "footer",
    "aside",
    "form",
    "dialog",
    "figure",
    '[role="navigation"]',
    '[role="banner"]',
    '[role="contentinfo"]',
    '[role="complementary"]',
    '[role="dialog"]',
    '[role="alertdialog"]',
    '[aria-hidden="true"]'
  ].join(",");
  const NOISE_NAME = /cookie|consent|gdpr|advert|sponsor|promo|newsletter|subscribe|paywall|sidebar|comment|related|share|social|breadcrumb|(^|[\s_-])ads?($|[\s_-])/i;
  function isNoise(paragraph) {
    if (paragraph.closest(CHROME_SELECTOR)) return true;
    let node = paragraph;
    for (let depth = 0; node && depth < 5; depth++, node = node.parentElement) {
      if (NOISE_NAME.test(`${node.id} ${node.getAttribute("class") ?? ""}`)) return true;
    }
    return false;
  }
  function paragraphsIn(root) {
    const out = [];
    for (const element of root.querySelectorAll("p")) {
      const text = clean(element.textContent);
      if (text.length < MIN_PARAGRAPH_CHARS || !isVisible(element) || isNoise(element)) continue;
      out.push({ element, text });
    }
    return out;
  }
  function totalLength(paragraphs) {
    return paragraphs.reduce((sum, paragraph) => sum + paragraph.text.length, 0);
  }
  function articleParagraphs() {
    let best = [];
    for (const selector of BODY_SELECTORS) {
      for (const container of document.querySelectorAll(selector)) {
        const found = paragraphsIn(container);
        if (totalLength(found) > totalLength(best)) best = found;
      }
      if (totalLength(best) >= MIN_ARTICLE_CHARS) return best.map((paragraph) => paragraph.text);
    }
    const all = paragraphsIn(document.querySelector('main, [role="main"]') ?? document.body);
    const byParent = /* @__PURE__ */ new Map();
    for (const paragraph of all) {
      const parent = paragraph.element.parentElement;
      byParent.set(parent, [...byParent.get(parent) ?? [], paragraph]);
    }
    let largest = [];
    for (const group of byParent.values()) {
      if (totalLength(group) > totalLength(largest)) largest = group;
    }
    const chosen = totalLength(largest) >= MIN_ARTICLE_CHARS ? largest : all;
    return chosen.map((paragraph) => paragraph.text);
  }
  const CONSENT_SELECTOR = [
    "#onetrust-banner-sdk",
    "#onetrust-consent-sdk",
    ".sp_message_container",
    '[id^="sp_message"]',
    "#CybotCookiebotDialog",
    "#didomi-host",
    ".fc-consent-root",
    ".qc-cmp2-container",
    "#usercentrics-root",
    '[id*="consent" i]',
    '[class*="consent" i]',
    '[id*="cookie-banner" i]',
    '[class*="cookie-banner" i]',
    '[class*="cookie-wall" i]',
    '[aria-label*="consent" i]'
  ].join(",");
  function consentWallVisible() {
    const viewport2 = Math.max(1, window.innerWidth * window.innerHeight);
    for (const element of document.querySelectorAll(CONSENT_SELECTOR)) {
      if (!isVisible(element)) continue;
      const rect = element.getBoundingClientRect();
      const position = getComputedStyle(element).position;
      if (rect.width * rect.height / viewport2 >= 0.3 || position === "fixed" && rect.height >= 120) return true;
    }
    return false;
  }
  const BODY_SELECTORS = [
    '[itemprop="articleBody"]',
    ".sdc-article-body",
    ".article__body",
    ".article-body",
    ".story-body",
    "#article-body",
    ".article__content",
    ".ArticleBody",
    ".entry-content",
    ".post-content",
    '[data-testid="article-body"]',
    "article",
    'main, [role="main"]'
  ];
  const STANDFIRST_SELECTORS = [
    '[data-component="standfirst"]',
    ".standfirst",
    ".article__intro",
    ".sdc-article-header__sub-title",
    ".article-subtitle",
    ".subheadline",
    ".dek",
    ".summary",
    'meta[name="description"]',
    'meta[property="og:description"]'
  ];
  function standfirst() {
    for (const selector of STANDFIRST_SELECTORS) {
      const node = document.querySelector(selector);
      if (!node) continue;
      const text = clean(node instanceof HTMLMetaElement ? node.content : node.textContent);
      if (text.length >= 40) return text.slice(0, 400);
    }
    return "";
  }
  function headline() {
    for (const h1 of document.querySelectorAll("h1")) {
      const text = clean(h1.textContent);
      if (text && isVisible(h1)) return text;
    }
    const og = document.querySelector('meta[property="og:title"]')?.content;
    return clean(og) || clean(document.title);
  }
  function readArticle() {
    const paragraphs = articleParagraphs();
    const intro = standfirst();
    const body = [intro, ...paragraphs.filter((text) => text !== intro)].filter(Boolean).join("\n");
    if (body.length < MIN_ARTICLE_CHARS) {
      if (consentWallVisible()) return `consent wall is up; article text is ${body.length} chars`;
      return `article text is ${body.length} chars, need ${MIN_ARTICLE_CHARS}`;
    }
    const title = headline();
    return { title, text: title ? `${title}

${body}` : body };
  }
  function readPage() {
    const site = location.hostname.replace(/^www\./, "");
    const skipped = isSkippedLocation();
    if (skipped) return { kind: "skip", reason: skipped, info: { site, chars: 0, preview: "" } };
    const found = isX() ? readTweet() : readArticle();
    if (typeof found === "string") return { kind: "thin", reason: found, info: { site, chars: 0, preview: "" } };
    const text = found.text.slice(0, TEXT_MAX_CHARS);
    return {
      kind: "page",
      info: { site, chars: text.length, preview: text.slice(0, 80) },
      page: { url: location.href.split("#")[0], site, title: found.title.slice(0, 300), text }
    };
  }
  const MIST_PER_SUI = 1000000000n;
  const GAS_RESERVE_MIST = 20000000n;
  const MIN_KICKOFF_LEAD_MS = 12e4;
  function formatSui(mist, decimals = 9) {
    const value = BigInt(mist);
    const fraction = (value % MIST_PER_SUI).toString().padStart(9, "0").slice(0, decimals).replace(/0+$/, "");
    return `${value / MIST_PER_SUI}${fraction ? `.${fraction}` : ""}`;
  }
  function parseSuiAmount(text) {
    const match = /^(\d{1,10})(?:\.(\d{1,9}))?$/.exec(text.trim());
    if (!match) return null;
    const mist = BigInt(match[1]) * MIST_PER_SUI + BigInt((match[2] ?? "").padEnd(9, "0"));
    return mist > 0n ? mist : null;
  }
  function stakeEligible(called, nowMs) {
    if (!called?.committed || !called.fixture || typeof called.pYes !== "number") return false;
    return Date.parse(called.fixture.startISO) - nowMs > MIN_KICKOFF_LEAD_MS;
  }
  const backsYes = (called) => (called.pYes ?? 0) >= 0.5;
  function stakeTileIds(tiles, calledByClaim, nowMs) {
    const chosen = /* @__PURE__ */ new Map();
    for (const { claim } of tiles) {
      const called = calledByClaim(claim.id);
      if (!called?.fixture || !stakeEligible(called, nowMs)) continue;
      const { home, away, subject } = called.fixture;
      const exact = claim.question.toLowerCase().startsWith(`will ${(subject === "home" ? home : away).toLowerCase()} beat`);
      const current = chosen.get(called.pickId);
      if (!current || exact && !current.exact) chosen.set(called.pickId, { claimId: claim.id, exact });
    }
    return new Set([...chosen.values()].map((entry) => entry.claimId));
  }
  const totalsFor = (pool, side) => {
    const yes = BigInt(pool.yesTotal);
    const no = BigInt(pool.noTotal);
    return { mine: side ? yes : no, other: side ? no : yes };
  };
  const multiplierText = (multiplier) => `${multiplier.toFixed(2)}x`;
  function multiplierWith(pool, side, addedMist) {
    const { mine, other } = totalsFor(pool, side);
    const sideTotal = mine + addedMist;
    if (sideTotal <= 0n) return null;
    const pot = sideTotal + other;
    const net = pot - pot * BigInt(pool.feeBps) / 10000n;
    return Number(net * 10000n / sideTotal) / 1e4;
  }
  function poolIsOpenForStakes(pool, nowMs) {
    if (pool.closeMs - nowMs <= MIN_KICKOFF_LEAD_MS) return false;
    return !pool.exists || pool.status === "open";
  }
  function poolLine(pool, side, sideLabel) {
    if (!pool.exists) return "No pool yet. Be the first to back it.";
    const { mine, other } = totalsFor(pool, side);
    const parts = [`Pool: ${formatSui(mine, 3)} SUI on ${sideLabel}`, `${formatSui(other, 3)} SUI against`];
    const multiplier = multiplierWith(pool, side, 0n);
    if (multiplier !== null && mine > 0n) parts.push(`pays ${multiplierText(multiplier)}`);
    return parts.join(" · ");
  }
  function backedLine(pool, side, heldMist) {
    const multiplier = multiplierWith(pool, side, 0n);
    return `You backed ${formatSui(heldMist, 4)} SUI${multiplier === null ? "" : ` · pays ~${multiplierText(multiplier)}`}`;
  }
  function canTopUp(limits, heldMist) {
    return heldMist + BigInt(limits.minStakeMist) <= BigInt(limits.maxStakePerUserMist);
  }
  function amountProblem(input) {
    const { amountMist, limits, heldMist, poolTotalMist, balanceMist } = input;
    if (amountMist === null) return "Enter an amount in SUI";
    const minimum = BigInt(limits.minStakeMist);
    if (amountMist < minimum) return `Below the ${formatSui(minimum)} SUI minimum`;
    const limit = BigInt(limits.maxStakePerUserMist);
    const room = limit - heldMist;
    if (amountMist > room) {
      return heldMist > 0n ? `Above your ${formatSui(limit)} SUI limit: you can add ${formatSui(room < 0n ? 0n : room)} more` : `Above your ${formatSui(limit)} SUI limit`;
    }
    const poolRoom = BigInt(limits.maxPoolMist) - poolTotalMist;
    if (amountMist > poolRoom) return poolRoom > 0n ? `Pool is nearly full: room for ${formatSui(poolRoom)} SUI more` : "Pool is full";
    if (balanceMist !== null && amountMist + GAS_RESERVE_MIST > balanceMist) {
      return `Not enough SUI: you have ${formatSui(balanceMist, 4)}, need ${formatSui(amountMist + GAS_RESERVE_MIST)} with gas`;
    }
    return null;
  }
  function backButtonState(input) {
    const { pool, poolFailed, amountMist, heldMist, balanceMist, balanceFailed, walletConnected, nowMs } = input;
    let reason;
    if (!pool) reason = poolFailed ? "Couldn't load this pool. Trying again…" : "Loading the pool…";
    else if (!poolIsOpenForStakes(pool, nowMs)) reason = "Pool closed";
    else reason = amountProblem({ amountMist, limits: pool.limits, heldMist, poolTotalMist: BigInt(pool.yesTotal) + BigInt(pool.noTotal), balanceMist });
    return {
      label: walletConnected ? "Back it" : "Connect wallet to back it",
      enabled: reason === null,
      reason,
      note: walletConnected && balanceFailed ? "Couldn't check your balance" : null
    };
  }
  function stakeEstimate(pool, side, amountMist, heldMist) {
    const { mine, other } = totalsFor(pool, side);
    const sideTotal = mine + amountMist;
    const pot = sideTotal + other;
    const net = pot - pot * BigInt(pool.feeBps) / 10000n;
    return {
      multiplier: sideTotal > 0n ? Number(net * 10000n / sideTotal) / 1e4 : 0,
      payoutMist: sideTotal > 0n ? (heldMist + amountMist) * net / sideTotal : 0n
    };
  }
  const feePercent = (feeBps) => `${feeBps / 100}%`;
  const CLOSED_TEXT = "This match is about to start or the pool has closed, so staking has stopped.";
  const LIMIT_TEXT = "That would take you over the limit for this pool.";
  const FULL_TEXT = "This pool is full.";
  const ABORT_TEXT = {
    "3": CLOSED_TEXT,
    "4": CLOSED_TEXT,
    "5": "That is below the minimum stake.",
    "6": "You already backed the other side of this pool.",
    "7": LIMIT_TEXT,
    "8": FULL_TEXT
  };
  function stakeErrorText(status, body) {
    if (status === 0) return { text: "I couldn't reach Soothia's server. Check your connection.", retry: true };
    if (status === 429 && body?.error !== "pool_cap_reached") return { text: "Too many requests just now. Try again in a minute.", retry: true };
    switch (body?.error) {
      case "too_close_to_kickoff":
      case "pool_not_open":
      case "fixture_not_open":
        return { text: CLOSED_TEXT, retry: false };
      case "above_user_limit":
        return { text: LIMIT_TEXT, retry: false };
      case "pool_full":
        return { text: FULL_TEXT, retry: false };
      case "below_min_stake":
        return { text: "That is below the minimum stake.", retry: false };
      case "side_switch":
        return { text: "You already backed the other side of this pool.", retry: false };
      case "insufficient_balance":
        return { text: `You don't have enough SUI. This needs ${formatSui(body.neededMist ?? "0")} SUI including gas.`, retry: true };
      case "stake_rejected":
        return { text: ABORT_TEXT[body.abortCode ?? ""] ?? "The contract refused this stake.", retry: false };
      case "staking_paused":
        return { text: "New pools are paused for a moment. Try again later.", retry: true };
      case "pool_cap_reached":
        return { text: "Soothia has opened all the pools it can today. Try again tomorrow.", retry: false };
      case "resolver_low_balance":
        return { text: "Soothia can't open new pools just now. Try again later.", retry: true };
      case "resolver_busy":
        return { text: "Soothia is busy opening another pool. Try again in a minute.", retry: true };
      case "espn_unavailable":
        return { text: "ESPN couldn't be checked just now. Try again in a minute.", retry: true };
      case "fixture_not_on_espn":
      case "fixture_date_mismatch":
        return { text: "ESPN doesn't list this match for that day, so it can't have a pool.", retry: false };
      case "pick_not_found":
        return { text: "Soothia can't find this call on your record yet. Try again in a minute.", retry: true };
      case "not_claimable":
        return { text: "This can't be claimed yet.", retry: false };
      case "no_position":
        return { text: "This wallet has no stake in that pool.", retry: false };
      case "pick_not_committed":
        return { text: "This call has no proof on Sui, so it can't be backed.", retry: false };
      default:
        return { text: "That didn't work. Please try again.", retry: true };
    }
  }
  function walletErrorText(message2, nothingHappened = "Nothing was staked.") {
    if (/reject|denied|declined|cancel/i.test(message2)) return { text: `You cancelled in your wallet. ${nothingHappened}`, retry: true };
    if (/insufficient|not enough|no valid gas|gas (coin|balance)/i.test(message2)) return { text: "Your wallet doesn't have enough SUI to cover this and gas.", retry: true };
    if (/did not respond in time/i.test(message2)) return { text: "Your wallet didn't answer in time. If you approved it, check your wallet before trying again.", retry: true };
    if (/^Transaction refused\./.test(message2)) return { text: `${message2} Nothing was sent to your wallet.`, retry: false };
    return { text: message2.slice(0, 160) || "Your wallet reported a problem.", retry: true };
  }
  function positionStatusText(position, when2) {
    const payout = `${formatSui(position.estimatedPayoutMist, 4)} SUI`;
    switch (position.status) {
      case "open":
        return "Open";
      case "awaiting_result":
        return "Awaiting result";
      case "challenge_window":
        return position.claimOpensAtMs === null ? "In challenge window" : `In challenge window until ${when2(position.claimOpensAtMs)}`;
      case "claimable":
        return `Won ${payout}`;
      case "lost":
        return "Lost";
      case "refundable":
        return `Refund of ${payout} ready`;
      case "claimed":
        if (position.result === "refunded") return `Refunded ${payout}`;
        return position.result === "won" ? `Claimed ${payout}` : "Claimed";
    }
  }
  const isClaimable = (status) => status === "claimable" || status === "refundable";
  function finalResult(position) {
    if (position.result !== void 0) return position.result;
    if (position.status === "claimable") return "won";
    if (position.status === "lost") return "lost";
    return position.status === "refundable" ? "refunded" : null;
  }
  function walletSummary(positions) {
    let stakedMist = 0n;
    let wonMist = 0n;
    let lostMist = 0n;
    let settledMist = 0n;
    let wonStakeMist = 0n;
    let bestMultiplier = null;
    for (const position of positions) {
      const result = finalResult(position);
      if (result === "refunded") continue;
      const amount = BigInt(position.amountMist);
      stakedMist += amount;
      if (result === "won") {
        const payout = BigInt(position.estimatedPayoutMist);
        wonMist += payout;
        wonStakeMist += amount;
        settledMist += amount;
        if (amount > 0n) {
          const multiplier = Number(payout * 10000n / amount) / 1e4;
          bestMultiplier = Math.max(bestMultiplier ?? 0, multiplier);
        }
      } else if (result === "lost") {
        lostMist += amount;
        settledMist += amount;
      }
    }
    const profitMist = settledMist > 0n ? wonMist - wonStakeMist - lostMist : null;
    const roiPercent = profitMist !== null ? Number(profitMist * 10000n / settledMist) / 100 : null;
    return { stakedMist, wonMist, lostMist, profitMist, roiPercent, bestMultiplier };
  }
  function signedSui(mist) {
    return `${mist < 0n ? "-" : "+"}${formatSui(mist < 0n ? -mist : mist, 4)} SUI`;
  }
  function signedSuiShort(mist) {
    const text = formatSui(mist < 0n ? -mist : mist, 4);
    return `${mist < 0n ? "-" : "+"}${text.includes(".") ? text : `${text}.0`} SUI`;
  }
  const isLockedCall = (call) => call.locked === true;
  const MINUTE = 6e4;
  const HOUR = 60 * MINUTE;
  const DAY = 24 * HOUR;
  function timeAgo(atMs, nowMs) {
    const gap = nowMs - atMs;
    if (gap < MINUTE) return "just now";
    if (gap < HOUR) return `${Math.floor(gap / MINUTE)}m ago`;
    if (gap < DAY) return `${Math.floor(gap / HOUR)}h ago`;
    return `${Math.floor(gap / DAY)}d ago`;
  }
  const initials = (handle) => handle.replace(/_/g, "").slice(0, 2).toUpperCase();
  const handleLine = (handle, score) => score === null ? `@${handle}` : `@${handle} · ${score}`;
  const matchLine = (fixture) => `${fixture.home} v ${fixture.away}`;
  function callLine(lean, confidence, stakeMist) {
    return `${lean} · ${confidence}%${stakeMist ? ` · ${formatSui(stakeMist, 4)} SUI` : ""}`;
  }
  const canTail = (fixture, nowMs) => Date.parse(fixture.startISO) - nowMs > MIN_KICKOFF_LEAD_MS;
  function followedLine(calls, consensus) {
    const names = calls.map((call) => `@${call.handle}`);
    const who = names.length <= 2 ? names.join(" and ") : `${names[0]}, ${names[1]} and ${names.length - 2} more`;
    return `${who} called this${consensus ? ` · ${consensus.count} say ${consensus.lean}` : ""}`;
  }
  const MIN_PERCENT$1 = 51;
  const MAX_PERCENT$1 = 99;
  const LONG_DATE = new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });
  function tailSheetFor(handle, source) {
    const { home, away, competition, startISO, subject } = source.fixture;
    const [team, other] = subject === "home" ? [home, away] : [away, home];
    const dateLabel = LONG_DATE.format(new Date(startISO));
    return {
      tile: {
        claim: {
          id: `tail:${handle}:${startISO}`,
          question: `Will ${team} beat ${other}${competition ? ` in ${competition}` : ""} on ${dateLabel}?`,
          category: "sports",
          endTime: startISO,
          resolution: { type: "sports_result", details: "", sources: [] },
          confidence: 1,
          sourceQuote: "",
          fromFixture: true
        }
      },
      fixture: { home, away, ...competition ? { competition } : {}, startISO, dateLabel, sourceUrl: `https://soothia.fun/u/${handle}`, evidence: [] },
      prefill: { side: source.side === "YES" ? "yes" : "no", percent: Math.min(MAX_PERCENT$1, Math.max(MIN_PERCENT$1, source.confidence)), tailOf: handle }
    };
  }
  const badgeText = (count) => count <= 0 ? null : count > 9 ? "9+" : String(count);
  const FEED_CHECK_MS = 18e4;
  function cachedFeedCount(check, seen, nowMs) {
    return check && check.seen === seen && nowMs - check.at < FEED_CHECK_MS ? check.count : null;
  }
  function pageFollowedCount(callsByClaim) {
    return new Set(callsByClaim.flatMap((calls) => (calls ?? []).map((call) => call.handle))).size;
  }
  const SITE_URL = "https://soothia.fun";
  const HANDLE = /^[a-z0-9_]{3,20}$/;
  function handleProblem(text) {
    return HANDLE.test(text.trim().toLowerCase()) ? null : "Use 3 to 20 letters, numbers or underscores.";
  }
  function socialErrorText(code, message2) {
    switch (code) {
      case "handle_taken":
        return "That handle is taken. Try another.";
      case "invalid_handle":
        return "Use 3 to 20 letters, numbers or underscores.";
      case "already_public":
        return "This wallet is already public.";
      case "record_already_public":
        return "This record is already public under another wallet.";
      case "challenge_expired":
        return "That took too long. Please try again.";
      case "invalid_signature":
        return "The wallet's signature didn't match. Please try again.";
      case "rate_limited":
        return "Too many tries just now. Wait a minute.";
    }
    if (message2 && /reject|denied|declined|cancel/i.test(message2)) return "You cancelled in your wallet. Nothing changed.";
    return message2 ? message2.slice(0, 140) : "That didn't work. Please try again.";
  }
  function createGoPublicPanel(host) {
    const node = el("section", "record-section go-public");
    node.hidden = true;
    let wallet = null;
    let profile = null;
    let busy = false;
    const status = el("p", "note go-public-status");
    status.setAttribute("aria-live", "polite");
    const picker = el("div", "wallet-row wallet-picker");
    picker.hidden = true;
    function say(text) {
      status.textContent = text;
      host.layout();
    }
    function chooseWallet(wallets) {
      return new Promise((resolve) => {
        picker.replaceChildren(
          ...wallets.map(
            (item) => button(item.name, "button small", () => {
              picker.hidden = true;
              picker.replaceChildren();
              resolve(item);
            })
          )
        );
        picker.hidden = false;
        say("Choose a wallet.");
      });
    }
    async function signedStep(action, path, extra) {
      const current = wallet;
      const challenge = await host.api("/social/profile/challenge", { address: current.address, action });
      if (!challenge.ok || !challenge.body) {
        say(socialErrorText(challenge.body?.error));
        return null;
      }
      say("Approve the message in your wallet. It isn't a transaction and costs nothing.");
      let signature;
      try {
        ({ signature } = await host.wallet.signMessage(current, challenge.body.message));
      } catch (error) {
        say(socialErrorText(void 0, String(error?.message ?? error)));
        return null;
      }
      const response = await host.api(path, { address: current.address, signature, ...extra });
      if (!response.ok) {
        say(socialErrorText(response.body?.error));
        return null;
      }
      return response;
    }
    async function act(run) {
      if (busy) return;
      busy = true;
      for (const control of node.querySelectorAll("button, input")) control.disabled = true;
      try {
        await run();
      } catch (error) {
        say(socialErrorText(void 0, String(error?.message ?? error)));
      }
      busy = false;
      for (const control of node.querySelectorAll("button, input")) control.disabled = false;
      host.layout();
    }
    async function ensureWallet() {
      if (wallet) return true;
      wallet = await host.wallet.connect(chooseWallet);
      if (!wallet) return false;
      const found = await lookUp(wallet);
      if (found) {
        profile = found;
        render();
        return false;
      }
      return true;
    }
    function renderPrivate(suggestion2) {
      const handle = el("input", "input go-public-handle");
      handle.type = "text";
      handle.placeholder = "your_handle";
      handle.maxLength = 20;
      handle.spellcheck = false;
      handle.autocomplete = "off";
      handle.setAttribute("aria-label", "Handle");
      handle.value = suggestion2 ?? "";
      const toggleRow = el("label", "toggle");
      const share = el("input", "toggle-box");
      share.type = "checkbox";
      toggleRow.append(share, el("span", "toggle-label", "Also show the calls I made before today"));
      const publish = button(wallet ? "Go public" : "Connect wallet to go public", "button small go-public-action", () => {
        void act(async () => {
          const problem2 = handleProblem(handle.value);
          if (problem2) return say(problem2);
          if (!await ensureWallet()) return;
          const done = await signedStep("publish", "/social/profile/publish", { handle: handle.value.trim().toLowerCase() });
          if (!done) return;
          profile = done.body.profile;
          if (share.checked) {
            say("Approve once more to share your earlier calls.");
            const updated = await signedStep("update", "/social/profile/update", { shareHistory: true });
            if (updated) profile = updated.body.profile;
          }
          render();
        });
      });
      node.replaceChildren(
        el("h3", "field-label", "Go public"),
        el("p", "note", "Your Call Score and new calls appear on the leaderboard and a public page. Private until you do this."),
        handle,
        toggleRow,
        publish,
        picker,
        status
      );
    }
    function renderPublic(current) {
      const share = el("input", "toggle-box");
      share.type = "checkbox";
      share.checked = current.shareHistory;
      const toggleRow = el("label", "toggle");
      toggleRow.append(share, el("span", "toggle-label", "Also show the calls I made before going public"));
      share.addEventListener("change", () => {
        const wanted = share.checked;
        void act(async () => {
          const updated = await signedStep("update", "/social/profile/update", { shareHistory: wanted });
          if (updated) {
            profile = updated.body.profile;
            render();
          } else {
            share.checked = !wanted;
          }
        });
      });
      const leave = button("Unpublish", "button small", () => {
        void act(async () => {
          const left = await signedStep("unpublish", "/social/profile/unpublish", {});
          if (left) {
            profile = null;
            render();
            say("You're private again.");
          }
        });
      });
      node.replaceChildren(
        el("h3", "field-label", "Public profile"),
        el("p", "go-public-title", `You're public as @${current.handle}`),
        externalLink("See your page", `${SITE_URL}/u/${encodeURIComponent(current.handle)}`, "link ext"),
        toggleRow,
        leave,
        status
      );
    }
    let suggestion = null;
    function render() {
      if (profile) renderPublic(profile);
      else renderPrivate(suggestion);
      node.hidden = false;
      host.onChange?.(profile);
      host.layout();
    }
    async function lookUp(current) {
      const response = await host.api("/social/profile/by-address", { address: current.address });
      const body = response.ok ? response.body : null;
      return body?.public && body.profile ? body.profile : null;
    }
    return {
      node,
      async load() {
        wallet = await host.wallet.current().catch(() => null);
        if (wallet) {
          profile = await lookUp(wallet);
          if (!profile) {
            const names = await host.api("/social/suins", { address: wallet.address });
            suggestion = names.ok ? names.body?.suggestion ?? null : null;
          }
        }
        render();
      }
    };
  }
  const PERIODS = [
    ["week", "Week"],
    ["month", "Month"],
    ["all", "All time"]
  ];
  const MAX_ROWS = 20;
  function createLeaderboardView(pane, host) {
    let period = "all";
    let seq = 0;
    function row(item) {
      const node = el("div", "board-row");
      const percent = item.hitRate === null ? "–" : `${Math.round(item.hitRate * 100)}%`;
      node.append(
        el("span", "board-rank", String(item.rank)),
        externalLink(`@${item.handle}`, `${SITE_URL}/u/${encodeURIComponent(item.handle)}`, "link board-handle"),
        el("span", "board-score", String(item.score)),
        el("span", "note board-meta", `${item.calls} calls · ${percent} right`)
      );
      return node;
    }
    async function render() {
      const current = ++seq;
      const switcher = el("div", "board-periods");
      for (const [value, label] of PERIODS) {
        const tab = button(label, `button small board-period${value === period ? " selected" : ""}`, () => {
          period = value;
          void render();
        });
        switcher.append(tab);
      }
      const list = el("div", "board-list");
      const status = el("p", "note", "Loading…");
      pane.replaceChildren(switcher, status, list, externalLink("See all", `${SITE_URL}/leaderboard`, "link ext board-all"));
      host.layout();
      const response = await host.api("/social/leaderboard", { board: "score", period });
      if (current !== seq) return;
      if (!response.ok || !response.body) {
        status.textContent = "Couldn't load the leaderboard.";
        host.layout();
        return;
      }
      const { rows } = response.body;
      status.textContent = rows.length === 0 ? "Nobody qualifies yet. It takes 10 settled calls." : "";
      list.replaceChildren(...rows.slice(0, MAX_ROWS).map(row));
      host.layout();
    }
    return { render };
  }
  const STAKE_PACKAGE = "0xf9507a1cb35b01c191614a67bf5ca3f22c7c3a7745fdc7ddea67369686a6720f";
  const RECALL_PACKAGE = "0xc7bb1087170732a31d392f20974ba5f3dac8c4081b39f7a8677ff7d28ada84c4";
  const PAY_PACKAGE = "0x69093f4bd2ec5d00c5780d8fd2e09adde6a4399146fed2bafc94071311d52a92";
  const PAY_CONFIG = "0x7b14fd24baed71d4062f88c22d06c61f4785fc040c3e692ae335b1cde7807f1e";
  const NETWORK = "sui:mainnet";
  const ASSET = "0x2::sui::SUI";
  const ADDRESS = /^0x[0-9a-f]{64}$/i;
  const NONCE = /^[0-9a-f]{32}$/;
  const AMOUNT = /^[1-9][0-9]{0,18}$/;
  const PREMIUM_PRICES = ["0.01", "0.02", "0.05", "0.1"];
  const MIN_PREMIUM_MIST = 10000000n;
  const MAX_PREMIUM_MIST = 500000000n;
  const AGENT_HARD_CAP_MIST = 100000000n;
  const AGENT_DEFAULT_BUDGET_MIST = 200000000n;
  const AGENT_DEFAULT_MAX_MIST = 50000000n;
  const premiumLine = (priceMist) => `Premium · ${formatSui(priceMist, 4)} SUI`;
  function parsePremiumPrice(text) {
    const mist = parseSuiAmount(text);
    return mist !== null && mist >= MIN_PREMIUM_MIST && mist <= MAX_PREMIUM_MIST ? mist : null;
  }
  function readRequirement(header) {
    if (!header) return null;
    let parsed;
    try {
      parsed = JSON.parse(atob(header));
    } catch {
      return null;
    }
    if (parsed.x402Version !== 2 || !Array.isArray(parsed.accepts)) return null;
    const accepted = parsed.accepts[0];
    const extra = accepted?.extra;
    if (!accepted || !extra) return null;
    const { scheme, network, asset, amount, payTo } = accepted;
    if (scheme !== "exact" || network !== NETWORK || asset !== ASSET) return null;
    if (extra.payPackage !== PAY_PACKAGE || extra.payConfig !== PAY_CONFIG) return null;
    if (typeof amount !== "string" || !AMOUNT.test(amount)) return null;
    if (typeof payTo !== "string" || !ADDRESS.test(payTo)) return null;
    if (typeof extra.nonce !== "string" || !NONCE.test(extra.nonce)) return null;
    return { accepted, amount, payTo, nonce: extra.nonce, resource: parsed.resource };
  }
  function paymentHeader(requirement, signed) {
    return btoa(JSON.stringify({ x402Version: 2, resource: requirement.resource, accepted: requirement.accepted, payload: { signature: signed.signature, transaction: signed.bytes } }));
  }
  const failed = (code, maybePaid = false) => ({ ok: false, code, maybePaid });
  const message = (error) => String(error?.message ?? error);
  const opened = (response) => {
    const body = response.body;
    return { ok: true, handle: body.handle, call: body.call, receipt: body.receipt ?? null };
  };
  async function runUnlock(deps) {
    const first = await deps.fetchCall();
    if (first.status === 200) return opened(first);
    if (first.status !== 402) return failed(first.body?.error ?? "unavailable");
    const requirement = readRequirement(first.required);
    if (!requirement) return failed("bad_requirements");
    if (requirement.amount !== deps.expectedPriceMist) return failed("price_changed");
    let signed;
    try {
      const txBytes = await deps.build();
      signed = await deps.sign(txBytes, { kind: "pay", nonce: requirement.nonce, recipient: requirement.payTo, priceMist: requirement.amount });
    } catch (error) {
      const text = message(error);
      if (/^[a-z_]+$/.test(text)) return failed(text);
      return { ok: false, code: "wallet", walletMessage: text, maybePaid: false };
    }
    let second;
    try {
      second = await deps.fetchCall(paymentHeader(requirement, signed));
    } catch {
      return failed("network", true);
    }
    if (second.status === 200) return opened(second);
    if (second.status === 0) return failed("network", true);
    const reason = second.body?.reason ?? second.body?.error ?? "unavailable";
    return failed(reason, reason === "broadcast_failed" || reason === "no_payment_event");
  }
  function unlockFailureText(result, walletText) {
    if (result.walletMessage !== void 0) return walletText(result.walletMessage);
    switch (result.code) {
      case "insufficient_balance":
        return "Not enough SUI to pay for this and gas.";
      case "price_changed":
        return "The price changed. Refresh and try again.";
      case "bad_requirements":
        return "Soothia refused this payment request. Nothing was paid.";
      case "premium_no_proof":
        return "This call has no proof on Sui, so it can't be sold.";
      case "premium_unavailable":
        return "This call isn't for sale any more.";
      case "not_found":
        return "That call has gone.";
      case "nonce_used":
      case "nonce_expired":
        return "That payment request ran out. Try again.";
      case "payment_in_progress":
        return "That payment is still going through. Give it a moment.";
      case "transaction_failed":
        return "The transaction failed on Sui. The call stays locked.";
      case "broadcast_failed":
      case "network":
        return "It's unclear whether that went through. Check your wallet before trying again.";
      default:
        return "That didn't work. Nothing was unlocked.";
    }
  }
  ({ dailyBudgetMist: AGENT_DEFAULT_BUDGET_MIST.toString(), maxPerCallMist: AGENT_DEFAULT_MAX_MIST.toString() });
  const isLockedItem = (item) => item.locked === true;
  const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const HOSTNAME = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i;
  const MAX_SOURCE_URL = 500;
  const MIN_CALL_PERCENT = 51;
  const QUIET_PENDING_MS = 15 * 60 * 1e3;
  function isRecallId(value) {
    return typeof value === "string" && UUID.test(value);
  }
  function isQuietableSite(site) {
    return HOSTNAME.test(site);
  }
  function pYesFor(side, percent) {
    return (side === "yes" ? percent : 100 - percent) / 100;
  }
  function suggestedPercent(chosen, shrink) {
    return Math.max(MIN_CALL_PERCENT, Math.round(50 + (chosen - 50) * shrink));
  }
  function overconfidencePoints(shrink, bias) {
    return typeof bias === "number" ? Math.round(bias * 100) : Math.round((1 - shrink) * 100);
  }
  function fixtureSubject(question, home) {
    return question.toLowerCase().startsWith(`will ${home.toLowerCase()} beat`) ? "home" : "away";
  }
  function trimSourceUrl(url) {
    if (url.length <= MAX_SOURCE_URL) return url;
    try {
      const parsed = new URL(url);
      const withoutQuery = `${parsed.origin}${parsed.pathname}`;
      return withoutQuery.length <= MAX_SOURCE_URL ? withoutQuery : parsed.origin;
    } catch {
      return url.slice(0, MAX_SOURCE_URL);
    }
  }
  function callBody({ claim }, side, percent, page, fixture, tail, premiumMist) {
    return {
      question: claim.question,
      category: claim.category,
      pYes: pYesFor(side, percent),
      endTime: claim.endTime,
      source: { site: page.site, url: trimSourceUrl(page.url) },
      ...claim.fromFixture && fixture ? {
        fixture: {
          home: fixture.home,
          away: fixture.away,
          ...fixture.competition ? { competition: fixture.competition } : {},
          startISO: fixture.startISO,
          subject: fixtureSubject(claim.question, fixture.home)
        }
      } : {},
      ...tail ? { tailOf: tail.tailOf, ...tail.flip ? { tailFlip: true } : {} } : {},
      ...premiumMist !== void 0 ? { premium: { priceMist: premiumMist.toString() } } : {}
    };
  }
  function leanLabel(pYes) {
    return pYes >= 0.5 ? `YES ${Math.round(pYes * 100)}%` : `NO ${Math.round((1 - pYes) * 100)}%`;
  }
  function leanSide(pick) {
    const yes = pick.pYes >= 0.5;
    if (!pick.fixture) return yes ? "YES" : "NO";
    const { home, away, subject } = pick.fixture;
    const backed = subject === "home" ? home : away;
    const other = subject === "home" ? away : home;
    return yes ? `${backed} win` : `${backed} doesn't win (${other} win or draw)`;
  }
  function callConfidence(pYes) {
    return Math.round(Math.max(pYes, 1 - pYes) * 100);
  }
  function pickLean(pick) {
    if (!pick.fixture) return leanLabel(pick.pYes);
    return `${leanSide(pick)} · ${callConfidence(pick.pYes)}%`;
  }
  function recordHeadline(summary) {
    const parts = [`${summary.picks} ${summary.picks === 1 ? "call" : "calls"}`, `${summary.hits} right`];
    if (summary.resolved > 0) parts.push(`${Math.round(summary.hits / summary.resolved * 100)}% hit rate`);
    if (summary.brier !== null) {
      const market = summary.vsMarketCalls > 0 && summary.marketBrier !== null ? ` vs market ${summary.marketBrier.toFixed(3)}` : "";
      parts.push(`Brier ${summary.brier.toFixed(3)}${market}`);
    }
    return parts.join(" · ");
  }
  function visibleNotes(insight) {
    return insight ? insight.notes.slice(0, 2) : [];
  }
  function calledFromPick(pick) {
    return {
      side: leanSide(pick),
      confidence: callConfidence(pick.pYes),
      pickId: pick.id,
      committed: pick.commit !== null,
      pYes: pick.pYes,
      fixture: pick.fixture ?? null
    };
  }
  function sortByRelevance(tiles, insights) {
    const relevance = (tile) => insights.get(tile.claim.id)?.relevance ?? 0;
    return [...tiles].sort((a, b) => relevance(b) - relevance(a));
  }
  function skipReasonText(reason) {
    switch (reason) {
      case "user_cap":
        return "you reached today's limit";
      case "global_cap":
        return "Soothia reached today's limit";
      case "low_balance":
        return "Soothia's Sui wallet is low";
      default:
        return "the daily counter could not be checked";
    }
  }
  function callErrorMessage(status, body) {
    if (status === 0) return { text: "I couldn't reach Soothia's server. Check your connection.", retry: true };
    if (status === 429) return { text: "Too many requests just now. Try again in a minute.", retry: true };
    if (status === 409 && body?.error === "duplicate_pick") return { text: "You already called this.", retry: false };
    switch (body?.error) {
      case "tail_source_not_found":
        return { text: "That call is no longer in their feed.", retry: false };
      case "tail_side_mismatch":
      case "tail_wrong_question":
        return { text: "This doesn't match the call you're tailing.", retry: false };
      case "cannot_tail_self":
        return { text: "That's your own call.", retry: false };
      case "tail_locked":
        return { text: "That call is locked until kickoff. Unlock it first.", retry: false };
      case "premium_not_eligible":
        return { text: "Premium calls need a public profile, a Call Score of 550 and 10 settled calls.", retry: false };
      case "premium_needs_match":
        return { text: "Only a call on a match can be premium.", retry: false };
      case "fixture_not_open":
      case "too_close_to_kickoff":
        return { text: "This match has started or is about to, so calls are closed.", retry: false };
      case "fixture_not_on_espn":
      case "fixture_date_mismatch":
        return { text: "ESPN doesn't list this match for that day.", retry: false };
      case "espn_unavailable":
        return { text: "ESPN couldn't be checked just now. Try again in a minute.", retry: true };
    }
    if (status === 400) {
      if (body?.field === "fixture.startISO") return { text: "This match has already kicked off.", retry: false };
      if (body?.field === "endTime") return { text: "The deadline for this call has passed.", retry: false };
      return { text: "Soothia couldn't accept this call.", retry: false };
    }
    return { text: "Your call wasn't saved. Please try again.", retry: true };
  }
  function formatGap(ms) {
    const minutes = Math.floor(Math.abs(ms) / 6e4);
    return `${Math.floor(minutes / 60)}h ${minutes % 60}m`;
  }
  function proofProblem(problem2) {
    switch (problem2) {
      case "hash_mismatch":
        return "The proof on Sui does not match this call.";
      case "no_commit_event":
        return "No commit was found in that transaction.";
      default:
        return "Couldn't check the proof just now.";
    }
  }
  function proofText(proof) {
    if (!proof.verified) return { text: proofProblem(proof.problem), good: false };
    if (proof.gapMs === null) return { text: "Committed on Sui ✓", good: true };
    if (proof.gapMs <= 0) return { text: `Committed ${formatGap(proof.gapMs)} after kickoff`, good: false };
    return { text: `Committed ${formatGap(proof.gapMs)} before kickoff ✓`, good: true };
  }
  function shortId(id) {
    return id.length > 12 ? `${id.slice(0, 6)}…${id.slice(-4)}` : id;
  }
  function mergeQuietSites(server, pending2, now) {
    const live = Object.fromEntries(Object.entries(pending2).filter(([, change]) => now - change.at < QUIET_PENDING_MS));
    const sites = new Set(server.map((site) => site.toLowerCase()));
    for (const [site, change] of Object.entries(live)) {
      if (change.quiet) sites.add(site);
      else sites.delete(site);
    }
    return { sites: [...sites].sort(), pending: live };
  }
  const SECTIONS = [
    ["feed", "Feed"],
    ["board", "Leaderboard"],
    ["following", "Following"]
  ];
  const SEARCH_DELAY_MS = 300;
  const profileLink = (text, handle) => externalLink(text, `${SITE_URL}/u/${encodeURIComponent(handle)}`, "link feed-handle");
  function followError(code) {
    switch (code) {
      case "cannot_follow_self":
        return "That's you.";
      case "follow_limit":
        return "You're following as many people as you can.";
      case "not_found":
        return "That profile has gone.";
      case "rate_limited":
        return "Too many tries just now. Wait a minute.";
      default:
        return "That didn't work. Please try again.";
    }
  }
  function receiptLine(receipt) {
    const line = el("p", "note premium-receipt");
    line.append(`Paid ${formatSui(receipt.priceMist, 4)} SUI · `, externalLink(shortId(receipt.digest), receipt.url, "link mono"));
    return line;
  }
  function unlockControl(pickId, priceMist, unlock, layout, done) {
    const node = el("div", "premium-unlock");
    const note = el("p", "note");
    note.setAttribute("aria-live", "polite");
    const picker = el("div", "wallet-row wallet-picker");
    picker.hidden = true;
    const report = (text) => {
      note.textContent = text;
      layout();
    };
    const choose = (wallets) => new Promise((resolve) => {
      picker.replaceChildren(
        ...wallets.map(
          (wallet) => button(wallet.name, "button small", () => {
            picker.hidden = true;
            resolve(wallet);
          })
        )
      );
      picker.hidden = false;
      report("Choose a wallet.");
    });
    const action = button("Unlock", "button small premium-button", () => {
      void (async () => {
        action.disabled = true;
        report("Waiting for your wallet…");
        const result = await unlock(pickId, priceMist, choose).catch((error) => ({ ok: false, code: "wallet", walletMessage: String(error?.message ?? error), maybePaid: false }));
        if (result.ok) return done(result.call, result.receipt);
        action.disabled = false;
        report(unlockFailureText(result, (text) => walletErrorText(text, "Nothing was paid.").text));
      })();
    });
    node.append(action, picker, note);
    return node;
  }
  function createSocialView(pane, host) {
    let current = "feed";
    let seq = 0;
    const nowMs = () => host.now?.() ?? Date.now();
    function lockedRow(entry, row) {
      const { item } = entry;
      if (!isLockedItem(item)) return row;
      row.append(el("p", "feed-call feed-premium", premiumLine(item.premium.priceMist)));
      if (item.proof) row.append(externalLink("Proof on Sui", item.proof.url, "link ext"));
      if (host.unlock && item.proof && canTail(item.fixture, nowMs())) {
        row.append(
          unlockControl(item.pickId, item.premium.priceMist, host.unlock, host.layout, (call, receipt) => {
            row.replaceWith(feedRow({ ...entry, item: call }, receipt));
            host.layout();
          })
        );
      } else if (!item.proof) {
        row.append(el("p", "note", "Waiting for its proof on Sui."));
      }
      return row;
    }
    function feedRow(entry, receipt = null) {
      const { handle, score, item, myCall } = entry;
      const row = el("div", "feed-row");
      const top = el("div", "feed-top");
      top.append(profileLink(handleLine(handle, score), handle), el("span", "feed-time", timeAgo(Date.parse(item.at), nowMs())));
      row.append(top, el("p", "feed-match", matchLine(item.fixture)));
      if (isLockedItem(item)) return lockedRow(entry, row);
      row.append(el("p", "feed-call", callLine(item.lean, item.confidence, item.stakeMist)));
      if (item.premium) row.append(el("p", "note feed-premium", "Premium call"));
      if (receipt) row.append(receiptLine(receipt));
      if (item.tailOf) row.append(el("p", "note", `Tail of @${item.tailOf}`));
      if (myCall) row.append(el("p", "feed-mine", `You: ${callLine(myCall.side, myCall.confidence)}`));
      else if (canTail(item.fixture, nowMs())) row.append(button("Tail", "button small feed-tail", () => host.onTail(handle, item)));
      return row;
    }
    async function renderFeed(slot, mine, agentNote = "") {
      slot.replaceChildren(host.state("watching", "Loading your feed…"));
      host.layout();
      const response = await host.api("/social/feed", {});
      if (mine !== seq) return;
      if (!response.ok || !response.body) {
        slot.replaceChildren(host.state("error", "Couldn't load your feed.", button("Try again", "button", () => void render())));
      } else {
        const { items } = response.body;
        if (items.length === 0) {
          slot.replaceChildren(host.state("empty", "Follow people to see their calls here.", button("Find people", "button", () => void select("following"))));
        } else {
          const refresh = button("Refresh", "link", () => void render());
          refresh.prepend(icon("refresh"));
          const tools = el("div", "refresh-row");
          tools.append(refresh);
          slot.replaceChildren(tools, ...agentNote ? [el("p", "note agent-note", agentNote)] : [], ...items.map((entry) => feedRow(entry)));
        }
      }
      host.layout();
      if (agentNote || !response.ok || !host.runAgent) return;
      const bought = await host.runAgent();
      if (bought > 0 && mine === seq) await renderFeed(slot, mine, `Your agent unlocked ${bought} call${bought === 1 ? "" : "s"}.`);
    }
    function followingRow(row, reload) {
      const node = el("div", "follow-row");
      const name = row.handle ? profileLink(handleLine(row.handle, row.score), row.handle) : el("span", "feed-handle mono", shortId(row.address));
      const note = el("span", "note", row.public ? "" : "No longer public");
      const unfollow = button("Unfollow", "button small", () => {
        void (async () => {
          unfollow.disabled = true;
          const response = await host.api("/social/unfollow", { address: row.address });
          if (response.ok) reload();
          else {
            unfollow.disabled = false;
            note.textContent = followError(response.body?.error);
            host.layout();
          }
        })();
      });
      node.append(name, note, unfollow);
      return node;
    }
    function searchRow(row, reload) {
      const node = el("div", "follow-row");
      const name = profileLink(handleLine(row.handle, row.score), row.handle);
      const note = el("span", "note", "");
      node.append(name, note);
      if (row.following) node.append(el("span", "note", "Following"));
      else {
        const follow = button("Follow", "button small", () => {
          void (async () => {
            follow.disabled = true;
            const response = await host.api("/social/follow", { handle: row.handle });
            if (response.ok) reload();
            else {
              follow.disabled = false;
              note.textContent = followError(response.body?.error);
              host.layout();
            }
          })();
        });
        node.append(follow);
      }
      return node;
    }
    async function renderFollowing(slot, mine) {
      const input = el("input", "input follow-search");
      input.type = "text";
      input.placeholder = "Search handles";
      input.spellcheck = false;
      input.autocomplete = "off";
      input.setAttribute("aria-label", "Search handles");
      const results = el("div", "follow-results");
      const list = el("div", "follow-list");
      let timer;
      let searchSeq = 0;
      const reload = () => void render();
      async function search() {
        const mineSearch = ++searchSeq;
        const query = input.value.trim().toLowerCase();
        if (!query) {
          results.replaceChildren();
          host.layout();
          return;
        }
        const response2 = await host.api("/social/search", { q: query });
        if (mineSearch !== searchSeq) return;
        const found = response2.ok && response2.body ? response2.body.results : [];
        results.replaceChildren(...found.length > 0 ? found.map((row) => searchRow(row, reload)) : [el("p", "note", response2.ok ? "No one by that name." : "Couldn't search just now.")]);
        host.layout();
      }
      input.addEventListener("input", () => {
        clearTimeout(timer);
        timer = setTimeout(() => void search(), SEARCH_DELAY_MS);
      });
      list.append(host.state("watching", "Loading…"));
      slot.replaceChildren(input, results, list);
      host.layout();
      const response = await host.api("/social/following", {});
      if (mine !== seq) return;
      if (!response.ok || !response.body) {
        list.replaceChildren(el("p", "note", "Couldn't load who you follow."));
      } else {
        const { following } = response.body;
        list.replaceChildren(...following.length > 0 ? following.map((row) => followingRow(row, reload)) : [el("p", "note", "You aren't following anyone yet.")]);
      }
      host.layout();
    }
    function segmented() {
      const bar = el("div", "record-segments social-segments");
      bar.setAttribute("role", "tablist");
      for (const [value, label] of SECTIONS) {
        const tab = button(label, `record-segment${value === current ? " selected" : ""}`, () => void select(value));
        tab.setAttribute("role", "tab");
        tab.setAttribute("aria-selected", String(value === current));
        bar.append(tab);
      }
      return bar;
    }
    function select(section2) {
      current = section2;
      return render();
    }
    async function render() {
      const mine = ++seq;
      const slot = el("div", "social-slot");
      pane.replaceChildren(segmented(), slot);
      if (current === "feed") await renderFeed(slot, mine);
      else if (current === "following") await renderFollowing(slot, mine);
      else await createLeaderboardView(slot, host).render();
    }
    return { render };
  }
  function followedRow(calls, consensus, onTail, layout, unlock) {
    const node = el("div", "followed");
    const head = button("", "followed-head", () => {
      list.hidden = !list.hidden;
      head.setAttribute("aria-expanded", String(!list.hidden));
      layout();
    });
    head.setAttribute("aria-expanded", "false");
    const avatars = el("span", "followed-avatars");
    avatars.append(...calls.slice(0, 3).map((call) => el("span", "followed-avatar", initials(call.handle))));
    head.append(avatars, el("span", "followed-text", followedLine(calls, consensus)));
    const list = el("div", "followed-list");
    list.hidden = true;
    for (const call of calls) {
      const row = el("div", "followed-call");
      if (isLockedCall(call)) {
        const lean = el("span", "followed-lean", premiumLine(call.premium.priceMist));
        row.append(el("span", "followed-who", `@${call.handle}`), lean);
        if (unlock && call.proof) {
          const control = unlockControl(call.pickId, call.premium.priceMist, unlock, layout, (open, receipt) => {
            lean.textContent = callLine(open.lean, open.confidence, open.stakeMist);
            control.replaceChildren(...receipt ? [receiptLine(receipt)] : []);
            layout();
          });
          row.append(control);
        }
      } else {
        row.append(el("span", "followed-who", `@${call.handle}`), el("span", "followed-lean", callLine(call.lean, call.confidence, call.stakeMist)));
        if (onTail) row.append(button("Tail", "button small", () => onTail(call)));
      }
      list.append(row);
    }
    node.append(head, list);
    return node;
  }
  const RECORD_SECTIONS = ["calls", "lessons", "wallet", "me"];
  const isRecordSection = (value) => RECORD_SECTIONS.includes(value);
  function stakesForSummary(positions, picks) {
    if (positions.length > 0) return positions;
    return picks.flatMap((pick) => {
      if (!pick.stake) return [];
      const position = {
        poolId: pick.stake.poolId,
        pickId: pick.id,
        match: { home: pick.fixture?.home ?? "", away: pick.fixture?.away ?? "", startISO: pick.fixture?.startISO ?? "", subject: pick.fixture?.subject ?? "home" },
        side: pick.stake.side,
        status: pick.stake.status ?? "open",
        amountMist: pick.stake.amountMist,
        estimatedPayoutMist: pick.stake.payoutMist ?? "0",
        claimOpensAtMs: pick.stake.claimOpensAtMs
      };
      return [position];
    });
  }
  function buildRecordHeader(input) {
    const { summary, handle, publicScore, stakes } = input;
    const settled = summary.resolved > 0;
    const score = publicScore ?? (settled ? summary.callScore ?? null : null);
    const parts = settled ? [`${summary.hits} of ${summary.resolved} right`] : [];
    if (stakes.length > 0) parts.push(signedSuiShort(walletSummary(stakes).profitMist ?? 0n));
    return {
      identity: handle ? `@${handle} · Public` : "Private",
      isPublic: handle !== null,
      score: score === null ? "—" : String(score),
      scoreNote: settled ? null : "Needs 1 settled call",
      summary: parts.join(" · ")
    };
  }
  const MAX_ATTENTION = 2;
  const NEW_LESSON_MS = 48 * 36e5;
  const SHORT_LESSON_CHARS = 64;
  function kickoffOf(pick) {
    return Date.parse(pick.fixture?.startISO ?? pick.endTime ?? "");
  }
  const sameLocalDay = (a, b) => new Date(a).toDateString() === new Date(b).toDateString();
  function shortLesson(text) {
    const first = text.split(/[.:]\s/)[0].replace(/\.$/, "");
    return first.length > SHORT_LESSON_CHARS ? `${first.slice(0, SHORT_LESSON_CHARS - 1).trimEnd()}…` : first;
  }
  function attentionItems(input) {
    const { stakes, picks, lessons, nowMs } = input;
    const items = [];
    const claimable = stakes.filter((stake) => isClaimable(stake.status)).length;
    if (claimable > 0) items.push({ text: `${claimable} ${claimable === 1 ? "stake" : "stakes"} ready to claim`, section: "wallet" });
    const today = picks.filter((pick) => pick.status === "open" && sameLocalDay(kickoffOf(pick), nowMs)).length;
    if (today > 0) items.push({ text: `${today} ${today === 1 ? "call settles" : "calls settle"} today`, section: "calls" });
    const [newest] = lessons.filter((lesson) => nowMs - Date.parse(lesson.at) <= NEW_LESSON_MS).sort((a, b) => b.at.localeCompare(a.at));
    if (newest) items.push({ text: `New lesson: ${shortLesson(newest.text)}`, section: "lessons" });
    return items.slice(0, MAX_ATTENTION);
  }
  const byKickoff = (a, b) => (kickoffOf(a) || 0) - (kickoffOf(b) || 0);
  function groupCalls(picks) {
    const upcoming = picks.filter((pick) => pick.status === "open").sort(byKickoff);
    const settled = picks.filter((pick) => pick.status !== "open").sort((a, b) => byKickoff(b, a));
    return { upcoming, settled };
  }
  function shortDate(pick) {
    const ms = kickoffOf(pick);
    return Number.isNaN(ms) ? "" : new Date(ms).toLocaleDateString([], { day: "numeric", month: "short" });
  }
  function lockedText(pick) {
    if (!pick.commit || !pick.fixture?.startISO) return null;
    const gapMs = Date.parse(pick.fixture.startISO) - Date.parse(pick.at);
    if (Number.isNaN(gapMs) || gapMs <= 0) return null;
    const hours = Math.floor(gapMs / 36e5);
    if (hours >= 48) return `Locked ${Math.floor(hours / 24)}d before kickoff`;
    return hours >= 1 ? `Locked ${hours}h before kickoff` : `Locked ${Math.max(1, Math.floor(gapMs / 6e4))}m before kickoff`;
  }
  const LESSON_RANK = (key) => {
    if (key.startsWith("entity:")) return 0;
    if (key.startsWith("category:")) return 1;
    if (key.startsWith("tail:")) return 2;
    if (key === "stakes" || key === "stake_size" || key === "premium") return 3;
    if (key === "consensus") return 4;
    if (key === "favourites") return 5;
    if (key === "vs_market") return 6;
    return 7;
  };
  const MAX_LESSONS = 3;
  function lessonsForDisplay(lessons) {
    const newest = /* @__PURE__ */ new Map();
    for (const lesson of lessons) {
      const known = newest.get(lesson.key);
      if (!known || lesson.at > known.at) newest.set(lesson.key, lesson);
    }
    return [...newest.values()].sort((a, b) => LESSON_RANK(a.key) - LESSON_RANK(b.key) || b.at.localeCompare(a.at)).slice(0, MAX_LESSONS);
  }
  function calibrationRows(buckets) {
    return buckets.filter((bucket) => bucket.calls > 0).map((bucket) => {
      const saidPercent = Math.round(bucket.claimed * 100 / 5) * 5;
      const rightPercent = Math.round(bucket.hitRate * 100);
      return { text: `When you say ~${saidPercent}%, you're right ${rightPercent}%`, saidPercent, rightPercent };
    });
  }
  const SHOWS_ESTIMATE = ["open", "awaiting_result", "challenge_window"];
  function stakeDetailText(position, pick, when2) {
    const estimate = SHOWS_ESTIMATE.includes(position.status) && BigInt(position.estimatedPayoutMist) > 0n ? ` · about ${formatSui(position.estimatedPayoutMist, 4)} SUI if right` : "";
    return `Staked ${formatSui(position.amountMist, 4)} SUI on ${leanSide(pick)} · ${positionStatusText(position, when2)}${estimate}`;
  }
  function stakeListLean(position, picks, when2) {
    const pick = picks.find((candidate) => candidate.id === position.pickId);
    const lean = leanSide(pick ?? { pYes: position.side === "YES" ? 1 : 0, fixture: position.match });
    return `${position.match.home} v ${position.match.away} · ${formatSui(position.amountMist, 4)} SUI on ${lean} · ${positionStatusText(position, when2)}`;
  }
  const DEFAULT_FUNDING = "0.05";
  const txUrl = (digest) => `https://suivision.xyz/txblock/${encodeURIComponent(digest)}`;
  const whenText = (iso) => new Date(iso).toLocaleString([], { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
  function suiInput(value, label) {
    const input = el("input", "input agent-input");
    input.type = "text";
    input.inputMode = "decimal";
    input.value = value;
    input.setAttribute("aria-label", label);
    return input;
  }
  function createAgentSection(host) {
    const node = el("section", "record-section agent");
    const title = el("h3", "field-label", "Agent");
    const slot = el("div", "agent-body");
    node.append(title, slot);
    const refresh = async () => {
      const status = await host.agent("status");
      slot.replaceChildren(...status ? status.address ? agentView(status, status.address) : createView() : [el("p", "note", "Couldn't load the agent wallet.")]);
      host.layout();
    };
    function createView() {
      const note = el("p", "note");
      const create = button("Create agent wallet", "button primary wide", () => {
        void (async () => {
          create.disabled = true;
          note.textContent = "Creating…";
          host.layout();
          if (await host.agent("create") === null) {
            note.textContent = "That didn't work. Please try again.";
            create.disabled = false;
            host.layout();
            return;
          }
          await refresh();
        })();
      });
      return [el("p", "note", "A separate wallet that unlocks premium calls from people you follow, without a popup."), el("p", "warn", "Keep small amounts here."), create, note];
    }
    function agentView(status, address) {
      const note = el("p", "note");
      note.setAttribute("aria-live", "polite");
      const report = (text) => {
        note.textContent = text;
        host.layout();
      };
      const info = el("div", "agent-info");
      info.append(el("p", "note mono", `Address ${shortId(address)}`), el("p", "note", `Balance ${status.balanceMist === null ? "unknown" : `${formatSui(status.balanceMist, 4)} SUI`}`), el("p", "warn", "Keep small amounts here. Uninstalling Soothia deletes this wallet's key."));
      const amount = suiInput(DEFAULT_FUNDING, "Amount to fund, in SUI");
      const fund = button("Fund from my wallet", "button small", () => void fundAgent());
      const fundRow = el("div", "wallet-row agent-row");
      fundRow.append(amount, fund);
      async function fundAgent() {
        const mist = parseSuiAmount(amount.value);
        if (mist === null) return report("Enter an amount in SUI.");
        fund.disabled = true;
        report("Preparing…");
        const built = await host.api("/premium/transfer/build", { sender: host.connected.address, recipient: address, amountMist: mist.toString() });
        if (!built.ok || !built.body) {
          fund.disabled = false;
          return report(built.body?.error === "insufficient_balance" ? "Your wallet doesn't have enough SUI." : "Couldn't prepare that. Please try again.");
        }
        report("Waiting for your wallet…");
        try {
          await host.wallet.sign(host.connected, built.body.transaction, { kind: "fund", recipient: address, amountMist: mist.toString() });
        } catch (error) {
          fund.disabled = false;
          return report(walletErrorText(String(error?.message ?? error), "Nothing was sent.").text);
        }
        await refresh();
      }
      const withdraw = button("Withdraw all", "button small", () => {
        void (async () => {
          withdraw.disabled = true;
          report("Sending it back to your wallet…");
          const result = await host.agent("withdraw");
          if (!result?.digest) {
            withdraw.disabled = false;
            report(result?.error === "insufficient_balance" ? "There's too little here to send." : "That didn't work. Please try again.");
            return;
          }
          await refresh();
        })();
      });
      const withdrawRow = el("div", "wallet-row agent-row");
      withdrawRow.append(withdraw);
      const enabled = el("input", "agent-check");
      enabled.type = "checkbox";
      enabled.checked = status.settings.enabled;
      enabled.setAttribute("aria-label", "Auto-unlock on");
      const onLabel = el("label", "agent-switch");
      onLabel.append(enabled, el("span", "", "Auto-unlock"));
      const budget = suiInput(formatSui(status.settings.dailyBudgetMist), "Daily budget in SUI");
      const max = suiInput(formatSui(status.settings.maxPerCallMist), "Most to pay for one call, in SUI");
      const field = (label, input) => {
        const row = el("div", "wallet-row agent-row");
        row.append(el("span", "field-label", label), input);
        return row;
      };
      const save = button("Save settings", "button small", () => {
        void (async () => {
          const budgetMist = parseSuiAmount(budget.value);
          const maxMist = parseSuiAmount(max.value);
          if (budgetMist === null || maxMist === null) return report("Enter amounts in SUI.");
          if (maxMist > AGENT_HARD_CAP_MIST) return report(`The most per call is ${formatSui(AGENT_HARD_CAP_MIST)} SUI.`);
          save.disabled = true;
          await host.agent("settings", { enabled: enabled.checked, dailyBudgetMist: budgetMist.toString(), maxPerCallMist: maxMist.toString() });
          await refresh();
        })();
      });
      const receipts = status.receipts.map((receipt) => {
        const row = el("div", "agent-receipt");
        row.append(el("span", "", `${whenText(receipt.at)} · @${receipt.handle} · ${receipt.match} · ${formatSui(receipt.priceMist, 4)} SUI`), externalLink(shortId(receipt.digest), txUrl(receipt.digest), "link mono"));
        return row;
      });
      return [
        info,
        fundRow,
        withdrawRow,
        note,
        onLabel,
        field("Daily budget (SUI)", budget),
        field("Max per call (SUI)", max),
        el("p", "note", "Only callers I follow: always on"),
        el("p", "note", `Spent today ${formatSui(status.spentTodayMist, 4)} of ${formatSui(status.settings.dailyBudgetMist, 4)} SUI`),
        save,
        ...receipts.length > 0 ? [el("p", "field-label", "Receipts"), ...receipts] : []
      ];
    }
    slot.append(el("p", "note", "Loading…"));
    void refresh();
    return node;
  }
  const when = (ms) => new Date(ms).toLocaleString([], { weekday: "short", hour: "2-digit", minute: "2-digit" });
  const EMPTY_TEXT = "No calls yet. Open a match page and tap Call it.";
  const SETTLED_PAGE = 10;
  const SECTION_LABELS = [
    ["calls", "Calls"],
    ["lessons", "Lessons"],
    ["wallet", "Wallet"],
    ["me", "Me"]
  ];
  function section(title, ...children) {
    const node = el("section", "record-section");
    node.append(el("h3", "field-label", title), ...children);
    return node;
  }
  function expander(title, ...children) {
    const node = el("details", "record-more");
    node.append(el("summary", "record-more-summary", title), ...children);
    return node;
  }
  function percentBar(name, percent, className) {
    const row = el("div", "cal-bar");
    const track = el("span", "cal-track");
    const fill = el("span", `cal-fill ${className}`);
    fill.style.width = `${Math.min(percent, 100)}%`;
    track.append(fill);
    row.append(el("span", "cal-name", name), track, el("span", "cal-value", `${percent}%`));
    return row;
  }
  function teamTable(entities) {
    const table = el("table", "record-table");
    const head = el("tr", "");
    for (const title of ["Team", "Calls", "Right"]) head.append(el("th", "", title));
    const thead = el("thead", "");
    thead.append(head);
    const tbody = el("tbody", "");
    for (const line of entities) {
      const row = el("tr", "");
      row.append(el("td", "", line.entity), el("td", "mono", String(line.calls)), el("td", "mono", String(line.hits)));
      tbody.append(row);
    }
    table.append(thead, tbody);
    return table;
  }
  function headerNode(view, onGoPublic, refresh) {
    const node = el("div", "record-header");
    const identity = el("div", "record-identity");
    identity.append(el("span", "record-who", view.identity));
    if (!view.isPublic) identity.append(button("Go public", "link record-go-public", onGoPublic));
    identity.append(refresh);
    node.append(identity, el("p", "record-score", view.score), el("p", "record-score-label", "CALL SCORE"));
    if (view.scoreNote) node.append(el("p", "note", view.scoreNote));
    if (view.summary) node.append(el("p", "record-tally", view.summary));
    return node;
  }
  function attentionStrip(items, open) {
    if (items.length === 0) return [];
    const strip = el("div", "record-attention");
    strip.append(...items.map((item) => button(item.text, "record-attention-item", () => open(item.section))));
    return [strip];
  }
  function walletStats(positions) {
    const summary = walletSummary(positions);
    const stat = (label, value) => {
      const node = el("span", "wallet-stat");
      node.append(el("b", "", value), label);
      return node;
    };
    const grid = el("div", "wallet-stats");
    grid.append(
      stat("staked", `${formatSui(summary.stakedMist, 4)} SUI`),
      stat("won", `${formatSui(summary.wonMist, 4)} SUI`),
      stat("lost", `${formatSui(summary.lostMist, 4)} SUI`),
      stat("profit or loss", summary.profitMist === null ? "—" : signedSui(summary.profitMist)),
      stat("ROI", summary.roiPercent === null ? "—" : `${summary.roiPercent.toFixed(1)}%`),
      stat("best multiplier", summary.bestMultiplier === null ? "—" : `${summary.bestMultiplier.toFixed(2)}x`)
    );
    return grid;
  }
  function proofLink(pickId, host, label = "Proof") {
    const result = el("span", "note proof-result");
    const link = button(label, "link", () => {
      void (async () => {
        link.disabled = true;
        result.textContent = "Checking on Sui…";
        host.layout();
        const response = await host.api("/recall/proof", { pickId });
        link.disabled = false;
        if (!response.ok || !response.body) {
          result.textContent = "Couldn't check the proof just now.";
          host.layout();
          return;
        }
        const { text, good } = proofText(response.body);
        result.textContent = text;
        result.classList.toggle("good", good);
        host.layout();
      })();
    });
    return { link, result };
  }
  function calledRow(called, host) {
    const row = el("div", "called-row");
    row.append(el("span", "called-badge", `Your call: ${called.side} · ${called.confidence}%`));
    if (called.committed) {
      const { link, result } = proofLink(called.pickId, host);
      row.append(link, result);
    }
    return row;
  }
  function createRecordView(pane, host) {
    let seq = 0;
    let current = "calls";
    let sectionLoaded = false;
    let data = null;
    let settledShown = SETTLED_PAGE;
    const expanded = /* @__PURE__ */ new Set();
    const headerSlot = el("div", "record-header-slot");
    function open(next) {
      current = next;
      host.saveSection?.(next);
      draw();
    }
    function refreshButton() {
      const link = button("Refresh", "link", () => void render());
      link.prepend(icon("refresh"));
      const row = el("div", "refresh-row");
      row.append(link);
      return row;
    }
    function drawHeader() {
      if (!data) return;
      const view = buildRecordHeader({
        summary: data.record.summary,
        handle: data.publicInfo?.handle ?? null,
        publicScore: data.publicInfo?.score ?? null,
        stakes: stakesForSummary(data.positions, data.record.picks)
      });
      headerSlot.replaceChildren(headerNode(view, () => open("me"), refreshButton()));
    }
    function positionFor(pickId) {
      return stakesForSummary(data?.positions ?? [], data?.record.picks ?? []).find((position) => position.pickId === pickId);
    }
    function callDetail(pick) {
      const detail = el("div", "call-detail");
      detail.append(el("p", "call-detail-line", `${pickLean(pick)} confident`));
      if (pick.detail) detail.append(el("p", "call-detail-line", pick.detail));
      const proof = el("div", "record-proof");
      if (pick.commit) {
        const { link, result } = proofLink(pick.id, host, "Proof on Sui");
        proof.append(link, externalLink("View transaction", pick.commit.explorerUrl, "link ext"), result);
      } else {
        proof.append(el("span", "note", pick.commitSkipped ? `No Sui proof (${skipReasonText(pick.commitSkipped)})` : "No Sui proof"));
      }
      detail.append(proof);
      const position = positionFor(pick.id);
      if (position) detail.append(el("p", "call-detail-line", stakeDetailText(position, pick, when)));
      const locked = lockedText(pick);
      if (locked) detail.append(el("p", "call-detail-line", locked));
      return detail;
    }
    function callRow(pick) {
      const row = el("div", "call-row");
      const head = button("", "call-row-head", () => {
        if (expanded.has(pick.id)) expanded.delete(pick.id);
        else expanded.add(pick.id);
        draw();
      });
      head.setAttribute("aria-expanded", String(expanded.has(pick.id)));
      const top = el("span", "call-row-top");
      if (pick.status !== "open") top.append(el("span", `call-icon ${pick.status}`, pick.status === "right" ? "✓" : "✗"));
      top.append(el("span", "call-match", pick.fixture ? `${pick.fixture.home} v ${pick.fixture.away}` : pick.question), el("span", "call-date", shortDate(pick)));
      const position = positionFor(pick.id);
      head.append(top, el("span", "call-lean", `${pickLean(pick)}${position ? ` · ${formatSui(position.amountMist, 4)} SUI` : ""}`));
      row.append(head);
      if (expanded.has(pick.id)) row.append(callDetail(pick));
      return row;
    }
    function callsSection(record) {
      if (record.picks.length === 0) return [host.state("empty", EMPTY_TEXT)];
      const { upcoming, settled } = groupCalls(record.picks);
      const groups = [];
      if (upcoming.length > 0) groups.push(section("Upcoming", ...upcoming.map(callRow)));
      if (settled.length > 0) {
        const shown = settled.slice(0, settledShown);
        const more = settled.length > shown.length ? [button("Show more", "link record-show-more", () => (settledShown += SETTLED_PAGE, draw()))] : [];
        groups.push(section("Settled", ...shown.map(callRow), ...more));
      }
      return groups;
    }
    function lessonsSection(record) {
      const lessons = lessonsForDisplay(record.lessons);
      const rows = calibrationRows(record.summary.calibration);
      const nodes = [];
      nodes.push(
        lessons.length > 0 ? section(
          "Lessons",
          ...lessons.map((lesson) => {
            const card = el("div", "tile");
            card.append(el("p", "lesson-text", lesson.text), el("p", "note", `From ${lesson.n} ${lesson.n === 1 ? "call" : "calls"}`));
            return card;
          })
        ) : host.state("empty", "Lessons appear after a few settled calls.")
      );
      if (rows.length > 0) {
        nodes.push(
          section(
            "Your confidence",
            ...rows.map((row) => {
              const item = el("div", "cal-bucket");
              item.append(el("p", "cal-label", row.text), percentBar("You said", row.saidPercent, "claimed"), percentBar("Right", row.rightPercent, "landed"));
              return item;
            })
          )
        );
      }
      nodes.push(expander("How Soothia learns", el("p", "note", "After each match, Soothia compares how sure you were with what happened. When a pattern changes, it writes a new lesson to your memory on Walrus.")));
      const { summary } = record;
      if (summary.resolved > 0 || summary.entities.length > 0) {
        nodes.push(expander("More numbers", el("p", "note record-headline", recordHeadline(summary)), ...summary.entities.length > 0 ? [teamTable(summary.entities)] : []));
      }
      return nodes;
    }
    function chooseWallet(picker, note) {
      return (wallets) => new Promise((resolve) => {
        picker.replaceChildren(
          ...wallets.map(
            (wallet) => button(wallet.name, "button small", () => {
              picker.hidden = true;
              resolve(wallet);
            })
          )
        );
        picker.hidden = false;
        note.textContent = "Choose a wallet.";
        host.layout();
      });
    }
    function connectView() {
      const note = el("p", "note");
      const picker = el("div", "wallet-row wallet-picker");
      picker.hidden = true;
      const connect = button("Connect Sui wallet", "button primary wide", () => {
        void (async () => {
          connect.disabled = true;
          try {
            if (await host.wallet?.connect(chooseWallet(picker, note)) ?? null) {
              await render();
              return;
            }
          } catch (error) {
            note.textContent = walletErrorText(String(error?.message ?? error), "").text;
          }
          connect.disabled = false;
          host.layout();
        })();
      });
      return [el("p", "note", "Connect a wallet to see your stakes and claim what you've won."), connect, picker, note];
    }
    async function claim(position, wallet, control, note) {
      const report = (text, bad = false) => {
        note.textContent = text;
        note.classList.toggle("bad", bad);
        host.layout();
      };
      control.disabled = true;
      report("Preparing your claim…");
      const built = await host.api("/stake/claim/build", { poolId: position.poolId, sender: wallet.address });
      if (!built.ok || !built.body) {
        const { text, retry } = stakeErrorText(built.status, built.body);
        report(text, true);
        control.disabled = !retry;
        return;
      }
      report("Waiting for your wallet…");
      try {
        const { digest } = await host.wallet.sign(wallet, built.body.txBytes, { kind: "claim", poolId: position.poolId });
        control.hidden = true;
        position.status = "claimed";
        report(`Claimed ${formatSui(position.estimatedPayoutMist, 4)} SUI. Proof: `);
        note.append(externalLink(`${digest.slice(0, 8)}…`, `https://suivision.xyz/txblock/${encodeURIComponent(digest)}`, "link ext"));
        drawHeader();
        host.layout();
      } catch (error) {
        const { text, retry } = walletErrorText(String(error?.message ?? error), "Nothing was claimed.");
        report(text, true);
        control.disabled = !retry;
      }
    }
    function claimRow(position, wallet) {
      const row = el("div", "stake-block");
      const note = el("p", "stake-claim-note");
      const control = button("Claim", "button primary small", () => void claim(position, wallet, control, note));
      row.append(el("span", "stake-text", `${position.match.home} v ${position.match.away} · ${formatSui(position.estimatedPayoutMist, 4)} SUI`), control, note);
      return row;
    }
    function walletSection(record, wallet, positions) {
      if (!wallet) return connectView();
      const claims = positions.filter((position) => isClaimable(position.status));
      const nodes = [];
      if (claims.length > 0) nodes.push(section("Ready to claim", ...claims.map((position) => claimRow(position, wallet))));
      nodes.push(section(`Wallet ${shortId(wallet.address)}`, walletStats(positions)));
      if (host.agent && host.wallet) nodes.push(createAgentSection({ agent: host.agent, api: host.api, wallet: host.wallet, connected: wallet, layout: host.layout }));
      if (positions.length === 0) {
        nodes.push(el("p", "note", "No stakes from this wallet yet."));
      } else {
        nodes.push(
          section(
            "Stakes",
            ...positions.map((position) => {
              const row = el("div", "stake-block");
              row.append(el("span", "stake-text", stakeListLean(position, record.picks, when)));
              return row;
            })
          )
        );
      }
      return nodes;
    }
    function quietSection() {
      const sites = host.quietSites();
      if (sites.length === 0) return [];
      const list = el("div", "quiet-list");
      for (const site of sites) {
        const row = el("div", "quiet-row");
        const undo = button("Undo", "link", () => {
          void (async () => {
            undo.disabled = true;
            if (await host.unquiet(site)) {
              row.remove();
              if (list.childElementCount === 0) list.closest(".record-section")?.remove();
            } else {
              undo.disabled = false;
              undo.textContent = "Try again";
            }
            host.layout();
          })();
        });
        row.append(el("span", "quiet-site", site), undo);
        list.append(row);
      }
      return [section("Quiet sites", list)];
    }
    function storageFooter(account) {
      const details = [];
      if (account) {
        const line = el("p", "note");
        line.append("Memory account ", externalLink(shortId(account.accountId), account.explorerUrl, "link mono"));
        if (account.owner) line.append(" owned by ", externalLink(shortId(account.owner), `https://suivision.xyz/account/${encodeURIComponent(account.owner)}`, "link mono"));
        details.push(line);
      }
      const packages = el("p", "note");
      packages.append("Packages: ", externalLink("proofs", `https://suivision.xyz/package/${RECALL_PACKAGE}`, "link"), " · ", externalLink("staking", `https://suivision.xyz/package/${STAKE_PACKAGE}`, "link"));
      details.push(packages);
      return expander("Calls stored on Walrus · proofs on Sui", ...details);
    }
    function meSection(record) {
      const nodes = [];
      if (host.wallet) {
        const panel = createGoPublicPanel({
          api: host.api,
          wallet: host.wallet,
          layout: host.layout,
          onChange: (profile) => {
            if (!data) return;
            const score = data.publicInfo?.handle === profile?.handle ? data.publicInfo?.score ?? null : null;
            data.publicInfo = profile ? { handle: profile.handle, score } : null;
            drawHeader();
          }
        });
        void panel.load().catch(() => void 0);
        nodes.push(panel.node);
      }
      nodes.push(...quietSection());
      const link = host.linkRecord?.();
      if (link) nodes.push(link);
      nodes.push(storageFooter(record.account));
      return nodes;
    }
    function segmented() {
      const bar = el("div", "record-segments");
      bar.setAttribute("role", "tablist");
      for (const [value, label] of SECTION_LABELS) {
        const tab = button(label, `record-segment${value === current ? " selected" : ""}`, () => open(value));
        tab.setAttribute("role", "tab");
        tab.setAttribute("aria-selected", String(value === current));
        bar.append(tab);
      }
      return bar;
    }
    function sectionNodes({ record, wallet, positions }) {
      switch (current) {
        case "lessons":
          return lessonsSection(record);
        case "wallet":
          return walletSection(record, wallet, positions);
        case "me":
          return meSection(record);
        default:
          return callsSection(record);
      }
    }
    function draw() {
      if (!data) return;
      drawHeader();
      const items = attentionItems({
        stakes: stakesForSummary(data.positions, data.record.picks),
        picks: data.record.picks,
        lessons: data.record.lessons,
        nowMs: Date.now()
      });
      pane.replaceChildren(headerSlot, ...attentionStrip(items, open), segmented(), ...sectionNodes(data));
      host.layout();
    }
    async function loadPositions() {
      const wallet = await host.wallet?.current().catch(() => null) ?? null;
      if (!wallet) return { wallet: null, positions: [] };
      const response = await host.api("/stake/positions", { address: wallet.address });
      return { wallet, positions: response.ok && response.body ? response.body.positions : [] };
    }
    async function loadPublic(wallet) {
      if (!wallet) return null;
      const response = await host.api("/social/profile/by-address", { address: wallet.address });
      const body = response.ok ? response.body : null;
      return body?.public && body.profile ? { handle: body.profile.handle, score: body.score ?? null } : null;
    }
    async function render() {
      const mine = ++seq;
      if (!sectionLoaded) {
        sectionLoaded = true;
        const saved = await host.loadSection?.().catch(() => null);
        if (isRecordSection(saved)) current = saved;
      }
      pane.replaceChildren(host.state("watching", "Loading your record…"));
      host.layout();
      const response = await host.api("/recall/record", {});
      if (mine !== seq) return;
      if (!response.ok || !response.body) {
        pane.replaceChildren(
          host.state(
            "error",
            "Couldn't load your record.",
            button("Try again", "button", () => void render())
          ),
          ...quietSection()
        );
        host.layout();
        return;
      }
      const { wallet, positions } = await loadPositions();
      if (mine !== seq) return;
      const publicInfo = await loadPublic(wallet);
      if (mine !== seq) return;
      data = { record: response.body, wallet, positions, publicInfo };
      draw();
    }
    return { render };
  }
  const TRUST_DOC_URL = "https://github.com/shrooms08/soothia/blob/main/docs/staking-trust.md";
  const CHIPS = ["0.1", "0.5", "1", "5"];
  const POOL_REFRESH_MS = 15e3;
  const CONFIRM_ATTEMPTS = 6;
  const CONFIRM_WAIT_MS = 2e3;
  const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const explorerUrl = (digest) => `https://suivision.xyz/txblock/${encodeURIComponent(digest)}`;
  function openBackSheet(host) {
    const { called } = host;
    const side = backsYes(called);
    const wait = host.wait ?? pause;
    let pool = null;
    let poolFailed = false;
    let held = 0n;
    let balance = null;
    let balanceFailed = false;
    let connected = null;
    let failure = null;
    let chosen = CHIPS[0];
    let busy = false;
    let disposed = false;
    let finished = false;
    let digest = null;
    let refreshTimer = null;
    const form = el("div", "form");
    const outcome = el("div", "outcome");
    outcome.hidden = true;
    const sideRow = el("div", "back-side");
    sideRow.append(el("span", "field-label", "Your call"), el("span", "called-badge", called.side));
    const chipRow = el("div", "back-chips");
    const chipButtons = /* @__PURE__ */ new Map();
    for (const value of CHIPS) {
      const chip = button(`${value} SUI`, "button small back-chip", () => {
        chosen = value;
        custom.value = "";
        clearFailure();
        render();
      });
      chipButtons.set(value, chip);
      chipRow.append(chip);
    }
    const custom = el("input", "input back-custom");
    custom.type = "text";
    custom.inputMode = "decimal";
    custom.placeholder = "Other amount in SUI";
    custom.setAttribute("aria-label", "Other amount in SUI");
    custom.addEventListener("input", () => {
      chosen = custom.value;
      clearFailure();
      render();
    });
    const amountField = el("div", "field");
    amountField.append(el("span", "field-label", "How much?"), chipRow, custom);
    const estimate = el("p", "back-estimate");
    const fee = el("p", "note");
    const schedule = el("p", "note", "Results from ESPN, settled 2h15m after kickoff, 6h challenge window, then claim");
    const notice = el("p", "note back-notice", "Staking may be restricted where you live. Unaudited beta: stake only what you can lose.");
    const trust = externalLink("Who can do what", TRUST_DOC_URL, "link ext");
    form.append(sideRow, amountField, estimate, fee, schedule, notice, trust);
    const picker = el("div", "wallet-row wallet-picker");
    picker.hidden = true;
    const status = el("p", "line status-line");
    status.setAttribute("aria-live", "polite");
    const check = el("p", "note", "Check the amount in your wallet popup before approving.");
    const balanceNote = el("p", "note");
    const backButton = button("Back it", "button primary wide back-submit", () => void submit());
    const foot = el("div", "sheet-foot");
    foot.append(picker, check, balanceNote, status, backButton);
    const header = el("div", "sheet-head");
    header.append(
      button("‹ Back", "back", () => host.back()),
      el("h3", "sheet-title", "Back it")
    );
    const node = el("div", "sheet");
    node.append(header, form, outcome, foot);
    function setStatus(text, bad = false) {
      status.textContent = text;
      status.classList.toggle("bad", bad);
      host.layout();
    }
    const amount = () => parseSuiAmount(chosen);
    const buttonState = () => backButtonState({
      pool,
      poolFailed,
      amountMist: amount(),
      heldMist: held,
      balanceMist: balance,
      balanceFailed,
      walletConnected: connected !== null,
      nowMs: host.now?.() ?? Date.now()
    });
    function clearFailure() {
      if (digest === null) failure = null;
    }
    function render() {
      for (const [value, chip] of chipButtons) chip.classList.toggle("selected", value === chosen);
      const state = buttonState();
      const stake = amount();
      if (pool && stake !== null && state.enabled) {
        const { multiplier, payoutMist } = stakeEstimate(pool, side, stake, held);
        estimate.textContent = `Pays about ${multiplier.toFixed(2)}x right now. About ${formatSui(payoutMist, 4)} SUI back if your side wins. It moves as others stake.`;
      } else {
        estimate.textContent = "";
      }
      if (pool) fee.textContent = `Soothia takes a ${feePercent(pool.feeBps)} fee from the pot.`;
      balanceNote.textContent = state.note ?? "";
      if (!busy && failure === null) {
        setStatus(state.reason ?? "", state.reason !== null);
        backButton.textContent = state.label;
        backButton.disabled = !state.enabled;
      }
      host.layout();
    }
    async function loadPool() {
      const { fixture } = called;
      if (!fixture) return;
      const response = await host.api("/stake/pool", {
        fixture: { home: fixture.home, away: fixture.away, startISO: fixture.startISO },
        subject: fixture.subject
      });
      if (disposed) return;
      if (response.ok && response.body) {
        pool = response.body;
        poolFailed = false;
      } else if (!pool) {
        poolFailed = true;
      }
      render();
    }
    async function loadAccount(wallet) {
      connected = wallet;
      render();
      const [balanceResponse, positionsResponse] = await Promise.all([
        host.api("/stake/balance", { address: wallet.address }),
        host.api("/stake/positions", { address: wallet.address })
      ]);
      if (disposed) return;
      if (balanceResponse.ok && balanceResponse.body) {
        balance = BigInt(balanceResponse.body.balanceMist);
        balanceFailed = false;
      } else {
        balance = null;
        balanceFailed = true;
      }
      if (positionsResponse.ok && positionsResponse.body) {
        const found = positionsResponse.body.positions.find((position) => position.pickId === called.pickId);
        held = found ? BigInt(found.amountMist) : 0n;
      }
      render();
    }
    function chooseWallet(wallets) {
      return new Promise((resolve) => {
        picker.replaceChildren(
          ...wallets.map(
            (wallet) => button(wallet.name, "button small", () => {
              picker.hidden = true;
              picker.replaceChildren();
              resolve(wallet);
            })
          )
        );
        picker.hidden = false;
        setStatus("Choose a wallet.");
      });
    }
    function fail(text, retry) {
      busy = false;
      failure = { retry };
      setStatus(text, true);
      backButton.textContent = retry ? "Try again" : buttonState().label;
      backButton.disabled = !retry;
      custom.disabled = false;
      host.sound?.("softError");
      host.layout();
    }
    function setBusy(text) {
      busy = true;
      backButton.disabled = true;
      custom.disabled = true;
      setStatus(text);
    }
    function showDone(sent, stake) {
      finished = true;
      form.hidden = true;
      foot.hidden = true;
      outcome.hidden = false;
      outcome.classList.add("success");
      const line = el("p", "question", `Backed ${formatSui(stake)} SUI on ${called.side}. Proof: `);
      line.append(externalLink(`${sent.slice(0, 8)}…`, explorerUrl(sent), "link ext"));
      outcome.append(line, button("Done", "button wide", () => host.back()));
      host.layout();
      host.celebrate?.();
      host.sound?.("betPlaced");
    }
    async function confirm(sent, stake) {
      setBusy("Confirming on Sui…");
      for (let attempt = 1; ; attempt++) {
        const response = await host.api("/stake/confirm", { pickId: called.pickId, digest: sent });
        if (disposed) return;
        if (response.ok) {
          busy = false;
          setStatus("");
          showDone(sent, stake);
          return;
        }
        const notSeenYet = response.status === 404 && response.body?.error === "transaction_not_found";
        if (!notSeenYet || attempt >= CONFIRM_ATTEMPTS) break;
        await wait(CONFIRM_WAIT_MS);
        if (disposed) return;
      }
      fail("Your stake went through on Sui, but Soothia couldn't record it yet. Press Try again. You won't be charged twice.", true);
      const proof = externalLink("See it on Sui", explorerUrl(sent), "link ext");
      status.append(" ", proof);
      host.layout();
    }
    async function ensureWallet() {
      if (connected) return connected;
      const saved = await host.wallet.current();
      if (saved) {
        await loadAccount(saved);
        return saved;
      }
      setBusy("Connect your wallet…");
      const fresh = await host.wallet.connect(chooseWallet);
      if (fresh) await loadAccount(fresh);
      return fresh;
    }
    async function submit() {
      if (busy || finished) return;
      const stake = amount();
      if (digest !== null && stake !== null) {
        await confirm(digest, stake);
        return;
      }
      failure = null;
      if (!buttonState().enabled || stake === null) {
        render();
        return;
      }
      let wallet;
      try {
        wallet = await ensureWallet();
      } catch (error) {
        const { text, retry } = walletErrorText(String(error?.message ?? error));
        fail(text, retry);
        return;
      }
      if (disposed) return;
      if (!wallet) {
        fail("No wallet was connected.", true);
        return;
      }
      busy = false;
      if (!buttonState().enabled) {
        custom.disabled = false;
        render();
        return;
      }
      setBusy("Preparing your stake…");
      const response = await host.api("/stake/build", { pickId: called.pickId, amountMist: stake.toString(), sender: wallet.address });
      if (disposed) return;
      if (!response.ok || !response.body) {
        const { text, retry } = stakeErrorText(response.status, response.body);
        fail(text, retry);
        return;
      }
      const built = response.body;
      setBusy("Waiting for your wallet…");
      try {
        const signed = await host.wallet.sign(wallet, built.txBytes, {
          kind: "stake",
          // The pool we were shown, when there was one, so the Worker can't swap it.
          poolId: pool?.poolId ?? built.summary.poolId,
          side,
          amountMist: stake.toString()
        });
        digest = signed.digest;
      } catch (error) {
        if (disposed) return;
        const { text, retry } = walletErrorText(String(error?.message ?? error));
        fail(text, retry);
        return;
      }
      await confirm(digest, stake);
    }
    async function refresh() {
      if (busy || finished || digest !== null) return;
      await loadPool();
    }
    void (async () => {
      await loadPool();
      const wallet = await host.wallet.current();
      if (wallet && !disposed) await loadAccount(wallet);
    })().catch(() => void 0);
    refreshTimer = setInterval(() => void refresh(), POOL_REFRESH_MS);
    render();
    return {
      node,
      refresh() {
        void refresh();
      },
      dispose() {
        disposed = true;
        if (refreshTimer !== null) clearInterval(refreshTimer);
      },
      trigger: () => void submit()
    };
  }
  const MIN_PERCENT = 51;
  const MAX_PERCENT = 99;
  const DEFAULT_PERCENT = 60;
  function openCallSheet(host) {
    const { claim } = host.tile;
    const closed = claim.fromFixture === true && host.fixture === null;
    const { prefill } = host;
    let side = prefill?.side ?? "yes";
    let percent = prefill?.percent ?? DEFAULT_PERCENT;
    let bias = null;
    let busy = false;
    let disposed = false;
    let premiumOn = false;
    let premiumPrice = PREMIUM_PRICES[0];
    const form = el("div", "form");
    const outcome = el("div", "outcome");
    outcome.hidden = true;
    const sides = el("div", "sides");
    sides.setAttribute("role", "radiogroup");
    const sideButtons = /* @__PURE__ */ new Map();
    for (const kind of ["yes", "no"]) {
      const node2 = button("", `side side-${kind}`, () => {
        side = kind;
        render();
      });
      node2.setAttribute("role", "radio");
      node2.append(el("span", "side-label", kind.toUpperCase()));
      sideButtons.set(kind, node2);
      sides.append(node2);
    }
    const value = el("span", "call-value");
    const sliderHead = el("div", "call-slider-head");
    sliderHead.append(el("span", "field-label", "How sure are you?"), value);
    const slider = el("input", "call-slider");
    slider.type = "range";
    slider.min = String(MIN_PERCENT);
    slider.max = String(MAX_PERCENT);
    slider.step = "1";
    slider.value = String(percent);
    slider.setAttribute("aria-label", "How sure are you, in percent");
    slider.addEventListener("input", () => {
      percent = Number(slider.value);
      render();
    });
    const sliderField = el("div", "field");
    sliderField.append(sliderHead, slider);
    const nudgeText = el("p", "note");
    const useButton = button("", "link", () => {
      percent = suggestedPercent(percent, host.shrink);
      slider.value = String(percent);
      render();
    });
    const nudge = el("div", "call-nudge");
    nudge.append(nudgeText, useButton);
    nudge.hidden = host.shrink >= 1;
    if (prefill) form.append(el("p", "tail-label", `Tail of @${prefill.tailOf}`));
    form.append(el("p", "question", claim.question), sides);
    form.append(sliderField, nudge);
    const premiumField = el("div", "field premium-field");
    premiumField.hidden = true;
    const premiumToggle = el("input", "agent-check");
    premiumToggle.type = "checkbox";
    premiumToggle.setAttribute("aria-label", "Make it premium");
    const premiumLabel = el("label", "agent-switch");
    premiumLabel.append(premiumToggle, el("span", "", "Make it premium"));
    const priceRow = el("div", "premium-prices");
    const priceButtons = /* @__PURE__ */ new Map();
    for (const price of PREMIUM_PRICES) {
      const node2 = button(price, "button small premium-price", () => {
        premiumPrice = price;
        customPrice.value = "";
        render();
      });
      priceButtons.set(price, node2);
      priceRow.append(node2);
    }
    const customPrice = el("input", "input premium-custom");
    customPrice.type = "text";
    customPrice.inputMode = "decimal";
    customPrice.placeholder = "Custom, up to 0.5";
    customPrice.setAttribute("aria-label", "Custom price in SUI, up to 0.5");
    customPrice.addEventListener("input", () => render());
    priceRow.append(customPrice);
    const premiumNote = el("p", "note", "Hidden until kickoff. You keep 90%.");
    const premiumChoices = el("div", "premium-choices");
    premiumChoices.append(priceRow, premiumNote);
    premiumField.append(premiumLabel, premiumChoices);
    premiumToggle.addEventListener("change", () => {
      premiumOn = premiumToggle.checked;
      render();
    });
    form.append(premiumField);
    function chosenPrice() {
      return parsePremiumPrice(customPrice.value.trim() || premiumPrice);
    }
    const status = el("p", "line status-line");
    status.setAttribute("aria-live", "polite");
    const lockButton = button("Lock my call", "button buy wide", () => void lock());
    const foot = el("div", "sheet-foot");
    foot.append(status, lockButton);
    const header = el("div", "sheet-head");
    header.append(
      button("‹ Back", "back", () => host.back()),
      el("h3", "sheet-title", "Call it")
    );
    const node = el("div", "sheet");
    node.append(header, form, outcome, foot);
    function setStatus(text) {
      status.textContent = text;
      host.layout();
    }
    function render() {
      for (const [kind, sideNode] of sideButtons) {
        sideNode.classList.toggle("selected", kind === side);
        sideNode.setAttribute("aria-checked", String(kind === side));
      }
      lockButton.dataset.side = side;
      premiumChoices.hidden = !premiumOn;
      for (const [price, priceNode] of priceButtons) priceNode.classList.toggle("selected", customPrice.value.trim() === "" && price === premiumPrice);
      const badPrice = premiumOn && chosenPrice() === null;
      premiumNote.textContent = badPrice ? "Prices run from 0.01 to 0.5 SUI." : "Hidden until kickoff. You keep 90%.";
      if (!busy && !closed) lockButton.disabled = badPrice;
      value.textContent = `${side.toUpperCase()} ${percent}%`;
      if (host.shrink < 1) {
        const suggested = suggestedPercent(percent, host.shrink);
        nudgeText.textContent = `You run ${overconfidencePoints(host.shrink, bias)} points overconfident. Soothia suggests ${suggested}%.`;
        useButton.textContent = `Use ${suggested}%`;
        useButton.hidden = suggested === percent;
      }
      host.layout();
    }
    function showSaved(pick) {
      form.hidden = true;
      outcome.hidden = false;
      outcome.classList.add("success");
      if (pick.commit) {
        outcome.append(
          el("p", "question", "Locked on Sui · remembered on Walrus"),
          externalLink("See the proof on Sui", `https://suivision.xyz/txblock/${encodeURIComponent(pick.commit.digest)}`, "link ext")
        );
      } else if (pick.commitSkipped) {
        outcome.append(el("p", "question", `Saved to Walrus. Sui proof skipped (${skipReasonText(pick.commitSkipped)}).`));
      } else {
        outcome.append(el("p", "question", "Saved to Walrus. The Sui proof didn't go through this time."));
      }
      if (pick.premium) outcome.append(el("p", "note", `${premiumLine(pick.premium.priceMist)}. Hidden until kickoff.`));
      if (host.offerBack && pick.commit && !pick.premium) {
        const called = calledFromPick(pick);
        outcome.append(button("Back it", "button primary wide", () => host.offerBack?.(called)));
      }
      outcome.append(button("Done", "button wide", () => host.back()));
      host.layout();
    }
    async function lock() {
      if (busy || closed) return;
      const premiumMist = premiumOn ? chosenPrice() : void 0;
      if (premiumMist === null) return;
      busy = true;
      lockButton.disabled = true;
      setStatus("Locking your call…");
      const response = await host.api("/recall/pick", callBody(host.tile, side, percent, host.page, host.fixture, prefill ? { tailOf: prefill.tailOf, flip: side !== prefill.side } : void 0, premiumMist));
      busy = false;
      if (response.ok && response.body) {
        const pick = response.body;
        host.locked(pick);
        if (disposed) return;
        status.textContent = "";
        showSaved(pick);
        if (pick.commit) host.celebrate?.();
        host.sound?.("betPlaced");
        return;
      }
      if (disposed) return;
      const { text, retry } = callErrorMessage(response.status, response.body);
      setStatus(text);
      lockButton.textContent = retry ? "Try again" : "Lock my call";
      lockButton.disabled = !retry;
      host.sound?.("softError");
    }
    if (closed) {
      lockButton.disabled = true;
      status.textContent = "This match has started, so calls are closed.";
    }
    if (!closed && !prefill && claim.fromFixture && host.fixture) {
      void host.api("/premium/eligible", {}).then((response) => {
        if (disposed || !response.ok || !response.body?.eligible) return;
        premiumField.hidden = false;
        render();
      }).catch(() => void 0);
    }
    if (host.shrink < 1) {
      void host.calibrationBias().then((found) => {
        if (disposed) return;
        bias = found;
        render();
      }).catch(() => void 0);
    }
    render();
    return {
      node,
      refresh() {
      },
      dispose() {
        disposed = true;
      },
      trigger: () => void lock()
    };
  }
  const MONTHS = [
    "january",
    "february",
    "march",
    "april",
    "may",
    "june",
    "july",
    "august",
    "september",
    "october",
    "november",
    "december"
  ];
  const MONTH_RE = "jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?";
  const TEAM = "[\\p{L}\\p{N}][\\p{L}\\p{N} .'&-]{0,38}?[\\p{L}\\p{N}.]";
  const STOP = "live|h2h|preview|prediction|predictions|team news|match|score|scores|odds|table|line-?ups?|stats|highlights|tickets";
  const TITLE_RE = new RegExp(
    `^(${TEAM})\\s+(?:vs?\\.?|versus|[-–—])\\s+(${TEAM})(?=\\s*(?:$|[|:–—,(]|\\s-\\s|\\s(?:${STOP})\\b))`,
    "iu"
  );
  const STARTED_RE = /\b(FT|HT|AET|Pens?|Full[- ]Time|Half[- ]Time|Postponed|Abandoned|Cancelled|Live now|LIVE)\b|\b\d{1,3}'\s*(?:\+\d+)?\b/;
  const SCORE_RE = /(?:^|\s)\d{1,2}\s*[-–]\s*\d{1,2}(?=\s|$)|(?:^|\s)\d{1,2}:\d(?!\d)/;
  const KNOWN_COMPETITIONS = [
    "Premier League",
    "LaLiga",
    "La Liga",
    "Bundesliga",
    "Serie A",
    "Ligue 1",
    "Champions League",
    "Europa League",
    "Conference League",
    "Eredivisie",
    "Primeira Liga",
    "Scottish Premiership",
    "Championship",
    "FA Cup",
    "Copa del Rey",
    "DFB-Pokal",
    "Coppa Italia",
    "MLS",
    "World Cup",
    "Euro 2028",
    "Nations League",
    "Copa America",
    "NBA",
    "NFL",
    "NHL",
    "MLB",
    "ATP",
    "WTA",
    "Wimbledon",
    "US Open",
    "UFC"
  ];
  function monthFromName(name) {
    const key = name.toLowerCase().slice(0, 3);
    return MONTHS.findIndex((month) => month.startsWith(key));
  }
  function dateLabelFor(date) {
    const month = MONTHS[date.getMonth()];
    return `${month[0].toUpperCase()}${month.slice(1)} ${date.getDate()}, ${date.getFullYear()}`;
  }
  function cleanTeam(text) {
    return text.replace(/\s+/g, " ").replace(/^[\s\-–—|:]+|[\s\-–—|:]+$/g, "").trim();
  }
  function sidesFromTitle(title) {
    const text = title.replace(/\s+/g, " ").trim();
    const match = TITLE_RE.exec(text);
    if (!match) return null;
    const home = cleanTeam(match[1]);
    const away = cleanTeam(match[2]);
    if (!home || !away || home.toLowerCase() === away.toLowerCase()) return null;
    if (home.split(" ").length > 5 || away.split(" ").length > 5) return null;
    return { home, away, evidence: text.slice(0, 160) };
  }
  function resolveKickoff(text, nowMs) {
    const now = new Date(nowMs);
    const source = text.replace(/\s+/g, " ");
    const time = /\b([01]?\d|2[0-3]):([0-5]\d)\s*(am|pm|AM|PM)?\b/.exec(source);
    if (!time) return null;
    let hours = Number(time[1]);
    const minutes = Number(time[2]);
    if (time[3]) {
      const pm = time[3].toLowerCase() === "pm";
      if (pm && hours < 12) hours += 12;
      if (!pm && hours === 12) hours = 0;
    }
    let day = null;
    let month = null;
    let year = null;
    let dateText = "";
    const dayFirst = new RegExp(`(?<![\\d-])\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+(${MONTH_RE})\\.?(?:\\s+(\\d{4}))?\\b`, "i").exec(
      source
    );
    const monthFirst = new RegExp(`\\b(${MONTH_RE})\\.?\\s+(\\d{1,2})(?:st|nd|rd|th)?(?:,?\\s+(\\d{4}))?\\b`, "i").exec(
      source
    );
    const iso = /\b(\d{4})-(\d{2})-(\d{2})\b/.exec(source);
    if (iso) {
      year = Number(iso[1]);
      month = Number(iso[2]) - 1;
      day = Number(iso[3]);
      dateText = iso[0];
    } else if (dayFirst) {
      day = Number(dayFirst[1]);
      month = monthFromName(dayFirst[2]);
      year = dayFirst[3] ? Number(dayFirst[3]) : null;
      dateText = dayFirst[0];
    } else if (monthFirst) {
      month = monthFromName(monthFirst[1]);
      day = Number(monthFirst[2]);
      year = monthFirst[3] ? Number(monthFirst[3]) : null;
      dateText = monthFirst[0];
    } else if (/\btomorrow\b/i.test(source)) {
      const t = new Date(nowMs + 864e5);
      day = t.getDate();
      month = t.getMonth();
      year = t.getFullYear();
      dateText = "Tomorrow";
    } else if (/\btoday\b/i.test(source)) {
      day = now.getDate();
      month = now.getMonth();
      year = now.getFullYear();
      dateText = "Today";
    }
    if (day === null || month === null || month < 0) return null;
    let date = new Date(year ?? now.getFullYear(), month, day, hours, minutes, 0, 0);
    if (year === null && date.getTime() < nowMs - 864e5)
      date = new Date(now.getFullYear() + 1, month, day, hours, minutes, 0, 0);
    if (Number.isNaN(date.getTime())) return null;
    return { date, evidence: `${dateText} ${time[0]}`.trim() };
  }
  function looksStartedOrFinished(headerText) {
    const text = headerText.replace(/\s+/g, " ");
    return STARTED_RE.test(text) || SCORE_RE.test(text);
  }
  function competitionIn(text, url) {
    const haystack = `${text} ${decodeURIComponent(url).replace(/[-_/]/g, " ")}`;
    for (const name of KNOWN_COMPETITIONS) {
      if (new RegExp(`\\b${name.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&")}\\b`, "i").test(haystack)) return name;
    }
    return void 0;
  }
  const nameOf = (value) => (typeof value === "string" ? value : value?.name ?? "").trim();
  function fixtureFromJsonLd(blocks, nowMs, url) {
    const events = [];
    const collect = (node) => {
      if (!node || typeof node !== "object") return;
      if (Array.isArray(node)) return node.forEach(collect);
      const item = node;
      const type = Array.isArray(item["@type"]) ? item["@type"].join(" ") : item["@type"] ?? "";
      if (/SportsEvent|\bEvent\b/.test(type)) events.push(item);
      if (item["@graph"]) collect(item["@graph"]);
    };
    for (const block of blocks) {
      try {
        collect(JSON.parse(block));
      } catch {
      }
    }
    for (const event of events) {
      if (event.eventStatus && !/Scheduled/i.test(event.eventStatus)) continue;
      let home = nameOf(event.homeTeam);
      let away = nameOf(event.awayTeam);
      if ((!home || !away) && event.competitor?.length === 2) {
        home = nameOf(event.competitor[0]);
        away = nameOf(event.competitor[1]);
      }
      if ((!home || !away) && event.name) {
        const sides = sidesFromTitle(event.name);
        if (sides) ({ home, away } = sides);
      }
      if (!home || !away || !event.startDate) continue;
      const start = new Date(event.startDate);
      if (Number.isNaN(start.getTime()) || start.getTime() <= nowMs) continue;
      const evidence = [event.name ?? `${home} vs ${away}`, `startDate ${event.startDate}`];
      const competition = nameOf(event.superEvent) || competitionIn(`${event.name ?? ""}`, url);
      if (competition) evidence.push(competition);
      return {
        home,
        away,
        competition,
        startISO: start.toISOString(),
        dateLabel: dateLabelFor(start),
        sourceUrl: url,
        evidence
      };
    }
    return null;
  }
  function fixtureFromSignals(signals, nowMs) {
    const fromLd = fixtureFromJsonLd(signals.jsonLd, nowMs, signals.url);
    if (fromLd) return fromLd;
    for (const title of signals.titles) {
      const sides = sidesFromTitle(title);
      if (!sides) continue;
      const header = signals.headerText;
      if (looksStartedOrFinished(signals.statusText ?? header)) return null;
      const kickoff = resolveKickoff(header, nowMs);
      if (!kickoff || kickoff.date.getTime() <= nowMs) return null;
      const competition = competitionIn(`${title} ${header}`, signals.url);
      const evidence = [sides.evidence, kickoff.evidence];
      if (competition) evidence.push(competition);
      return {
        home: sides.home,
        away: sides.away,
        competition,
        startISO: kickoff.date.toISOString(),
        dateLabel: dateLabelFor(kickoff.date),
        sourceUrl: signals.url,
        evidence
      };
    }
    return null;
  }
  const MAX_HEADER_CHARS = 700;
  const MAX_HEADER_TRIES = 12;
  const NOT_TEXT = /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE)$/;
  const visibleText = (element) => (element.innerText ?? element.textContent ?? "").replace(/\s+/g, " ");
  function matchHeaderText(doc, sides, nowMs) {
    if (!doc.body) return null;
    const home = sides.home.toLowerCase();
    const away = sides.away.toLowerCase();
    const walker = doc.createTreeWalker(
      doc.body,
      4
      /* NodeFilter.SHOW_TEXT */
    );
    let tries = 0;
    for (let node = walker.nextNode(); node && tries < MAX_HEADER_TRIES; node = walker.nextNode()) {
      const parent = node.parentElement;
      if (!parent || NOT_TEXT.test(parent.tagName) || !(node.nodeValue ?? "").toLowerCase().includes(home)) continue;
      tries += 1;
      for (let block = parent; block && block !== doc.body; block = block.parentElement) {
        if (block.checkVisibility?.() === false) continue;
        const text = visibleText(block);
        if (text.length > MAX_HEADER_CHARS) break;
        const all = (block.textContent ?? "").toLowerCase();
        if (all.includes(home) && all.includes(away) && (resolveKickoff(text, nowMs) !== null || looksStartedOrFinished(text))) return text;
      }
    }
    return null;
  }
  function findFixture(doc, nowMs) {
    const jsonLd = [...doc.querySelectorAll('script[type="application/ld+json"]')].map((node) => node.textContent ?? "");
    const titles = [
      doc.querySelector('meta[property="og:title"]')?.content ?? "",
      ...[...doc.querySelectorAll("h1")].map((h) => h.textContent ?? ""),
      doc.title
    ].filter(Boolean);
    const sides = titles.map(sidesFromTitle).find(Boolean) ?? null;
    const body = (doc.body?.innerText ?? "").replace(/\s+/g, " ");
    let headerText = "";
    let statusText;
    const ownHeader = sides ? matchHeaderText(doc, sides, nowMs) : null;
    if (ownHeader) {
      headerText = ownHeader;
      statusText = ownHeader;
    } else if (sides) {
      const lower = body.toLowerCase();
      const at = lower.indexOf(sides.home.toLowerCase());
      const other = lower.indexOf(sides.away.toLowerCase(), at >= 0 ? at : 0);
      const end = at >= 0 && other >= 0 && other - at < 400 ? other + sides.away.length + 120 : at + 260;
      if (at >= 0) {
        headerText = body.slice(Math.max(0, at - 60), end);
        statusText = body.slice(at, end);
      }
    }
    const timeNode = doc.querySelector("time[datetime]");
    if (timeNode?.dateTime && !/\d{4}-\d{2}-\d{2}/.test(headerText)) headerText = `${timeNode.dateTime} ${headerText}`;
    return fixtureFromSignals({ jsonLd, titles, headerText, statusText, url: doc.location.href.split("#")[0] }, nowMs);
  }
  function describeFixture(fixture) {
    return [`${fixture.home} vs ${fixture.away}`, fixture.evidence[1] ?? fixture.dateLabel, fixture.competition].filter(Boolean).join(" · ");
  }
  let reportIssue = () => {
  };
  let contextDead = false;
  function isContextDead() {
    return contextDead;
  }
  function describe(error) {
    if (error instanceof Error) return `${error.name}: ${error.message}`.slice(0, 200);
    return String(error).slice(0, 200);
  }
  function noteIfDead(error) {
    if (/context invalidated|Extension context/i.test(describe(error))) contextDead = true;
  }
  function safe(label, fn) {
    try {
      const result = fn();
      if (result instanceof Promise) {
        return result.catch((error) => {
          noteIfDead(error);
          reportIssue(`${label}: ${describe(error)}`);
          return void 0;
        });
      }
      return result;
    } catch (error) {
      noteIfDead(error);
      reportIssue(`${label}: ${describe(error)}`);
      return void 0;
    }
  }
  function guarded(label, fn) {
    return (...args) => {
      safe(label, () => fn(...args));
    };
  }
  function ours(text) {
    let id = "";
    try {
      id = chrome.runtime.id;
    } catch {
    }
    return id !== "" && text.includes(id) || /soothia/i.test(text);
  }
  function installGuards(report) {
    reportIssue = report;
    window.addEventListener("error", (event) => {
      const where = `${event.filename ?? ""} ${event.error?.stack ?? ""}`;
      if (!ours(where)) return;
      event.preventDefault();
      noteIfDead(event.error);
      reportIssue(`error: ${describe(event.error ?? event.message)}`);
    });
    window.addEventListener("unhandledrejection", (event) => {
      const reason = event.reason;
      const where = `${reason?.stack ?? ""} ${describe(reason)}`;
      if (!ours(where) && !/context invalidated|Receiving end does not exist|message port closed/i.test(where)) return;
      event.preventDefault();
      noteIfDead(reason);
      reportIssue(`rejection: ${describe(reason)}`);
    });
  }
  function createStakeRow(host, called) {
    const node = el("div", "stake-row");
    node.hidden = true;
    const line = el("p", "stake-line");
    const action = button("Back it", "button small stake-back", () => host.onBack(called));
    node.append(line, action);
    let seq = 0;
    async function heldMist() {
      const wallet = await host.wallet.current();
      if (!wallet) return 0n;
      const response = await host.api("/stake/positions", { address: wallet.address });
      if (!response.ok || !response.body) return 0n;
      const found = response.body.positions.find((position) => position.pickId === called.pickId);
      return found ? BigInt(found.amountMist) : 0n;
    }
    async function refresh() {
      const current = ++seq;
      const { fixture } = called;
      if (!fixture) return;
      const [response, held] = await Promise.all([
        host.api("/stake/pool", { fixture: { home: fixture.home, away: fixture.away, startISO: fixture.startISO }, subject: fixture.subject }),
        heldMist().catch(() => 0n)
      ]);
      if (current !== seq) return;
      const pool = response.ok ? response.body : null;
      if (!pool || !poolIsOpenForStakes(pool, host.now?.() ?? Date.now())) {
        node.hidden = true;
        host.layout();
        return;
      }
      const side = backsYes(called);
      line.textContent = held > 0n ? backedLine(pool, side, held) : poolLine(pool, side, called.side);
      action.textContent = held > 0n ? "Top up" : "Back it";
      action.hidden = held > 0n && !canTopUp(pool.limits, held);
      node.hidden = false;
      host.layout();
    }
    return { node, refresh };
  }
  const WALLET_CHANNEL = "soothia:v1:wallet";
  const BRIDGE_READY_ID = "ready";
  function envelope(event, win, nonce, direction) {
    if (event.source !== win || event.origin !== win.location.origin) return null;
    const data = event.data;
    if (typeof data !== "object" || data === null) return null;
    if (data.channel !== WALLET_CHANNEL || data.direction !== direction || data.nonce !== nonce || typeof data.id !== "string") return null;
    return data;
  }
  function acceptResponse(event, win, nonce) {
    const data = envelope(event, win, nonce, "response");
    if (!data || typeof data.ok !== "boolean") return null;
    return data;
  }
  const READY_TIMEOUT_MS = 5e3;
  const LIST_TIMEOUT_MS = 5e3;
  const APPROVAL_TIMEOUT_MS = 18e4;
  const timeoutFor = (method) => method === "connect" || method === "signAndExecute" || method === "signPersonalMessage" || method === "signTransaction" ? APPROVAL_TIMEOUT_MS : LIST_TIMEOUT_MS;
  function createWalletBridge(scriptUrl, win = window, doc = document) {
    const nonce = crypto.randomUUID();
    const pending2 = /* @__PURE__ */ new Map();
    let starting = null;
    let onReady = null;
    let nextId = 0;
    win.addEventListener("message", (event) => {
      const response = acceptResponse(event, win, nonce);
      if (!response) return;
      if (response.id === BRIDGE_READY_ID) {
        onReady?.();
        return;
      }
      const waiter = pending2.get(response.id);
      if (!waiter) return;
      pending2.delete(response.id);
      if (response.ok) waiter.resolve(response.result);
      else waiter.reject(new Error(response.error ?? "The wallet did not respond."));
    });
    function start() {
      starting ??= new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          starting = null;
          reject(new Error("The wallet connection could not start on this page."));
        }, READY_TIMEOUT_MS);
        onReady = () => {
          clearTimeout(timer);
          resolve();
        };
        const script = doc.createElement("script");
        script.src = scriptUrl();
        script.dataset.soothiaNonce = nonce;
        (doc.head ?? doc.documentElement).append(script);
      });
      return starting;
    }
    return {
      async call(method, params = {}) {
        await start();
        const id = `w${++nextId}`;
        const request = { channel: WALLET_CHANNEL, direction: "request", nonce, id, method, params };
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            pending2.delete(id);
            reject(new Error("The wallet did not respond in time."));
          }, timeoutFor(method));
          pending2.set(id, {
            resolve: (value) => {
              clearTimeout(timer);
              resolve(value);
            },
            reject: (error) => {
              clearTimeout(timer);
              reject(error);
            }
          });
          win.postMessage(request, win.location.origin);
        });
      }
    };
  }
  function isOwnershipMessage(message2, address) {
    return typeof message2 === "string" && message2.length < 400 && message2.startsWith("Soothia: confirm you own this wallet.\n") && message2.includes(`
Address: ${address.toLowerCase()}
`);
  }
  const checkInBackground = (txBytes, expected) => chrome.runtime.sendMessage({ type: CHECK_TX, txBytes, expected });
  async function signOnlyChecked(bridge, check, wallet, txBytes, expected) {
    const verdict = await check(txBytes, expected);
    if (!verdict?.ok) throw new Error(verdict?.reason ?? "The transaction could not be checked.");
    const signed = await bridge.call("signTransaction", { walletId: wallet.walletId, address: wallet.address, txBytes });
    const after = await check(signed.bytes, expected);
    if (!after?.ok) throw new Error(after?.reason ?? "The signed transaction could not be checked.");
    return signed;
  }
  async function signChecked(bridge, check, wallet, txBytes, expected) {
    const verdict = await check(txBytes, expected);
    if (!verdict?.ok) throw new Error(verdict?.reason ?? "The transaction could not be checked.");
    return await bridge.call("signAndExecute", { walletId: wallet.walletId, address: wallet.address, txBytes });
  }
  const shortAddress = (address) => `${address.slice(0, 6)}…${address.slice(-4)}`;
  function isConnectedWallet(value) {
    const wallet = value;
    return typeof wallet?.address === "string" && typeof wallet.walletId === "string" && typeof wallet.walletName === "string";
  }
  const chromeWalletStorage = {
    read: async () => (await chrome.storage.local.get(SUI_WALLET_KEY))[SUI_WALLET_KEY],
    write: (wallet) => chrome.storage.local.set({ [SUI_WALLET_KEY]: wallet }),
    clear: () => chrome.storage.local.remove(SUI_WALLET_KEY)
  };
  const problem = (error) => String(error?.message ?? error).slice(0, 120);
  function createWalletSettings(bridge, storage, onLayout = () => {
  }) {
    const root = el("div", "field wallet-field");
    const status = el("p", "wallet-note");
    const actions = el("div", "wallet-row");
    const picker = el("div", "wallet-row wallet-picker");
    picker.hidden = true;
    let connected = null;
    function show(text) {
      status.textContent = text;
      onLayout();
    }
    function hidePicker() {
      picker.hidden = true;
      picker.replaceChildren();
    }
    async function chooseWallet(use) {
      hidePicker();
      let wallets;
      try {
        wallets = await bridge.call("list");
      } catch (error) {
        show(problem(error));
        return;
      }
      if (wallets.length === 0) {
        show("No Sui wallet found in this browser.");
        return;
      }
      if (wallets.length === 1) {
        await use(wallets[0]);
        return;
      }
      picker.replaceChildren(
        ...wallets.map(
          (wallet) => button(wallet.name, "button small", () => {
            hidePicker();
            void use(wallet);
          })
        )
      );
      picker.hidden = false;
      show("Choose a wallet.");
    }
    async function connectAndSave(wallet) {
      show(`Approve in ${wallet.name}…`);
      try {
        const { address, walletName } = await bridge.call("connect", { walletId: wallet.id });
        connected = { address, walletId: wallet.id, walletName };
        await storage.write(connected);
        render();
      } catch (error) {
        show(problem(error));
      }
    }
    async function testWallet(wallet) {
      show(`Approve in ${wallet.name}…`);
      try {
        const { address } = await bridge.call("connect", { walletId: wallet.id });
        show(`Test wallet: ${address}`);
      } catch (error) {
        show(problem(error));
      }
    }
    async function disconnect() {
      const leaving = connected;
      connected = null;
      await storage.clear();
      render();
      if (leaving) await bridge.call("disconnect", { walletId: leaving.walletId }).catch(() => void 0);
    }
    const connectButton = button("Connect Sui wallet", "button small", () => void chooseWallet(connectAndSave));
    const disconnectButton = button("Disconnect", "button small", () => void disconnect());
    const testButton = button("Test wallet", "button small", () => void chooseWallet(testWallet));
    testButton.hidden = true;
    actions.append(connectButton, disconnectButton, testButton);
    root.append(el("span", "field-label", "Sui wallet"), actions, picker, status);
    function render() {
      hidePicker();
      connectButton.hidden = connected !== null;
      disconnectButton.hidden = connected === null;
      show(connected ? `Connected to ${connected.walletName}: ${shortAddress(connected.address)}` : "");
    }
    return {
      root,
      async load() {
        const saved = await storage.read().catch(() => null);
        connected = isConnectedWallet(saved) ? saved : null;
        render();
      },
      setDebugVisible(visible) {
        testButton.hidden = !visible;
      }
    };
  }
  function createWalletAccess(bridge, storage, check) {
    return {
      async current() {
        const saved = await storage.read().catch(() => null);
        return isConnectedWallet(saved) ? saved : null;
      },
      async connect(choose) {
        const wallets = await bridge.call("list");
        if (wallets.length === 0) throw new Error("No Sui wallet found in this browser. Install Slush and reload this page.");
        const wallet = wallets.length === 1 ? wallets[0] : await choose(wallets);
        if (!wallet) return null;
        const { address, walletName } = await bridge.call("connect", { walletId: wallet.id });
        const connected = { address, walletId: wallet.id, walletName };
        await storage.write(connected);
        return connected;
      },
      sign: (wallet, txBytes, expected) => signChecked(bridge, check, wallet, txBytes, expected),
      signOnly: (wallet, txBytes, expected) => signOnlyChecked(bridge, check, wallet, txBytes, expected),
      async signMessage(wallet, message2) {
        if (!isOwnershipMessage(message2, wallet.address)) throw new Error("Soothia refused to sign an unexpected message.");
        return await bridge.call("signPersonalMessage", { walletId: wallet.walletId, address: wallet.address, message: message2 });
      }
    };
  }
  const HOST_ID = "soothia-host";
  const POSITION_KEY = "soothia:orbPosition";
  const DRAG_THRESHOLD = 4;
  const SHOW_DEBUG_KEY = "soothia:showDebug";
  const MUTED_KEY = "soothia:muted";
  const STYLE_KEY = "soothia:sfxStyle";
  const QUIET_SITES_KEY = "soothia.quietSites";
  const QUIET_PENDING_KEY = "soothia.quietPending";
  const BUBBLE_KEY = "soothia:bubbleShown";
  const BUBBLE_DELAY_MS = 1500;
  const SETTLE_MS = 600;
  const THIN_WATCH_MS = 8e3;
  const THIN_DEBOUNCE_MS = 400;
  const THIN_RETRIES = 1;
  const MIN_THINKING_MS = 600;
  function currentUrl() {
    return location.href.split("#")[0];
  }
  function viewport() {
    return {
      width: document.documentElement.clientWidth || window.innerWidth,
      height: window.innerHeight
    };
  }
  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), Math.max(min, max));
  }
  async function loadPosition() {
    const fallback = { right: ORB_MARGIN, bottom: ORB_MARGIN };
    try {
      const stored = (await chrome.storage.local.get(POSITION_KEY))[POSITION_KEY];
      if (typeof stored?.right === "number" && typeof stored?.bottom === "number") {
        return { right: stored.right, bottom: stored.bottom };
      }
    } catch {
    }
    return fallback;
  }
  function savePosition(position) {
    chrome.storage.local.set({ [POSITION_KEY]: position }).catch(() => {
    });
  }
  function tileNode({ claim }, insight, onCall, proofHost, stakeRow, followed) {
    const tile = el("div", "tile");
    const meta = el("div", "meta");
    const ends = endDate(claim.endTime);
    meta.append(el("span", "chip", claim.category), el("span", "ends", ends ? `Ends ${ends}` : ""));
    const source = claim.fromFixture ? (() => {
      const line = el("p", "quote from-match");
      line.append(el("span", "from-match-label", "From match info"), ` · ${claim.sourceQuote}`);
      return line;
    })() : el("p", "quote", `“${claim.sourceQuote}”`);
    tile.append(el("p", "question", claim.question), meta, source);
    if (insight?.called) {
      tile.append(calledRow(insight.called, proofHost));
      if (stakeRow) tile.append(stakeRow);
    } else {
      const recall = el("div", "tile-recall");
      recall.append(button("Call it", "button primary call-it", onCall));
      tile.append(recall);
    }
    if (followed) tile.append(followed);
    const notes = visibleNotes(insight);
    if (notes.length > 0) {
      const list = el("div", "tile-notes");
      list.append(...notes.map((note) => el("p", "tile-note", note)));
      tile.append(list);
    }
    return tile;
  }
  function statusRow() {
    const row = el("div", "status");
    const label = el("span", "label");
    row.append(el("span", "dot"), label);
    return {
      row,
      set(text, state) {
        label.textContent = text;
        row.dataset.state = state;
      }
    };
  }
  async function mount() {
    if (document.getElementById(HOST_ID)) return;
    const host = document.createElement("div");
    host.id = HOST_ID;
    for (const [property, value] of Object.entries(HOST_STYLES)) {
      host.style.setProperty(property, value, "important");
    }
    const shadow = host.attachShadow({ mode: "closed" });
    const style2 = document.createElement("style");
    style2.textContent = STYLES;
    const orb = el("button", "orb");
    orb.type = "button";
    orb.setAttribute("aria-label", "Soothia");
    orb.setAttribute("aria-expanded", "false");
    orb.dataset.state = "idle";
    const orbBody = el("span", "orb-body");
    orbBody.append(el("span", "orb-shimmer"));
    const orbStars = el("span", "orb-stars");
    const orbBadge = el("span", "orb-badge");
    orbBadge.hidden = true;
    orb.append(orbBody, starSvg("orb-glint"), el("span", "orb-arc"), orbStars, el("span", "orb-pulse"), orbBadge);
    function pageIsLight() {
      for (const node of [document.body, document.documentElement]) {
        const match = /rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([\d.]+))?/.exec(
          getComputedStyle(node).backgroundColor
        );
        if (!match || match[4] !== void 0 && Number(match[4]) === 0) continue;
        const [r, g, b] = [Number(match[1]), Number(match[2]), Number(match[3])];
        return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 > 0.6;
      }
      return true;
    }
    function applyTheme() {
      host.dataset.theme = pageIsLight() ? "light" : "dark";
    }
    const card = el("div", "card");
    card.hidden = true;
    card.setAttribute("role", "dialog");
    card.setAttribute("aria-label", "Soothia");
    const cardStars = el("div", "card-stars");
    cardStars.setAttribute("aria-hidden", "true");
    for (let i = 0; i < 6; i++) cardStars.append(starSvg("card-star"));
    card.append(cardStars);
    const proxyRow = statusRow();
    const body = el("div", "body");
    const recordPane = el("div", "body");
    recordPane.hidden = true;
    const socialPane = el("div", "body");
    socialPane.hidden = true;
    const socialView = createSocialView(socialPane, { api, layout, state: stateBlock, onTail: (handle, source) => openSocialTail(handle, source), unlock: unlockCall, runAgent });
    const recordView = createRecordView(recordPane, {
      api,
      layout,
      get wallet() {
        return walletAccess;
      },
      agent: agentRequest,
      linkRecord: () => recallFieldNode(),
      loadSection: async () => (await chrome.storage.local.get(RECORD_SECTION_KEY))[RECORD_SECTION_KEY],
      saveSection: (section2) => {
        chrome.storage.local.set({ [RECORD_SECTION_KEY]: section2 }).catch(() => {
        });
      },
      state: stateBlock,
      quietSites: () => quietSites,
      unquiet: async (site) => {
        const done = await setSiteQuiet(site, false);
        if (done && site === hereSite()) resumeAfterQuiet();
        return done;
      }
    });
    const tabs = el("div", "tabs");
    tabs.setAttribute("role", "tablist");
    const claimsTab = button("This page", "tab selected", () => showTab("claims"));
    const recordTab = button("My record", "tab", () => showTab("record"));
    const socialTab = button("Social", "tab", () => showTab("social"));
    for (const tab of [claimsTab, recordTab, socialTab]) tab.setAttribute("role", "tab");
    tabs.append(claimsTab, recordTab, socialTab);
    function showTab(which) {
      closeSocialSheet();
      body.hidden = which !== "claims";
      recordPane.hidden = which !== "record";
      socialPane.hidden = which !== "social";
      for (const [name, tab] of [
        ["claims", claimsTab],
        ["record", recordTab],
        ["social", socialTab]
      ]) {
        tab.classList.toggle("selected", which === name);
        tab.setAttribute("aria-selected", String(which === name));
      }
      if (which === "record") void safe("record", recordView.render);
      if (which === "social") {
        markSocialSeen();
        void safe("social", socialView.render);
      }
      layout();
    }
    const debug = el("details", "debug");
    const scanInfo = el("dl", "scan");
    const scanAgain = el("button", "button small", "Scan again");
    scanAgain.type = "button";
    function toggle(label) {
      const row = el("label", "toggle");
      const box = el("input", "toggle-box");
      box.type = "checkbox";
      row.append(box, el("span", "toggle-label", label));
      return { row, box };
    }
    const replayRow = el("div", "replay");
    replayRow.append(
      button("Show welcome again", "link mono", () => {
        chrome.runtime.sendMessage({ type: OPEN_WELCOME }).catch(() => {
        });
      }),
      button("Reset first-run bubble", "link mono", () => {
        chrome.storage.local.remove(BUBBLE_KEY).catch(() => {
        });
      })
    );
    const showDebugToggle = toggle("Show debug info");
    let linkedRecallId = "";
    const linkedInputs = /* @__PURE__ */ new Set();
    function recallFieldNode() {
      const input = el("input", "input recall-input");
      input.type = "text";
      input.placeholder = "Recall ID";
      input.spellcheck = false;
      input.autocomplete = "off";
      input.value = linkedRecallId;
      linkedInputs.add(input);
      const note = el("p", "note");
      async function save(value) {
        if (value && !isRecallId(value)) {
          note.textContent = "That isn't a valid Recall ID.";
          layout();
          return;
        }
        try {
          if (value) await chrome.storage.local.set({ [RECALL_ID_KEY]: value });
          else await chrome.storage.local.remove(RECALL_ID_KEY);
        } catch {
          note.textContent = "Couldn't save that. Reload this tab and try again.";
          layout();
          return;
        }
        setLinkedRecallId(value);
        note.textContent = value ? "Record linked." : "Record unlinked.";
        onRecallIdentityChanged();
        layout();
      }
      const row = el("div", "recall-row");
      row.append(input, button("Save", "button small", () => void save(input.value.trim())), button("Clear", "button small", () => void save("")));
      const field = el("div", "field recall-field");
      field.append(el("span", "field-label", "Link record"), row, note);
      return field;
    }
    function setLinkedRecallId(value) {
      linkedRecallId = value;
      for (const input of linkedInputs) {
        if (input.isConnected) input.value = value;
        else linkedInputs.delete(input);
      }
    }
    const recallField = recallFieldNode();
    const walletBridge = createWalletBridge(() => chrome.runtime.getURL("wallet-bridge.js"));
    const walletAccess = createWalletAccess(walletBridge, chromeWalletStorage, checkInBackground);
    const walletSettings = createWalletSettings(
      walletBridge,
      chromeWalletStorage,
      () => {
        if (!card.hidden) layout();
      }
    );
    const summary = el("summary", "debug-summary", "settings");
    summary.append(el("span", "debug-version", extensionVersion()));
    debug.append(
      summary,
      scanInfo,
      scanAgain,
      showDebugToggle.row,
      recallField,
      walletSettings.root,
      replayRow,
      proxyRow.row
    );
    function applyDebugVisibility() {
      const show = showDebugToggle.box.checked;
      scanInfo.hidden = !show;
      walletSettings.setDebugVisible(show);
      if (!card.hidden) layout();
    }
    applyDebugVisibility();
    const head = el("div", "card-head");
    const brand = el("div", "brand");
    const mark = el("span", "mark");
    mark.append(el("span", "mark-body"), starSvg("star"));
    brand.append(mark, el("h2", "wordmark", "Soothia"));
    const close = button("", "close", () => setOpen(false));
    close.setAttribute("aria-label", "Close");
    close.append(icon("close"));
    const muteButton = button("", "close mute", () => void toggleMute());
    function renderMute() {
      const label = isMuted() ? "Unmute sounds" : "Mute sounds";
      muteButton.setAttribute("aria-label", label);
      muteButton.title = label;
      muteButton.replaceChildren(icon(isMuted() ? "muted" : "sound"));
    }
    async function toggleMute() {
      setMuted(!isMuted());
      renderMute();
      chrome.storage.local.set({ [MUTED_KEY]: isMuted() }).catch(() => {
      });
    }
    const headActions = el("div", "head-actions");
    const quietButton = button("", "close quiet", () => void quietHere());
    quietButton.setAttribute("aria-label", "Quiet here");
    quietButton.title = "Quiet here";
    quietButton.append(icon("quiet"));
    headActions.append(quietButton, muteButton, close);
    head.append(brand, headActions);
    function sound(name) {
      playSound(name);
    }
    armSounds(shadow);
    armSounds(window);
    card.append(head, tabs, body, recordPane, socialPane, debug);
    for (const type of ["keydown", "keypress", "keyup"]) {
      card.addEventListener(type, (event) => event.stopPropagation());
    }
    const bubble = el("div", "bubble");
    bubble.setAttribute("role", "status");
    bubble.hidden = true;
    const bubbleClose = button("", "bubble-close", () => dismissBubble());
    bubbleClose.setAttribute("aria-label", "Dismiss");
    bubbleClose.append(icon("close"));
    bubble.append(
      el("p", "bubble-text", "I'll glow when I spot something you can call. Click me anytime."),
      bubbleClose
    );
    let bubbleTimer;
    function dismissBubble() {
      clearTimeout(bubbleTimer);
      if (bubble.hidden) return;
      bubble.hidden = true;
      chrome.storage.local.set({ [BUBBLE_KEY]: true }).catch(() => {
      });
    }
    async function maybeShowBubble() {
      try {
        if ((await chrome.storage.local.get(BUBBLE_KEY))[BUBBLE_KEY] === true) return;
      } catch {
        return;
      }
      bubbleTimer = setTimeout(() => {
        if (!card.hidden) return;
        bubble.hidden = false;
        layout();
      }, BUBBLE_DELAY_MS);
    }
    shadow.append(style2, orb, card, bubble);
    let position = await loadPosition();
    function layout() {
      const { width, height } = viewport();
      position = {
        right: clamp(position.right, 0, width - ORB_SIZE),
        bottom: clamp(position.bottom, 0, height - ORB_SIZE)
      };
      const orbLeft = width - position.right - ORB_SIZE;
      const orbTop = height - position.bottom - ORB_SIZE;
      orb.style.left = `${orbLeft}px`;
      orb.style.top = `${orbTop}px`;
      if (!bubble.hidden) {
        const bubbleWidth = Math.min(240, width - EDGE_PADDING * 2);
        bubble.style.width = `${bubbleWidth}px`;
        const bubbleHeight = bubble.offsetHeight;
        let bubbleLeft = orbLeft - CARD_GAP - bubbleWidth;
        let bubbleTop = orbTop + ORB_SIZE / 2 - bubbleHeight / 2;
        bubble.dataset.side = "left";
        if (bubbleLeft < EDGE_PADDING) {
          bubbleLeft = clamp(orbLeft + ORB_SIZE - bubbleWidth, EDGE_PADDING, width - bubbleWidth - EDGE_PADDING);
          bubbleTop = orbTop - CARD_GAP - bubbleHeight;
          bubble.dataset.side = "above";
          if (bubbleTop < EDGE_PADDING) {
            bubbleTop = orbTop + ORB_SIZE + CARD_GAP;
            bubble.dataset.side = "below";
          }
        }
        bubble.style.left = `${bubbleLeft}px`;
        bubble.style.top = `${clamp(bubbleTop, EDGE_PADDING, height - bubbleHeight - EDGE_PADDING)}px`;
      }
      if (card.hidden) return;
      const cardWidth = Math.min(CARD_WIDTH, width - EDGE_PADDING * 2);
      const cardHeight = card.offsetHeight;
      let left = orbLeft - CARD_GAP - cardWidth;
      if (left < EDGE_PADDING) left = orbLeft + ORB_SIZE + CARD_GAP;
      left = clamp(left, EDGE_PADDING, width - cardWidth - EDGE_PADDING);
      let top = orbTop + ORB_SIZE - cardHeight;
      if (top < EDGE_PADDING) top = orbTop;
      top = clamp(top, EDGE_PADDING, height - cardHeight - EDGE_PADDING);
      card.style.left = `${left}px`;
      card.style.top = `${top}px`;
    }
    async function refreshProxy() {
      proxyRow.set("Proxy: checking…", "idle");
      let online = false;
      try {
        const response = await chrome.runtime.sendMessage({ type: HEALTH_REQUEST });
        online = response?.online === true;
      } catch {
        online = false;
      }
      proxyRow.set(online ? "Proxy: online" : "Proxy: offline", online ? "good" : "bad");
    }
    let foundSoundUrl = "";
    function setOrb(state, count = 0) {
      const was = orb.dataset.state;
      orb.dataset.state = state;
      if (state === "found" && was !== "found" && foundSoundUrl !== watchedUrl) {
        foundSoundUrl = watchedUrl;
        sound("found");
      }
      if (state !== "found") orbStars.replaceChildren();
      else if (was !== "found" || orbStars.childElementCount !== Math.min(count, 3)) {
        orbStars.replaceChildren(...Array.from({ length: Math.min(Math.max(count, 1), 3) }, () => starSvg("star")));
      }
      orb.setAttribute("aria-label", state === "found" ? `Soothia, ${count} found` : "Soothia");
    }
    function pulseOrb() {
      orb.classList.remove("success");
      void orb.offsetWidth;
      orb.classList.add("success");
      setTimeout(() => orb.classList.remove("success"), 1300);
    }
    function stateBlock(kind, text, ...extra) {
      const block = el("div", `state ${kind}`);
      block.append(el("span", "state-orb"), el("p", "state-text", text), ...extra);
      return block;
    }
    function rescanButton() {
      return button("Scan again", "button", rescan);
    }
    let tiles = [];
    let sheet = null;
    let stakeRows = [];
    function closeSheet() {
      sheet?.dispose();
      sheet = null;
      body.classList.remove("has-sheet");
    }
    function showTiles() {
      closeSheet();
      setOrb("found", tiles.length);
      const staking = stakeTileIds(tiles, (claimId) => insightsByClaim.get(claimId)?.called, Date.now());
      stakeRows = [];
      let followedShown = false;
      body.replaceChildren(
        ...tiles.map((tile) => {
          const insight = insightsByClaim.get(tile.claim.id);
          let row;
          if (insight?.called && staking.has(tile.claim.id)) {
            const stakeRow = createStakeRow({ api, wallet: walletAccess, layout, onBack: (called) => openBack(called) }, insight.called);
            stakeRows.push(stakeRow);
            row = stakeRow.node;
          }
          let followed;
          if (!followedShown && insight?.followedCalls?.length) {
            followedShown = true;
            followed = followedRow(insight.followedCalls, insight.consensus ?? null, insight.called ? null : (call) => openPageTail(call), layout, unlockCall);
          }
          return tileNode(tile, insight, () => openCall(tile), { api, layout }, row, followed);
        })
      );
      if (!card.hidden) refreshStakeRows();
      layout();
    }
    function refreshStakeRows() {
      for (const row of stakeRows) void safe("stake row", row.refresh);
    }
    function openBack(called) {
      closeSheet();
      showTab("claims");
      sheet = openBackSheet({ called, api, wallet: walletAccess, layout, back: showTiles, celebrate: pulseOrb, sound });
      body.classList.add("has-sheet");
      body.replaceChildren(sheet.node);
      layout();
    }
    async function unlockCall(pickId, priceMist, choose) {
      const wallet = await walletAccess.current() ?? await walletAccess.connect(choose);
      if (!wallet) return { ok: false, code: "wallet", walletMessage: "No wallet was connected.", maybePaid: false };
      return runUnlock({
        expectedPriceMist: priceMist,
        fetchCall: (payment) => chrome.runtime.sendMessage({ type: PREMIUM_CALL, pickId, payment }),
        build: async () => {
          const built = await api("/premium/build", { pickId, sender: wallet.address });
          if (!built.ok || !built.body) throw new Error(built.body?.error ?? "unavailable");
          return built.body.transaction;
        },
        sign: (txBytes, expected) => walletAccess.signOnly(wallet, txBytes, expected)
      });
    }
    function agentRequest(action, settings) {
      return chrome.runtime.sendMessage({ type: AGENT_REQUEST, action, settings }).catch(() => null);
    }
    async function runAgent() {
      return (await agentRequest("run"))?.unlocked.length ?? 0;
    }
    function openPageTail(call) {
      const { tile, prefill } = tailSheetFor(call.handle, call);
      openCall(tile, { prefill, offerBack: (called) => openBack(called) });
    }
    let socialSheet = null;
    function closeSocialSheet() {
      socialSheet?.dispose();
      socialSheet = null;
      socialPane.classList.remove("has-sheet");
    }
    function showInSocial(next) {
      closeSocialSheet();
      socialSheet = next;
      socialPane.classList.add("has-sheet");
      socialPane.replaceChildren(next.node);
      layout();
    }
    function backToSocial() {
      closeSocialSheet();
      void safe("social", socialView.render);
    }
    function openSocialTail(handle, source) {
      const { tile, fixture, prefill } = tailSheetFor(handle, source);
      showInSocial(
        openCallSheet({
          tile,
          page: { site: "soothia.fun", url: fixture.sourceUrl },
          fixture,
          shrink: recallShrink,
          calibrationBias,
          api,
          layout,
          back: backToSocial,
          locked: () => void 0,
          celebrate: pulseOrb,
          sound,
          prefill,
          offerBack: (called) => showInSocial(openBackSheet({ called, api, wallet: walletAccess, layout, back: backToSocial, celebrate: pulseOrb, sound }))
        })
      );
    }
    function openCall(tile, tail) {
      closeSheet();
      showTab("claims");
      sheet = openCallSheet({
        tile,
        page: { site: hereSite(), url: watchedUrl },
        fixture: pageFixture,
        shrink: recallShrink,
        calibrationBias,
        api,
        layout,
        back: showTiles,
        locked: (pick) => {
          const called = calledFromPick(pick);
          const settled = tile.claim.fromFixture ? tiles.filter((item) => item.claim.fromFixture) : [tile];
          for (const { claim } of settled) {
            const known = insightsByClaim.get(claim.id);
            insightsByClaim.set(claim.id, {
              claimId: claim.id,
              relevance: known?.relevance ?? 0,
              notes: known?.notes ?? [],
              nudge: known?.nudge ?? 0,
              called
            });
          }
        },
        celebrate: pulseOrb,
        sound,
        ...tail ?? {}
      });
      body.classList.add("has-sheet");
      body.replaceChildren(sheet.node);
      layout();
    }
    let pageFixture = null;
    let calibrationBiasCache;
    function hereSite() {
      return location.hostname.replace(/^www\./, "").toLowerCase();
    }
    async function calibrationBias() {
      if (calibrationBiasCache !== void 0) return calibrationBiasCache;
      const response = await api("/recall/record", {});
      if (!response.ok || !response.body) return null;
      const lesson = response.body.lessons.find((item) => item.key === "calibration");
      calibrationBiasCache = lesson?.bias ?? null;
      return calibrationBiasCache;
    }
    let insightsByClaim = /* @__PURE__ */ new Map();
    let recallShrink = 1;
    let insightSeq = 0;
    async function loadInsights() {
      const seq = ++insightSeq;
      const claims = tiles.slice(0, 3).map(({ claim }) => ({
        id: claim.id,
        question: claim.question,
        category: claim.category,
        ...claim.fromFixture && pageFixture ? { fixture: { home: pageFixture.home, away: pageFixture.away, startISO: pageFixture.startISO } } : {}
      }));
      if (claims.length === 0) return;
      const response = await api("/recall/insights", { claims });
      if (seq !== insightSeq || !response.ok || !response.body) return;
      const result = response.body;
      if (!Array.isArray(result.insights)) return;
      insightsByClaim = new Map(result.insights.map((insight) => [insight.claimId, insight]));
      pageFollowed = pageFollowedCount(result.insights.map((insight) => insight.followedCalls));
      renderBadge();
      recallShrink = typeof result.shrink === "number" ? result.shrink : 1;
      if (Array.isArray(result.quietSites)) applyQuietSites(result.quietSites);
      tiles = sortByRelevance(tiles, insightsByClaim);
      if (!sheet) showTiles();
    }
    let quietSites = [];
    let quietPending = {};
    function isQuietHere() {
      return quietSites.includes(hereSite());
    }
    function renderQuietButton() {
      quietButton.hidden = !isQuietableSite(hereSite()) || isQuietHere();
    }
    function applyQuietSites(list) {
      const merged = mergeQuietSites(list, quietPending, Date.now());
      quietSites = merged.sites;
      quietPending = merged.pending;
      chrome.storage.local.set({ [QUIET_SITES_KEY]: quietSites, [QUIET_PENDING_KEY]: quietPending }).catch(() => {
      });
      renderQuietButton();
    }
    async function setSiteQuiet(site, quiet) {
      const response = await api("/recall/pref", { kind: quiet ? "quiet_site" : "unquiet_site", site });
      if (!response.ok) return false;
      quietPending = { ...quietPending, [site]: { quiet, at: Date.now() } };
      applyQuietSites(quietSites);
      return true;
    }
    async function quietHere() {
      quietButton.disabled = true;
      const done = await setSiteQuiet(hereSite(), true);
      quietButton.disabled = false;
      if (!done) {
        sound("softError");
        if (!sheet) body.prepend(el("p", "warn", "Couldn't quiet this site just now."));
        layout();
        return;
      }
      clearTimeout(detectTimer);
      stopWatchingForText();
      insightSeq++;
      tiles = [];
      render({ kind: "quiet" });
      showTab("claims");
    }
    function resumeAfterQuiet() {
      render({ kind: "watching" });
      scheduleDetect();
    }
    async function showCallsHere() {
      if (await setSiteQuiet(hereSite(), false)) {
        resumeAfterQuiet();
        return;
      }
      sound("softError");
      body.replaceChildren(
        stateBlock(
          "error",
          "Couldn't change that just now.",
          button("Try again", "button", () => void showCallsHere())
        )
      );
      layout();
    }
    async function api(path, payload) {
      try {
        const message2 = { type: API_REQUEST, path, body: payload };
        const response = await chrome.runtime.sendMessage(message2);
        return response ?? { ok: false, status: 0, body: null };
      } catch {
        return { ok: false, status: 0, body: null };
      }
    }
    let pageFollowed = 0;
    let newFeedItems = 0;
    function renderBadge() {
      const text = badgeText(pageFollowed + newFeedItems);
      orbBadge.hidden = text === null;
      orbBadge.textContent = text ?? "";
    }
    function markSocialSeen() {
      const now = Date.now();
      newFeedItems = 0;
      renderBadge();
      chrome.storage.local.set({ [SOCIAL_SEEN_KEY]: now, [FEED_CHECK_KEY]: { at: now, seen: now, count: 0 } }).catch(() => {
      });
    }
    async function refreshFeedBadge() {
      const stored = await chrome.storage.local.get([SOCIAL_SEEN_KEY, FEED_CHECK_KEY]);
      const now = Date.now();
      const savedSeen = stored[SOCIAL_SEEN_KEY];
      if (typeof savedSeen !== "number") {
        await chrome.storage.local.set({ [SOCIAL_SEEN_KEY]: now });
        return;
      }
      const cached = cachedFeedCount(stored[FEED_CHECK_KEY], savedSeen, now);
      let count = cached;
      if (count === null) {
        const response = await api("/social/feed/new", { since: savedSeen });
        if (!response.ok || !response.body) return;
        count = response.body.count;
        await chrome.storage.local.set({ [FEED_CHECK_KEY]: { at: now, seen: savedSeen, count } });
      }
      newFeedItems = count;
      renderBadge();
    }
    function render(view) {
      closeSheet();
      if (view.kind !== "tiles") {
        pageFollowed = 0;
        renderBadge();
      }
      switch (view.kind) {
        case "watching":
          setOrb("idle");
          body.replaceChildren(stateBlock("watching", "I'm watching this page."));
          break;
        case "thinking":
          setOrb("thinking");
          body.replaceChildren(stateBlock("watching", "Reading this page…"));
          break;
        case "tiles":
          tiles = view.tiles;
          insightsByClaim = /* @__PURE__ */ new Map();
          showTiles();
          void safe("insights", loadInsights);
          break;
        case "empty":
          setOrb("idle");
          body.replaceChildren(stateBlock("empty", "Nothing to call here."));
          break;
        case "quiet":
          setOrb("idle");
          body.replaceChildren(
            stateBlock(
              "skipped",
              `Soothia is quiet on ${hereSite()}.`,
              button("Show calls here again", "button", () => void showCallsHere())
            )
          );
          break;
        case "skipped":
          setOrb("idle");
          body.replaceChildren(stateBlock("skipped", "Not enough to read on this page."));
          break;
        case "error":
          setOrb("idle");
          sound("softError");
          if (view.reason === "limit") {
            body.replaceChildren(stateBlock("error", "That's all my calls for today. I'll be back tomorrow."));
          } else if (view.reason === "updated") {
            body.replaceChildren(stateBlock("error", "Soothia was updated. Reload this tab to keep going."));
          } else {
            body.replaceChildren(stateBlock("error", "I couldn't read this one just now.", rescanButton()));
          }
          break;
      }
      layout();
    }
    let scan = { read: null, state: "waiting for the page to settle", detect: null };
    function renderDebug() {
      const rows = [
        ["version", extensionVersion()],
        ["site", scan.read?.site ?? location.hostname.replace(/^www\./, "")],
        ["extracted", scan.read ? `${scan.read.chars} chars` : "–"],
        ["text", scan.read?.preview || "–"],
        ["path", scan.path ?? "–"],
        ...scan.fixture ? [["fixture", scan.fixture]] : [],
        ["detect", scan.state]
      ];
      const audio = getAudioState();
      rows.push(["audio", `${audio.muted ? "muted" : audio.context} · ${audio.last}`]);
      for (const issue of issues) rows.push(["issue", issue]);
      const detect = scan.detect;
      if (detect) {
        const worker = detect.cache ?? "–";
        rows.push(
          ["http", detect.httpStatus === null ? "no response" : String(detect.httpStatus)],
          ["cache", detect.fromClientCache ? `client 10-min rule (worker said ${worker})` : worker],
          ["claims", `${detect.claimsReturned} returned, ${detect.dropped.length} dropped`]
        );
        for (const dropped of detect.dropped) {
          rows.push(["dropped", `${dropped.reason}: ${dropped.question || "(no question)"}`]);
        }
      }
      scanInfo.replaceChildren(
        ...rows.flatMap(([name, value]) => [el("dt", "scan-name", name), el("dd", "scan-value", value)])
      );
      if (!card.hidden) layout();
    }
    function setScan(update) {
      scan = { ...scan, ...update };
      renderDebug();
      emitScanEvent();
    }
    const issues = [];
    function logIssue(text) {
      issues.push(`${(/* @__PURE__ */ new Date()).toISOString().slice(11, 19)} ${text}`);
      if (issues.length > 3) issues.shift();
      renderDebug();
    }
    installGuards(logIssue);
    function extensionVersion() {
      try {
        return chrome.runtime.getManifest().version;
      } catch {
        return "unknown";
      }
    }
    let devEvents = false;
    const scanStarted = Date.now();
    function emitScanEvent(extra = {}) {
      if (!devEvents) return;
      try {
        window.postMessage(
          {
            type: "soothia:v1:scan",
            state: scan.state,
            chars: scan.read?.chars ?? 0,
            site: scan.read?.site ?? "",
            elapsedMs: Date.now() - scanStarted,
            issues: [...issues],
            ...extra
          },
          "*"
        );
      } catch {
      }
    }
    onAudioState(() => renderDebug());
    function onRecallIdentityChanged() {
      insightsByClaim = /* @__PURE__ */ new Map();
      recallShrink = 1;
      calibrationBiasCache = void 0;
      if (!recordPane.hidden) void safe("record", recordView.render);
      if (tiles.length > 0) {
        if (!sheet) showTiles();
        void safe("insights", loadInsights);
      }
    }
    async function loadSettings() {
      try {
        const stored = await chrome.storage.local.get([
          MUTED_KEY,
          STYLE_KEY,
          SHOW_DEBUG_KEY,
          RECALL_ID_KEY,
          QUIET_SITES_KEY,
          QUIET_PENDING_KEY,
          "soothia:devEvents"
        ]);
        setLinkedRecallId(isRecallId(stored[RECALL_ID_KEY]) ? stored[RECALL_ID_KEY] : "");
        const savedQuiet = stored[QUIET_SITES_KEY];
        quietSites = Array.isArray(savedQuiet) ? savedQuiet.filter((site) => typeof site === "string") : [];
        const savedPending = stored[QUIET_PENDING_KEY];
        quietPending = typeof savedPending === "object" && savedPending !== null ? savedPending : {};
        devEvents = stored["soothia:devEvents"] === true;
        showDebugToggle.box.checked = stored[SHOW_DEBUG_KEY] === true;
        setMuted(stored[MUTED_KEY] === true);
        const saved = stored[STYLE_KEY];
        if (typeof saved === "string" && [...SYNTH_STYLES, "files"].includes(saved)) setStyle(saved);
      } catch {
      }
      applyDebugVisibility();
      renderMute();
      renderQuietButton();
    }
    showDebugToggle.box.addEventListener("change", () => {
      chrome.storage.local.set({ [SHOW_DEBUG_KEY]: showDebugToggle.box.checked }).catch(() => {
      });
      applyDebugVisibility();
    });
    let watchedUrl = currentUrl();
    let detectTimer;
    let thinObserver = null;
    let thinTimer;
    let thinDeadline;
    function stopWatchingForText() {
      thinObserver?.disconnect();
      thinObserver = null;
      clearTimeout(thinTimer);
      clearTimeout(thinDeadline);
    }
    function watchForText(url, reason, refresh) {
      stopWatchingForText();
      setScan({ state: `waiting for text (${reason})` });
      render({ kind: "thinking" });
      const finish = () => {
        stopWatchingForText();
        void safe("detect", () => runDetect(url, 0, refresh, true));
      };
      const peek = () => {
        if (url !== watchedUrl) return stopWatchingForText();
        const look = safe("read page", readPage);
        if (!look || look.kind === "thin") {
          if (look) setScan({ state: `waiting for text (${look.reason})` });
          return;
        }
        finish();
      };
      try {
        thinObserver = new MutationObserver(
          guarded("observer", () => {
            clearTimeout(thinTimer);
            thinTimer = setTimeout(peek, THIN_DEBOUNCE_MS);
          })
        );
        thinObserver.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
      } catch {
        thinObserver = null;
      }
      thinDeadline = setTimeout(finish, THIN_WATCH_MS);
    }
    async function runDetect(url, retriesLeft, refresh, lastLook = false) {
      if (url !== watchedUrl) return;
      if (isContextDead()) {
        render({ kind: "error", reason: "updated" });
        return;
      }
      render({ kind: "thinking" });
      const read = safe("read page", readPage);
      if (!read) {
        setScan({ state: "error (could not read the page)", detect: null });
        render({ kind: "error", reason: "unavailable" });
        return;
      }
      if (read.kind === "thin" && !lastLook && retriesLeft > 0) {
        setScan({ read: read.info });
        watchForText(url, read.reason, refresh);
        return;
      }
      if (read.kind === "thin" && !lastLook) {
        watchForText(url, read.reason, refresh);
        return;
      }
      const fixture = read.kind === "skip" ? null : safe("fixture", () => findFixture(document, Date.now())) ?? null;
      pageFixture = fixture;
      if (read.kind !== "page" && !fixture) {
        setScan({ read: read.info, state: `skipped (${read.reason})`, detect: null, path: "none" });
        render({ kind: "skipped" });
        emitScanEvent({ done: "skipped", path: "none" });
        return;
      }
      const page = read.kind === "page" ? read.page : {
        url: watchedUrl.split("#")[0],
        site: location.hostname.replace(/^www\./, ""),
        title: document.title.slice(0, 300),
        text: fixture ? fixture.evidence.join("\n") : ""
      };
      const fixtureNote = fixture ? describeFixture(fixture) : "";
      setScan({
        read: read.kind === "page" ? read.info : { site: page.site, chars: page.text.length, preview: fixtureNote.slice(0, 80) },
        state: refresh ? "running (scan again)" : "running",
        detect: null,
        path: fixture && read.kind !== "page" ? "fixture" : "prose",
        fixture: fixtureNote
      });
      const started = Date.now();
      let result;
      let relayError = "";
      try {
        const message2 = { type: DETECT_REQUEST, page, refresh, ...fixture ? { fixture } : {} };
        result = await chrome.runtime.sendMessage(message2);
        if (!result) relayError = "background gave no answer";
      } catch (error) {
        relayError = /context invalidated/i.test(String(error?.message)) ? "extension updated; reload this tab" : "background unreachable; reload this tab";
      }
      const remaining = MIN_THINKING_MS - (Date.now() - started);
      if (remaining > 0) await new Promise((resolve) => setTimeout(resolve, remaining));
      if (url !== watchedUrl) return;
      if (!refresh && isQuietHere()) return;
      if (!result) {
        setScan({ state: `error (${relayError})`, detect: null });
        render({ kind: "error", reason: isContextDead() ? "updated" : "unavailable" });
        emitScanEvent({ done: "error" });
      } else if (result.status === "error") {
        setScan({ state: `error (${result.reason})`, detect: result.debug });
        render({ kind: "error", reason: result.reason });
        emitScanEvent({ done: "error" });
      } else {
        const path = result.debug.path ?? (fixture && read.kind !== "page" ? "fixture" : "prose");
        setScan({ state: "done", detect: result.debug, path: result.tiles.length === 0 ? "none" : path });
        if (result.tiles.length === 0) render({ kind: "empty" });
        else render({ kind: "tiles", tiles: result.tiles.slice(0, 3) });
        emitScanEvent({
          done: "ok",
          path,
          tiles: result.tiles.slice(0, 3).map((tile) => tile.claim.question),
          cached: result.debug.fromClientCache
        });
      }
    }
    function rescan() {
      clearTimeout(detectTimer);
      stopWatchingForText();
      void safe("detect", () => runDetect(watchedUrl, THIN_RETRIES, true));
    }
    scanAgain.addEventListener("click", rescan);
    function scheduleDetect() {
      clearTimeout(detectTimer);
      stopWatchingForText();
      if (isQuietHere()) {
        render({ kind: "quiet" });
        return;
      }
      const url = watchedUrl;
      detectTimer = setTimeout(() => void safe("detect", () => runDetect(url, THIN_RETRIES, false)), SETTLE_MS);
    }
    function onUrlMaybeChanged() {
      const url = currentUrl();
      if (url === watchedUrl) return;
      watchedUrl = url;
      setScan({ read: null, state: "waiting for the page to settle", detect: null });
      render({ kind: "watching" });
      scheduleDetect();
    }
    window.addEventListener("popstate", onUrlMaybeChanged);
    window.addEventListener("message", (event) => {
      if (event.source !== window || event.origin !== window.location.origin) return;
      if (event.data?.type === NAV_CHANGED) onUrlMaybeChanged();
    });
    debug.addEventListener("toggle", layout);
    function setOpen(open) {
      card.hidden = !open;
      orb.setAttribute("aria-expanded", String(open));
      if (!open) return;
      sound("open");
      dismissBubble();
      void refreshProxy();
      sheet?.refresh();
      if (!sheet) refreshStakeRows();
      layout();
    }
    document.addEventListener(
      "keydown",
      (event) => {
        if (event.key === "Escape" && !card.hidden) setOpen(false);
      },
      true
    );
    document.addEventListener(
      "pointerdown",
      (event) => {
        if (!card.hidden && event.target !== host) setOpen(false);
      },
      true
    );
    let drag = null;
    let suppressClick = false;
    orb.addEventListener("pointerdown", (event) => {
      if (event.button !== 0) return;
      drag = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        origin: position,
        moved: false
      };
      orb.setPointerCapture(event.pointerId);
    });
    orb.addEventListener("pointermove", (event) => {
      if (!drag || event.pointerId !== drag.pointerId) return;
      const dx = event.clientX - drag.startX;
      const dy = event.clientY - drag.startY;
      if (!drag.moved && Math.hypot(dx, dy) < DRAG_THRESHOLD) return;
      drag.moved = true;
      orb.classList.add("dragging");
      position = { right: drag.origin.right - dx, bottom: drag.origin.bottom - dy };
      layout();
    });
    function endDrag(event) {
      if (!drag || event.pointerId !== drag.pointerId) return;
      if (drag.moved) {
        suppressClick = true;
        setTimeout(() => suppressClick = false, 0);
        savePosition(position);
      }
      orb.classList.remove("dragging");
      drag = null;
    }
    orb.addEventListener("pointerup", endDrag);
    orb.addEventListener("pointercancel", endDrag);
    orb.addEventListener("click", () => {
      if (suppressClick) {
        suppressClick = false;
        return;
      }
      setOpen(card.hidden);
    });
    window.addEventListener("resize", layout);
    proxyRow.set("Proxy: checking…", "idle");
    loadFonts();
    applyTheme();
    setTimeout(applyTheme, 1500);
    renderDebug();
    await safe("settings", loadSettings);
    await safe("wallet", walletSettings.load);
    void safe("feed badge", refreshFeedBadge);
    setInterval(guarded("feed badge", () => void safe("feed badge", refreshFeedBadge)), FEED_CHECK_MS);
    chrome.storage.onChanged.addListener(
      guarded("wallet change", (changes) => {
        if (SUI_WALLET_KEY in changes) void safe("wallet", walletSettings.load);
      })
    );
    void safe("bubble", maybeShowBubble);
    render({ kind: "watching" });
    document.documentElement.append(host);
    if (document.readyState !== "loading") scheduleDetect();
    else document.addEventListener("DOMContentLoaded", guarded("start", scheduleDetect), { once: true });
  }
  if (window.top === window) {
    mount().catch(() => {
    });
  }
})();
