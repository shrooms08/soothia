(function() {
  "use strict";
  const WALLET_STATUS = "soothia:v1:wallet-status";
  const WALLET_REQUEST = "soothia:v1:wallet-request";
  const WALLET_RPC_REQUEST = "soothia:v1:wallet-rpc";
  const WALLET_RPC_RESPONSE = "soothia:v1:wallet-rpc-result";
  var __classPrivateFieldGet = function(receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
  };
  var __classPrivateFieldSet = function(receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
  };
  var _AppReadyEvent_detail;
  let wallets = void 0;
  const registeredWalletsSet = /* @__PURE__ */ new Set();
  function addRegisteredWallet(wallet) {
    cachedWalletsArray = void 0;
    registeredWalletsSet.add(wallet);
  }
  function removeRegisteredWallet(wallet) {
    cachedWalletsArray = void 0;
    registeredWalletsSet.delete(wallet);
  }
  const listeners$1 = {};
  function getWallets() {
    if (wallets)
      return wallets;
    wallets = Object.freeze({ register, get, on });
    if (typeof window === "undefined")
      return wallets;
    const api = Object.freeze({ register });
    try {
      window.addEventListener("wallet-standard:register-wallet", ({ detail: callback }) => callback(api));
    } catch (error) {
      console.error("wallet-standard:register-wallet event listener could not be added\n", error);
    }
    try {
      window.dispatchEvent(new AppReadyEvent(api));
    } catch (error) {
      console.error("wallet-standard:app-ready event could not be dispatched\n", error);
    }
    return wallets;
  }
  function register(...wallets2) {
    wallets2 = wallets2.filter((wallet) => !registeredWalletsSet.has(wallet));
    if (!wallets2.length)
      return () => {
      };
    wallets2.forEach((wallet) => addRegisteredWallet(wallet));
    listeners$1["register"]?.forEach((listener) => guard(() => listener(...wallets2)));
    return function unregister() {
      wallets2.forEach((wallet) => removeRegisteredWallet(wallet));
      listeners$1["unregister"]?.forEach((listener) => guard(() => listener(...wallets2)));
    };
  }
  let cachedWalletsArray;
  function get() {
    if (!cachedWalletsArray) {
      cachedWalletsArray = [...registeredWalletsSet];
    }
    return cachedWalletsArray;
  }
  function on(event, listener) {
    listeners$1[event]?.push(listener) || (listeners$1[event] = [listener]);
    return function off() {
      listeners$1[event] = listeners$1[event]?.filter((existingListener) => listener !== existingListener);
    };
  }
  function guard(callback) {
    try {
      callback();
    } catch (error) {
      console.error(error);
    }
  }
  class AppReadyEvent extends Event {
    get detail() {
      return __classPrivateFieldGet(this, _AppReadyEvent_detail, "f");
    }
    get type() {
      return "wallet-standard:app-ready";
    }
    constructor(api) {
      super("wallet-standard:app-ready", {
        bubbles: false,
        cancelable: false,
        composed: false
      });
      _AppReadyEvent_detail.set(this, void 0);
      __classPrivateFieldSet(this, _AppReadyEvent_detail, api, "f");
    }
    /** @deprecated */
    preventDefault() {
      throw new Error("preventDefault cannot be called");
    }
    /** @deprecated */
    stopImmediatePropagation() {
      throw new Error("stopImmediatePropagation cannot be called");
    }
    /** @deprecated */
    stopPropagation() {
      throw new Error("stopPropagation cannot be called");
    }
  }
  _AppReadyEvent_detail = /* @__PURE__ */ new WeakMap();
  const SOLANA_MAINNET = "solana:mainnet";
  const CONNECT = "standard:connect";
  const DISCONNECT = "standard:disconnect";
  const EVENTS = "standard:events";
  const SIGN = "solana:signTransaction";
  class WalletError extends Error {
    constructor(reason, message = reason) {
      super(message);
      this.reason = reason;
    }
    reason;
  }
  const LEGACY_PROVIDERS = [
    {
      name: "Phantom",
      find: () => {
        const w = window;
        return w.phantom?.solana ?? (w.solana?.isPhantom ? w.solana : null);
      }
    },
    {
      name: "Solflare",
      find: () => window.solflare ?? null
    },
    {
      name: "Backpack",
      find: () => window.backpack ?? null
    }
  ];
  let selected = null;
  const listeners = /* @__PURE__ */ new Set();
  function usable(wallet) {
    return wallet.chains.includes(SOLANA_MAINNET) && CONNECT in wallet.features && SIGN in wallet.features;
  }
  function standardWallets() {
    if (typeof window === "undefined") return [];
    return getWallets().get().filter(usable);
  }
  function listWallets() {
    const out = standardWallets().map((wallet) => ({ name: wallet.name, icon: wallet.icon }));
    for (const legacy of LEGACY_PROVIDERS) {
      if (out.some((info) => info.name.toLowerCase() === legacy.name.toLowerCase())) continue;
      if (legacy.find()) out.push({ name: legacy.name, icon: "", legacy: true });
    }
    return out;
  }
  function onWalletsChange(listener) {
    listeners.add(listener);
    const registry = getWallets();
    const offs = [registry.on("register", listener), registry.on("unregister", listener)];
    return () => {
      listeners.delete(listener);
      for (const off of offs) off();
    };
  }
  function notify() {
    for (const listener of listeners) listener();
  }
  function isRejection(error) {
    const code = error?.code;
    if (code === 4001) return true;
    return /reject|cancel|denied|declined/i.test(String(error?.message ?? ""));
  }
  function toFailure(error) {
    if (error instanceof WalletError) return error;
    if (isRejection(error)) return new WalletError("rejected");
    return new WalletError("failed", String(error?.message ?? "").slice(0, 200));
  }
  function mainnetAccount(accounts) {
    return accounts.find((account) => account.chains.includes(SOLANA_MAINNET)) ?? accounts[0] ?? null;
  }
  function connected() {
    if (!selected) return null;
    if (selected.kind === "legacy") return { name: selected.name, icon: "", legacy: true, publicKey: selected.publicKey };
    return { name: selected.wallet.name, icon: selected.wallet.icon, publicKey: selected.account.address };
  }
  async function connect(name, options = {}) {
    const wallet = standardWallets().find((candidate) => candidate.name === name);
    if (wallet) {
      try {
        let account = options.silent ? mainnetAccount(wallet.accounts) : null;
        if (!account) {
          const feature = wallet.features[CONNECT];
          const result = await feature.connect(options.silent ? { silent: true } : void 0);
          account = mainnetAccount(result.accounts);
        }
        if (!account) {
          if (options.silent) return null;
          throw new WalletError("failed", "The wallet returned no account.");
        }
        if (selected?.kind === "standard") selected.off?.();
        const events = wallet.features[EVENTS];
        const off = events?.on("change", (properties) => {
          if (!properties.accounts || selected?.kind !== "standard" || selected.wallet !== wallet) return;
          const next = mainnetAccount(properties.accounts);
          if (next) selected.account = next;
          else selected = null;
          notify();
        });
        selected = { kind: "standard", wallet, account, off };
        notify();
        return connected();
      } catch (error) {
        if (options.silent) return null;
        throw toFailure(error);
      }
    }
    const legacy = LEGACY_PROVIDERS.find((candidate) => candidate.name.toLowerCase() === name.toLowerCase());
    const provider = legacy?.find();
    if (!legacy || !provider) throw new WalletError("no_wallet");
    try {
      let publicKey = provider.publicKey?.toString() ?? null;
      if (!publicKey) {
        const result = await provider.connect(options.silent ? { onlyIfTrusted: true } : void 0);
        publicKey = result.publicKey.toString();
      }
      selected = { kind: "legacy", name: legacy.name, provider, publicKey };
      notify();
      return connected();
    } catch (error) {
      if (options.silent) return null;
      throw toFailure(error);
    }
  }
  async function disconnect() {
    const current = selected;
    selected = null;
    notify();
    if (!current) return;
    try {
      if (current.kind === "standard") {
        current.off?.();
        const feature = current.wallet.features[DISCONNECT];
        await feature?.disconnect();
      } else await current.provider.disconnect();
    } catch {
    }
  }
  function fromBase64(text) {
    return Uint8Array.from(atob(text), (char) => char.charCodeAt(0));
  }
  function toBase64(bytes) {
    let binary = "";
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary);
  }
  const BASE58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  function base58(bytes) {
    let value = 0n;
    for (const byte of bytes) value = value << 8n | BigInt(byte);
    let out = "";
    for (; value > 0n; value /= 58n) out = BASE58[Number(value % 58n)] + out;
    for (const byte of bytes) {
      if (byte !== 0) break;
      out = "1" + out;
    }
    return out;
  }
  function firstSignature(bytes) {
    return base58(bytes.subarray(1, 65));
  }
  async function signTransaction(txBase64, legacy) {
    if (!selected) throw new WalletError("no_wallet");
    const bytes = fromBase64(txBase64);
    try {
      let signed;
      if (selected.kind === "standard") {
        const feature = selected.wallet.features[SIGN];
        const [output] = await feature.signTransaction({
          account: selected.account,
          transaction: bytes,
          chain: SOLANA_MAINNET
        });
        signed = output.signedTransaction;
      } else {
        if (!legacy) throw new WalletError("legacy_needs_signer");
        signed = legacy.serialize(await selected.provider.signTransaction(legacy.deserialize(bytes)));
      }
      return { signedTxBase64: toBase64(signed), signature: firstSignature(signed) };
    } catch (error) {
      throw toFailure(error);
    }
  }
  const LEGACY_SIGNER_KEY = "__soothiaLegacySigner";
  function legacySigner() {
    return window[LEGACY_SIGNER_KEY];
  }
  let lastReport = "";
  function report(force = false) {
    const message = { type: WALLET_STATUS, wallets: listWallets(), connected: connected() };
    const serialized = JSON.stringify(message);
    if (!force && serialized === lastReport) return;
    lastReport = serialized;
    window.postMessage(message, window.location.origin);
  }
  function failure(error) {
    if (error instanceof WalletError) {
      if (error.reason === "rejected" || error.reason === "legacy_needs_signer")
        return { ok: false, reason: error.reason };
      return { ok: false, reason: error.reason, message: error.message.slice(0, 200) };
    }
    return { ok: false, reason: "failed", message: String(error?.message ?? "").slice(0, 200) };
  }
  async function handle(request) {
    try {
      switch (request.method) {
        case "listWallets":
          return { ok: true, wallets: listWallets(), wallet: connected(), publicKey: connected()?.publicKey ?? null };
        case "connect": {
          if (!request.wallet) return { ok: false, reason: "no_wallet" };
          const result = await connect(request.wallet);
          return { ok: true, publicKey: result?.publicKey ?? null, wallet: result };
        }
        case "disconnect":
          await disconnect();
          return { ok: true, publicKey: null, wallet: null };
        case "getPublicKey": {
          const current = connected();
          if (current) return { ok: true, publicKey: current.publicKey, wallet: current };
          const preferred = request.wallet ?? listWallets()[0]?.name;
          if (!preferred) return { ok: true, publicKey: null, wallet: null };
          const result = await connect(preferred, { silent: true });
          return { ok: true, publicKey: result?.publicKey ?? null, wallet: result };
        }
        case "signTransaction": {
          if (typeof request.txBase64 !== "string") return { ok: false, reason: "failed", message: "no transaction" };
          const signed = await signTransaction(request.txBase64, legacySigner());
          return { ok: true, ...signed };
        }
        default:
          return null;
      }
    } catch (error) {
      return failure(error);
    }
  }
  if (window.top === window) {
    report(true);
    onWalletsChange(() => report());
    for (const delay of [500, 1500, 4e3]) setTimeout(() => report(), delay);
    window.addEventListener("message", (event) => {
      if (event.source !== window || event.origin !== window.location.origin) return;
      const data = event.data;
      if (data?.type === WALLET_REQUEST) {
        report(true);
        return;
      }
      if (data?.type !== WALLET_RPC_REQUEST) return;
      const request = data;
      if (typeof request.id !== "string" || typeof request.method !== "string") return;
      void handle(request).then((outcome) => {
        if (!outcome) return;
        const response = { type: WALLET_RPC_RESPONSE, id: request.id, ...outcome };
        window.postMessage(response, window.location.origin);
        report();
      });
    });
  }
})();
