(function() {
  "use strict";
  const WALLET_STATUS = "soothia:v1:wallet-status";
  const WALLET_REQUEST = "soothia:v1:wallet-request";
  const WALLET_RPC_REQUEST = "soothia:v1:wallet-rpc";
  const WALLET_RPC_RESPONSE = "soothia:v1:wallet-rpc-result";
  function phantom() {
    const w = window;
    if (w.phantom?.solana) return w.phantom.solana;
    return w.solana?.isPhantom ? w.solana : null;
  }
  function report() {
    const message = { type: WALLET_STATUS, phantom: phantom() !== null };
    window.postMessage(message, window.location.origin);
  }
  function isRejection(error) {
    return error?.code === 4001;
  }
  async function handle(request) {
    if (request.method !== "connect" && request.method !== "disconnect" && request.method !== "getPublicKey") {
      return null;
    }
    const provider = phantom();
    if (!provider) return { ok: false, reason: "no_wallet" };
    try {
      switch (request.method) {
        case "connect":
          return { ok: true, publicKey: (await provider.connect()).publicKey.toString() };
        case "disconnect":
          await provider.disconnect();
          return { ok: true, publicKey: null };
        case "getPublicKey": {
          if (provider.publicKey) return { ok: true, publicKey: provider.publicKey.toString() };
          try {
            return { ok: true, publicKey: (await provider.connect({ onlyIfTrusted: true })).publicKey.toString() };
          } catch {
            return { ok: true, publicKey: null };
          }
        }
      }
    } catch (error) {
      if (isRejection(error)) return { ok: false, reason: "rejected" };
      return { ok: false, reason: "failed", message: String(error?.message ?? "").slice(0, 200) };
    }
  }
  if (window.top === window) {
    report();
    for (const delay of [500, 1500, 4e3]) setTimeout(report, delay);
    window.addEventListener("message", (event) => {
      if (event.source !== window || event.origin !== window.location.origin) return;
      const data = event.data;
      if (data?.type === WALLET_REQUEST) {
        report();
        return;
      }
      if (data?.type !== WALLET_RPC_REQUEST) return;
      const request = data;
      if (typeof request.id !== "string" || typeof request.method !== "string") return;
      void handle(request).then((outcome) => {
        if (!outcome) return;
        const response = { type: WALLET_RPC_RESPONSE, id: request.id, ...outcome };
        window.postMessage(response, window.location.origin);
      });
    });
  }
})();
