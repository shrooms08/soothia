(function() {
  "use strict";
  const NAV_CHANGED = "soothia:v1:nav-changed";
  if (window.top === window) {
    for (const method of ["pushState", "replaceState"]) {
      const original = history[method];
      history[method] = function(...args) {
        const result = original.apply(this, args);
        try {
          window.postMessage({ type: NAV_CHANGED }, window.location.origin);
        } catch {
        }
        return result;
      };
    }
  }
})();
